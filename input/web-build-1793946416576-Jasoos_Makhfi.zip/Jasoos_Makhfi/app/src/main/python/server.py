import os
import json
import random
import sqlite3
import threading

from flask import (
    Flask,
    request,
    redirect,
    url_for,
    render_template_string
)

app = Flask(__name__)

DB = None
_server_started = False
_server_lock = threading.Lock()


# =========================================================
# قالب اصلی
# =========================================================

BASE_HTML = """
<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>جاسوس مخفی | خاوران سافت</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 15px;
    font-family: Tahoma, Arial, sans-serif;
    background: radial-gradient(circle at top, #263b61, #101827 65%);
    color: white;
    min-height: 100vh;
}

.container {
    max-width: 650px;
    margin: auto;
}

.header {
    text-align: center;
    padding: 22px 10px;
    background: linear-gradient(135deg,#243b61,#17243b);
    border: 1px solid #455a7b;
    border-radius: 22px;
    margin-bottom: 18px;
    box-shadow: 0 8px 25px #0005;
}

.header h1 {
    color: #ffd166;
    font-size: 27px;
    margin: 5px;
}

.header small {
    color: #cbd5e1;
}

.card {
    background: linear-gradient(145deg,#1e2d46,#17243a);
    border: 1px solid #394d6c;
    padding: 22px;
    border-radius: 20px;
    margin-bottom: 16px;
    box-shadow: 0 8px 20px #0003;
}

h2 {
    color: #ffd166;
    font-size: 21px;
}

h3 {
    color: #f8fafc;
}

input:not([type=checkbox]):not([type=radio]),
select,
textarea {
    width: 100%;
    padding: 15px;
    margin-top: 12px;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    font-size: 16px;
    font-family: Tahoma;
    background: #f8fafc;
    color: #172033;
}

textarea {
    min-height: 90px;
    resize: vertical;
}

button {
    width: 100%;
    padding: 16px;
    margin-top: 12px;
    border: none;
    border-radius: 13px;
    font-size: 16px;
    font-family: Tahoma;
    font-weight: bold;
    cursor: pointer;
    background: linear-gradient(135deg,#ffd166,#e6a52b);
    color: #172033;
    transition: .2s;
}

button:active {
    transform: scale(.97);
}

button.secondary {
    background: #334968;
    color: white;
}

button.success {
    background: linear-gradient(135deg,#20c997,#10966c);
    color: white;
}

button.danger {
    background: #d9485f;
    color: white;
}

button:disabled {
    opacity: .5;
    cursor: not-allowed;
}

a {
    text-decoration: none;
}

.center {
    text-align: center;
}

.menu {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}

.menu a {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 85px;
    padding: 12px;
    background: #304663;
    border: 1px solid #506989;
    border-radius: 15px;
    color: white;
    font-size: 16px;
    text-align: center;
}

.player {
    background: #304663;
    padding: 14px;
    border-radius: 12px;
    margin: 9px 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
}

.player a {
    color: #ff8999;
}

.big-name {
    font-size: clamp(34px, 10vw, 62px);
    font-weight: bold;
    color: #ffd166;
    text-align: center;
    padding: 25px 5px;
    overflow-wrap: anywhere;
    text-shadow: 0 3px 15px #0008;
}

.secret-card {
    background: linear-gradient(145deg,#263f63,#17263e);
    border: 2px solid #e6b84e;
    border-radius: 22px;
    padding: 25px 15px;
    margin: 20px 0;
    text-align: center;
    box-shadow: 0 10px 30px #0005;
}

.secret-card.closed {
    background: repeating-linear-gradient(
        135deg,
        #203653,
        #203653 12px,
        #294565 12px,
        #294565 24px
    );
    border: 3px dashed #ffd166;
    cursor: pointer;
    min-height: 220px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    user-select: none;
}

.lock-icon {
    font-size: 68px;
    margin: 8px;
}

.closed-title {
    font-size: 25px;
    color: #ffd166;
    font-weight: bold;
}

.closed-hint {
    font-size: 14px;
    color: #d5e1f1;
    margin-top: 12px;
}

.secret-word {
    font-size: clamp(35px, 10vw, 55px);
    font-weight: bold;
    color: #ffd166;
    padding: 25px 5px;
    overflow-wrap: anywhere;
}

.vote-card {
    background: linear-gradient(145deg,#263d5e,#1a2a43);
    border: 2px solid #526d91;
    border-radius: 16px;
    padding: 17px;
    margin: 12px 0;
    display: flex;
    align-items: center;
    gap: 12px;
}

.vote-card input {
    width: 25px;
    height: 25px;
    margin: 0;
    accent-color: #ffd166;
}

.vote-card span {
    flex: 1;
    font-size: 21px;
    font-weight: bold;
}

.notice {
    background: #304663;
    border-right: 4px solid #ffd166;
    padding: 15px;
    border-radius: 12px;
    line-height: 2;
    margin: 14px 0;
}

.small-text {
    color: #bdcce0;
    font-size: 13px;
    line-height: 2;
}

.progress {
    height: 9px;
    background: #34445d;
    border-radius: 20px;
    overflow: hidden;
    margin: 15px 0;
}

.progress div {
    height: 100%;
    background: #ffd166;
}

table {
    width: 100%;
    border-collapse: collapse;
}

td, th {
    padding: 13px 5px;
    border-bottom: 1px solid #405573;
    text-align: center;
}

.footer {
    text-align: center;
    color: #94a3b8;
    padding: 20px;
    font-size: 12px;
}

.select-player {
    display: flex;
    align-items: center;
    gap: 12px;
    background: #304663;
    padding: 14px;
    border-radius: 13px;
    margin: 9px 0;
    border: 1px solid #506989;
}

.select-player input {
    width: 24px;
    height: 24px;
    accent-color: #ffd166;
}

.select-player label {
    font-size: 18px;
    font-weight: bold;
    flex: 1;
    cursor: pointer;
}

.selected-count {
    color: #ffd166;
    font-weight: bold;
}

.question-box {
    background: linear-gradient(135deg,#3b3262,#263b61);
    border: 2px solid #a78bfa;
    padding: 24px 15px;
    border-radius: 18px;
    text-align: center;
    margin: 18px 0;
}

.question-box h2 {
    color: #e9d5ff;
}

.question-text {
    font-size: 22px;
    line-height: 2;
    font-weight: bold;
    color: white;
}

.hint-box {
    background: #174c47;
    border: 2px solid #20c997;
    padding: 15px;
    border-radius: 14px;
    margin-top: 15px;
    line-height: 2;
}

@media(max-width:380px) {
    body {
        padding: 8px;
    }

    .card {
        padding: 15px;
    }

    .menu a {
        font-size: 14px;
    }
}

</style>
</head>

<body>

<div class="container">

<div class="header">
    <h1>🕵️ جاسوس مخفی</h1>
    <small>ساخته شده توسط خاوران سافت</small>
</div>

{{ content|safe }}

<div class="footer">
    خاوران سافت | بازی گروهی جاسوس مخفی
</div>

</div>

<script>

let audioContext = null;

function playSound(type) {

    try {

        if (!audioContext) {
            audioContext = new (
                window.AudioContext ||
                window.webkitAudioContext
            )();
        }

        if (audioContext.state === "suspended") {
            audioContext.resume();
        }

        const oscillator = audioContext.createOscillator();
        const gain = audioContext.createGain();

        oscillator.connect(gain);
        gain.connect(audioContext.destination);

        const now = audioContext.currentTime;

        let frequency = 500;
        let duration = 0.12;

        if (type === "success") {
            frequency = 700;
            duration = 0.22;
        }

        if (type === "turn") {
            frequency = 600;
            duration = 0.3;
        }

        if (type === "win") {
            frequency = 850;
            duration = 0.5;
        }

        if (type === "error") {
            frequency = 180;
            duration = 0.25;
        }

        oscillator.frequency.setValueAtTime(frequency, now);
        oscillator.type = "sine";

        gain.gain.setValueAtTime(0.001, now);

        gain.gain.exponentialRampToValueAtTime(
            0.18, now + 0.02
        );

        gain.gain.exponentialRampToValueAtTime(
            0.001, now + duration
        );

        oscillator.start(now);
        oscillator.stop(now + duration);

    } catch(e) {}

}

document.querySelectorAll("button").forEach(btn => {

    btn.addEventListener("click", function() {
        playSound("click");
    });

});

</script>

</body>
</html>
"""


def page(content, **kwargs):

    return render_template_string(
        BASE_HTML,
        content=render_template_string(
            content,
            **kwargs
        )
    )


# =========================================================
# دیتابیس و مهاجرت
# =========================================================

DEFAULT_WORDS = [

    ("مدرسه", "مکان‌ها"),
    ("بیمارستان", "مکان‌ها"),
    ("فرودگاه", "مکان‌ها"),
    ("رستوران", "مکان‌ها"),
    ("بانک", "مکان‌ها"),
    ("کتابخانه", "مکان‌ها"),
    ("پارک", "مکان‌ها"),
    ("ورزشگاه", "مکان‌ها"),
    ("سینما", "مکان‌ها"),
    ("مسجد", "مکان‌ها"),

    ("دریا", "طبیعت"),
    ("کوه", "طبیعت"),
    ("جنگل", "طبیعت"),
    ("باران", "طبیعت"),
    ("برف", "طبیعت"),
    ("خورشید", "طبیعت"),
    ("ماه", "طبیعت"),
    ("رودخانه", "طبیعت"),

    ("سیب", "خوراکی"),
    ("پیتزا", "خوراکی"),
    ("هندوانه", "خوراکی"),
    ("بستنی", "خوراکی"),
    ("نان", "خوراکی"),
    ("برنج", "خوراکی"),
    ("خرما", "خوراکی"),
    ("پنیر", "خوراکی"),
    ("آب‌میوه", "خوراکی"),

    ("فوتبال", "ورزش"),
    ("شنا", "ورزش"),
    ("والیبال", "ورزش"),
    ("بسکتبال", "ورزش"),
    ("کشتی", "ورزش"),
    ("دوچرخه‌سواری", "ورزش"),

    ("هواپیما", "وسایل"),
    ("قطار", "وسایل"),
    ("موبایل", "وسایل"),
    ("دوچرخه", "وسایل"),
    ("تلویزیون", "وسایل"),
    ("یخچال", "وسایل"),
    ("ماشین", "وسایل"),
    ("کامپیوتر", "وسایل")
]


DEFAULT_QUESTIONS = [

    "معمولاً در چه مکانی با این موضوع روبه‌رو می‌شویم؟",
    "چه کسی بیشتر با این موضوع سروکار دارد؟",
    "اگر بخواهید بدون گفتن نام آن را توصیف کنید، چه می‌گویید؟",
    "مهم‌ترین ویژگی این موضوع چیست؟",
    "آیا این موضوع در زندگی روزمره کاربرد دارد؟",
    "این موضوع بیشتر برای تفریح است یا برای کار؟",
    "چه چیزی ممکن است در کنار این موضوع دیده شود؟",
    "آیا این موضوع در خانه هم پیدا می‌شود؟",
    "آیا کودکان هم با این موضوع آشنا هستند؟",
    "این موضوع بیشتر در شهر دیده می‌شود یا طبیعت؟",
    "اگر این موضوع نبود، چه چیزی تغییر می‌کرد؟",
    "چه فایده‌ای می‌توان برای آن بیان کرد؟",
    "آیا این موضوع به زمان یا فصل خاصی مربوط است؟",
    "چه رنگی را بیشتر با این موضوع مرتبط می‌دانید؟",
    "آیا این موضوع بزرگ است یا کوچک؟",
    "آیا این موضوع معمولاً ثابت است یا حرکت می‌کند؟",
    "چه شغلی ممکن است با این موضوع ارتباط داشته باشد؟",
    "آیا این موضوع به انسان، طبیعت یا وسایل مربوط است؟",
    "اگر بخواهید آن را به یک دوست معرفی کنید، چه می‌گویید؟",
    "چه چیزی باعث می‌شود این موضوع را بشناسیم؟",
    "آیا استفاده از این موضوع آسان است؟",
    "این موضوع بیشتر در داخل ساختمان است یا بیرون؟",
    "چه خاطره‌ای ممکن است با این موضوع داشته باشید؟",
    "آیا این موضوع به سلامتی ارتباط دارد؟",
    "آیا این موضوع معمولاً گران است یا ارزان؟",
    "آیا می‌توان آن را با دست لمس کرد؟",
    "چه چیزی ممکن است جایگزین آن شود؟",
    "آیا این موضوع بیشتر برای یک نفر است یا چند نفر؟",
    "چه زمانی بیشتر به آن نیاز پیدا می‌کنیم؟",
    "اگر آن را در یک جمله توصیف کنید، چه می‌گویید؟",
    "آیا این موضوع در گذشته هم وجود داشته است؟",
    "چه چیزی آن را از موارد مشابه متمایز می‌کند؟",
    "آیا این موضوع به سفر و جابه‌جایی ارتباط دارد؟",
    "آیا این موضوع به خوراکی‌ها مربوط است؟",
    "اگر آن را در یک فیلم ببینید، چه نقشی دارد؟"
]


def connect_db():

    if not DB:
        raise RuntimeError("مسیر دیتابیس تنظیم نشده است.")

    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row

    return conn


def init_db():

    with connect_db() as conn:

        conn.execute("""
            CREATE TABLE IF NOT EXISTS players (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                score INTEGER DEFAULT 0
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS words (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word TEXT NOT NULL,
                category TEXT NOT NULL
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                question TEXT NOT NULL UNIQUE
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS game (
                id INTEGER PRIMARY KEY,
                phase TEXT DEFAULT 'idle',
                current_index INTEGER DEFAULT 0,
                word TEXT DEFAULT '',
                spy_ids TEXT DEFAULT '[]',
                votes TEXT DEFAULT '{}',
                accused_id INTEGER DEFAULT 0,
                winner TEXT DEFAULT '',
                scored INTEGER DEFAULT 0,
                selected_players TEXT DEFAULT '[]',
                spy_hint TEXT DEFAULT '',
                discussion_question TEXT DEFAULT '',
                card_open INTEGER DEFAULT 0
            )
        """)

        # مهاجرت دیتابیس قدیمی
        # ستون‌های قبلی حذف نمی‌شوند تا اطلاعات دیتابیس حفظ شود.

        columns = [
            row["name"]
            for row in conn.execute(
                "PRAGMA table_info(words)"
            ).fetchall()
        ]

        if "spy_hint" not in columns:
            conn.execute(
                "ALTER TABLE words ADD COLUMN spy_hint TEXT DEFAULT ''"
            )

        game_columns = [
            row["name"]
            for row in conn.execute(
                "PRAGMA table_info(game)"
            ).fetchall()
        ]

        migrations = {
            "scored": "INTEGER DEFAULT 0",
            "selected_players": "TEXT DEFAULT '[]'",
            "spy_hint": "TEXT DEFAULT ''",
            "discussion_question": "TEXT DEFAULT ''",
            "card_open": "INTEGER DEFAULT 0"
        }

        for name, definition in migrations.items():

            if name not in game_columns:

                conn.execute(
                    f"ALTER TABLE game ADD COLUMN {name} {definition}"
                )

        conn.execute("""
            INSERT OR IGNORE INTO game (id, phase)
            VALUES (1, 'idle')
        """)

        # افزودن کلمات اولیه فقط در صورت خالی بودن بانک کلمات

        word_count = conn.execute(
            "SELECT COUNT(*) FROM words"
        ).fetchone()[0]

        if word_count == 0:

            conn.executemany(
                """
                INSERT INTO words (word, category)
                VALUES (?, ?)
                """,
                DEFAULT_WORDS
            )

        # افزودن سؤال‌های اولیه بدون تکرار

        conn.executemany(
            """
            INSERT OR IGNORE INTO questions (question)
            VALUES (?)
            """,
            [(q,) for q in DEFAULT_QUESTIONS]
        )


# =========================================================
# توابع کمکی
# =========================================================

def get_game():

    with connect_db() as conn:

        return conn.execute(
            "SELECT * FROM game WHERE id=1"
        ).fetchone()


def update_game(**kwargs):

    if not kwargs:
        return

    columns = []
    values = []

    for key, value in kwargs.items():

        columns.append(key + "=?")
        values.append(value)

    values.append(1)

    query = (
        "UPDATE game SET "
        + ", ".join(columns)
        + " WHERE id=?"
    )

    with connect_db() as conn:
        conn.execute(query, values)


def get_players():

    with connect_db() as conn:

        return conn.execute(
            "SELECT * FROM players ORDER BY id"
        ).fetchall()


def get_round_players(game=None):

    game = game or get_game()

    try:
        ids = json.loads(game["selected_players"] or "[]")
    except Exception:
        ids = []

    all_players = get_players()

    if not ids:
        return all_players

    by_id = {
        p["id"]: p
        for p in all_players
    }

    return [
        by_id[i]
        for i in ids
        if i in by_id
    ]


def reset_round():

    update_game(
        phase="idle",
        current_index=0,
        word="",
        spy_ids="[]",
        votes="{}",
        accused_id=0,
        winner="",
        scored=0,
        selected_players="[]",
        spy_hint="",
        discussion_question="",
        card_open=0
    )


def finish_game(winner):

    game = get_game()

    if game["scored"]:
        return

    spies = json.loads(game["spy_ids"])
    players = get_round_players(game)

    with connect_db() as conn:

        for player in players:

            if winner == "spies" and player["id"] in spies:

                conn.execute(
                    "UPDATE players SET score=score+2 WHERE id=?",
                    (player["id"],)
                )

            elif winner == "citizens" and player["id"] not in spies:

                conn.execute(
                    "UPDATE players SET score=score+1 WHERE id=?",
                    (player["id"],)
                )

        conn.execute("""
            UPDATE game
            SET phase='finished',
                winner=?,
                scored=1,
                card_open=0
            WHERE id=1
        """, (winner,))


def get_questions():

    with connect_db() as conn:

        return conn.execute(
            "SELECT * FROM questions ORDER BY id"
        ).fetchall()


# =========================================================
# صفحه اصلی
# =========================================================

@app.route("/", methods=["GET", "POST"])
def index():

    all_players = get_players()
    game = get_game()

    if request.method == "POST":

        if game["phase"] not in ["idle", "finished"]:
            return redirect(url_for("continue_game"))

        chosen = request.form.getlist("player_ids")

        valid_ids = {
            str(p["id"])
            for p in all_players
        }

        chosen = [
            int(x)
            for x in chosen
            if x in valid_ids
        ]

        chosen = list(dict.fromkeys(chosen))

        if len(chosen) < 3:

            return page("""
            <div class="card center">
                <h2>⚠️ تعداد بازیکنان کافی نیست</h2>
                <p>برای شروع حداقل ۳ بازیکن انتخاب کنید.</p>
                <a href="{{ url_for('index') }}">
                    <button>بازگشت</button>
                </a>
            </div>
            """)

        if len(chosen) > 12:
            return redirect(url_for("index"))

        update_game(
            selected_players=json.dumps(chosen)
        )

        return redirect(url_for("start"))

    saved_ids = []

    try:
        saved_ids = [
            int(x)
            for x in json.loads(game["selected_players"] or "[]")
        ]
    except Exception:
        pass

    if not saved_ids:
        saved_ids = [
            p["id"]
            for p in all_players
        ]

    content = """

    <div class="card center">

        <h2>🎮 به بازی جاسوس مخفی خوش آمدید</h2>

        <div class="notice">

            بازیکنان شرکت‌کننده در این دور را انتخاب کنید.

            <br>

            می‌توانید هر دور ترکیب بازیکنان را تغییر دهید.

            <br>

            <span class="selected-count" id="selectedCount">
                {{ selected_ids|length }} نفر انتخاب شده‌اند
            </span>

        </div>

        {% if all_players|length < 3 %}

            <p>برای شروع حداقل ۳ بازیکن ثبت کنید.</p>

        {% endif %}

        <form method="post">

            {% for p in all_players %}

            <div class="select-player">

                <input
                    type="checkbox"
                    name="player_ids"
                    value="{{ p.id }}"
                    id="player{{ p.id }}"
                    {% if p.id in selected_ids %}checked{% endif %}
                >

                <label for="player{{ p.id }}">
                    {{ p.name }}
                </label>

                <span class="small-text">
                    {{ p.score }} امتیاز
                </span>

            </div>

            {% endfor %}

            <button class="success"
                {% if all_players|length < 3 %}disabled{% endif %}>
                تأیید بازیکنان و ادامه
            </button>

        </form>

    </div>

    <div class="card">

        <div class="menu">

            <a href="{{ url_for('players_page') }}">
                👥 مدیریت بازیکنان
            </a>

            <a href="{{ url_for('words_page') }}">
                📚 مدیریت کلمات
            </a>

            <a href="{{ url_for('questions_page') }}">
                ❓ مدیریت سؤال‌ها
            </a>

            <a href="{{ url_for('scores_page') }}">
                🏆 جدول امتیازات
            </a>

        </div>

    </div>

    {% if game.phase not in ['idle','finished'] %}

    <div class="card center">

        <h3>بازی قبلی هنوز تمام نشده است</h3>

        <a href="{{ url_for('continue_game') }}">
            <button class="success">ادامه بازی جاری</button>
        </a>

    </div>

    {% elif game.phase == 'finished' %}

    <div class="card center">

        <a href="{{ url_for('final_result') }}">
            <button class="secondary">مشاهده نتیجه دور قبلی</button>
        </a>

    </div>

    {% endif %}

    <script>

    (function(){

        const boxes = document.querySelectorAll(
            'input[name="player_ids"]'
        );

        const output = document.getElementById(
            'selectedCount'
        );

        function updateCount(){

            const count = [
                ...boxes
            ].filter(x => x.checked).length;

            output.textContent = count + ' نفر انتخاب شده‌اند';

        }

        boxes.forEach(box => {
            box.addEventListener("change", updateCount);
        });

    })();

    </script>

    """

    return page(
        content,
        all_players=all_players,
        selected_ids=saved_ids,
        game=game
    )


@app.route("/continue")
def continue_game():

    game = get_game()

    routes = {
        "reveal": "reveal",
        "discussion": "discussion",
        "vote": "vote",
        "result": "result",
        "guess": "guess",
        "finished": "final_result"
    }

    return redirect(
        url_for(
            routes.get(game["phase"], "index")
        )
    )


# =========================================================
# مدیریت بازیکنان
# =========================================================

@app.route("/players")
def players_page():

    players = get_players()
    game = get_game()

    content = """

    <div class="card">

        <h2>👥 مدیریت بازیکنان</h2>

        <form method="post"
              action="{{ url_for('add_player') }}">

            <input
                name="name"
                placeholder="نام بازیکن را وارد کنید"
                required
                maxlength="40"
            >

            <button class="success">
                افزودن بازیکن
            </button>

        </form>

        <h3>فهرست بازیکنان</h3>

        {% for p in players %}

        <div class="player">

            <strong>{{ p.name }}</strong>

            {% if game.phase in ['idle','finished'] %}

            <a href="{{ url_for('remove_player', player_id=p.id) }}"
               onclick="return confirm('این بازیکن حذف شود؟')">
               حذف
            </a>

            {% endif %}

        </div>

        {% endfor %}

    </div>

    <a href="{{ url_for('index') }}">
        <button class="secondary">
            بازگشت به صفحه اصلی
        </button>
    </a>

    """

    return page(
        content,
        players=players,
        game=game
    )


@app.route("/add-player", methods=["POST"])
def add_player():

    name = request.form.get(
        "name", ""
    ).strip()

    game = get_game()

    if (
        name
        and game["phase"] in ["idle", "finished"]
        and len(get_players()) < 30
    ):

        with connect_db() as conn:

            conn.execute(
                "INSERT INTO players(name) VALUES(?)",
                (name,)
            )

    return redirect(url_for("players_page"))


@app.route("/remove-player/<int:player_id>")
def remove_player(player_id):

    game = get_game()

    if game["phase"] in ["idle", "finished"]:

        with connect_db() as conn:

            conn.execute(
                "DELETE FROM players WHERE id=?",
                (player_id,)
            )

        try:

            ids = json.loads(
                game["selected_players"] or "[]"
            )

            ids = [
                x for x in ids
                if int(x) != player_id
            ]

            update_game(
                selected_players=json.dumps(ids)
            )

        except Exception:
            pass

    return redirect(url_for("players_page"))


# =========================================================
# شروع بازی
# =========================================================

@app.route("/start", methods=["GET", "POST"])
def start():

    game = get_game()

    all_players = get_players()

    if game["phase"] not in ["idle", "finished"]:
        return redirect(url_for("continue_game"))

    try:

        selected_ids = [
            int(x)
            for x in json.loads(
                game["selected_players"] or "[]"
            )
        ]

    except Exception:
        selected_ids = []

    if not selected_ids:

        selected_ids = [
            p["id"]
            for p in all_players
        ]

    by_id = {
        p["id"]: p
        for p in all_players
    }

    players = [
        by_id[i]
        for i in selected_ids
        if i in by_id
    ]

    if len(players) < 3:

        return page("""
        <div class="card center">

            <h2>⚠️ حداقل ۳ بازیکن انتخاب کنید</h2>

            <a href="{{ url_for('index') }}">
                <button>بازگشت به انتخاب بازیکنان</button>
            </a>

        </div>
        """)

    if len(players) > 12:
        return redirect(url_for("index"))

    if request.method == "POST":

        category = request.form.get(
            "category", "همه"
        )

        with connect_db() as conn:

            if category == "همه":

                words = conn.execute(
                    "SELECT * FROM words"
                ).fetchall()

            else:

                words = conn.execute(
                    "SELECT * FROM words WHERE category=?",
                    (category,)
                ).fetchall()

        if not words:
            return redirect(url_for("words_page"))

        selected = random.choice(words)

        player_ids = [
            p["id"]
            for p in players
        ]

        spy_count = (
            1 if len(players) <= 6 else 2
        )

        spies = random.sample(
            player_ids,
            spy_count
        )

        questions = get_questions()

        if not questions:

            return page("""
            <div class="card center">
                <h2>سؤالی در بانک سؤال وجود ندارد.</h2>
                <a href="{{ url_for('questions_page') }}">
                    <button>مدیریت سؤال‌ها</button>
                </a>
            </div>
            """)

        selected_question = random.choice(questions)

        update_game(
            phase="reveal",
            current_index=0,
            word=selected["word"],
            spy_hint="",
            spy_ids=json.dumps(spies),
            votes="{}",
            accused_id=0,
            winner="",
            scored=0,
            selected_players=json.dumps(player_ids),
            discussion_question=selected_question["question"],
            card_open=0
        )

        return redirect(url_for("reveal"))

    with connect_db() as conn:

        categories = conn.execute(
            """
            SELECT DISTINCT category
            FROM words
            ORDER BY category
            """
        ).fetchall()

    content = """

    <div class="card">

        <h2>🎮 تنظیمات بازی</h2>

        <div class="notice">

            تعداد بازیکنان انتخاب‌شده:

            <strong>{{ players|length }}</strong>

            <br>

            ۳ تا ۶ نفر: یک جاسوس

            <br>

            ۷ تا ۱۲ نفر: دو جاسوس

        </div>

        <form method="post">

            <label>دسته‌بندی کلمات</label>

            <select name="category">

                <option value="همه">
                    همه دسته‌ها
                </option>

                {% for c in categories %}

                <option value="{{ c.category }}">
                    {{ c.category }}
                </option>

                {% endfor %}

            </select>

            <button class="success">
                شروع بازی
            </button>

        </form>

        <a href="{{ url_for('index') }}">
            <button class="secondary">
                بازگشت و تغییر بازیکنان
            </button>
        </a>

    </div>

    """

    return page(
        content,
        players=players,
        categories=categories
    )


# =========================================================
# کارت محرمانه
# =========================================================

@app.route("/reveal")
def reveal():

    game = get_game()

    players = get_round_players(game)

    if game["phase"] != "reveal":
        return redirect(url_for("index"))

    index = game["current_index"]

    if index >= len(players):

        update_game(
            phase="discussion",
            current_index=0,
            card_open=0
        )

        return redirect(url_for("discussion"))

    player = players[index]

    card_open = bool(game["card_open"])

    secret_word = ""
    is_spy = False

    if card_open:

        spies = json.loads(game["spy_ids"])
        is_spy = player["id"] in spies

        if not is_spy:
            secret_word = game["word"]

    content = """

    <div class="card center">

        <h2>🔐 کارت محرمانه</h2>

        <div class="notice">

            گوشی را فقط به بازیکنی بدهید
            که نامش در پایین نوشته شده است.

        </div>

        <div class="big-name">
            {{ player.name }}
        </div>

        <div class="small-text">
            بازیکن شماره {{ index + 1 }}
            از {{ total }}
        </div>

        {% if not card_open %}

            <form method="post"
                  action="{{ url_for('open_card') }}">

                <button class="secret-card closed"
                        type="submit">

                    <span class="lock-icon">🔒</span>

                    <span class="closed-title">
                        کارت شما بسته است
                    </span>

                    <span class="closed-hint">
                        برای مشاهده کارت لمس کنید
                    </span>

                </button>

            </form>

        {% else %}

            <div class="secret-card">

                {% if is_spy %}

                    <h3>🕵️ شما جاسوس هستید!</h3>

                    <div class="secret-word">
                        ؟؟؟؟؟
                    </div>

                    <p>
                        کلمه اصلی را نمی‌دانید.
                        تلاش کنید جاسوس بودن خود را مخفی کنید.
                    </p>

                {% else %}

                    <h3>کلمه محرمانه شما</h3>

                    <div class="secret-word">
                        {{ secret_word }}
                    </div>

                    <p>
                        این کلمه را به هیچ‌کس نشان ندهید.
                    </p>

                {% endif %}

            </div>

            <form method="post"
                  action="{{ url_for('next_player') }}">

                <button class="success">
                    مخفی کردن کارت و ادامه
                </button>

            </form>

            <div class="notice">
                کارت را مخفی کنید و گوشی را به نفر بعد بدهید.
            </div>

        {% endif %}

    </div>

    """

    return page(
        content,
        player=player,
        index=index,
        total=len(players),
        card_open=card_open,
        is_spy=is_spy,
        secret_word=secret_word
    )


@app.route("/open-card", methods=["POST"])
def open_card():

    game = get_game()

    if game["phase"] != "reveal":
        return redirect(url_for("index"))

    update_game(card_open=1)

    return redirect(url_for("reveal"))


@app.route("/next", methods=["POST"])
def next_player():

    game = get_game()

    if game["phase"] != "reveal":
        return redirect(url_for("index"))

    if not game["card_open"]:
        return redirect(url_for("reveal"))

    players = get_round_players(game)

    next_index = game["current_index"] + 1

    if next_index >= len(players):

        update_game(
            phase="discussion",
            current_index=0,
            card_open=0
        )

        return redirect(url_for("discussion"))

    update_game(
        current_index=next_index,
        card_open=0
    )

    return redirect(url_for("reveal"))


# =========================================================
# مرحله گفت‌وگو
# =========================================================

@app.route("/discussion", methods=["GET", "POST"])
def discussion():

    game = get_game()

    if game["phase"] != "discussion":
        return redirect(url_for("continue_game"))

    if request.method == "POST":

        update_game(
            phase="vote",
            current_index=0
        )

        return redirect(url_for("vote"))

    content = """

    <div class="card center">

        <h2>💬 مرحله گفت‌وگو</h2>

        <div class="notice">

            اکنون همه بازیکنان کارت خود را دیده‌اند.

            <br>

            به سؤال زیر پاسخ دهید و درباره آن گفت‌وگو کنید.

        </div>

        <div class="question-box">

            <h2>❓ سؤال این دور</h2>

            <div class="question-text">
                {{ question }}
            </div>

        </div>

        <div class="notice">

            <strong>قوانین گفت‌وگو:</strong>

            <br>

            ۱. هر بازیکن به سؤال پاسخ بدهد.

            <br>

            ۲. نام کلمه مخفی را مستقیماً نگویید.

            <br>

            ۳. پاسخ‌ها باید طبیعی و کوتاه باشند.

            <br>

            ۴. به پاسخ‌های مشکوک دقت کنید.

        </div>

        <form method="post">

            <button class="success">
                پایان گفت‌وگو و شروع رأی‌گیری
            </button>

        </form>

    </div>

    """

    return page(
        content,
        question=game["discussion_question"]
    )


# =========================================================
# رأی‌گیری مخفی
# =========================================================

@app.route("/vote", methods=["GET", "POST"])
def vote():

    game = get_game()

    players = get_round_players(game)

    if game["phase"] != "vote":
        return redirect(url_for("index"))

    index = game["current_index"]

    if index >= len(players):
        return redirect(url_for("result"))

    voter = players[index]

    votes = json.loads(game["votes"])

    if request.method == "POST":

        target_id = request.form.get(
            "target_id", type=int
        )

        valid_ids = [
            p["id"]
            for p in players
            if p["id"] != voter["id"]
        ]

        if (
            target_id not in valid_ids
            or str(voter["id"]) in votes
        ):

            return redirect(url_for("vote"))

        votes[str(voter["id"])] = target_id

        next_index = index + 1

        if next_index >= len(players):

            update_game(
                votes=json.dumps(votes),
                current_index=0,
                phase="result"
            )

            return redirect(url_for("result"))

        update_game(
            votes=json.dumps(votes),
            current_index=next_index
        )

        return redirect(url_for("vote"))

    remaining_players = [
        p for p in players
        if p["id"] != voter["id"]
    ]

    content = """

    <div class="card center">

        <h2>🗳️ رأی‌گیری مخفیانه</h2>

        <div class="notice">
            نوبت رأی دادن:
        </div>

        <div class="big-name">
            {{ voter.name }}
        </div>

        <div class="progress">
            <div style="width:{{ progress }}%"></div>
        </div>

        <p class="small-text">
            بازیکن شماره {{ index + 1 }}
            از {{ total }}
        </p>

        <div class="notice">
            به نظر شما چه کسی جاسوس است؟
            <br>
            فقط یک نفر را انتخاب کنید.
        </div>

        <form method="post">

            {% for p in remaining_players %}

            <label class="vote-card">

                <input
                    type="radio"
                    name="target_id"
                    value="{{ p.id }}"
                    required
                >

                <span>{{ p.name }}</span>

            </label>

            {% endfor %}

            <button class="success">
                ثبت رأی محرمانه
            </button>

        </form>

        <p class="small-text">
            رأی شما مخفی می‌ماند.
        </p>

    </div>

    """

    return page(
        content,
        voter=voter,
        remaining_players=remaining_players,
        index=index,
        total=len(players),
        progress=int(index / len(players) * 100)
    )


# =========================================================
# نتیجه رأی‌گیری
# =========================================================

@app.route("/result")
def result():

    game = get_game()

    players = get_round_players(game)

    if game["phase"] != "result":
        return redirect(url_for("index"))

    votes = json.loads(game["votes"])

    if len(votes) != len(players):
        return redirect(url_for("vote"))

    vote_counts = {}

    for target in votes.values():

        target = int(target)

        vote_counts[target] = (
            vote_counts.get(target, 0) + 1
        )

    max_votes = max(vote_counts.values())

    candidates = [
        player_id
        for player_id, count in vote_counts.items()
        if count == max_votes
    ]

    accused_id = random.choice(candidates)

    update_game(
        accused_id=accused_id
    )

    spies = json.loads(game["spy_ids"])

    accused = next(
        (
            p for p in players
            if p["id"] == accused_id
        ),
        None
    )

    if accused_id in spies:

        content = """

        <div class="card center">

            <h2>🎯 جاسوس شناسایی شد!</h2>

            <div class="secret-card">

                <div class="big-name">
                    {{ accused.name }}
                </div>

                <h3>این بازیکن جاسوس بود!</h3>

            </div>

            <div class="notice">
                جاسوس‌ها هنوز یک فرصت دارند
                تا کلمه اصلی را حدس بزنند.
            </div>

            <a href="{{ url_for('guess') }}">
                <button class="success">
                    رفتن به مرحله حدس کلمه
                </button>
            </a>

        </div>

        """

        return page(
            content,
            accused=accused
        )

    finish_game("spies")

    return redirect(
        url_for("final_result")
    )


# =========================================================
# حدس کلمه توسط جاسوس
# =========================================================

@app.route("/guess", methods=["GET", "POST"])
def guess():

    game = get_game()

    if game["phase"] != "result":
        return redirect(url_for("index"))

    spies = json.loads(game["spy_ids"])

    players = get_round_players(game)

    spy_names = [
        p["name"]
        for p in players
        if p["id"] in spies
    ]

    if request.method == "POST":

        answer = request.form.get(
            "answer", ""
        ).strip()

        if answer == game["word"]:

            finish_game("spies")

        else:

            finish_game("citizens")

        return redirect(
            url_for("final_result")
        )

    content = """

    <div class="card center">

        <h2>🕵️ فرصت آخر جاسوس</h2>

        <div class="secret-card">

            <div class="big-name">
                {{ spy_names|join('، ') }}
            </div>

            <h3>آیا می‌توانید کلمه را حدس بزنید؟</h3>

        </div>

        <div class="notice">
            جاسوس‌ها باید کلمه اصلی را حدس بزنند.
        </div>

        <form method="post">

            <input
                name="answer"
                placeholder="کلمه مورد نظر را وارد کنید"
                required
                autocomplete="off"
            >

            <button class="success">
                ثبت حدس
            </button>

        </form>

    </div>

    """

    return page(
        content,
        spy_names=spy_names
    )


# =========================================================
# نتیجه نهایی
# =========================================================

@app.route("/final-result")
def final_result():

    game = get_game()

    players = get_round_players(game)

    if game["phase"] != "finished":
        return redirect(url_for("index"))

    spies = json.loads(game["spy_ids"])

    spy_names = [
        p["name"]
        for p in players
        if p["id"] in spies
    ]

    if game["winner"] == "spies":

        winner_text = "جاسوس‌ها برنده شدند!"
        winner_icon = "🕵️"

    else:

        winner_text = "شهروندان برنده شدند!"
        winner_icon = "🏆"

    content = """

    <div class="card center">

        <h2>نتیجه نهایی بازی</h2>

        <div class="secret-card">

            <div class="secret-word">
                {{ winner_icon }}
            </div>

            <h2>{{ winner_text }}</h2>

        </div>

        <div class="notice">

            کلمه اصلی:

            <div class="secret-word">
                {{ game.word }}
            </div>

            سؤال گفت‌وگو:

            <p>{{ game.discussion_question }}</p>

            جاسوس‌ها:

            <h3>{{ spy_names|join('، ') }}</h3>

        </div>

        <a href="{{ url_for('scores_page') }}">
            <button class="success">
                مشاهده جدول امتیازات
            </button>
        </a>

        <a href="{{ url_for('next_round') }}">
            <button>
                شروع دور جدید و انتخاب بازیکنان
            </button>
        </a>

        <a href="{{ url_for('index') }}">
            <button class="secondary">
                صفحه اصلی
            </button>
        </a>

    </div>

    """

    return page(
        content,
        game=game,
        winner_text=winner_text,
        winner_icon=winner_icon,
        spy_names=spy_names
    )


# =========================================================
# دور جدید
# =========================================================

@app.route("/next-round")
def next_round():

    reset_round()

    return redirect(url_for("index"))


# =========================================================
# مدیریت کلمات
# =========================================================

@app.route("/words", methods=["GET", "POST"])
def words_page():

    if request.method == "POST":

        word = request.form.get(
            "word", ""
        ).strip()

        category = request.form.get(
            "category", ""
        ).strip()

        if word and category:

            with connect_db() as conn:

                conn.execute(
                    """
                    INSERT INTO words
                    (word, category)
                    VALUES (?, ?)
                    """,
                    (word, category)
                )

        return redirect(url_for("words_page"))

    with connect_db() as conn:

        words = conn.execute(
            """
            SELECT * FROM words
            ORDER BY category, word
            """
        ).fetchall()

    content = """

    <div class="card">

        <h2>📚 مدیریت کلمات</h2>

        <form method="post">

            <input
                name="word"
                placeholder="کلمه مخفی"
                required
                maxlength="100"
            >

            <input
                name="category"
                placeholder="دسته‌بندی کلمه"
                required
                maxlength="60"
            >

            <div class="notice">

                مثال:

                <br>

                کلمه: هواپیما

                <br>

                دسته‌بندی: وسایل نقلیه

            </div>

            <button class="success">
                افزودن کلمه
            </button>

        </form>

    </div>

    <div class="card">

        <h2>فهرست کلمات</h2>

        {% for w in words %}

        <div class="player" style="display:block">

            <strong>{{ w.word }}</strong>

            <br>

            <small>{{ w.category }}</small>

            <div style="text-align:left">

                <a href="{{ url_for('delete_word', word_id=w.id) }}"
                   onclick="return confirm('این کلمه حذف شود؟')">
                   حذف
                </a>

            </div>

        </div>

        {% endfor %}

    </div>

    <a href="{{ url_for('index') }}">
        <button class="secondary">بازگشت</button>
    </a>

    """

    return page(
        content,
        words=words
    )


@app.route("/delete-word/<int:word_id>")
def delete_word(word_id):

    with connect_db() as conn:

        conn.execute(
            "DELETE FROM words WHERE id=?",
            (word_id,)
        )

    return redirect(url_for("words_page"))


# =========================================================
# مدیریت سؤال‌های گفت‌وگو
# =========================================================

@app.route("/questions", methods=["GET", "POST"])
def questions_page():

    if request.method == "POST":

        question = request.form.get(
            "question", ""
        ).strip()

        if question:

            with connect_db() as conn:

                conn.execute(
                    """
                    INSERT OR IGNORE INTO questions(question)
                    VALUES(?)
                    """,
                    (question,)
                )

        return redirect(url_for("questions_page"))

    questions = get_questions()

    content = """

    <div class="card">

        <h2>❓ مدیریت سؤال‌های گفت‌وگو</h2>

        <div class="notice">

            در هر دور یک سؤال از این فهرست
            به‌صورت تصادفی انتخاب می‌شود.

        </div>

        <form method="post">

            <textarea
                name="question"
                placeholder="سؤال جدید را وارد کنید"
                required
                maxlength="300"
            ></textarea>

            <button class="success">
                افزودن سؤال
            </button>

        </form>

    </div>

    <div class="card">

        <h2>فهرست سؤال‌ها ({{ questions|length }})</h2>

        {% for q in questions %}

        <div class="player">

            <span>{{ loop.index }}. {{ q.question }}</span>

            <a href="{{ url_for('delete_question', question_id=q.id) }}"
               onclick="return confirm('این سؤال حذف شود؟')">
               حذف
            </a>

        </div>

        {% endfor %}

    </div>

    <a href="{{ url_for('index') }}">
        <button class="secondary">بازگشت</button>
    </a>

    """

    return page(
        content,
        questions=questions
    )


@app.route("/delete-question/<int:question_id>")
def delete_question(question_id):

    with connect_db() as conn:

        conn.execute(
            "DELETE FROM questions WHERE id=?",
            (question_id,)
        )

    return redirect(url_for("questions_page"))


# =========================================================
# جدول امتیازات
# =========================================================

@app.route("/scores", methods=["GET", "POST"])
def scores_page():

    if request.method == "POST":

        confirm = request.form.get("confirm")

        if confirm == "yes":

            with connect_db() as conn:

                conn.execute(
                    "UPDATE players SET score=0"
                )

        return redirect(
            url_for("scores_page")
        )

    with connect_db() as conn:

        players = conn.execute(
            """
            SELECT * FROM players
            ORDER BY score DESC, name
            """
        ).fetchall()

    content = """

    <div class="card">

        <h2>🏆 جدول امتیازات</h2>

        <table>

            <tr>
                <th>رتبه</th>
                <th>نام بازیکن</th>
                <th>امتیاز</th>
            </tr>

            {% for p in players %}

            <tr>

                <td>{{ loop.index }}</td>

                <td>{{ p.name }}</td>

                <td>{{ p.score }}</td>

            </tr>

            {% endfor %}

        </table>

        <form method="post"
              onsubmit="return confirm('همه امتیازات پاک شوند؟')">

            <input
                type="hidden"
                name="confirm"
                value="yes"
            >

            <button class="danger">
                پاک کردن تمام امتیازات
            </button>

        </form>

    </div>

    <a href="{{ url_for('index') }}">
        <button class="secondary">بازگشت</button>
    </a>

    """

    return page(
        content,
        players=players
    )


# =========================================================
# راه‌اندازی سرور اندروید
# =========================================================

def start_server(data_dir):

    global DB, _server_started

    with _server_lock:

        if _server_started:
            return

        os.makedirs(
            data_dir,
            exist_ok=True
        )

        DB = os.path.join(
            data_dir,
            "game.db"
        )

        init_db()

        _server_started = True

        def run_flask():

            app.run(
                host="127.0.0.1",
                port=5003,
                debug=False,
                use_reloader=False,
                threaded=True
            )

        thread = threading.Thread(
            target=run_flask,
            daemon=True
        )

        thread.start()


# =========================================================
# اجرای ویندوز
# =========================================================

if __name__ == "__main__":

    data_dir = os.path.join(
        os.path.dirname(
            os.path.abspath(__file__)
        ),
        "data"
    )

    os.makedirs(
        data_dir,
        exist_ok=True
    )

    DB = os.path.join(
        data_dir,
        "game.db"
    )

    init_db()

    print("=" * 45)
    print("      جاسوس مخفی - خاوران سافت")
    print("=" * 45)
    print("آدرس بازی: http://127.0.0.1:5003")
    print("برای توقف: Ctrl + C")
    print("=" * 45)

    app.run(
        host="127.0.0.1",
        port=5003,
        debug=False,
        use_reloader=False,
        threaded=True
    )