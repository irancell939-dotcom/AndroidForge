# -*- coding: utf-8 -*-
from flask import Flask, request, jsonify, render_template_string
import os, random
app=Flask(__name__)
app.secret_key=os.environ.get("SECRET_KEY","basket-game-secret")
STATE={"players":[],"items":[],"turn":0,"started":False,"seen":[],"log":[]}
HTML=r"""
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>سبد گمشده</title><style>
*{box-sizing:border-box}body{margin:0;background:linear-gradient(135deg,#101c3b,#253f69);font-family:Tahoma,Arial;color:#17233b;padding:18px}
main{max-width:760px;margin:auto}.panel{background:#fff;border-radius:20px;padding:20px;margin:12px 0;box-shadow:0 12px 35px #0003}
h1{text-align:center;color:#fff;margin:8px}h2{margin-top:0;color:#24456f}.muted{color:#66758a;font-size:13px}
input,textarea,button{font:inherit;border-radius:12px;padding:12px;border:1px solid #ccd5e2;width:100%;margin:6px 0}
button{background:#1769aa;color:white;border:0;font-weight:bold;cursor:pointer}button:disabled{opacity:.45}
.secondary{background:#e8eef6;color:#1c3e63}.danger{background:#b93649}.good{background:#16845b}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(125px,1fr));gap:8px}.item{background:#f1f5fa;padding:12px;border-radius:12px;text-align:center;font-weight:bold}
.lock{font-size:48px;text-align:center;padding:12px}.hidden{display:none}.player{padding:12px;border:1px solid #dce3ed;border-radius:12px;margin:7px 0}
.notice{padding:12px;background:#fff5d8;border-radius:12px;color:#6b4d00}.center{text-align:center}
</style></head><body><main><h1>🧺 سبد گمشده</h1><section id="setup" class="panel"><h2>آماده‌سازی بازی</h2>
<label>نام بازیکنان (هر نام در یک خط)</label><textarea id="names" rows="4" placeholder="احمد&#10;علی&#10;رضا"></textarea>
<label>فهرست کالاها (هر کالا در یک خط؛ حداقل ۳ برابر تعداد بازیکنان)</label><textarea id="items" rows="6" placeholder="سیب&#10;نان&#10;شیر&#10;..."></textarea>
<button onclick="start()">شروع بازی</button><p class="muted">هر بازیکن در نوبت خودش صفحه را باز می‌کند و سه کالای داخل سبدش را می‌بیند. پس از زدن «دیدم»، نوبت نفر بعد می‌شود.</p></section>
<section id="game" class="panel hidden"><div class="center"><div class="muted" id="progress"></div><h2 id="who"></h2></div>
<div id="locked"><div class="lock">🔒</div><p class="center">صفحه قفل است. گوشی را فقط به بازیکنی بدهید که نامش نمایش داده شده است.</p><button onclick="reveal()">باز کردن صفحه من</button></div>
<div id="revealed" class="hidden"><div class="notice center">این سه کالا در سبد شماست؛ آن‌ها را به خاطر بسپارید.</div><div id="myitems" class="grid"></div><button class="good" onclick="seen()">دیدم؛ نفر بعدی</button></div>
<div id="finished" class="hidden center"><h2>🎉 همه بازیکنان سبد خود را دیدند!</h2><p>می‌توانید بازی تازه‌ای شروع کنید.</p><button onclick="location.reload()">بازی جدید</button></div></section>
<section id="trade" class="panel hidden"><h2>جابجایی کالا</h2><p class="muted">برای برداشتن یک کالا از سبد خود، ابتدا یکی از کالاهای فعلی‌تان را خالی کنید.</p>
<label>بازیکن</label><select id="tradeplayer"></select><label>کالایی که از سبد خود خالی می‌کنید</label><select id="drop"></select><label>کالایی که می‌خواهید بردارید</label><select id="take"></select><button onclick="trade()">خالی کردن و برداشتن کالا</button><div id="tradeMsg"></div></section>
<section class="panel"><h2>وضعیت بازی</h2><div id="status" class="muted">هنوز بازی شروع نشده است.</div></section>
</main><script>
let data=null,opened=false;
async function api(url,body){let r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{})});let j=await r.json();if(!r.ok||!j.ok)throw Error(j.error||'خطا');return j}
function opts(el,arr){el.innerHTML=arr.map((x,i)=>`<option value="${i}">${x}</option>`).join('')}
async function start(){try{let j=await api('/start',{names:names.value,items:items.value});data=j;setup.classList.add('hidden');game.classList.remove('hidden');trade.classList.remove('hidden');refresh()}catch(e){alert(e.message)}}
function refresh(){if(!data)return;let done=data.turn>=data.players.length;locked.classList.toggle('hidden',done||opened);revealed.classList.toggle('hidden',done||!opened);finished.classList.toggle('hidden',!done);if(done){who.textContent='بازی به پایان رسید';progress.textContent='تمام نوبت‌ها انجام شد';return}
who.textContent='نوبت مشاهده: '+data.players[data.turn].name;progress.textContent=`بازیکن ${data.turn+1} از ${data.players.length}`;
status.innerHTML=data.players.map((p,i)=>`<div class="player">${i+1}. ${p.name} — ${data.seen.includes(i)?'✅ مشاهده شد':(i===data.turn?'▶ نوبت فعلی':'🔒 در انتظار')}</div>`).join('');
opts(tradeplayer,data.players.map(p=>p.name));updateTrade()}
function reveal(){opened=true;myitems.innerHTML=data.players[data.turn].basket.map(x=>`<div class="item">${x}</div>`).join('');locked.classList.add('hidden');revealed.classList.remove('hidden')}
async function seen(){try{data=await api('/seen');opened=false;refresh()}catch(e){alert(e.message)}}
function updateTrade(){let p=data.players[+tradeplayer.value||0];if(!p)return;opts(drop,p.basket);let all=data.items.filter(x=>!p.basket.includes(x));opts(take,all.length?all:['کالای دیگری موجود نیست'])}
tradeplayer.onchange=updateTrade;
async function trade(){try{let j=await api('/trade',{player:+tradeplayer.value,drop:+drop.value,take:take.options[take.selectedIndex]?.text});data=j;tradeMsg.textContent='جابجایی انجام شد.';updateTrade()}catch(e){tradeMsg.textContent=e.message}}
</script></body></html>"""
@app.get("/")
def index(): return render_template_string(HTML)
@app.post("/start")
def start():
    d=request.get_json() or {}
    names=[x.strip() for x in d.get("names","").splitlines() if x.strip()]
    items=[x.strip() for x in d.get("items","").splitlines() if x.strip()]
    if len(names)<2:return jsonify(ok=False,error="حداقل دو بازیکن وارد کنید."),400
    if len(set(names))!=len(names):return jsonify(ok=False,error="نام بازیکنان تکراری نباشد."),400
    if len(items)<len(names)*3:return jsonify(ok=False,error=f"حداقل {len(names)*3} کالا وارد کنید."),400
    if len(set(items))!=len(items):return jsonify(ok=False,error="نام کالاها تکراری نباشد."),400
    random.shuffle(items)
    STATE.update(players=[{"name":n,"basket":items[i*3:i*3+3]} for i,n in enumerate(names)],items=items,turn=0,started=True,seen=[],log=[])
    return jsonify(ok=True,**STATE)
@app.post("/seen")
def seen():
    if not STATE["started"] or STATE["turn"]>=len(STATE["players"]):return jsonify(ok=False,error="بازی فعال نیست."),400
    STATE["seen"].append(STATE["turn"]);STATE["turn"]+=1
    return jsonify(ok=True,**STATE)
@app.post("/trade")
def trade():
    d=request.get_json() or {};i=d.get("player",0)
    if not isinstance(i,int) or i<0 or i>=len(STATE["players"]):return jsonify(ok=False,error="بازیکن نامعتبر است."),400
    p=STATE["players"][i];drop=d.get("drop",0);take=d.get("take")
    if not isinstance(drop,int) or drop<0 or drop>=len(p["basket"]):return jsonify(ok=False,error="کالای انتخابی معتبر نیست."),400
    if not take or take not in STATE["items"] or take in p["basket"]:return jsonify(ok=False,error="کالای قابل برداشتن انتخاب نشده است."),400
    old=p["basket"].pop(drop);p["basket"].append(take);STATE["items"].remove(take);STATE["items"].append(old)
    return jsonify(ok=True,**STATE)
if __name__=="__main__":app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)),debug=False)
