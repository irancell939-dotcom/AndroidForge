package ir.khavaran.debtmanager;

import android.content.BroadcastReceiver;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "zarmanag_due_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "یادآوری سررسیدها", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("یادآوری یک روز پیش از تاریخ سررسید");
            manager.createNotificationChannel(channel);
        }
        int id = intent.getIntExtra("record_id", 1);
        String person = intent.getStringExtra("person");
        String kind = intent.getStringExtra("kind");
        String due = intent.getStringExtra("due_date");
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(context, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, CHANNEL) : new Notification.Builder(context);
        Notification notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("یادآوری سررسید زرمانگ")
            .setContentText("فردا موعد " + (kind == null ? "سررسید" : kind) + " «" + (person == null ? "" : person) + "» است.")
            .setStyle(new Notification.BigTextStyle().bigText("فردا موعد " + (kind == null ? "سررسید" : kind) + " «" + (person == null ? "" : person) + "» است. تاریخ سررسید: " + (due == null ? "" : due)))
            .setAutoCancel(true).setContentIntent(content).setPriority(Notification.PRIORITY_HIGH).build();
        manager.notify(id, notification);
    }
}
