import os
import sqlite3
import shutil
import hashlib
import smtplib
import secrets
import re
import tempfile
import jdatetime
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
from functools import wraps
from flask import (Flask, render_template, request, redirect, url_for,
                   flash, g, jsonify, session, send_file, abort, send_from_directory)
from werkzeug.utils import secure_filename

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
# Android: writable files live in the app-private directory; templates/static stay packaged.
DATA_DIR = os.environ.get('ZARMANAG_DATA_DIR', BASE_DIR)
# Android's writable temporary directory must be inside the app-private files area.
TEMP_DIR = os.path.join(DATA_DIR, 'tmp')
os.makedirs(TEMP_DIR, exist_ok=True)
os.environ['TMPDIR'] = TEMP_DIR
tempfile.tempdir = TEMP_DIR
UPLOAD_FOLDER = os.path.join(DATA_DIR, 'static', 'uploads')
BACKUP_FOLDER = os.path.join(DATA_DIR, 'backups')
DB_PATH = os.path.join(DATA_DIR, 'debts.db')

# ============ تنظیمات ایمیل (اختیاری) ============
MAIL_HOST = os.environ.get('MAIL_HOST', '')
MAIL_PORT = int(os.environ.get('MAIL_PORT', '587'))
MAIL_USER = os.environ.get('MAIL_USER', '')
MAIL_PASS = os.environ.get('MAIL_PASS', '')
MAIL_TO   = os.environ.get('MAIL_TO', '')

# ============ رمز مادر ============
MASTER_PASSWORD = os.environ.get('MASTER_PASSWORD', '10246600')

# ============ حالت آزمایشی ============
TRIAL_LIMIT = 3

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', secrets.token_hex(32))
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    # User photos are stored in the writable app-private uploads directory on Android.
    return send_from_directory(UPLOAD_FOLDER, filename)
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)
ALLOWED_EXT = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(BACKUP_FOLDER, exist_ok=True)


# ============ Database ============
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def _columns_of(db, table):
    rows = db.execute(f"PRAGMA table_info({table})").fetchall()
    return {r[1] for r in rows}


def _table_exists(db, table):
    row = db.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (table,)
    ).fetchone()
    return row is not None


def migrate_db(db):
    if not _table_exists(db, 'records'):
        return

    cols = _columns_of(db, 'records')
    wanted = {
        'phone':        "ALTER TABLE records ADD COLUMN phone TEXT",
        'total_amount': "ALTER TABLE records ADD COLUMN total_amount INTEGER",
        'archived':     "ALTER TABLE records ADD COLUMN archived INTEGER DEFAULT 0",
        'subject':      "ALTER TABLE records ADD COLUMN subject TEXT",
        'description':  "ALTER TABLE records ADD COLUMN description TEXT",
        'image':        "ALTER TABLE records ADD COLUMN image TEXT",
        'created_at':   "ALTER TABLE records ADD COLUMN created_at TEXT",
    }
    for col, ddl in wanted.items():
        if col not in cols:
            db.execute(ddl)

    if 'amount' in cols and 'total_amount' not in cols:
        db.execute("UPDATE records SET total_amount = amount WHERE total_amount IS NULL")

    if 'due_date' not in cols:
        db.execute("ALTER TABLE records ADD COLUMN due_date TEXT")

    db.execute("UPDATE records SET archived = 0 WHERE archived IS NULL")
    db.execute("UPDATE records SET total_amount = 0 WHERE total_amount IS NULL")
    db.execute("UPDATE records SET created_at = '' WHERE created_at IS NULL")

    if not _table_exists(db, 'payments'):
        db.execute('''
            CREATE TABLE payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                paid_date TEXT NOT NULL,
                note TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (record_id) REFERENCES records(id) ON DELETE CASCADE
            )
        ''')
    db.commit()


def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.executescript('''
            CREATE TABLE IF NOT EXISTS records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                person TEXT NOT NULL,
                phone TEXT,
                total_amount INTEGER NOT NULL,
                due_date TEXT NOT NULL,
                subject TEXT,
                description TEXT,
                image TEXT,
                created_at TEXT NOT NULL,
                archived INTEGER DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                paid_date TEXT NOT NULL,
                note TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (record_id) REFERENCES records(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            );
        ''')
        db.commit()
        migrate_db(db)


init_db()


# ============ Helpers ============
def days_remaining(due_date_str):
    try:
        y, m, d = map(int, due_date_str.split('/'))
        due = jdatetime.date(y, m, d).togregorian()
        today = datetime.now().date()
        return (due - today).days
    except Exception:
        return 0


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT


def format_money(amount):
    try:
        return f"{int(amount):,}"
    except Exception:
        return str(amount)


def today_jalali():
    return jdatetime.date.today().strftime('%Y/%m/%d')


def paid_of(record_id):
    db = get_db()
    return db.execute(
        'SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE record_id = ?',
        (record_id,)
    ).fetchone()['s']


def get_setting(key, default=None):
    db = get_db()
    row = db.execute('SELECT value FROM settings WHERE key = ?', (key,)).fetchone()
    return row['value'] if row else default


def set_setting(key, value):
    db = get_db()
    db.execute(
        'INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)',
        (key, str(value))
    )
    db.commit()


# ============ رمز عبور ============
def _hash_password(password):
    return hashlib.sha256(password.encode('utf-8')).hexdigest()


def get_password_hash():
    return get_setting('app_password_hash')


def is_password_set():
    return get_password_hash() is not None


def set_app_password(password):
    set_setting('app_password_hash', _hash_password(password))


def verify_app_password(password):
    stored = get_password_hash()
    if not stored:
        return False
    return stored == _hash_password(password)


# ============ Login Required ============
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get('logged_in'):
            flash('لطفاً وارد شوید.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapper


# ============ حالت آزمایشی ============
def is_trial():
    return not session.get('registered', False)


def trial_count():
    db = get_db()
    return db.execute('SELECT COUNT(*) AS c FROM records').fetchone()['c']


def trial_remaining():
    if not is_trial():
        return None
    return max(0, TRIAL_LIMIT - trial_count())


# ============ اعلان‌های سررسید (Android local notifications) ============
@app.get('/api/reminders')
def api_reminders():
    # This endpoint is consumed by the Android WebView bridge. It is intentionally
    # local/offline and returns only records which still have an unpaid balance.
    if not session.get('logged_in'):
        return jsonify(items=[]), 401
    db = get_db()
    rows = db.execute("SELECT * FROM records WHERE archived=0 ORDER BY id").fetchall()
    items = []
    today = datetime.now().date()
    for row in rows:
        if int(row['total_amount'] or 0) - int(paid_of(row['id']) or 0) <= 0:
            continue
        try:
            y, m, d = map(int, row['due_date'].split('/'))
            due_gregorian = jdatetime.date(y, m, d).togregorian()
            reminder_day = due_gregorian - timedelta(days=1)
        except Exception:
            continue
        if reminder_day < today:
            continue
        items.append({
            'id': int(row['id']),
            'person': row['person'] or 'بدون نام',
            'kind': 'طلب' if row['type'] == 'receivable' else 'بدهی',
            'due_date': row['due_date'],
            'reminder_date': reminder_day.strftime('%Y-%m-%d')
        })
    return jsonify(items=items)


# ============ اعداد به حروف فارسی ============
ONES = ['', 'یک', 'دو', 'سه', 'چهار', 'پنج', 'شش', 'هفت', 'هشت', 'نه']
TEENS = ['ده', 'یازده', 'دوازده', 'سیزده', 'چهارده', 'پانزده', 'شانزده',
         'هفده', 'هجده', 'نوزده']
TENS = ['', '', 'بیست', 'سی', 'چهل', 'پنجاه', 'شصت', 'هفتاد', 'هشتاد', 'نود']
HUNDREDS = ['', 'صد', 'دویست', 'سیصد', 'چهارصد', 'پانصد', 'ششصد', 'هفتصد',
            'هشتصد', 'نهصد']
SCALES = ['', ' هزار', ' میلیون', ' میلیارد', ' تریلیون']


def _three_digits_to_words(n):
    parts = []
    h, rem = divmod(n, 100)
    if h:
        parts.append(HUNDREDS[h])
    if 10 <= rem < 20:
        parts.append(TEENS[rem - 10])
    else:
        t, o = divmod(rem, 10)
        if t:
            parts.append(TENS[t])
        if o:
            parts.append(ONES[o])
    return ' و '.join(parts)


def number_to_fa_words(num):
    try:
        num = int(num)
    except (TypeError, ValueError):
        return ''
    if num == 0:
        return 'صفر'
    if num < 0:
        return 'منفی ' + number_to_fa_words(-num)

    parts = []
    scale_idx = 0
    while num > 0:
        chunk = num % 1000
        if chunk:
            parts.append(_three_digits_to_words(chunk) + SCALES[scale_idx])
        num //= 1000
        scale_idx += 1
    return ' و '.join(reversed(parts))


@app.template_filter('fa_words')
def fa_words_filter(value):
    return number_to_fa_words(value)


@app.template_filter('fa_money')
def fa_money_filter(value):
    try:
        return f"{int(value):,}"
    except (TypeError, ValueError):
        return str(value)


@app.context_processor
def utility_processor():
    return dict(
        days_remaining=days_remaining,
        format_money=format_money,
        today_jalali=today_jalali(),
        is_registered=session.get('registered', False),
        is_trial=not session.get('registered', False),
        trial_limit=TRIAL_LIMIT,
        trial_remaining=trial_remaining() if session.get('logged_in') else None,
    )


# ============ Auth Routes ============
@app.route('/login', methods=['GET', 'POST'])
def login():
    if session.get('logged_in'):
        return redirect(url_for('index'))

    # اگر رمزی تعیین نشده، به صفحه تعیین رمز برود
    if not is_password_set():
        return redirect(url_for('set_password'))

    if request.method == 'POST':
        password = request.form.get('password', '')

        # رمز مادر
        if password == MASTER_PASSWORD:
            session['master_mode'] = True
            return redirect(url_for('set_password'))

        if not verify_app_password(password):
            flash('رمز عبور اشتباه است.', 'error')
            return render_template('login.html')

        session.permanent = True
        session['logged_in'] = True
        session['registered'] = bool(get_setting('registered', '0') == '1')
        return redirect(url_for('index'))

    return render_template('login.html')


@app.route('/set-password', methods=['GET', 'POST'])
def set_password():
    """تعیین رمز اولیه یا رمز جدید (در حالت رمز مادر)"""
    if is_password_set() and not session.get('master_mode'):
        return redirect(url_for('login'))

    if request.method == 'POST':
        password = request.form.get('password', '')
        confirm = request.form.get('confirm', '')

        errors = []
        if len(password) < 4:
            errors.append('رمز عبور باید حداقل ۴ کاراکتر باشد.')
        if password != confirm:
            errors.append('تکرار رمز عبور مطابقت ندارد.')

        if errors:
            for e in errors:
                flash(e, 'error')
            return render_template('set_password.html',
                                   master_mode=session.get('master_mode', False))

        set_app_password(password)
        session.pop('master_mode', None)
        session['logged_in'] = True
        session['registered'] = bool(get_setting('registered', '0') == '1')
        flash('رمز عبور با موفقیت تنظیم شد.', 'success')
        return redirect(url_for('index'))

    return render_template('set_password.html',
                           master_mode=session.get('master_mode', False))


@app.route('/logout')
def logout():
    session.clear()
    flash('خارج شدید.', 'success')
    return redirect(url_for('login'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if not session.get('logged_in'):
        return redirect(url_for('login'))

    if session.get('registered'):
        return redirect(url_for('index'))

    if request.method == 'POST':
        action = request.form.get('action', '')
        if action == 'generate_request':
            request_id = f"{secrets.randbelow(9000000) + 1000000:07d}"
            code1 = request_id + '10246600'
            session['register_request_id'] = request_id
            session['register_code1'] = code1
            return render_template('register.html', request_id=request_id, code1=code1)

        code1 = session.get('register_code1', '')
        code2 = request.form.get('code2', '').strip().upper()
        if not re.fullmatch(r'\d{15}', code1):
            flash('ابتدا روی «درخواست کد ریجستر» بزنید تا شناسه اختصاصی ساخته شود.', 'error')
            return redirect(url_for('register'))

        # فرمول دقیق نسخه قبلی: پنج رقم میانی + DOA + چهار رقم انتهایی + RE + پنج رقم اول + رقم یازدهم
        expected = code1[5:10] + 'DOA' + code1[11:15] + 'RE' + code1[0:5] + code1[10]
        if not secrets.compare_digest(expected, code2):
            flash('کد ریجستر دوم نامعتبر است. کد دریافتی را دقیق وارد کنید.', 'error')
            return render_template('register.html', request_id=session.get('register_request_id'), code1=code1)

        set_setting('registered', '1')
        session['registered'] = True
        session.pop('register_code1', None)
        session.pop('register_request_id', None)
        flash('ثبت‌نام با موفقیت تکمیل شد. اکنون به همه امکانات دسترسی دارید.', 'success')
        return redirect(url_for('index'))

    return render_template('register.html', request_id=session.get('register_request_id'), code1=session.get('register_code1'))


@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if request.method == 'POST':
        action = request.form.get('action', '')

        if action == 'change_password':
            current = request.form.get('current', '')
            new_pass = request.form.get('new', '')
            confirm = request.form.get('confirm', '')
            errors = []
            if not verify_app_password(current):
                errors.append('رمز فعلی اشتباه است.')
            if len(new_pass) < 4:
                errors.append('رمز جدید باید حداقل ۴ کاراکتر باشد.')
            if new_pass != confirm:
                errors.append('تکرار رمز جدید مطابقت ندارد.')
            if errors:
                for e in errors:
                    flash(e, 'error')
                return redirect(url_for('settings'))
            set_app_password(new_pass)
            flash('رمز عبور با موفقیت تغییر کرد.', 'success')
            return redirect(url_for('settings'))

        elif action == 'save_email':
            host = request.form.get('mail_host', '').strip()
            port = request.form.get('mail_port', '587').strip() or '587'
            user = request.form.get('mail_user', '').strip()
            password = request.form.get('mail_pass', '')
            to_email = request.form.get('mail_to', '').strip()
            try:
                port_num = int(port)
                if not (1 <= port_num <= 65535):
                    raise ValueError
            except ValueError:
                flash('شماره پورت ایمیل معتبر نیست.', 'error')
                return redirect(url_for('settings'))
            set_setting('mail_host', host)
            set_setting('mail_port', str(port_num))
            set_setting('mail_user', user)
            if password:
                set_setting('mail_pass', password)
            set_setting('mail_to', to_email)
            flash('تنظیمات ایمیل روی همین گوشی ذخیره شد.', 'success')
            return redirect(url_for('settings'))

        elif action == 'reset_register':
            set_setting('registered', '0')
            session['registered'] = False
            flash('وضعیت ثبت‌نام ریست شد.', 'success')
            return redirect(url_for('register'))

    mail_settings = {
        'host': get_setting('mail_host', MAIL_HOST),
        'port': get_setting('mail_port', str(MAIL_PORT)),
        'user': get_setting('mail_user', MAIL_USER),
        'to': get_setting('mail_to', MAIL_TO),
        'password_saved': bool(get_setting('mail_pass', MAIL_PASS)),
    }
    return render_template('settings.html', mail_settings=mail_settings)


# ============ List ============
@app.route('/')
@login_required
def index():
    rec_type = request.args.get('type', 'receivable')
    if rec_type not in ('receivable', 'payable'):
        rec_type = 'receivable'

    q = request.args.get('q', '').strip()
    db = get_db()

    sql = 'SELECT * FROM records WHERE type = ? AND archived = 0'
    params = [rec_type]

    if q:
        sql += ' AND (person LIKE ? OR phone LIKE ? OR subject LIKE ? OR description LIKE ?)'
        like = f'%{q}%'
        params.extend([like, like, like, like])

    sql += ' ORDER BY due_date ASC'
    rows = db.execute(sql, params).fetchall()

    result = []
    grand_total = 0
    grand_paid = 0
    for r in rows:
        paid = paid_of(r['id'])
        remaining = r['total_amount'] - paid
        grand_total += r['total_amount']
        grand_paid += paid
        result.append({'record': r, 'paid': paid, 'remaining': remaining})

    return render_template(
        'index.html',
        items=result,
        rec_type=rec_type,
        q=q,
        total=grand_total,
        paid=grand_paid,
        remaining=grand_total - grand_paid,
    )


# ============ API: جستجوی زنده ============
@app.route('/api/search')
@login_required
def api_search():
    rec_type = request.args.get('type', 'receivable')
    if rec_type not in ('receivable', 'payable'):
        rec_type = 'receivable'
    q = request.args.get('q', '').strip()
    archived = 1 if request.args.get('archived') == '1' else 0

    db = get_db()
    sql = 'SELECT * FROM records WHERE type = ? AND archived = ?'
    params = [rec_type, archived]
    if q:
        sql += ' AND (person LIKE ? OR phone LIKE ? OR subject LIKE ? OR description LIKE ?)'
        like = f'%{q}%'
        params.extend([like, like, like, like])
    sql += ' ORDER BY due_date ASC'
    rows = db.execute(sql, params).fetchall()

    items = []
    for r in rows:
        paid = paid_of(r['id'])
        remaining = r['total_amount'] - paid
        dr = days_remaining(r['due_date'])
        items.append({
            'id': r['id'],
            'person': r['person'],
            'phone': r['phone'] or '',
            'total_amount': r['total_amount'],
            'total_amount_fmt': format_money(r['total_amount']),
            'paid': paid,
            'paid_fmt': format_money(paid),
            'remaining': remaining,
            'remaining_fmt': format_money(remaining),
            'due_date': r['due_date'],
            'subject': r['subject'] or '',
            'days_remaining': dr,
            'progress': round(paid * 100 / r['total_amount'], 1) if r['total_amount'] else 0,
        })

    return jsonify({'items': items, 'count': len(items)})


# ============ Add / Edit ============
@app.route('/add', methods=['GET', 'POST'])
@login_required
def add():
    rec_type = request.args.get('type', 'receivable')
    if rec_type not in ('receivable', 'payable'):
        rec_type = 'receivable'

    # حالت آزمایشی: بررسی سقف
    if is_trial() and trial_count() >= TRIAL_LIMIT:
        flash('در حالت آزمایشی فقط ۳ مورد قابل ثبت است. برای ثبت بیشتر، ثبت‌نام را تکمیل کنید.', 'error')
        return redirect(url_for('register'))

    if request.method == 'POST':
        return _save_record(None)

    return render_template('add.html', rec_type=rec_type, form={}, record=None)


@app.route('/edit/<int:rec_id>', methods=['GET', 'POST'])
@login_required
def edit(rec_id):
    if is_trial():
        flash('ویرایش در نسخه آزمایشی غیرفعال است. برای فعال‌سازی کامل زرمانگ، درخواست کد ریجستر را ارسال کنید.', 'error')
        return redirect(url_for('register'))
    db = get_db()
    rec = db.execute('SELECT * FROM records WHERE id = ?', (rec_id,)).fetchone()
    if not rec:
        flash('رکورد یافت نشد.', 'error')
        return redirect(url_for('index'))

    if request.method == 'POST':
        return _save_record(rec_id)

    return render_template('add.html', rec_type=rec['type'], form=dict(rec), record=rec)


def _save_record(rec_id):
    db = get_db()
    existing = None
    if rec_id:
        existing = db.execute('SELECT * FROM records WHERE id = ?', (rec_id,)).fetchone()

    # حالت آزمایشی: بررسی در ایجاد جدید
    if not existing and is_trial() and trial_count() >= TRIAL_LIMIT:
        flash('در حالت آزمایشی فقط ۳ مورد قابل ثبت است.', 'error')
        return redirect(url_for('register'))

    rec_type = request.form.get('type', 'receivable')
    person = request.form.get('person', '').strip()
    phone = request.form.get('phone', '').strip()
    total_str = request.form.get('total_amount', '').replace(',', '').strip()
    due_date = request.form.get('due_date', '').strip()
    subject = request.form.get('subject', '').strip()
    description = request.form.get('description', '').strip()
    image_file = request.files.get('image')
    remove_image = request.form.get('remove_image') == '1'

    errors = []
    if not person:
        errors.append('نام شخص الزامی است.')
    try:
        total_amount = int(total_str)
        if total_amount <= 0:
            raise ValueError
    except ValueError:
        errors.append('مبلغ کل باید عددی مثبت باشد.')
        total_amount = 0

    try:
        y, m, d = map(int, due_date.split('/'))
        jdatetime.date(y, m, d)
    except Exception:
        errors.append('تاریخ سررسید نامعتبر است.')

    image_name = existing['image'] if existing else None
    if remove_image:
        if image_name:
            try:
                os.remove(os.path.join(app.config['UPLOAD_FOLDER'], image_name))
            except OSError:
                pass
        image_name = None
    if image_file and image_file.filename:
        if allowed_file(image_file.filename):
            fname = secure_filename(image_file.filename)
            stamp = datetime.now().strftime('%Y%m%d%H%M%S')
            new_name = f"{stamp}_{fname}"
            image_file.save(os.path.join(app.config['UPLOAD_FOLDER'], new_name))
            image_name = new_name
        else:
            errors.append('فرمت عکس مجاز نیست.')

    if errors:
        for e in errors:
            flash(e, 'error')
        form = dict(request.form)
        form['id'] = rec_id
        return render_template('add.html', rec_type=rec_type, form=form, record=existing)

    if existing:
        db.execute(
            '''UPDATE records SET person=?, phone=?, total_amount=?, due_date=?,
               subject=?, description=?, image=? WHERE id=?''',
            (person, phone, total_amount, due_date, subject,
             description, image_name, rec_id)
        )
        db.commit()
        flash('ویرایش با موفقیت انجام شد.', 'success')
        return redirect(url_for('detail', rec_id=rec_id))
    else:
        db.execute(
            '''INSERT INTO records (type, person, phone, total_amount, due_date,
               subject, description, image, created_at, archived)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)''',
            (rec_type, person, phone, total_amount, due_date,
             subject, description, image_name, datetime.now().isoformat())
        )
        db.commit()
        flash('با موفقیت ثبت شد.', 'success')
        return redirect(url_for('index', type=rec_type))


# ============ Detail ============
@app.route('/detail/<int:rec_id>')
@login_required
def detail(rec_id):
    rec, payments = get_record_with_payments(rec_id)
    if not rec:
        flash('رکورد یافت نشد.', 'error')
        return redirect(url_for('index'))

    total_paid = sum(p['amount'] for p in payments)
    remaining = rec['total_amount'] - total_paid

    return render_template(
        'detail.html',
        record=rec,
        payments=payments,
        total_paid=total_paid,
        remaining=remaining,
    )


def get_record_with_payments(record_id):
    db = get_db()
    rec = db.execute('SELECT * FROM records WHERE id = ?', (record_id,)).fetchone()
    if not rec:
        return None, []
    payments = db.execute(
        'SELECT * FROM payments WHERE record_id = ? ORDER BY paid_date ASC, id ASC',
        (record_id,)
    ).fetchall()
    return rec, payments


# ============ آرشیو خودکار ============
def _maybe_archive_when_settled(rec_id):
    db = get_db()
    rec = db.execute('SELECT * FROM records WHERE id = ?', (rec_id,)).fetchone()
    if not rec or rec['archived']:
        return
    paid = paid_of(rec_id)
    if paid >= rec['total_amount']:
        db.execute('UPDATE records SET archived = 1 WHERE id = ?', (rec_id,))
        db.commit()


# ============ Payments ============
@app.route('/pay/<int:rec_id>', methods=['POST'])
@login_required
def add_payment(rec_id):
    db = get_db()
    rec = db.execute('SELECT * FROM records WHERE id = ?', (rec_id,)).fetchone()
    if not rec:
        flash('رکورد یافت نشد.', 'error')
        return redirect(url_for('index'))

    amount_str = request.form.get('amount', '').replace(',', '').strip()
    paid_date = request.form.get('paid_date', '').strip()
    note = request.form.get('note', '').strip()

    errors = []
    try:
        amount = int(amount_str)
        if amount <= 0:
            raise ValueError
    except ValueError:
        errors.append('مبلغ پرداخت باید عددی مثبت باشد.')
        amount = 0

    try:
        y, m, d = map(int, paid_date.split('/'))
        jdatetime.date(y, m, d)
    except Exception:
        errors.append('تاریخ پرداخت نامعتبر است.')

    if amount > 0:
        already = paid_of(rec_id)
        if already + amount > rec['total_amount']:
            errors.append(f'مجموع پرداخت‌ها از مبلغ کل بیشتر می‌شود. '
                          f'باقیمانده: {format_money(rec["total_amount"] - already)}')

    if errors:
        for e in errors:
            flash(e, 'error')
        return redirect(url_for('detail', rec_id=rec_id))

    db.execute(
        '''INSERT INTO payments (record_id, amount, paid_date, note, created_at)
           VALUES (?, ?, ?, ?, ?)''',
        (rec_id, amount, paid_date, note, datetime.now().isoformat())
    )
    db.commit()
    _maybe_archive_when_settled(rec_id)
    flash('پرداخت ثبت شد.', 'success')

    rec2 = db.execute('SELECT archived FROM records WHERE id = ?', (rec_id,)).fetchone()
    if rec2 and rec2['archived']:
        flash('این رکورد تسویه شد و به بایگانی منتقل شد.', 'success')
        return redirect(url_for('index', type=rec['type']))
    return redirect(url_for('detail', rec_id=rec_id))


@app.route('/payment/<int:pay_id>/delete', methods=['POST'])
@login_required
def delete_payment(pay_id):
    if is_trial():
        flash('حذف پرداخت در نسخه آزمایشی غیرفعال است. برای فعال‌سازی کامل زرمانگ، درخواست کد ریجستر را ارسال کنید.', 'error')
        return redirect(url_for('register'))
    db = get_db()
    pay = db.execute('SELECT * FROM payments WHERE id = ?', (pay_id,)).fetchone()
    if pay:
        db.execute('DELETE FROM payments WHERE id = ?', (pay_id,))
        db.commit()
        flash('پرداخت حذف شد.', 'success')
        return redirect(url_for('detail', rec_id=pay['record_id']))
    return redirect(url_for('index'))


# ============ Archive ============
@app.route('/archive/<int:rec_id>', methods=['POST'])
@login_required
def archive_record(rec_id):
    db = get_db()
    rec = db.execute('SELECT * FROM records WHERE id = ?', (rec_id,)).fetchone()
    if rec:
        new_state = 0 if rec['archived'] else 1
        db.execute('UPDATE records SET archived = ? WHERE id = ?', (new_state, rec_id))
        db.commit()
        msg = 'به بایگانی منتقل شد.' if new_state else 'از بایگانی خارج شد.'
        flash(msg, 'success')
        if new_state:
            return redirect(url_for('index', type=rec['type']))
        return redirect(url_for('detail', rec_id=rec_id))
    return redirect(url_for('index'))


@app.route('/archive')
@login_required
def archive_list():
    rec_type = request.args.get('type', 'receivable')
    if rec_type not in ('receivable', 'payable'):
        rec_type = 'receivable'

    q = request.args.get('q', '').strip()
    db = get_db()

    sql = 'SELECT * FROM records WHERE type = ? AND archived = 1'
    params = [rec_type]

    if q:
        sql += ' AND (person LIKE ? OR phone LIKE ? OR subject LIKE ? OR description LIKE ?)'
        like = f'%{q}%'
        params.extend([like, like, like, like])

    sql += ' ORDER BY due_date DESC'
    rows = db.execute(sql, params).fetchall()

    result = []
    for r in rows:
        paid = paid_of(r['id'])
        result.append({'record': r, 'paid': paid, 'remaining': r['total_amount'] - paid})

    return render_template('archive.html', items=result, rec_type=rec_type, q=q)


# ============ Delete ============
@app.route('/delete/<int:rec_id>', methods=['POST'])
@login_required
def delete(rec_id):
    if is_trial():
        flash('حذف رکورد در نسخه آزمایشی غیرفعال است. برای فعال‌سازی کامل زرمانگ، درخواست کد ریجستر را ارسال کنید.', 'error')
        return redirect(url_for('register'))
    db = get_db()
    rec = db.execute('SELECT * FROM records WHERE id = ?', (rec_id,)).fetchone()
    if rec:
        if rec['image']:
            try:
                os.remove(os.path.join(app.config['UPLOAD_FOLDER'], rec['image']))
            except OSError:
                pass
        db.execute('DELETE FROM payments WHERE record_id = ?', (rec_id,))
        db.execute('DELETE FROM records WHERE id = ?', (rec_id,))
        db.commit()
        flash('رکورد و پرداخت‌های آن حذف شد.', 'success')
        return redirect(url_for('index', type=rec['type']))
    return redirect(url_for('index'))


# ============ Balance ============
@app.route('/balance')
@login_required
def balance():
    db = get_db()

    def stats(rec_type):
        rows = db.execute(
            'SELECT * FROM records WHERE type = ? AND archived = 0',
            (rec_type,)
        ).fetchall()
        total = 0
        paid = 0
        overdue_count = 0
        overdue_amount = 0
        for r in rows:
            p = paid_of(r['id'])
            total += r['total_amount']
            paid += p
            remaining = r['total_amount'] - p
            if remaining > 0 and days_remaining(r['due_date']) < 0:
                overdue_count += 1
                overdue_amount += remaining
        return {
            'count': len(rows),
            'total': total,
            'paid': paid,
            'remaining': total - paid,
            'overdue_count': overdue_count,
            'overdue_amount': overdue_amount,
        }

    rec = stats('receivable')
    pay = stats('payable')
    net = rec['remaining'] - pay['remaining']

    return render_template('balance.html', rec=rec, pay=pay, net=net)


# ============ Backup / Restore / Email ============
@app.route('/backup')
@login_required
def backup_page():
    backups = []
    if os.path.isdir(BACKUP_FOLDER):
        for f in sorted(os.listdir(BACKUP_FOLDER), reverse=True):
            if f.endswith('.db'):
                path = os.path.join(BACKUP_FOLDER, f)
                backups.append({
                    'name': f,
                    'size': os.path.getsize(path),
                    'mtime': datetime.fromtimestamp(os.path.getmtime(path)).strftime('%Y-%m-%d %H:%M'),
                })
    return render_template('backup.html', backups=backups,
                           mail_configured=bool(get_setting('mail_host', MAIL_HOST) and get_setting('mail_user', MAIL_USER) and get_setting('mail_pass', MAIL_PASS)),
                           mail_to=get_setting('mail_to', MAIL_TO))


@app.route('/backup/download')
@login_required
def backup_download():
    # Create a durable copy in the app-private backup folder. Do not use
    # TemporaryDirectory here: WebView/DownloadManager reads the response later.
    os.makedirs(BACKUP_FOLDER, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'zarmanag_backup_{stamp}.db'
    backup_path = os.path.join(BACKUP_FOLDER, filename)
    src = sqlite3.connect(DB_PATH)
    dst = sqlite3.connect(backup_path)
    try:
        with dst:
            src.backup(dst)
    finally:
        dst.close()
        src.close()
    response = send_file(backup_path, as_attachment=True, download_name=filename,
                         mimetype='application/x-sqlite3', conditional=False)
    response.headers['Cache-Control'] = 'no-store'
    return response


@app.route('/backup/save', methods=['POST'])
@login_required
def backup_save():
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'debts_backup_{stamp}.db'
    path = os.path.join(BACKUP_FOLDER, filename)
    src = sqlite3.connect(DB_PATH)
    dst = sqlite3.connect(path)
    with dst:
        src.backup(dst)
    dst.close()
    src.close()
    flash(f'نسخه پشتیبان در حافظه داخلی برنامه ذخیره شد: {filename}', 'success')
    return redirect(url_for('backup_page'))


@app.route('/backup/restore', methods=['POST'])
@login_required
def backup_restore():
    source = request.form.get('source', 'upload')

    if source == 'existing':
        name = request.form.get('filename', '')
        if not name or '/' in name or '\\' in name:
            flash('نام فایل نامعتبر است.', 'error')
            return redirect(url_for('backup_page'))
        src_path = os.path.join(BACKUP_FOLDER, name)
        if not os.path.exists(src_path):
            flash('فایل بکاپ یافت نشد.', 'error')
            return redirect(url_for('backup_page'))
        return _do_restore(src_path)

    f = request.files.get('backup_file')
    if not f or not f.filename:
        flash('فایلی انتخاب نشده است.', 'error')
        return redirect(url_for('backup_page'))
    if not f.filename.lower().endswith('.db'):
        flash('فایل باید با پسوند .db باشد.', 'error')
        return redirect(url_for('backup_page'))

    tmpdir = tempfile.mkdtemp()
    tmp_path = os.path.join(tmpdir, 'restore.db')
    f.save(tmp_path)
    try:
        return _do_restore(tmp_path)
    finally:
        try:
            os.remove(tmp_path)
            os.rmdir(tmpdir)
        except OSError:
            pass


def _do_restore(src_path):
    try:
        test = sqlite3.connect(src_path)
        test.execute('SELECT COUNT(*) FROM records').fetchone()
        test.close()
    except Exception:
        flash('فایل بکاپ معتبر نیست.', 'error')
        return redirect(url_for('backup_page'))

    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    safety = os.path.join(BACKUP_FOLDER, f'before_restore_{stamp}.db')
    try:
        src_cur = sqlite3.connect(DB_PATH)
        dst = sqlite3.connect(safety)
        with dst:
            src_cur.backup(dst)
        dst.close()
        src_cur.close()
    except Exception:
        pass

    try:
        shutil.copyfile(src_path, DB_PATH)
        flash('بازیابی با موفقیت انجام شد.', 'success')
    except Exception as e:
        flash(f'خطا در بازیابی: {e}', 'error')

    return redirect(url_for('index'))


@app.route('/backup/email', methods=['POST'])
@login_required
def backup_email():
    to_email = request.form.get('email', '').strip() or get_setting('mail_to', MAIL_TO)
    if not to_email:
        flash('آدرس ایمیل گیرنده را وارد کنید.', 'error')
        return redirect(url_for('backup_page'))

    mail_host = get_setting('mail_host', MAIL_HOST)
    mail_port = int(get_setting('mail_port', str(MAIL_PORT)) or MAIL_PORT)
    mail_user = get_setting('mail_user', MAIL_USER)
    mail_pass = get_setting('mail_pass', MAIL_PASS)
    if not (mail_host and mail_user and mail_pass):
        flash('تنظیمات ایمیل را ابتدا در صفحه تنظیمات تکمیل کنید.', 'error')
        return redirect(url_for('backup_page'))

    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'debts_backup_{stamp}.db'
    tmpdir = tempfile.mkdtemp()
    tmp_path = os.path.join(tmpdir, filename)
    try:
        src = sqlite3.connect(DB_PATH)
        dst = sqlite3.connect(tmp_path)
        with dst:
            src.backup(dst)
        dst.close()
        src.close()

        msg = MIMEMultipart()
        msg['From'] = mail_user
        msg['To'] = to_email
        msg['Subject'] = f'بکاپ برنامه مدیریت طلب و بدهی - {stamp}'
        body = 'فایل پشتیبان دیتابیس برنامه به پیوست ارسال شد.'
        msg.attach(MIMEText(body, 'plain', 'utf-8'))

        with open(tmp_path, 'rb') as f:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(f.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename="{filename}"')
        msg.attach(part)

        server = smtplib.SMTP(mail_host, mail_port)
        server.starttls()
        server.login(mail_user, mail_pass)
        server.send_message(msg)
        server.quit()

        flash(f'ایمیل به {to_email} ارسال شد.', 'success')
    except Exception as e:
        flash(f'خطا در ارسال ایمیل: {e}', 'error')
    finally:
        try:
            os.remove(tmp_path)
            os.rmdir(tmpdir)
        except OSError:
            pass

    return redirect(url_for('backup_page'))


if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=int(os.environ.get('PORT', '5000')))