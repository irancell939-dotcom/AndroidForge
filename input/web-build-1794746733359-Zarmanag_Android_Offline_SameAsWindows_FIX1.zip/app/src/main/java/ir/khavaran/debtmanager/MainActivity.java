package ir.khavaran.debtmanager;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.os.Handler;
import android.graphics.Color;
import android.view.View;
import android.webkit.*;
import android.widget.*;
import android.content.*;
import java.io.*;
import java.net.*;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private WebView web;
    private LinearLayout root;
    private TextView status;
    private boolean ready = false;
    private final Handler handler = new Handler();
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 77;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(79,70,229));
        getWindow().setNavigationBarColor(Color.rgb(31,41,55));
        buildScreen();
        preparePrivateFiles();
        startLocalServer();
    }

    private void buildScreen() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(244,246,251));
        status = new TextView(this); status.setText("زرمانگ\nدر حال آماده‌سازی برنامه...");
        status.setTextColor(Color.rgb(31,41,55)); status.setTextSize(17);
        status.setGravity(17); status.setPadding(20,30,20,30);
        root.addView(status, new LinearLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    private void preparePrivateFiles() {
        File data = getFilesDir();
        File db = new File(data,"debts.db");
        File uploads = new File(data,"static/uploads");
        File backups = new File(data,"backups");
        uploads.mkdirs(); backups.mkdirs();
        if (!db.exists()) {
            try (InputStream in=getAssets().open("debts.db"); OutputStream out=new FileOutputStream(db)) {
                byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
            } catch(Exception e) { status.setText("خطا در آماده‌سازی پایگاه داده: "+e.getMessage()); }
        }
        getApplicationContext().getFilesDir();
        // Flask reads this path for the database, uploaded images and backups.
        System.setProperty("ZARMANAG_DATA_DIR", data.getAbsolutePath());
    }

    private void startLocalServer() {
        new Thread(() -> {
            try {
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                Python.getInstance().getModule("server").callAttr("start_server", getFilesDir().getAbsolutePath());
                runOnUiThread(() -> showWebView());
            } catch (Throwable e) {
                runOnUiThread(() -> status.setText("اجرای برنامه با خطا مواجه شد:\n"+e.toString()));
            }
        }).start();
    }

    private void showWebView() {
        if (ready) return; ready=true;
        web = new WebView(this);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true); s.setLoadWithOverviewMode(true); s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        web.setBackgroundColor(Color.rgb(244,246,251));
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !"127.0.0.1".equals(r.getUrl().getHost());
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) status.setText("اتصال داخلی برقرار نشد. برنامه را دوباره باز کنید.\n"+e.getDescription());
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=cb;
                Intent i=p.createIntent();
                try { startActivityForResult(i,FILE_REQUEST); } catch(Exception ex){fileCallback=null;return false;}
                return true;
            }
        });
        root.removeAllViews(); root.addView(web,new LinearLayout.LayoutParams(-1,-1));
        web.loadUrl("http://127.0.0.1:5000/");
    }

    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if(req==FILE_REQUEST && fileCallback!=null){
            Uri[] result=WebChromeClient.FileChooserParams.parseResult(res,data);
            fileCallback.onReceiveValue(result); fileCallback=null;
        }
    }

    @Override public void onBackPressed() {
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
