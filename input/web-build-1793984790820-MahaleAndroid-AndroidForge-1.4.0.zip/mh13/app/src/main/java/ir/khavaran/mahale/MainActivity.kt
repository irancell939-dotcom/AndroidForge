package ir.khavaran.mahale

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.view.View
import android.graphics.Color
import android.widget.Toast
import java.io.File
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = FrameLayout(this)
        webView = WebView(this)
        progress = ProgressBar(this)
        progress.isIndeterminate = true
        val params = FrameLayout.LayoutParams(120, 120, android.view.Gravity.CENTER)
        layout.addView(webView, FrameLayout.LayoutParams(-1, -1))
        layout.addView(progress, params)
        layout.setBackgroundColor(Color.rgb(245,247,250))
        setContentView(layout)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
            }
        }
        webView.webChromeClient = WebChromeClient()

        try {
            val dbFile = File(filesDir, "mahalle.db")
            if (!dbFile.exists()) {
                assets.open("mahalle.db").use { input ->
                    dbFile.outputStream().use { output -> input.copyTo(output) }
                }
            }
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
            val py = Python.getInstance()
            py.getModule("launcher").callAttr("start", dbFile.absolutePath)
            webView.postDelayed({ webView.loadUrl("http://127.0.0.1:5004/") }, 1200)
        } catch (e: Exception) {
            progress.visibility = View.GONE
            Toast.makeText(this, "خطا در راه‌اندازی برنامه: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
