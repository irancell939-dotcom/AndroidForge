import os
import threading

def start(database_path):
    os.environ["MAHALE_DB_PATH"] = database_path
    from app import app
    def run():
        app.run(host="127.0.0.1", port=5004, debug=False, use_reloader=False, threaded=True)
    threading.Thread(target=run, daemon=True).start()
