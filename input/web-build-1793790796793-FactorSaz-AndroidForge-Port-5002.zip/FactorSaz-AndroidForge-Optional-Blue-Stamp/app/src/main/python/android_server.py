"""Starts the existing Flask invoice app inside the Android app process."""
import os
import threading
import time

_started = False


def start_server(data_dir):
    global _started
    if _started:
        return
    os.makedirs(data_dir, exist_ok=True)
    os.environ['FACTORSAZ_DATA_DIR'] = data_dir

    # Import only after setting the private writable Android data directory.
    import app as invoice_app
    invoice_app.init_database()

    def serve():
        invoice_app.app.run(
            host='127.0.0.1', port=5002,
            debug=False, threaded=True, use_reloader=False
        )

    threading.Thread(target=serve, name='FactorSaz-Flask', daemon=True).start()
    _started = True
