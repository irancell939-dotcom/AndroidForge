# factorsaz.py - سیستم فاکتورسازی پیشرفته با جستجوی محصولات
from flask import Flask, render_template_string, request, send_file, jsonify
import jdatetime
import os
import webbrowser
import threading
import time
import sqlite3
from io import BytesIO
from reportlab.lib.pagesizes import A4, A5
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle, SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_CENTER
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import json
import traceback
import shutil
from pathlib import Path

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'

PREVIEW_CACHE = {}

APP_DIR = Path(os.environ.get('FACTORSAZ_DATA_DIR', Path(__file__).parent)).resolve()

def setup_directories():
    db_dir = APP_DIR / "database"
    db_dir.mkdir(exist_ok=True)
    font_dir = APP_DIR / "fonts"
    font_dir.mkdir(exist_ok=True)
    pdf_dir = APP_DIR / "pdfs"
    pdf_dir.mkdir(exist_ok=True)
    return APP_DIR, db_dir, font_dir, pdf_dir

USER_DATA_DIR, DB_DIR, FONT_DIR, PDF_DIR = setup_directories()
DB_PATH = str(APP_DIR / 'invoices.db')
# اگر نسخه قبلی دیتابیس در پوشه database باشد، آن را بدون حذف نسخه قبلی منتقل می‌کنیم.
_OLD_DB_PATH = DB_DIR / 'invoices.db'
if not Path(DB_PATH).exists() and _OLD_DB_PATH.exists():
    shutil.copy2(_OLD_DB_PATH, DB_PATH)

# ✅ واحد "حلقه" اضافه شد
UNITS_LIST = ['عدد', 'کارتن', 'بسته', 'رول', 'حلقه', 'تخته', 'کیلوگرم', 'گرم', 'لیتر', 'متر', 'متر مربع', 'متر مکعب', 'جفت', 'دستگاه']

def register_fonts():
    try:
        b_nazanin_path = FONT_DIR / 'BNazanin.ttf'
        b_naznnbd_path = FONT_DIR / 'BNaznnBd.ttf'
        vazir_path = FONT_DIR / 'Vazir.ttf'
        vazir_bold_path = FONT_DIR / 'Vazir-Bold.ttf'

        if b_nazanin_path.exists():
            pdfmetrics.registerFont(TTFont('B-Nazanin', str(b_nazanin_path)))
            if b_naznnbd_path.exists():
                pdfmetrics.registerFont(TTFont('B-Nazanin-Bold', str(b_naznnbd_path)))
            return 'B-Nazanin', 'B-Nazanin-Bold'
        elif vazir_path.exists():
            pdfmetrics.registerFont(TTFont('Vazir', str(vazir_path)))
            if vazir_bold_path.exists():
                pdfmetrics.registerFont(TTFont('Vazir-Bold', str(vazir_bold_path)))
            return 'Vazir', 'Vazir-Bold'
        else:
            if os.path.exists('BNazanin.ttf'):
                pdfmetrics.registerFont(TTFont('B-Nazanin', 'BNazanin.ttf'))
                if os.path.exists('BNaznnBd.ttf'):
                    pdfmetrics.registerFont(TTFont('B-Nazanin-Bold', 'BNaznnBd.ttf'))
                return 'B-Nazanin', 'B-Nazanin-Bold'
            elif os.path.exists('Vazir.ttf'):
                pdfmetrics.registerFont(TTFont('Vazir', 'Vazir.ttf'))
                if os.path.exists('Vazir-Bold.ttf'):
                    pdfmetrics.registerFont(TTFont('Vazir-Bold', 'Vazir-Bold.ttf'))
                return 'Vazir', 'Vazir-Bold'
            else:
                print("⚠️ فونت فارسی یافت نشد")
                return 'Helvetica', 'Helvetica-Bold'
    except Exception as e:
        print(f"⚠️ خطا در ثبت فونت: {e}")
        return 'Helvetica', 'Helvetica-Bold'

FONT_NAME, FONT_NAME_BOLD = register_fonts()

def number_to_persian_words(n):
    if n == 0:
        return "صفر"
    if n < 0:
        return "منفی " + number_to_persian_words(-n)
    yekan = ["", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه"]
    dahgan = ["", "ده", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود"]
    sadgan = ["", "یکصد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد"]
    dah = ["ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده"]

    def _convert_below_1000(num):
        if num == 0:
            return ""
        res = ""
        if num >= 100:
            res += sadgan[num // 100]
            num %= 100
            if num > 0:
                res += " و "
        if 10 <= num <= 19:
            res += dah[num - 10]
        elif num >= 20:
            if num % 10 == 0:
                res += dahgan[num // 10]
            else:
                res += dahgan[num // 10] + " و " + yekan[num % 10]
        elif num < 10:
            res += yekan[num]
        return res

    milliard = n // 1000000000
    n %= 1000000000
    million = n // 1000000
    n %= 1000000
    hezar = n // 1000
    n %= 1000
    baghi = n
    parts = []
    if milliard:
        parts.append("یک میلیارد" if milliard == 1 else _convert_below_1000(milliard) + " میلیارد")
    if million:
        parts.append("یک میلیون" if million == 1 else _convert_below_1000(million) + " میلیون")
    if hezar:
        parts.append("یک هزار" if hezar == 1 else _convert_below_1000(hezar) + " هزار")
    if baghi:
        parts.append(_convert_below_1000(baghi))
    return " و ".join(parts) if parts else "صفر"

def init_database():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                unit TEXT,
                price REAL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS invoices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_number TEXT UNIQUE NOT NULL,
                shop_name TEXT NOT NULL,
                shop_phone TEXT,
                shop_address TEXT,
                buyer_name TEXT NOT NULL,
                buyer_phone TEXT,
                invoice_date TEXT NOT NULL,
                page_size TEXT DEFAULT 'A5',
                discount_type TEXT DEFAULT 'percent',
                discount_value REAL DEFAULT 0,
                discount_amount REAL DEFAULT 0,
                total_amount REAL NOT NULL,
                final_amount REAL NOT NULL,
                items_json TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                template_id INTEGER DEFAULT 1
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE NOT NULL,
                value TEXT
            )
        ''')
        cursor.execute('''
            INSERT OR IGNORE INTO settings (key, value) 
            VALUES ('default_shop_name', 'فروشگاه من'),
                   ('default_shop_phone', ''),
                   ('default_shop_address', ''),
                   ('last_invoice_number', '1000')
        ''')
        # ارتقای امن دیتابیس‌های قبلی
        cursor.execute('PRAGMA table_info(invoices)')
        invoice_columns = [row[1] for row in cursor.fetchall()]
        if 'template_id' not in invoice_columns:
            cursor.execute('ALTER TABLE invoices ADD COLUMN template_id INTEGER DEFAULT 1')
        if 'stamp_enabled' not in invoice_columns:
            cursor.execute('ALTER TABLE invoices ADD COLUMN stamp_enabled INTEGER DEFAULT 0')
        conn.commit()
        conn.close()
        print(f"✅ دیتابیس کنار برنامه در {DB_PATH} ایجاد شد")
    except Exception as e:
        print(f"❌ خطا در ایجاد دیتابیس: {e}")
        raise

def get_products():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT id, name, unit, price FROM products ORDER BY name')
    products = cursor.fetchall()
    conn.close()
    return [{'id': p[0], 'name': p[1], 'unit': p[2], 'price': p[3]} for p in products]

def save_product(name, unit, price):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute('INSERT OR REPLACE INTO products (name, unit, price) VALUES (?, ?, ?)', (name, unit, price))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error saving product: {e}")
        return False
    finally:
        conn.close()

def delete_product(product_id):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM products WHERE id = ?', (product_id,))
    conn.commit()
    conn.close()

# ✅ تابع save_invoice با پشتیبانی از ویرایش
def save_invoice(invoice_data):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        invoice_id = invoice_data.get('id')
        
        if invoice_id:
            cursor.execute('''
                UPDATE invoices SET
                    invoice_number = ?, shop_name = ?, shop_phone = ?, shop_address = ?,
                    buyer_name = ?, buyer_phone = ?, invoice_date = ?, page_size = ?,
                    discount_type = ?, discount_value = ?, discount_amount = ?,
                    total_amount = ?, final_amount = ?, items_json = ?, template_id = ?, stamp_enabled = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (
                invoice_data['invoice_number'],
                invoice_data['shop_name'],
                invoice_data.get('shop_phone', ''),
                invoice_data.get('shop_address', ''),
                invoice_data['buyer_name'],
                invoice_data.get('buyer_phone', ''),
                invoice_data['invoice_date'],
                invoice_data.get('page_size', 'A5'),
                invoice_data.get('discount_type', 'percent'),
                invoice_data.get('discount_value', 0),
                invoice_data.get('discount_amount', 0),
                invoice_data['total_amount'],
                invoice_data['final_amount'],
                json.dumps(invoice_data['items'], ensure_ascii=False),
                int(invoice_data.get('template_id', 1)),
                1 if invoice_data.get('stamp_enabled') else 0,
                invoice_id
            ))
            conn.commit()
            return invoice_id
        else:
            cursor.execute('SELECT value FROM settings WHERE key = "last_invoice_number"')
            last_num = cursor.fetchone()
            last_num = int(last_num[0]) if last_num else 1000

            if not invoice_data.get('invoice_number'):
                invoice_data['invoice_number'] = str(last_num + 1)
                cursor.execute('UPDATE settings SET value = ? WHERE key = "last_invoice_number"', 
                              (str(last_num + 1),))

            cursor.execute('''
                INSERT INTO invoices (
                    invoice_number, shop_name, shop_phone, shop_address,
                    buyer_name, buyer_phone, invoice_date, page_size,
                    discount_type, discount_value, discount_amount,
                    total_amount, final_amount, items_json, template_id, stamp_enabled
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                invoice_data['invoice_number'],
                invoice_data['shop_name'],
                invoice_data.get('shop_phone', ''),
                invoice_data.get('shop_address', ''),
                invoice_data['buyer_name'],
                invoice_data.get('buyer_phone', ''),
                invoice_data['invoice_date'],
                invoice_data.get('page_size', 'A5'),
                invoice_data.get('discount_type', 'percent'),
                invoice_data.get('discount_value', 0),
                invoice_data.get('discount_amount', 0),
                invoice_data['total_amount'],
                invoice_data['final_amount'],
                json.dumps(invoice_data['items'], ensure_ascii=False),
                int(invoice_data.get('template_id', 1)),
                1 if invoice_data.get('stamp_enabled') else 0
            ))
            conn.commit()
            return cursor.lastrowid
    except Exception as e:
        print(f"Error saving invoice: {e}")
        return None
    finally:
        conn.close()

def get_invoices():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, invoice_number, shop_name, buyer_name,
        invoice_date, total_amount, final_amount, created_at
        FROM invoices ORDER BY created_at DESC
    ''')
    invoices = cursor.fetchall()
    conn.close()
    return [{
        'id': i[0], 'invoice_number': i[1], 'shop_name': i[2], 'buyer_name': i[3],
        'invoice_date': i[4], 'total_amount': i[5], 'final_amount': i[6], 'created_at': i[7]
    } for i in invoices]


def lookup_product_unit(product_name):
    try:
        with sqlite3.connect(DB_PATH) as conn:
            row = conn.execute('SELECT unit FROM products WHERE name = ?', (product_name,)).fetchone()
            return row[0] if row and row[0] else ''
    except Exception:
        return ''

def resolve_item_units(items):
    """واحد اقلام قدیمی/خالی را از فهرست کالاها بازیابی می‌کند."""
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        for item in items:
            unit = str(item.get('unit') or '').strip()
            if not unit and item.get('name'):
                cur.execute('SELECT unit FROM products WHERE name = ?', (str(item['name']).strip(),))
                row = cur.fetchone()
                if row and row[0]:
                    item['unit'] = row[0]
                else:
                    item['unit'] = '—'
        conn.close()
    except Exception:
        for item in items:
            item['unit'] = str(item.get('unit') or '—')
    return items

def get_invoice_by_id(invoice_id):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM invoices WHERE id = ?', (invoice_id,))
    invoice = cursor.fetchone()
    conn.close()
    if invoice:
        return {
            'id': invoice[0], 'invoice_number': invoice[1], 'shop_name': invoice[2],
            'shop_phone': invoice[3], 'shop_address': invoice[4], 'buyer_name': invoice[5],
            'buyer_phone': invoice[6], 'invoice_date': invoice[7], 'page_size': invoice[8],
            'discount_type': invoice[9], 'discount_value': invoice[10],
            'discount_amount': invoice[11], 'total_amount': invoice[12],
            'final_amount': invoice[13], 'items': resolve_item_units(json.loads(invoice[14])),
            'created_at': invoice[15], 'updated_at': invoice[16],
            'template_id': invoice[17] if len(invoice) > 17 else 1,
            'stamp_enabled': bool(invoice[18]) if len(invoice) > 18 else False
        }
    return None

def delete_invoice(invoice_id):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM invoices WHERE id = ?', (invoice_id,))
    conn.commit()
    conn.close()

def get_settings():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT key, value FROM settings')
    settings = cursor.fetchall()
    conn.close()
    return {s[0]: s[1] for s in settings}

def intcomma(value):
    try:
        return f"{int(value):,}".replace(",", "٬")
    except:
        try:
            return f"{float(value):,}".replace(",", "٬")
        except:
            return str(value)

# ✅ حذف .0 از اعداد صحیح
def format_qty(value):
    try:
        num = float(value)
        if num == int(num):
            return str(int(num))
        return str(num)
    except:
        return str(value)

app.jinja_env.filters['intcomma'] = intcomma
app.jinja_env.filters['format_qty'] = format_qty

HTML_TEMPLATE = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>سیستم فاکتورسازی</title>
<style>
* { box-sizing: border-box; font-family: Tahoma, sans-serif; }
body { background: #f0f2f5; margin: 0; padding: 20px; color: #333; }
.container { max-width: 1100px; margin: 0 auto; background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
h1 { text-align: center; color: #2b6cb0; margin-bottom: 25px; }
.nav-tabs { display: flex; background: #f8fafc; border-radius: 8px; padding: 5px; margin-bottom: 25px; }
.nav-tab { flex: 1; padding: 12px; text-align: center; cursor: pointer; border-radius: 6px; font-weight: bold; }
.nav-tab.active { background: #4CAF50; color: white; }
.tab-content { display: none; }
.tab-content.active { display: block; }
.form-section { margin-bottom: 20px; padding: 20px; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; }
.section-title { color: #2d3748; margin-bottom: 15px; border-bottom: 2px solid #4CAF50; padding-bottom: 8px; }
.form-row { display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 15px; }
.form-group { flex: 1; min-width: 220px; }
label { display: block; margin-bottom: 5px; font-weight: bold; font-size: 13px; }
input, select, textarea { width: 100%; padding: 8px 12px; border: 1px solid #cbd5e0; border-radius: 6px; font-size: 13px; }
input:focus, select:focus { outline: none; border-color: #4CAF50; }
.items-table { width: 100%; border-collapse: collapse; margin: 15px 0; }
.items-table th { background: #4CAF50; color: white; padding: 10px 8px; text-align: center; font-size: 13px; }
.items-table td { padding: 8px; border-bottom: 1px solid #e2e8f0; text-align: center; }
.items-table input, .items-table select { padding: 6px; font-size: 12px; }
.btn { padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: bold; margin: 5px; }
.btn-add { background: #4CAF50; color: white; }
.btn-generate { background: #FF9800; color: white; }
.btn-save { background: #2196F3; color: white; }
.btn-remove { background: #f44336; color: white; padding: 6px 12px; font-size: 12px; border-radius: 4px; border: none; cursor: pointer; }
.size-options { display: flex; gap: 10px; margin: 10px 0; justify-content: center; }
.size-option { padding: 10px 20px; border: 2px solid #cbd5e0; border-radius: 6px; cursor: pointer; font-weight: bold; }
.size-option.selected { border-color: #4CAF50; background: #4CAF50; color: white; }
.total-display { background: #e8f5e9; padding: 15px; border-radius: 8px; margin-top: 15px; text-align: center; font-size: 16px; border: 2px solid #4CAF50; }
.discount-section { background: #fff3e0; padding: 15px; border-radius: 8px; margin-top: 15px; border: 2px solid #FF9800; }
.final-total { background: #e3f2fd; padding: 15px; border-radius: 8px; margin-top: 15px; text-align: center; font-size: 18px; border: 2px solid #2196F3; color: #0d47a1; }
.invoices-table { width: 100%; border-collapse: collapse; margin: 15px 0; }
.invoices-table th { background: #2b6cb0; color: white; padding: 10px; text-align: center; }
.invoices-table td { padding: 10px; border-bottom: 1px solid #e2e8f0; text-align: center; }
.btn-edit { background: #2196F3; color: white; padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 12px; border: none; }
.btn-delete { background: #f44336; color: white; padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 12px; border: none; }
.btn-download { background: #4CAF50; color: white; padding: 5px 10px; border-radius: 4px; text-decoration: none; font-size: 12px; }
.btn-print { background: #FF9800; color: white; padding: 5px 10px; border-radius: 4px; text-decoration: none; font-size: 12px; }
.editing-notice { background: #fff3cd; border: 2px solid #ffc107; padding: 12px; border-radius: 6px; margin-bottom: 15px; text-align: center; font-weight: bold; display: none; }
.products-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px; }
.product-card { background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; }
.autocomplete { position: relative; }
.autocomplete-items { position: absolute; border: 1px solid #ddd; border-top: none; z-index: 99; top: 100%; left: 0; right: 0; background: white; max-height: 200px; overflow-y: auto; }
.autocomplete-item { padding: 8px 12px; cursor: pointer; border-bottom: 1px solid #f1f1f1; }
.autocomplete-item:hover { background: #f1f1f1; }
.template-swatches{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.swatch{width:34px;height:34px;border-radius:8px;display:grid;place-items:center;color:white;font-weight:bold;box-shadow:0 2px 5px #0002}.t1{background:#2563eb}.t2{background:#16834a}.t3{background:#b58a32}.t4{background:#9f1239}.t5{background:#64748b}.t6{background:#0891b2}.t7{background:#6d28d9}.t8{background:#ea580c}.t9{background:#172554}.t10{background:#db2777}
.template-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:12px;margin:12px 0}.template-card{background:#fff;border:2px solid #d8dee9;border-radius:10px;padding:12px 8px;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:9px;min-height:86px;transition:.15s}.template-card:hover{transform:translateY(-2px);box-shadow:0 4px 12px #0002}.template-card.selected{border-color:#2563eb;box-shadow:0 0 0 3px #2563eb22;background:#f8fbff}.template-card b{font-size:12px;color:#263449}.template-card .mini-lines{display:block;width:78px;height:35px;border-top:4px solid var(--tone);border-bottom:2px solid var(--tone);position:relative}.template-card .mini-lines:before{content:'';position:absolute;top:8px;left:8px;right:8px;border-top:2px dashed var(--tone)}.template-card .mini-lines:after{content:'';position:absolute;top:17px;left:18px;right:18px;border-top:3px double var(--tone)}.template-card.t1{--tone:#2563eb}.template-card.t2{--tone:#16834a}.template-card.t3{--tone:#b58a32}.template-card.t4{--tone:#9f1239}.template-card.t5{--tone:#64748b}.template-card.t6{--tone:#0891b2}.template-card.t7{--tone:#6d28d9}.template-card.t8{--tone:#ea580c}.template-card.t9{--tone:#172554}.template-card.t10{--tone:#db2777}


/* ✅ استایل‌های جستجوی محصولات */
.search-container {
    margin-bottom: 20px;
    position: relative;
}
.search-input {
    width: 100%;
    padding: 12px 45px 12px 15px;
    border: 2px solid #cbd5e0;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.3s;
}
.search-input:focus {
    outline: none;
    border-color: #4CAF50;
    box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1);
}
.search-icon {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 18px;
    color: #718096;
    pointer-events: none;
}
.clear-search {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    background: #f44336;
    color: white;
    border: none;
    border-radius: 50%;
    width: 24px;
    height: 24px;
    cursor: pointer;
    font-size: 14px;
    display: none;
    align-items: center;
    justify-content: center;
}
.search-stats {
    margin-top: 10px;
    font-size: 13px;
    color: #718096;
    text-align: center;
}
.no-results {
    text-align: center;
    padding: 40px 20px;
    color: #718096;
    font-size: 16px;
    background: #f8fafc;
    border-radius: 8px;
    border: 2px dashed #cbd5e0;
}

/* طراحی واکنش‌گرا برای موبایل و تبلت: بدون نیاز به زوم افقی صفحه */
html { -webkit-text-size-adjust: 100%; text-size-adjust: 100%; }
body { min-width: 0; }
.container { width: 100%; min-width: 0; }
img, svg, canvas { max-width: 100%; height: auto; }
button, .btn, .nav-tab, .template-card, .size-option { touch-action: manipulation; }
input, select, textarea { min-height: 44px; font-size: 16px; }
textarea { min-height: 88px; }
.table-scroll, .items-table-wrap, .invoices-table-wrap { max-width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; }
@media (max-width: 900px) {
  body { padding: 12px; }
  .container { padding: 18px; }
  .form-row { gap: 12px; }
  .form-group { min-width: min(100%, 240px); }
  .products-grid { grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); }
}
@media (max-width: 640px) {
  body { padding: 0; background: #f7f8fa; }
  .container { width: 100%; max-width: none; margin: 0; padding: 12px 10px 24px; border-radius: 0; box-shadow: none; }
  h1 { font-size: 21px; line-height: 1.5; margin: 8px 0 16px; }
  h2 { font-size: 18px; }
  .nav-tabs { display: flex; gap: 6px; overflow-x: auto; padding: 5px; margin: 0 -2px 16px; scrollbar-width: thin; }
  .nav-tab { flex: 0 0 auto; min-width: 105px; padding: 12px 10px; font-size: 13px; white-space: nowrap; }
  .form-section { padding: 13px 10px; margin-bottom: 13px; border-radius: 11px; }
  .section-title { font-size: 16px; margin-bottom: 12px; }
  .form-row { display: grid; grid-template-columns: minmax(0, 1fr); gap: 10px; margin-bottom: 10px; }
  .form-group { min-width: 0; width: 100%; }
  label { font-size: 13px; margin-bottom: 6px; }
  input, select, textarea { width: 100%; max-width: 100%; padding: 11px 12px; border-radius: 8px; }
  .items-table, .invoices-table { display: block; width: 100%; max-width: 100%; overflow-x: auto; white-space: nowrap; -webkit-overflow-scrolling: touch; }
  .items-table { min-width: 0; }
  .items-table th, .items-table td, .invoices-table th, .invoices-table td { padding: 9px 7px; font-size: 12px; }
  .items-table input, .items-table select { min-width: 92px; font-size: 14px; padding: 8px; }
  .btn { min-height: 44px; padding: 11px 14px; margin: 4px 2px; font-size: 14px; }
  .btn-remove, .btn-edit, .btn-delete, .btn-download, .btn-print { min-height: 40px; padding: 9px 10px; }
  .size-options { flex-wrap: wrap; gap: 8px; }
  .size-option { flex: 1 1 42%; text-align: center; padding: 11px 8px; }
  .total-display, .discount-section, .final-total { padding: 12px 10px; font-size: 15px; }
  .products-grid { grid-template-columns: minmax(0, 1fr); gap: 10px; }
  .product-card { padding: 12px; }
  .template-cards { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }
  .template-card { min-width: 0; min-height: 88px; padding: 10px 6px; }
  .template-card b { font-size: 11px; text-align: center; }
  .editing-notice { font-size: 13px; padding: 10px; }
  .search-input { min-height: 48px; font-size: 16px; }
  .autocomplete-items { max-height: 180px; }
  .final-total { overflow-wrap: anywhere; }
}
@media (max-width: 380px) {
  .container { padding-left: 8px; padding-right: 8px; }
  .template-cards { grid-template-columns: minmax(0, 1fr); }
  .btn { width: 100%; margin: 4px 0; }
  .size-option { flex-basis: 100%; }
}
</style>
<script>
let selectedSize = 'A5';
function chooseInvoiceTemplate(id) {
    document.getElementById('templateId').value = String(id);
    document.querySelectorAll('.template-card').forEach(card => {
        card.classList.toggle('selected', Number(card.dataset.template) === Number(id));
    });
}

const unitsList = {{ units|tojson }};
let products = {{ products|tojson }};
let editingInvoiceId = null;

function selectSize(size) {
    selectedSize = size;
    document.querySelectorAll('.size-option').forEach(opt => opt.classList.remove('selected'));
    const el = document.querySelector(`.size-option[data-size="${size}"]`);
    if (el) el.classList.add('selected');
    document.getElementById('pageSize').value = size;
}

function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.nav-tab').forEach(tab => tab.classList.remove('active'));
    document.getElementById(tabName + '-tab').classList.add('active');
    document.getElementById(tabName).classList.add('active');
    if (tabName === 'products') loadProducts();
    if (tabName === 'invoices') loadInvoices();
}

function formatQtyValue(val) {
    if (val === null || val === undefined || val === '') return '';
    const num = parseFloat(val);
    if (isNaN(num)) return '';
    if (num === Math.floor(num)) return Math.floor(num).toString();
    return num.toString();
}

function formatQtyDisplay(input) {
    const val = parseFloat(input.value);
    if (isNaN(val)) return;
    if (val === Math.floor(val)) input.value = Math.floor(val);
}

function addItemRow(itemData = null) {
    const table = document.getElementById('itemsTable');
    const tbody = table.querySelector('tbody');
    const rowCount = tbody.rows.length + 1;
    let unitOptions = '<option value="">انتخاب واحد</option>';
    unitsList.forEach(unit => {
        unitOptions += `<option value="${unit}">${unit}</option>`;
    });
    const newRow = document.createElement('tr');
    newRow.innerHTML = `
        <td>${rowCount}</td>
        <td>
            <div class="autocomplete">
                <input type="text" name="item_name" required placeholder="نام کالا" 
                       class="item-name-input" oninput="showProductSuggestions(this)" 
                       value="${itemData ? itemData.name : ''}">
                <div class="autocomplete-items"></div>
            </div>
        </td>
        <td><input type="number" name="item_qty" step="1" min="0" required placeholder="0" 
            class="qty-input" value="${itemData ? formatQtyValue(itemData.qty) : ''}" 
            onblur="formatQtyDisplay(this)"></td>
        <td><select name="item_unit" class="unit-select">${unitOptions}</select></td>
        <td><input type="number" name="item_price" step="0.01" min="0" required placeholder="0" 
            class="price-input" value="${itemData ? itemData.price : ''}"></td>
        <td><span class="total-cell">0</span></td>
        <td>
            <button type="button" class="btn-remove" onclick="removeRow(this)">🗑️</button>
            <button type="button" class="btn-remove" onclick="saveProductFromRow(this)" style="background: #2196F3;">💾</button>
        </td>
    `;
    tbody.appendChild(newRow);
    if (itemData && itemData.unit) {
        newRow.querySelector('.unit-select').value = itemData.unit;
    }
    const qtyInput = newRow.querySelector('.qty-input');
    const priceInput = newRow.querySelector('.price-input');
    qtyInput.addEventListener('input', calculateAllTotals);
    priceInput.addEventListener('input', calculateAllTotals);
    updateRowNumbers();
    calculateAllTotals();
}

function showProductSuggestions(input) {
    const value = input.value.toLowerCase();
    const suggestionsDiv = input.parentNode.querySelector('.autocomplete-items');
    suggestionsDiv.innerHTML = '';
    if (value.length < 2) return;
    const filteredProducts = products.filter(product => product.name.toLowerCase().includes(value));
    filteredProducts.forEach(product => {
        const div = document.createElement('div');
        div.className = 'autocomplete-item';
        div.innerHTML = `<strong>${product.name}</strong> - ${product.unit || ''} - ${product.price || 0}`;
        div.onclick = function() {
            input.value = product.name;
            const row = input.closest('tr');
            row.querySelector('.unit-select').value = product.unit || '';
            row.querySelector('.price-input').value = product.price || '';
            suggestionsDiv.innerHTML = '';
            calculateAllTotals();
        };
        suggestionsDiv.appendChild(div);
    });
}

function saveProductFromRow(button) {
    const row = button.closest('tr');
    const name = row.querySelector('.item-name-input').value.trim();
    const unit = row.querySelector('.unit-select').value;
    const price = parseFloat(row.querySelector('.price-input').value) || 0;
    if (!name) { alert('نام محصول را وارد کنید'); return; }
    fetch('/save_product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, unit, price })
    }).then(r => r.json()).then(data => {
        if (data.success) {
            alert('محصول ذخیره شد');
            products.push({name, unit, price});
            // ✅ به‌روزرسانی جستجو در صورت فعال بودن
            const searchInput = document.getElementById('productSearch');
            if (searchInput && searchInput.value.trim()) {
                filterProducts();
            } else {
                loadProducts();
            }
        }
    });
}

function removeRow(button) {
    if (confirm('حذف این ردیف؟')) {
        button.closest('tr').remove();
        updateRowNumbers();
        calculateAllTotals();
    }
}

function updateRowNumbers() {
    document.querySelectorAll('#itemsTable tbody tr').forEach((row, index) => {
        row.cells[0].textContent = index + 1;
    });
}

function calculateAllTotals() {
    const rows = document.querySelectorAll('#itemsTable tbody tr');
    let grandTotal = 0;
    rows.forEach(row => {
        const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
        const price = parseFloat(row.querySelector('.price-input').value) || 0;
        const total = qty * price;
        row.querySelector('.total-cell').textContent = total.toLocaleString('fa-IR');
        grandTotal += total;
    });
    document.getElementById('grandTotal').textContent = grandTotal.toLocaleString('fa-IR') + ' تومان';
    const discountType = document.querySelector('input[name="discount_type"]:checked').value;
    const discountValue = parseFloat(document.getElementById('discountValue').value) || 0;
    let discountAmount = 0;
    if (discountType === 'percent') discountAmount = (grandTotal * discountValue) / 100;
    else if (discountType === 'amount') discountAmount = discountValue;
    const finalTotal = grandTotal - discountAmount;
    document.getElementById('discountAmount').textContent = discountAmount.toLocaleString('fa-IR') + ' تومان';
    document.getElementById('finalTotal').textContent = finalTotal.toLocaleString('fa-IR') + ' تومان';
}

function openInvoiceLink(url) {
    const absoluteUrl = new URL(url, window.location.href).href;
    if (window.AndroidBridge && AndroidBridge.openExternal) AndroidBridge.openExternal(absoluteUrl);
    else window.open(absoluteUrl, '_blank');
}

function generatePreview() {
    const form = document.querySelector('#invoiceForm');
    const formData = new FormData(form);
    if (!formData.get('shop_name')) { alert('نام فروشگاه را وارد کنید'); return; }
    if (!formData.get('buyer_name')) { alert('نام خریدار را وارد کنید'); return; }
    let hasItems = false;
    formData.getAll('item_name').forEach(name => { if (name.trim()) hasItems = true; });
    if (!hasItems) { alert('حداقل یک کالا وارد کنید'); return; }
    const tempForm = document.createElement('form');
    tempForm.method = 'POST';
    tempForm.action = '/generate';
    tempForm.target = '_blank';
    tempForm.style.display = 'none';
    Array.from(form.elements).forEach(element => {
        if (element.name && !element.disabled) {
            const clone = element.cloneNode(true);
            // cloneNode وضعیت انتخاب‌شده‌ی select و مقدار جاری بعضی کنترل‌ها را منتقل نمی‌کند.
            if (element.tagName === 'SELECT') {
                Array.from(clone.options).forEach((option, index) => {
                    option.selected = element.options[index].selected;
                });
            } else if (element.type === 'checkbox' || element.type === 'radio') {
                clone.checked = element.checked;
            } else {
                clone.value = element.value;
            }
            tempForm.appendChild(clone);
        }
    });
    document.body.appendChild(tempForm);
    tempForm.submit();
    document.body.removeChild(tempForm);
}

function saveInvoice() {
    const form = document.querySelector('#invoiceForm');
    const formData = new FormData(form);
    const data = {
        id: editingInvoiceId,
        shop_name: formData.get('shop_name'),
        shop_phone: formData.get('shop_phone'),
        shop_address: formData.get('shop_address'),
        buyer_name: formData.get('buyer_name'),
        buyer_phone: formData.get('buyer_phone'),
        invoice_number: formData.get('invoice_number'),
        invoice_date: formData.get('invoice_date'),
        page_size: formData.get('page_size'),
        template_id: parseInt(formData.get('template_id') || '1'),
        stamp_enabled: formData.get('stamp_enabled') === '1',
        discount_type: formData.get('discount_type'),
        discount_value: parseFloat(formData.get('discount_value')) || 0,
        items: [],
        total_amount: 0,
        final_amount: 0
    };
    const itemNames = formData.getAll('item_name');
    const itemQtys = formData.getAll('item_qty');
    const itemUnits = formData.getAll('item_unit');
    const itemPrices = formData.getAll('item_price');
    let totalSum = 0;
    for (let i = 0; i < itemNames.length; i++) {
        if (itemNames[i].trim()) {
            const qty = parseFloat(itemQtys[i]) || 0;
            const price = parseFloat(itemPrices[i]) || 0;
            const total = qty * price;
            totalSum += total;
            data.items.push({ name: itemNames[i].trim(), qty, unit: itemUnits[i] || '', price, total });
        }
    }
    data.total_amount = totalSum;
    let discountAmount = 0;
    if (data.discount_type === 'percent') discountAmount = (totalSum * data.discount_value) / 100;
    else if (data.discount_type === 'amount') discountAmount = data.discount_value;
    data.discount_amount = discountAmount;
    data.final_amount = totalSum - discountAmount;
    fetch('/save_invoice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }).then(r => r.json()).then(result => {
        if (result.success) {
            const msg = editingInvoiceId ? '✅ فاکتور ویرایش شد!' : '✅ فاکتور ذخیره شد!';
            alert(msg + ' شماره: ' + result.invoice_number);
            if (editingInvoiceId) {
                editingInvoiceId = null;
                document.getElementById('editingNotice').style.display = 'none';
            }
        } else {
            alert('خطا: ' + result.message);
        }
    });
}

// ✅ تابع بارگذاری محصولات با پشتیبانی از جستجو
function loadProducts() {
    fetch('/get_products').then(r => r.json()).then(data => {
        products = data; // به‌روزرسانی لیست محصولات
        renderProductsList(data);
    });
}

// ✅ تابع رندر لیست محصولات (قابل فیلتر)
function renderProductsList(productsToRender) {
    const container = document.getElementById('productsList');
    const searchInput = document.getElementById('productSearch');
    const clearBtn = document.getElementById('clearSearch');
    const statsDiv = document.getElementById('searchStats');
    
    if (productsToRender.length === 0) {
        const searchTerm = searchInput ? searchInput.value.trim() : '';
        if (searchTerm) {
            container.innerHTML = `<div class="no-results">
                🔍 محصولی با عبارت "<strong>${searchTerm}</strong>" یافت نشد
            </div>`;
            if (statsDiv) statsDiv.textContent = `نتیجه‌ای یافت نشد`;
        } else {
            container.innerHTML = '<div class="no-results">هنوز محصولی ثبت نشده است</div>';
            if (statsDiv) statsDiv.textContent = '';
        }
        return;
    }
    
    // ✅ نمایش آمار جستجو
    if (statsDiv) {
        const searchTerm = searchInput ? searchInput.value.trim() : '';
        if (searchTerm) {
            statsDiv.textContent = `${productsToRender.length} محصول از ${products.length} محصول یافت شد`;
            if (clearBtn) clearBtn.style.display = 'flex';
        } else {
            statsDiv.textContent = `مجموع: ${products.length} محصول`;
            if (clearBtn) clearBtn.style.display = 'none';
        }
    }
    
    let html = '<div class="products-grid">';
    productsToRender.forEach(product => {
        html += `<div class="product-card">
            <div style="font-weight: bold; margin-bottom: 8px; font-size: 16px;">${product.name}</div>
            <div style="margin-bottom: 5px;">📦 واحد: <strong>${product.unit || 'ندارد'}</strong></div>
            <div style="margin-bottom: 10px;">💰 قیمت: <strong style="color: #388E3C;">${product.price ? product.price.toLocaleString('fa-IR') : '0'} تومان</strong></div>
            <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                <button class="btn-remove" onclick="useProduct(${product.id})" style="background: #4CAF50; flex: 1;">✅ استفاده</button>
                <button class="btn-remove" onclick="deleteProduct(${product.id})" style="flex: 1;">🗑️ حذف</button>
            </div>
        </div>`;
    });
    html += '</div>';
    container.innerHTML = html;
}

// ✅ تابع فیلتر محصولات بر اساس جستجو
function filterProducts() {
    const searchInput = document.getElementById('productSearch');
    const searchTerm = searchInput.value.trim().toLowerCase();
    
    if (!searchTerm) {
        renderProductsList(products);
        return;
    }
    
    const filtered = products.filter(product => {
        const name = (product.name || '').toLowerCase();
        const unit = (product.unit || '').toLowerCase();
        const priceStr = (product.price || 0).toString();
        return name.includes(searchTerm) || 
               unit.includes(searchTerm) || 
               priceStr.includes(searchTerm);
    });
    
    renderProductsList(filtered);
}

// ✅ پاک کردن جستجو
function clearSearch() {
    const searchInput = document.getElementById('productSearch');
    if (searchInput) {
        searchInput.value = '';
        filterProducts();
        searchInput.focus();
    }
}

function useProduct(productId) {
    fetch(`/get_product/${productId}`).then(r => r.json()).then(product => {
        addItemRow(product);
        switchTab('create');
    });
}

function deleteProduct(productId) {
    if (confirm('حذف محصول؟')) {
        fetch(`/delete_product/${productId}`, { method: 'DELETE' })
            .then(r => r.json()).then(() => {
                // ✅ به‌روزرسانی لیست پس از حذف با حفظ فیلتر جستجو
                const searchInput = document.getElementById('productSearch');
                const searchTerm = searchInput ? searchInput.value.trim() : '';
                loadProducts().then(() => {
                    if (searchTerm) {
                        setTimeout(filterProducts, 100);
                    }
                });
            });
    }
}

function loadInvoices() {
    fetch('/get_invoices').then(r => r.json()).then(data => {
        const container = document.getElementById('invoicesList');
        if (data.length === 0) {
            container.innerHTML = '<div>هنوز فاکتوری ثبت نشده</div>';
            return;
        }
        let html = `<table class="invoices-table">
            <thead><tr><th>شماره</th><th>فروشگاه</th><th>خریدار</th><th>تاریخ</th><th>مبلغ کل</th><th>مبلغ نهایی</th><th>عملیات</th></tr></thead><tbody>`;
        data.forEach(invoice => {
            html += `<tr>
                <td>${invoice.invoice_number}</td>
                <td>${invoice.shop_name}</td>
                <td>${invoice.buyer_name}</td>
                <td>${invoice.invoice_date}</td>
                <td>${invoice.total_amount.toLocaleString('fa-IR')}</td>
                <td>${invoice.final_amount.toLocaleString('fa-IR')}</td>
                <td>
                    <button type="button" class="btn-print" onclick="openInvoiceLink('/print_invoice/${invoice.id}')">🖨️ چاپ</button>
                    <a href="/generate_pdf/${invoice.id}" class="btn-download" target="_blank">PDF</a>
                    <button class="btn-edit" onclick="editInvoice(${invoice.id})">ویرایش</button>
                    <button class="btn-delete" onclick="deleteInvoice(${invoice.id})">حذف</button>
                </td>
            </tr>`;
        });
        html += '</tbody></table>';
        container.innerHTML = html;
    });
}

function editInvoice(invoiceId) {
    fetch(`/get_invoice/${invoiceId}`)
        .then(r => r.json())
        .then(invoice => {
            if (invoice.error) {
                alert('خطا: ' + invoice.error);
                return;
            }
            document.getElementById('shop_name').value = invoice.shop_name || '';
            document.getElementById('shop_phone').value = invoice.shop_phone || '';
            document.getElementById('shop_address').value = invoice.shop_address || '';
            document.getElementById('stamp_enabled').checked = !!invoice.stamp_enabled;
            document.getElementById('buyer_name').value = invoice.buyer_name || '';
            document.getElementById('buyer_phone').value = invoice.buyer_phone || '';
            document.getElementById('invoice_number').value = invoice.invoice_number || '';
            document.getElementById('invoice_date').value = invoice.invoice_date || '';
            
            selectSize(invoice.page_size || 'A5');
            chooseInvoiceTemplate(invoice.template_id || 1);
            
            const discountRadio = document.querySelector(`input[name="discount_type"][value="${invoice.discount_type}"]`);
            if (discountRadio) discountRadio.checked = true;
            document.getElementById('discountValue').value = invoice.discount_value || 0;
            
            const tbody = document.querySelector('#itemsTable tbody');
            tbody.innerHTML = '';
            
            if (invoice.items && invoice.items.length > 0) {
                invoice.items.forEach(item => addItemRow(item));
            } else {
                addItemRow();
            }
            
            editingInvoiceId = invoiceId;
            document.getElementById('editingNotice').style.display = 'block';
            document.getElementById('editingInvoiceNumber').textContent = invoice.invoice_number;
            
            calculateAllTotals();
            switchTab('create');
            alert('✅ فاکتور بارگذاری شد. پس از ویرایش روی "ذخیره فاکتور" کلیک کنید.');
        })
        .catch(err => {
            console.error('Error:', err);
            alert('خطا در بارگذاری فاکتور: ' + err);
        });
}

function deleteInvoice(invoiceId) {
    if (confirm('حذف فاکتور؟')) {
        fetch(`/delete_invoice/${invoiceId}`, { method: 'DELETE' })
            .then(r => r.json()).then(() => loadInvoices());
    }
}

function cancelEdit() {
    if (confirm('لغو ویرایش؟')) {
        editingInvoiceId = null;
        document.getElementById('editingNotice').style.display = 'none';
        document.getElementById('invoiceForm').reset();
        document.querySelector('#itemsTable tbody').innerHTML = '';
        addItemRow();
        document.getElementById('shop_name').value = '{{ settings.default_shop_name }}';
        document.getElementById('invoice_date').value = '{{ current_date }}';
        calculateAllTotals();
    }
}

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('input[name="discount_type"]').forEach(input => {
        input.addEventListener('change', calculateAllTotals);
    });
    document.getElementById('discountValue').addEventListener('input', calculateAllTotals);
    selectSize('A5');
    calculateAllTotals();
    loadProducts();
    addItemRow();
    
    // ✅ اضافه کردن event listener برای جستجوی محصولات
    const searchInput = document.getElementById('productSearch');
    if (searchInput) {
        searchInput.addEventListener('input', filterProducts);
        // پشتیبانی از کلید Escape برای پاک کردن جستجو
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                clearSearch();
            }
        });
    }
});
</script>
</head>
<body>
<div class="container">
<h1>📄 سیستم فاکتورسازی</h1>

<div id="editingNotice" class="editing-notice">
    ⚠️ در حال ویرایش فاکتور شماره: <span id="editingInvoiceNumber"></span>
    <button onclick="cancelEdit()" style="margin-right: 15px; background: #f44336; color: white; border: none; padding: 5px 15px; border-radius: 5px; cursor: pointer;">لغو</button>
</div>

<div class="nav-tabs">
    <div class="nav-tab active" onclick="switchTab('create')" id="create-tab">ایجاد فاکتور</div>
    <div class="nav-tab" onclick="switchTab('products')" id="products-tab">محصولات</div>
    <div class="nav-tab" onclick="switchTab('invoices')" id="invoices-tab">فاکتورها</div>
</div>

<div id="create" class="tab-content active">
    <form id="invoiceForm">
        <input type="hidden" name="page_size" id="pageSize" value="A5">
        <div class="form-section template-picker">
            <h2 class="section-title">🎨 انتخاب طرح ظاهری فاکتور</h2>
            <input type="hidden" name="template_id" id="templateId" value="1">
            <div class="template-cards" role="group" aria-label="انتخاب مدل فاکتور">
              <button type="button" class="template-card t1 selected" data-template="1" onclick="chooseInvoiceTemplate(1)"><i class="mini-lines"></i><b>۱ ـ رسمی آبی</b></button>
              <button type="button" class="template-card t2" data-template="2" onclick="chooseInvoiceTemplate(2)"><i class="mini-lines"></i><b>۲ ـ سبز کلاسیک</b></button>
              <button type="button" class="template-card t3" data-template="3" onclick="chooseInvoiceTemplate(3)"><i class="mini-lines"></i><b>۳ ـ مشکی و طلایی</b></button>
              <button type="button" class="template-card t4" data-template="4" onclick="chooseInvoiceTemplate(4)"><i class="mini-lines"></i><b>۴ ـ زرشکی لوکس</b></button>
              <button type="button" class="template-card t5" data-template="5" onclick="chooseInvoiceTemplate(5)"><i class="mini-lines"></i><b>۵ ـ مینیمال خاکستری</b></button>
              <button type="button" class="template-card t6" data-template="6" onclick="chooseInvoiceTemplate(6)"><i class="mini-lines"></i><b>۶ ـ فیروزه‌ای مدرن</b></button>
              <button type="button" class="template-card t7" data-template="7" onclick="chooseInvoiceTemplate(7)"><i class="mini-lines"></i><b>۷ ـ بنفش سلطنتی</b></button>
              <button type="button" class="template-card t8" data-template="8" onclick="chooseInvoiceTemplate(8)"><i class="mini-lines"></i><b>۸ ـ نارنجی تجاری</b></button>
              <button type="button" class="template-card t9" data-template="9" onclick="chooseInvoiceTemplate(9)"><i class="mini-lines"></i><b>۹ ـ سرمه‌ای شرکتی</b></button>
              <button type="button" class="template-card t10" data-template="10" onclick="chooseInvoiceTemplate(10)"><i class="mini-lines"></i><b>۱۰ ـ صورتی ظریف</b></button>
            </div>
            <small>برای انتخاب مدل، روی کارت دلخواه کلیک کنید. مدل انتخابی در فاکتور ذخیره و هنگام چاپ و PDF استفاده می‌شود.</small>
        </div>
        
        <div class="form-section">
            <h2 class="section-title">🏪 اطلاعات فروشگاه</h2>
            <div class="form-row">
                <div class="form-group">
                    <label>نام فروشگاه *:</label>
                    <input type="text" name="shop_name" id="shop_name" required value="{{ settings.default_shop_name }}">
                </div>
                <div class="form-group">
                    <label>تلفن:</label>
                    <input type="text" name="shop_phone" id="shop_phone" value="{{ settings.default_shop_phone }}">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>آدرس:</label>
                    <textarea name="shop_address" id="shop_address" rows="2">{{ settings.default_shop_address }}</textarea>
                </div>
            </div>
            <label class="stamp-option" style="display:flex;align-items:center;gap:9px;margin-top:12px;padding:10px 12px;background:#eef6ff;border:1px solid #b7d5f5;border-radius:10px;">
                <input type="checkbox" name="stamp_enabled" id="stamp_enabled" value="1" style="width:20px;height:20px;">
                <span>درج مهر آبی فروشگاه زیر امضای فروشنده (اختیاری)</span>
            </label>
        </div>

        <div class="form-section">
            <h2 class="section-title">👤 اطلاعات خریدار</h2>
            <div class="form-row">
                <div class="form-group">
                    <label>نام خریدار *:</label>
                    <input type="text" name="buyer_name" id="buyer_name" required>
                </div>
                <div class="form-group">
                    <label>تلفن:</label>
                    <input type="text" name="buyer_phone" id="buyer_phone">
                </div>
            </div>
        </div>

        <div class="form-section">
            <h2 class="section-title">📅 اطلاعات فاکتور</h2>
            <div class="form-row">
                <div class="form-group">
                    <label>شماره فاکتور:</label>
                    <input type="text" name="invoice_number" id="invoice_number">
                </div>
                <div class="form-group">
                    <label>تاریخ:</label>
                    <input type="text" name="invoice_date" id="invoice_date" value="{{ current_date }}" required>
                </div>
            </div>
        </div>

        <div class="form-section">
            <h2 class="section-title">📏 سایز فاکتور</h2>
            <div class="size-options">
                <div class="size-option" data-size="A4" onclick="selectSize('A4')">A4</div>
                <div class="size-option selected" data-size="A5" onclick="selectSize('A5')">A5</div>
            </div>
        </div>

        <div class="form-section">
            <h2 class="section-title">📦 اقلام فاکتور</h2>
            <table class="items-table" id="itemsTable">
                <thead>
                    <tr>
                        <th width="5%">ردیف</th>
                        <th width="28%">شرح کالا</th>
                        <th width="10%">تعداد</th>
                        <th width="12%">واحد</th>
                        <th width="15%">قیمت واحد</th>
                        <th width="15%">قیمت کل</th>
                        <th width="8%">عملیات</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
            <div style="text-align: center; margin: 15px 0;">
                <button type="button" class="btn btn-add" onclick="addItemRow()">➕ افزودن ردیف</button>
            </div>
            <div class="total-display">
                <strong>جمع کل:</strong> <span id="grandTotal">0 تومان</span>
            </div>
            <div class="discount-section">
                <h3 style="text-align: center; color: #e65100; margin-bottom: 10px;">🎁 تخفیف</h3>
                <div style="display: flex; gap: 20px; align-items: center; justify-content: center; flex-wrap: wrap;">
                    <div>
                        <label><input type="radio" name="discount_type" value="percent" checked> درصدی</label>
                        <label style="margin-right: 15px;"><input type="radio" name="discount_type" value="amount"> مبلغی</label>
                    </div>
                    <div>
                        <label>مقدار:</label>
                        <input type="number" id="discountValue" name="discount_value" step="0.01" min="0" value="0" style="width: 120px;">
                    </div>
                    <div>
                        <label>مبلغ تخفیف:</label>
                        <div style="font-size: 16px; color: #388E3C; font-weight: bold;"><span id="discountAmount">0 تومان</span></div>
                    </div>
                </div>
            </div>
            <div class="final-total">
                <strong>مبلغ قابل پرداخت:</strong> <span id="finalTotal">0 تومان</span>
            </div>
        </div>

        <div style="text-align: center; margin-top: 20px;">
            <button type="button" class="btn btn-generate" onclick="generatePreview()">👁️ نمایش و چاپ</button>
            <button type="button" class="btn btn-save" onclick="saveInvoice()">💾 ذخیره فاکتور</button>
        </div>
    </form>
</div>

<div id="products" class="tab-content">
    <div class="form-section">
        <h2 class="section-title">📦 مدیریت محصولات</h2>
        
        <!-- ✅ باکس جستجوی محصولات -->
        <div class="search-container">
            <input type="text" 
                   id="productSearch" 
                   class="search-input" 
                   placeholder="🔍 جستجو در محصولات (نام، واحد یا قیمت)...">
            <span class="search-icon">🔍</span>
            <button id="clearSearch" class="clear-search" onclick="clearSearch()" title="پاک کردن جستجو">✕</button>
        </div>
        <div id="searchStats" class="search-stats"></div>
        
        <div id="productsList"></div>
    </div>
</div>

<div id="invoices" class="tab-content">
    <div class="form-section">
        <h2 class="section-title">📋 فاکتورها</h2>
        <div id="invoicesList"></div>
    </div>
</div>
</div>
</body>
</html>'''

PRINT_TEMPLATE = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>فاکتور - {{ shop_name }}</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: Tahoma, sans-serif; color: #000; background: white; }
@page { size: {{ page_size }}; margin: 0.3cm; }
.invoice-container { width: {{ page_width }}; padding: {{ padding_size }}; background: white; margin: 0 auto; }
/* ده هویت بصری مستقل برای فاکتور */
.invoice-container.theme-1 .header{border-color:#2563eb}.theme-1 .header-title,.theme-1 .info-label{color:#1d4ed8}.theme-1 .items-table th{background:#dbeafe;color:#1e3a8a}.theme-1 .grand-total-row{background:#eff6ff;color:#1e40af;border-color:#2563eb}
.invoice-container.theme-2 .header{border-bottom:3px double #16834a}.theme-2 .header-title,.theme-2 .info-label{color:#166534}.theme-2 .items-table th{background:#dcfce7;color:#14532d}.theme-2 .grand-total-row{background:#f0fdf4;color:#166534;border-color:#16834a}
.invoice-container.theme-3{border:2px solid #b58a32}.theme-3 .header{border-color:#b58a32}.theme-3 .header-title,.theme-3 .info-label{color:#8a641c}.theme-3 .items-table th{background:#292524;color:#fef3c7}.theme-3 .grand-total-row{background:#fffbeb;color:#78350f;border-color:#b58a32}
.invoice-container.theme-4 .header{border-bottom:3px solid #9f1239}.theme-4 .header-title,.theme-4 .info-label{color:#9f1239}.theme-4 .items-table th{background:#881337;color:white}.theme-4 .grand-total-row{background:#fff1f2;color:#881337;border-color:#9f1239}
.invoice-container.theme-5{border:1px solid #cbd5e1}.theme-5 .header{border-color:#64748b}.theme-5 .header-title,.theme-5 .info-label{color:#475569}.theme-5 .items-table th{background:#e2e8f0;color:#334155}.theme-5 .grand-total-row{background:#f1f5f9;color:#334155;border-color:#94a3b8}
.invoice-container.theme-6 .header{border-bottom:3px solid #0891b2}.theme-6 .header-title,.theme-6 .info-label{color:#0e7490}.theme-6 .items-table th{background:#cffafe;color:#155e75}.theme-6 .grand-total-row{background:#ecfeff;color:#155e75;border-color:#0891b2}
.invoice-container.theme-7 .header{border-bottom:3px double #6d28d9}.theme-7 .header-title,.theme-7 .info-label{color:#6d28d9}.theme-7 .items-table th{background:#5b21b6;color:white}.theme-7 .grand-total-row{background:#f5f3ff;color:#5b21b6;border-color:#7c3aed}
.invoice-container.theme-8 .header{border-color:#ea580c}.theme-8 .header-title,.theme-8 .info-label{color:#c2410c}.theme-8 .items-table th{background:#ffedd5;color:#9a3412}.theme-8 .grand-total-row{background:#fff7ed;color:#9a3412;border-color:#ea580c}
.invoice-container.theme-9{border-top:5px solid #172554}.theme-9 .header{border-color:#172554}.theme-9 .header-title,.theme-9 .info-label{color:#172554}.theme-9 .items-table th{background:#172554;color:white}.theme-9 .grand-total-row{background:#eff6ff;color:#172554;border-color:#1e3a8a}
.invoice-container.theme-10 .header{border-bottom:3px dotted #db2777}.theme-10 .header-title,.theme-10 .info-label{color:#be185d}.theme-10 .items-table th{background:#fce7f3;color:#9d174d}.theme-10 .grand-total-row{background:#fdf2f8;color:#9d174d;border-color:#db2777}

.brand-mark{display:none!important}.header-ornament{width:22mm;min-width:22mm;height:14mm;display:flex;flex-direction:column;justify-content:center;gap:2mm;margin-left:3mm}.header-ornament span{display:block;height:1.2mm;background:var(--invoice-tone,#2563eb);border-radius:3mm}.theme-1 .header-ornament span:nth-child(2){width:72%;margin:auto}.theme-2 .header-ornament span{height:1mm;border-top:1px double currentColor}.theme-3 .header-ornament span:nth-child(1){height:2mm}.theme-3 .header-ornament span:nth-child(2){width:65%;margin:auto}.theme-4 .header-ornament span:nth-child(1){width:70%}.theme-5 .header-ornament span{height:.5mm}.theme-6 .header-ornament span:nth-child(2){width:80%;margin:auto}.theme-7 .header-ornament span{border-radius:0;transform:skewX(-25deg)}.theme-8 .header-ornament span:nth-child(3){width:55%}.theme-9 .header-ornament span:nth-child(1){height:2mm}.theme-10 .header-ornament span{background:repeating-linear-gradient(90deg,var(--invoice-tone,#db2777) 0 2mm,transparent 2mm 3mm);height:1mm}
.brand-copy{flex:1;text-align:center}.header-number{font-size:8pt;padding:2mm 3mm;min-width:22mm;text-align:center;font-weight:bold}.theme-1 .header-number{border:2px solid #2563eb;border-radius:2mm}.theme-2 .header-number{border:3px double #16834a;border-radius:0 0 4mm 4mm}.theme-3 .header-number{border:1px solid #b58a32;outline:1px solid #b58a32;outline-offset:2px}.theme-4 .header-number{border-right:4px solid #9f1239;background:#fff1f2}.theme-5 .header-number{border:0;border-bottom:1px solid #64748b}.theme-6 .header-number{border:1px solid #0891b2;border-radius:8mm 2mm 8mm 2mm;background:#ecfeff}.theme-7 .header-number{border:2px double #6d28d9;border-radius:8mm 1mm}.theme-8 .header-number{border:0;border-top:3px solid #ea580c;border-bottom:1px solid #ea580c}.theme-9 .header-number{border:2px solid #172554;border-radius:0;background:#eef2ff}.theme-10 .header-number{border:2px dotted #db2777;border-radius:5mm}
.theme-1 .header-ornament{--invoice-tone:#2563eb;color:#2563eb}.theme-1 .header-number{order:3}.theme-2 .header-ornament{--invoice-tone:#16834a;color:#16834a}.theme-2 .header-number{order:3}.theme-3 .header-ornament{--invoice-tone:#b58a32;color:#b58a32}.theme-3 .header-number{order:3}.theme-4 .header-ornament{--invoice-tone:#9f1239;color:#9f1239}.theme-4 .header-number{order:3}.theme-5 .header-ornament{--invoice-tone:#64748b;color:#64748b}.theme-5 .header-number{order:3}.theme-6 .header-ornament{--invoice-tone:#0891b2;color:#0891b2}.theme-6 .header-number{order:3}.theme-7 .header-ornament{--invoice-tone:#6d28d9;color:#6d28d9}.theme-7 .header-number{order:3}.theme-8 .header-ornament{--invoice-tone:#ea580c;color:#ea580c}.theme-8 .header-number{order:3}.theme-9 .header-ornament{--invoice-tone:#172554;color:#172554}.theme-9 .header-number{order:3}.theme-10 .header-ornament{--invoice-tone:#db2777;color:#db2777}.theme-10 .header-number{order:3}.theme-4 .header-number,.theme-8 .header-number,.theme-9 .header-number{order:-1}.theme-4 .header-ornament,.theme-8 .header-ornament,.theme-9 .header-ornament{order:3}.shop-phone{font-size:{{ phone_size }};margin-top:1mm}.header{display:flex;align-items:center;justify-content:space-between;text-align:center;position:relative;}
/* ده فرم متفاوت برای قوس خطوط، جای نشان، سربرگ، جدول و امضا */

.theme-1 .items-table th{border-radius:0}.theme-1 .signature-box{border-bottom:2px solid #2563eb}
.theme-2 .header{border:2px double #16834a;border-radius:0 0 12mm 12mm;padding:3mm}.theme-2 .items-table th{border-radius:4px}.theme-2 .signature-box{border-bottom:2px dotted #16834a}
.theme-3{border:2px double #b58a32;border-radius:5mm}.theme-3 .header{border:1px solid #b58a32;border-radius:4mm;padding:3mm}.theme-3 .items-table th{padding:3mm 1mm}.theme-3 .signature-box{height:15mm;border-bottom:1px solid #b58a32}
.theme-4 .header{border-bottom:4px solid #9f1239;border-radius:0 0 8mm 8mm;padding:2mm}.theme-4 .info-grid{border-radius:5mm}.theme-4 .signature-box{border-bottom:2px solid #9f1239}
.theme-5 .header{border-bottom:1px solid #94a3b8;padding:1mm}.theme-5 .items-table th,.theme-5 .items-table td{border-left:0;border-right:0;padding:2mm 1mm}.theme-5 .signature-box{height:9mm;border-bottom:1px solid #94a3b8}
.theme-6 .header{background:#ecfeff;border:1px solid #0891b2;border-radius:7mm;padding:3mm}.theme-6 .items-table{border-radius:4mm;overflow:hidden}.theme-6 .signature-box{border-bottom:2px dashed #0891b2}
.theme-7 .header{border:2px solid #6d28d9;border-radius:12mm 2mm 12mm 2mm;padding:3mm}.theme-7 .info-grid{border-radius:8mm 2mm}.theme-7 .signature-box{height:16mm;border-bottom:2px double #6d28d9}
.theme-8 .header{border-bottom:3px solid #ea580c;border-radius:0 0 3mm 3mm;padding:2mm}.theme-8 .items-table th{padding:2.5mm 1mm}.theme-8 .signature-box{border-bottom:2px solid #ea580c}
.theme-9 .header{border-top:5px solid #172554;border-bottom:1px solid #172554;padding:3mm 1mm}.theme-9 .header-number{border-radius:0}.theme-9 .items-table th,.theme-9 .items-table td{padding:2.2mm 1mm}.theme-9 .signature-box{border-bottom:3px double #172554}
.theme-10 .header{border:2px dotted #db2777;border-radius:8mm;padding:3mm}.theme-10 .info-grid{border-radius:8mm}.theme-10 .signature-box{border-bottom:2px dotted #db2777}
.theme-1 .col-name{width:31%}.theme-1 .col-price{width:19%}
.theme-2 .col-name{width:34%}.theme-2 .col-qty{width:9%}.theme-2 .col-total{width:21%}
.theme-3 .col-name{width:27%}.theme-3 .col-price{width:22%}.theme-3 .col-total{width:25%}
.theme-4 .col-name{width:30%}.theme-4 .col-unit{width:12%}
.theme-5 .col-name{width:36%}.theme-5 .col-row{width:5%}.theme-5 .col-total{width:20%}
.theme-6 .col-name{width:32%}.theme-6 .col-unit{width:13%}
.theme-7 .col-name{width:28%}.theme-7 .col-price{width:20%}
.theme-8 .col-name{width:33%}.theme-8 .col-qty{width:8%}
.theme-9 .col-name{width:30%}.theme-9 .col-row{width:5%}.theme-9 .col-price{width:20%}
.theme-10 .col-name{width:35%}.theme-10 .col-total{width:22%}
.theme-2 .footer{border-top:3px double #16834a;padding-top:4mm}.theme-4 .footer{flex-direction:row-reverse}
.theme-6 .footer{background:#ecfeff;border-radius:5mm;padding:3mm}.theme-8 .footer{border-top:2px solid #ea580c}
.theme-9 .footer{border-top:3px double #172554}.theme-10 .footer{border-top:2px dotted #db2777;border-radius:8mm;padding:3mm}

.header { text-align: center; margin-bottom: {{ header_margin }}; padding-bottom: {{ header_padding }}; border-bottom: 1px solid #2b6cb0; }
.header-title { font-size: {{ title_size }}; font-weight: bold; color: #2b6cb0; }
.shop-name { font-size: {{ shop_name_size }}; font-weight: bold; }
.info-grid { display: flex; justify-content: space-between; margin: {{ info_margin }} 0; padding: {{ info_padding }}; background: #f8f8f8; border: 1px solid #e2e8f0; }
.info-col { width: 48%; }
.info-row { margin: {{ info_row_margin }} 0; font-size: {{ info_font_size }}; }
.info-label { font-weight: bold; color: #d32f2f; display: inline-block; width: 65px; }
.items-table { width: 100%; border-collapse: collapse; font-size: {{ table_font_size }}; border: 0.5px solid #000; }
.items-table th { background: #e2e8f0; padding: {{ table_padding }}; border: 0.5px solid #000; text-align: center; font-weight: bold; }
.items-table td { padding: {{ table_padding }}; border: 0.5px solid #000; text-align: center; }
.col-row { width: 6%; }
.col-name { width: 30%; text-align: right !important; }
.col-qty { width: 9%; }
.col-unit { width: 11%; }
.col-price { width: 18%; }
.col-total { width: 18%; }
.calculation-section { margin-top: 8px; padding: 6px; background: #f9f9f9; border: 1px solid #ddd; }
.calculation-row { display: flex; justify-content: space-between; padding: 4px 3px; font-size: {{ calculation_font_size }}; border-bottom: 0.5px dashed #ccc; }
.calculation-row:last-child { border-bottom: none; }
.grand-total-row { background: #e3f2fd; font-size: {{ grand_total_font_size }}; color: #0d47a1; border: 1px solid #2196F3; margin-top: 5px; padding: 5px 3px; }
.total-words-section { margin-top: 8px; padding: 6px; background: #f0f8ff; border: 0.5px dashed #999; font-size: {{ total_words_size }}; }
.footer { margin-top: {{ footer_margin }}; display: flex; justify-content: space-between; padding-top: {{ footer_padding }}; border-top: 0.5px dashed #999; }
.signature { text-align: center; width: 45%; }
.signature-box { height: {{ signature_height }}; border-bottom: 0.5px solid #000; margin-bottom: 3px; }
.stamp-area{min-height:25mm;display:flex;align-items:center;justify-content:center;margin-top:2mm}.shop-stamp{width:34mm;min-height:19mm;border:2px solid #1769aa;border-radius:48%;color:#1769aa;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:2mm 3mm;transform:rotate(-7deg);font-weight:bold;position:relative;opacity:.88;box-shadow:inset 0 0 0 1px #1769aa,inset 0 0 0 3px rgba(23,105,170,.18);font-family:Tahoma,sans-serif}.shop-stamp:before{content:'';position:absolute;inset:2mm;border:1px dashed rgba(23,105,170,.75);border-radius:50%}.shop-stamp-name{font-size:8pt;line-height:1.5;max-width:100%;overflow-wrap:anywhere}.shop-stamp-phone{font-size:7pt;direction:ltr;margin-top:1mm}
.shop-address { text-align: center; margin-top: {{ address_margin }}; padding: {{ address_padding }}; background: #f9f9f9; font-size: {{ address_font_size }}; }
.print-controls { position: fixed; top: 8px; right: 8px; z-index: 99999; background: rgba(255,255,255,0.97); padding: 7px; border-radius: 8px; box-shadow: 0 3px 12px rgba(0,0,0,0.2); display:flex; gap:6px; }
.print-btn { padding: 10px 20px; background: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer; margin: 3px; font-weight: bold; }
.close-btn { background: #f44336; }
@media (max-width: 640px) { .print-controls { top: 5px; right: 5px; left: 5px; justify-content: center; padding: 5px; } .print-btn { padding: 9px 14px; font-size: 13px; } .invoice-container { padding-top: 48px !important; } }
@media print { .no-print { display: none !important; } * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; } body{background:#fff!important} .invoice-container{margin:0 auto!important;box-shadow:none!important} }
</style>
</head>
<body>
<div class="invoice-container theme-{{ template_id }}">
    <div class="header">
        <div class="header-ornament" aria-hidden="true"><span></span><span></span><span></span></div>
        <div class="brand-copy">
            <div class="header-title">فاکتور فروش</div>
            <div class="shop-name">{{ shop_name }}</div>
            {% if shop_phone %}<div class="shop-phone">تلفن: {{ shop_phone }}</div>{% endif %}
        </div>
        <div class="header-number"><small>شماره فاکتور</small><strong>{{ invoice_number or '—' }}</strong></div>
    </div>
    <div class="info-grid">
        <div class="info-col">
            <div class="info-row"><span class="info-label">خریدار:</span> <strong>{{ buyer_name }}</strong></div>
            <div class="info-row"><span class="info-label">تلفن:</span> {{ buyer_phone or "—" }}</div>
        </div>
        <div class="info-col">
            <div class="info-row"><span class="info-label">شماره:</span> {{ invoice_number or "—" }}</div>
            <div class="info-row"><span class="info-label">تاریخ:</span> {{ invoice_date }}</div>
        </div>
    </div>
    <div>
        <table class="items-table">
            <thead>
                <tr>
                    <th class="col-row">ردیف</th>
                    <th class="col-name">شرح کالا</th>
                    <th class="col-qty">تعداد</th>
                    <th class="col-unit">واحد</th>
                    <th class="col-price">قیمت واحد</th>
                    <th class="col-total">قیمت کل</th>
                </tr>
            </thead>
            <tbody>
                {% for item in items %}
                <tr>
                    <td>{{ loop.index }}</td>
                    <td class="col-name">{{ item.name }}</td>
                    <td>{{ item.qty|format_qty }}</td>
                    <td>{{ item.unit or "—" }}</td>
                    <td>{{ item.price|intcomma }}</td>
                    <td>{{ item.total|intcomma }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
    <div class="calculation-section">
        <div class="calculation-row">
            <span>جمع کل:</span>
            <span>{{ total|intcomma }}</span>
        </div>
        {% if discount_amount > 0 %}
        <div class="calculation-row">
            <span>تخفیف {% if discount_type == 'percent' %}({{ discount_value }}٪){% else %}(مبلغی){% endif %}:</span>
            <span style="color: #388E3C;">{{ discount_amount|intcomma }}</span>
        </div>
        {% endif %}
        <div class="calculation-row grand-total-row">
            <span>مبلغ قابل پرداخت:</span>
            <span>{{ final_total|intcomma }}</span>
        </div>
    </div>
    <div class="total-words-section">
        <strong>مبلغ به حروف:</strong> {{ total_words }} تومان
    </div>
    <div class="footer">
        <div class="signature">
            <div class="signature-box"></div>
            امضاء خریدار
        </div>
        <div class="signature">
            <div class="signature-box"></div>
            امضاء فروشنده
            {% if stamp_enabled %}<div class="stamp-area"><div class="shop-stamp"><div class="shop-stamp-name">{{ shop_name }}</div><div class="shop-stamp-phone">{{ shop_phone or '' }}</div></div></div>{% endif %}
        </div>
    </div>
    {% if shop_address %}
    <div class="shop-address">آدرس: {{ shop_address }}</div>
    {% endif %}
</div>
<div class="print-controls no-print">
    <button class="print-btn" onclick="window.print()">🖨️ پرینت</button>
    <button class="print-btn close-btn" onclick="closeInvoiceTab()">✖️ بستن</button>
</div>
<script>function closeInvoiceTab(){window.close();setTimeout(function(){if(!window.closed){if(history.length>1)history.back();else location.href='about:blank';}},180);}</script>
</body>
</html>'''

def create_pdf(invoice_data, page_size='A5'):
    """ساخت PDF با ۱۰ چیدمان واقعی و متفاوت؛ طرح ذخیره‌شده هر فاکتور اعمال می‌شود."""
    try:
        page = A4 if str(page_size).upper() == 'A4' else A5
        template_id = max(1, min(10, int(invoice_data.get('template_id', 1) or 1)))
        # رنگ اصلی، رنگ روشن، رنگ متن و سبک جدول برای هر یک از ده طرح
        themes = {
            1:  {'main': '#245B9E', 'light': '#EAF2FB', 'dark': '#17365D', 'style': 'grid'},
            2:  {'main': '#16834A', 'light': '#E9F7EF', 'dark': '#14532D', 'style': 'rows'},
            3:  {'main': '#A77B22', 'light': '#FBF4DF', 'dark': '#292524', 'style': 'boxed'},
            4:  {'main': '#9F1239', 'light': '#FFF0F3', 'dark': '#881337', 'style': 'grid'},
            5:  {'main': '#64748B', 'light': '#F1F5F9', 'dark': '#334155', 'style': 'minimal'},
            6:  {'main': '#0891B2', 'light': '#E8FAFD', 'dark': '#155E75', 'style': 'rows'},
            7:  {'main': '#6D28D9', 'light': '#F3EEFF', 'dark': '#4C1D95', 'style': 'boxed'},
            8:  {'main': '#EA580C', 'light': '#FFF1E7', 'dark': '#9A3412', 'style': 'grid'},
            9:  {'main': '#172554', 'light': '#EEF2FF', 'dark': '#172554', 'style': 'corporate'},
            10: {'main': '#DB2777', 'light': '#FDF0F7', 'dark': '#9D174D', 'style': 'minimal'},
        }
        theme = themes[template_id]
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=page,
            rightMargin=9*mm, leftMargin=9*mm, topMargin=9*mm, bottomMargin=9*mm)
        usable_width = page[0] - 18*mm
        styles = getSampleStyleSheet()
        rtl_style = ParagraphStyle('InvoiceRTL', parent=styles['Normal'],
            fontName=FONT_NAME, fontSize=8 if page_size == 'A5' else 9,
            leading=12 if page_size == 'A5' else 14, alignment=TA_RIGHT,
            wordWrap='RTL', spaceAfter=3)
        small_style = ParagraphStyle('InvoiceSmall', parent=rtl_style, fontSize=7,
            leading=10, spaceAfter=1)
        title_style = ParagraphStyle('InvoiceTitle', parent=styles['Heading1'],
            fontName=FONT_NAME_BOLD, fontSize=16 if page_size == 'A5' else 19,
            leading=21, alignment=TA_CENTER, textColor=colors.HexColor(theme['dark']),
            spaceAfter=3)
        shop_style = ParagraphStyle('InvoiceShop', parent=title_style,
            fontSize=11 if page_size == 'A5' else 13, leading=16, spaceAfter=2)
        story = []

        # سربرگ دارای نشان گرافیکی برداری و جایگاه متفاوت در هر یک از ده مدل
        shop_name_text = str(invoice_data.get('shop_name', 'فروشگاه'))
        shop_lines = []
        if invoice_data.get('shop_phone'):
            shop_lines.append('تلفن: ' + str(invoice_data['shop_phone']))
        if invoice_data.get('shop_address'):
            shop_lines.append('آدرس: ' + str(invoice_data['shop_address']))
        # نشان حرفی حذف شد؛ به‌جای آن سه خط تزئینی متناسب با مدل چاپ می‌شود.
        ornament_data = [[' ', ' '], [' ', ' '], [' ', ' ']]
        mark_cell = Table(ornament_data, colWidths=[7*mm, 7*mm], rowHeights=[1.2*mm, 1.2*mm, 1.2*mm])
        ornament_commands = [('VALIGN',(0,0),(-1,-1),'MIDDLE'),
            ('LINEBELOW',(0,0),(-1,0),1.8,colors.HexColor(theme['main'])),
            ('LINEBELOW',(0,1),(-1,1),0.9,colors.HexColor(theme['main'])),
            ('LINEBELOW',(0,2),(-1,2),1.3,colors.HexColor(theme['main']))]
        if template_id in (2, 7): ornament_commands.append(('LINEABOVE',(0,0),(-1,0),1.1,colors.HexColor(theme['main'])))
        if template_id in (3, 9): ornament_commands.append(('BOX',(0,0),(-1,-1),0.8,colors.HexColor(theme['main'])))
        mark_cell.setStyle(TableStyle(ornament_commands))
        shop_block = [Paragraph('فاکتور فروش', title_style), Paragraph(shop_name_text, shop_style)]
        if shop_lines:
            shop_block.append(Paragraph('　 |　 '.join(shop_lines), small_style))
        invoice_badge = Paragraph('<font color="'+theme['dark']+'"><b>شماره فاکتور</b><br/><font size="12">'+str(invoice_data.get('invoice_number','—'))+'</font></font>', small_style)
        if template_id in (2, 6, 10):
            header_cells = [[shop_block, mark_cell, invoice_badge]]
            header_widths = [usable_width-42*mm, 14*mm, 28*mm]
        elif template_id in (4, 8, 9):
            header_cells = [[invoice_badge, shop_block, mark_cell]]
            header_widths = [28*mm, usable_width-42*mm, 14*mm]
        else:
            header_cells = [[mark_cell, shop_block, invoice_badge]]
            header_widths = [14*mm, usable_width-42*mm, 28*mm]
        header_table = Table(header_cells, colWidths=header_widths, hAlign='CENTER')
        header_commands = [
            ('VALIGN',(0,0),(-1,-1),'MIDDLE'), ('ALIGN',(0,0),(-1,-1),'CENTER'),
            ('LEFTPADDING',(0,0),(-1,-1),4), ('RIGHTPADDING',(0,0),(-1,-1),4),
            ('TOPPADDING',(0,0),(-1,-1),5), ('BOTTOMPADDING',(0,0),(-1,-1),5),
            ('LINEBELOW',(0,-1),(-1,-1),1.2,colors.HexColor(theme['main'])),
        ]
        if template_id in (3, 7):
            header_commands += [('BOX',(0,0),(-1,-1),1.5,colors.HexColor(theme['main'])),
                                ('BACKGROUND',(0,0),(-1,-1),colors.HexColor(theme['light']))]
        elif template_id in (4, 8):
            header_commands += [('LINEABOVE',(0,0),(-1,0),2,colors.HexColor(theme['main']))]
        header_table.setStyle(TableStyle(header_commands))
        story.append(header_table)
        story.append(Spacer(1, 7))

        # اطلاعات فروشنده و خریدار در کادرهای مستقل و راست‌چین
        buyer_text = (
            f"<b>خریدار:</b> {invoice_data.get('buyer_name','')}<br/>"
            f"<b>تلفن:</b> {invoice_data.get('buyer_phone') or '---'}"
        )
        number_text = (
            f"<b>شماره فاکتور:</b> {invoice_data.get('invoice_number','---')}<br/>"
            f"<b>تاریخ:</b> {invoice_data.get('invoice_date','')}"
        )
        meta = Table([[Paragraph(buyer_text, rtl_style), Paragraph(number_text, rtl_style)]],
                     colWidths=[usable_width*0.5, usable_width*0.5])
        meta_cmds = [
            ('VALIGN',(0,0),(-1,-1),'MIDDLE'), ('BOX',(0,0),(-1,-1),0.7,colors.HexColor(theme['main'])),
            ('BACKGROUND',(0,0),(-1,-1),colors.HexColor(theme['light'])),
            ('LEFTPADDING',(0,0),(-1,-1),7), ('RIGHTPADDING',(0,0),(-1,-1),7),
            ('TOPPADDING',(0,0),(-1,-1),6), ('BOTTOMPADDING',(0,0),(-1,-1),6),
        ]
        if template_id == 5:
            meta_cmds = [('LINEBELOW',(0,0),(-1,-1),0.6,colors.HexColor(theme['main'])),
                         ('VALIGN',(0,0),(-1,-1),'MIDDLE'), ('TOPPADDING',(0,0),(-1,-1),5)]
        meta.setStyle(TableStyle(meta_cmds))
        story.append(meta)
        story.append(Spacer(1, 9))

        # جدول اقلام با عرض متناسب با A4/A5
        table_data = [[Paragraph(x, small_style) for x in ['ردیف','شرح کالا','تعداد','واحد','قیمت واحد','قیمت کل']]]
        for i, item in enumerate(invoice_data.get('items', []), 1):
            table_data.append([
                str(i), Paragraph(str(item.get('name','')), small_style),
                format_qty(item.get('qty', 0)), str(item.get('unit') or lookup_product_unit(str(item.get('name',''))) or '—'),
                f"{int(float(item.get('price',0))):,}", f"{int(float(item.get('total',0))):,}"
            ])
        # نسبت ستون‌ها در هر مدل متفاوت است؛ شرح کالا در بعضی طرح‌ها عریض‌تر است.
        column_ratios = {
            1: (.06,.31,.09,.11,.19,.24), 2: (.07,.34,.09,.12,.17,.21),
            3: (.06,.27,.10,.10,.22,.25), 4: (.07,.30,.09,.12,.18,.24),
            5: (.05,.36,.09,.12,.18,.20), 6: (.06,.32,.10,.13,.17,.22),
            7: (.07,.28,.09,.11,.20,.25), 8: (.06,.33,.08,.12,.18,.23),
            9: (.05,.30,.10,.12,.20,.23), 10:(.07,.35,.08,.11,.17,.22)
        }
        widths = [usable_width * ratio for ratio in column_ratios[template_id]]
        items_table = Table(table_data, colWidths=widths, repeatRows=1, hAlign='CENTER')
        base_cmds = [
            ('FONTNAME',(0,0),(-1,-1),FONT_NAME), ('FONTNAME',(0,0),(-1,0),FONT_NAME_BOLD),
            ('FONTSIZE',(0,0),(-1,-1),7 if page_size == 'A5' else 8),
            ('ALIGN',(0,0),(-1,-1),'CENTER'), ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
            ('TEXTCOLOR',(0,0),(-1,0),colors.white),
            ('BACKGROUND',(0,0),(-1,0),colors.HexColor(theme['main'])),
            ('TOPPADDING',(0,0),(-1,-1),5), ('BOTTOMPADDING',(0,0),(-1,-1),5),
            ('LEFTPADDING',(0,0),(-1,-1),3), ('RIGHTPADDING',(0,0),(-1,-1),3),
        ]
        style = theme['style']
        if style == 'grid' or style == 'boxed':
            base_cmds.append(('GRID',(0,0),(-1,-1),0.55,colors.HexColor(theme['main'])))
        elif style == 'rows':
            base_cmds.append(('LINEBELOW',(0,1),(-1,-1),0.45,colors.HexColor(theme['main'])))
            for row in range(1, len(table_data)):
                if row % 2 == 0:
                    base_cmds.append(('BACKGROUND',(0,row),(-1,row),colors.HexColor(theme['light'])))
        elif style == 'corporate':
            base_cmds.extend([('BOX',(0,0),(-1,-1),1,colors.HexColor(theme['main'])),
                              ('LINEBELOW',(0,0),(-1,0),1.5,colors.HexColor(theme['dark']))])
        else:
            base_cmds.extend([('LINEBELOW',(0,0),(-1,0),1.2,colors.HexColor(theme['main'])),
                              ('LINEBELOW',(0,1),(-1,-1),0.35,colors.HexColor('#CBD5E1'))])
        items_table.setStyle(TableStyle(base_cmds))
        story.append(items_table)
        story.append(Spacer(1, 10))

        total = int(round(float(invoice_data.get('total_amount', 0))))
        discount = int(round(float(invoice_data.get('discount_amount', 0))))
        final = int(round(float(invoice_data.get('final_amount', 0))))
        calc_rows = [[Paragraph('<b>جمع کل</b>', rtl_style), f'{total:,} تومان']]
        if discount > 0:
            calc_rows.append([Paragraph('<b>تخفیف</b>', rtl_style), f'{discount:,} تومان'])
        calc_rows.append([Paragraph('<b>مبلغ قابل پرداخت</b>', rtl_style), f'{final:,} تومان'])
        calc = Table(calc_rows, colWidths=[usable_width*.52, usable_width*.48], hAlign='RIGHT')
        calc_style = [
            ('FONTNAME',(0,0),(-1,-1),FONT_NAME), ('FONTSIZE',(0,0),(-1,-1),8),
            ('ALIGN',(0,0),(0,-1),'RIGHT'), ('ALIGN',(1,0),(1,-1),'RIGHT'),
            ('VALIGN',(0,0),(-1,-1),'MIDDLE'), ('TOPPADDING',(0,0),(-1,-1),5),
            ('BOTTOMPADDING',(0,0),(-1,-1),5),
            ('BACKGROUND',(0,-1),(-1,-1),colors.HexColor(theme['light'])),
            ('BOX',(0,-1),(-1,-1),1.1,colors.HexColor(theme['main'])),
        ]
        if template_id in (2, 6):
            calc_style.append(('LINEBELOW',(0,0),(-1,-2),0.4,colors.HexColor(theme['main'])))
        elif template_id in (3, 7):
            calc_style.append(('BOX',(0,0),(-1,-1),1,colors.HexColor(theme['main'])))
        calc.setStyle(TableStyle(calc_style))
        story.append(calc)
        story.append(Spacer(1, 6))
        words = number_to_persian_words(final)
        words_box = Table([[Paragraph(f'<b>مبلغ به حروف:</b> {words} تومان', rtl_style)]],
                          colWidths=[usable_width])
        words_box.setStyle(TableStyle([
            ('BACKGROUND',(0,0),(-1,-1),colors.HexColor(theme['light'])),
            ('BOX',(0,0),(-1,-1),0.6,colors.HexColor(theme['main'])),
            ('ALIGN',(0,0),(-1,-1),'RIGHT'), ('TOPPADDING',(0,0),(-1,-1),6),
            ('BOTTOMPADDING',(0,0),(-1,-1),6), ('LEFTPADDING',(0,0),(-1,-1),7),
            ('RIGHTPADDING',(0,0),(-1,-1),7),
        ]))
        story.append(words_box)
        story.append(Spacer(1, 16))

        # امضاها نیز با سبک هر طرح هماهنگ هستند
        signature_height = 42 if template_id in (3, 7) else (24 if template_id == 5 else 34)
        sign = Table([
            [Paragraph('امضاء خریدار', rtl_style), Paragraph('امضاء فروشنده', rtl_style)],
            ['', '']
        ], colWidths=[usable_width/2, usable_width/2], rowHeights=[18, signature_height])
        signature_commands = [
            ('FONTNAME',(0,0),(-1,-1),FONT_NAME), ('ALIGN',(0,0),(-1,-1),'CENTER'),
            ('VALIGN',(0,0),(-1,-1),'BOTTOM'),
            ('LINEBELOW',(0,1),(0,1),0.6,colors.HexColor(theme['main'])),
            ('LINEBELOW',(1,1),(1,1),0.6,colors.HexColor(theme['main'])),
            ('TOPPADDING',(0,0),(-1,-1),5), ('BOTTOMPADDING',(0,0),(-1,-1),5),
        ]
        if template_id in (2, 6, 10):
            signature_commands = [c for c in signature_commands if c[0] != 'LINEBELOW']
            signature_commands += [('LINEBELOW',(0,1),(0,1),1.2,colors.HexColor(theme['main'])),
                                   ('LINEBELOW',(1,1),(1,1),1.2,colors.HexColor(theme['main']))]
        if template_id in (3, 7):
            signature_commands += [('BOX',(0,0),(-1,-1),0.8,colors.HexColor(theme['main']))]
        sign.setStyle(TableStyle(signature_commands))
        story.append(sign)
        doc.build(story)
        buffer.seek(0)
        return buffer
    except Exception as e:
        print(f"Error creating PDF: {e}")
        traceback.print_exc()
        return None

def render_print_html(invoice_data):
    page_size = invoice_data.get('page_size', 'A5').upper()
    page_config = {
        'A4': {'width': '195mm', 'padding': '3mm', 'title_size': '14pt',
               'shop_name_size': '11pt', 'phone_size': '9pt',
               'info_font_size': '8pt', 'table_font_size': '8pt',
               'calculation_font_size': '8pt', 'grand_total_font_size': '9pt',
               'total_words_size': '8pt', 'address_font_size': '8pt',
               'header_margin': '4mm', 'header_padding': '2mm',
               'info_margin': '3mm', 'info_padding': '1.5mm',
               'info_row_margin': '0.5mm', 'table_margin': '3mm',
               'table_padding': '1.5mm 1mm', 'footer_margin': '6mm',
               'footer_padding': '3mm', 'signature_height': '12mm',
               'address_margin': '3mm', 'address_padding': '1.5mm'},
        'A5': {'width': '140mm', 'padding': '2.5mm', 'title_size': '12pt',
               'shop_name_size': '10pt', 'phone_size': '8pt',
               'info_font_size': '7pt', 'table_font_size': '7pt',
               'calculation_font_size': '7pt', 'grand_total_font_size': '8pt',
               'total_words_size': '7pt', 'address_font_size': '7pt',
               'header_margin': '3mm', 'header_padding': '1.5mm',
               'info_margin': '2mm', 'info_padding': '1mm',
               'info_row_margin': '0.3mm', 'table_margin': '2mm',
               'table_padding': '1mm 0.5mm', 'footer_margin': '5mm',
               'footer_padding': '2mm', 'signature_height': '10mm',
               'address_margin': '2mm', 'address_padding': '1mm'}
    }
    config = page_config.get(page_size, page_config['A5'])
    total_words = number_to_persian_words(int(round(invoice_data['final_amount'])))
    
    return render_template_string(PRINT_TEMPLATE,
        page_size=page_size, template_id=int(invoice_data.get('template_id', 1)), page_width=config['width'],
        padding_size=config['padding'], title_size=config['title_size'],
        shop_name_size=config['shop_name_size'], phone_size=config['phone_size'],
        info_font_size=config['info_font_size'], table_font_size=config['table_font_size'],
        calculation_font_size=config['calculation_font_size'],
        grand_total_font_size=config['grand_total_font_size'],
        total_words_size=config['total_words_size'],
        address_font_size=config['address_font_size'],
        header_margin=config['header_margin'], header_padding=config['header_padding'],
        info_margin=config['info_margin'], info_padding=config['info_padding'],
        info_row_margin=config['info_row_margin'], table_margin=config['table_margin'],
        table_padding=config['table_padding'], footer_margin=config['footer_margin'],
        footer_padding=config['footer_padding'], signature_height=config['signature_height'],
        address_margin=config['address_margin'], address_padding=config['address_padding'],
        shop_name=invoice_data['shop_name'],
        shop_phone=invoice_data.get('shop_phone', ''),
        stamp_enabled=bool(invoice_data.get('stamp_enabled', False)),
        shop_address=invoice_data.get('shop_address', ''),
        buyer_name=invoice_data['buyer_name'],
        buyer_phone=invoice_data.get('buyer_phone', ''),
        invoice_number=invoice_data.get('invoice_number', '—'),
        invoice_date=invoice_data['invoice_date'],
        items=invoice_data['items'],
        total=invoice_data['total_amount'],
        discount_type=invoice_data.get('discount_type', 'percent'),
        discount_value=invoice_data.get('discount_value', 0),
        discount_amount=invoice_data.get('discount_amount', 0),
        final_total=invoice_data['final_amount'],
        total_words=total_words)

@app.route('/')
def index():
    init_database()
    current_date = jdatetime.datetime.now().strftime("%Y/%m/%d")
    settings = get_settings()
    products = get_products()
    return render_template_string(HTML_TEMPLATE,
        current_date=current_date, units=UNITS_LIST,
        settings=settings, products=products)

@app.route('/generate', methods=['POST'])
def generate_invoice():
    try:
        shop_name = request.form.get('shop_name', '').strip()
        shop_phone = request.form.get('shop_phone', '').strip()
        shop_address = request.form.get('shop_address', '').strip()
        buyer_name = request.form.get('buyer_name', '').strip()
        buyer_phone = request.form.get('buyer_phone', '').strip()
        invoice_number = request.form.get('invoice_number', '').strip()
        invoice_date = request.form.get('invoice_date', '').strip()
        page_size = request.form.get('page_size', 'A5').upper()
        template_id = max(1, min(10, int(request.form.get('template_id', 1) or 1)))
        discount_type = request.form.get('discount_type', 'percent')
        discount_value = float(request.form.get('discount_value', 0) or 0)

        if not shop_name: return "خطا: نام فروشگاه", 400
        if not buyer_name: return "خطا: نام خریدار", 400

        item_names = request.form.getlist('item_name')
        item_qtys = request.form.getlist('item_qty')
        item_units = request.form.getlist('item_unit')
        item_prices = request.form.getlist('item_price')
        items_data = []
        total_sum = 0
        for i in range(len(item_names)):
            if item_names[i].strip():
                try:
                    qty = float(item_qtys[i]) if item_qtys[i] else 0
                    price = float(item_prices[i]) if item_prices[i] else 0
                    total = qty * price
                    total_sum += total
                    item_name = item_names[i].strip()
                    unit_value = item_units[i].strip() if i < len(item_units) else ''
                    if not unit_value:
                        unit_value = lookup_product_unit(item_name) or '—'
                    items_data.append({
                        'name': item_name, 'qty': qty,
                        'unit': unit_value,
                        'price': price, 'total': total
                    })
                except ValueError:
                    return f"خطا: مقادیر ردیف {i+1}", 400
        if not items_data: return "خطا: حداقل یک کالا", 400

        discount_amount = 0
        if discount_type == 'percent':
            discount_amount = (total_sum * discount_value) / 100
        elif discount_type == 'amount':
            discount_amount = discount_value
        final_total = total_sum - discount_amount
        total_words = number_to_persian_words(int(round(final_total)))

        page_config = {
            'A4': {'width': '195mm', 'padding': '3mm', 'title_size': '14pt',
                   'shop_name_size': '11pt', 'phone_size': '9pt',
                   'info_font_size': '8pt', 'table_font_size': '8pt',
                   'calculation_font_size': '8pt', 'grand_total_font_size': '9pt',
                   'total_words_size': '8pt', 'address_font_size': '8pt',
                   'header_margin': '4mm', 'header_padding': '2mm',
                   'info_margin': '3mm', 'info_padding': '1.5mm',
                   'info_row_margin': '0.5mm', 'table_margin': '3mm',
                   'table_padding': '1.5mm 1mm', 'footer_margin': '6mm',
                   'footer_padding': '3mm', 'signature_height': '12mm',
                   'address_margin': '3mm', 'address_padding': '1.5mm'},
            'A5': {'width': '140mm', 'padding': '2.5mm', 'title_size': '12pt',
                   'shop_name_size': '10pt', 'phone_size': '8pt',
                   'info_font_size': '7pt', 'table_font_size': '7pt',
                   'calculation_font_size': '7pt', 'grand_total_font_size': '8pt',
                   'total_words_size': '7pt', 'address_font_size': '7pt',
                   'header_margin': '3mm', 'header_padding': '1.5mm',
                   'info_margin': '2mm', 'info_padding': '1mm',
                   'info_row_margin': '0.3mm', 'table_margin': '2mm',
                   'table_padding': '1mm 0.5mm', 'footer_margin': '5mm',
                   'footer_padding': '2mm', 'signature_height': '10mm',
                   'address_margin': '2mm', 'address_padding': '1mm'}
        }
        config = page_config.get(page_size, page_config['A5'])
        html = render_template_string(PRINT_TEMPLATE,
            page_size=page_size, template_id=max(1, min(10, int(request.form.get('template_id', 1) or 1))), page_width=config['width'],
            padding_size=config['padding'], title_size=config['title_size'],
            shop_name_size=config['shop_name_size'], phone_size=config['phone_size'],
            info_font_size=config['info_font_size'], table_font_size=config['table_font_size'],
            calculation_font_size=config['calculation_font_size'],
            grand_total_font_size=config['grand_total_font_size'],
            total_words_size=config['total_words_size'],
            address_font_size=config['address_font_size'],
            header_margin=config['header_margin'], header_padding=config['header_padding'],
            info_margin=config['info_margin'], info_padding=config['info_padding'],
            info_row_margin=config['info_row_margin'], table_margin=config['table_margin'],
            table_padding=config['table_padding'], footer_margin=config['footer_margin'],
            footer_padding=config['footer_padding'], signature_height=config['signature_height'],
            address_margin=config['address_margin'], address_padding=config['address_padding'],
            shop_name=shop_name, shop_phone=shop_phone, shop_address=shop_address,
            stamp_enabled=request.form.get('stamp_enabled') == '1',
            buyer_name=buyer_name, buyer_phone=buyer_phone,
            invoice_number=invoice_number or "—", invoice_date=invoice_date,
            items=items_data, total=total_sum, discount_type=discount_type,
            discount_value=discount_value, discount_amount=discount_amount,
            final_total=final_total, total_words=total_words)
        import uuid
        token = uuid.uuid4().hex
        PREVIEW_CACHE[token] = html
        preview_url = request.url_root.rstrip('/') + '/preview/' + token
        bridge_page = "<!doctype html><html lang='fa'><meta charset='utf-8'><script>(function(){var u=" + json.dumps(preview_url) + ";if(window.AndroidBridge && AndroidBridge.openExternal) AndroidBridge.openExternal(u);else location.replace(u);})();</script><body>در حال بازکردن فاکتور در مرورگر...</body></html>"
        return bridge_page
    except Exception as e:
        return f"خطا: {str(e)}", 500

@app.route('/preview/<token>')
def preview_invoice(token):
    html = PREVIEW_CACHE.pop(token, None)
    if html is None:
        return 'پیش‌نمایش منقضی شده است؛ دوباره روی نمایش و چاپ بزنید.', 404
    return html

@app.route('/print_invoice/<int:invoice_id>')
def print_invoice(invoice_id):
    invoice = get_invoice_by_id(invoice_id)
    if not invoice:
        return "فاکتور یافت نشد", 404
    return render_print_html(invoice)

@app.route('/save_product', methods=['POST'])
def api_save_product():
    try:
        data = request.get_json()
        name = data.get('name', '').strip()
        unit = data.get('unit', '').strip()
        price = float(data.get('price', 0) or 0)
        if not name: return jsonify({'success': False, 'message': 'نام الزامی است'})
        success = save_product(name, unit, price)
        return jsonify({'success': success, 'message': 'ذخیره شد' if success else 'خطا'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/get_products', methods=['GET'])
def api_get_products():
    return jsonify(get_products())

@app.route('/get_product/<int:product_id>', methods=['GET'])
def api_get_product(product_id):
    products = get_products()
    product = next((p for p in products if p['id'] == product_id), None)
    if product: return jsonify(product)
    return jsonify({'error': 'یافت نشد'}), 404

@app.route('/delete_product/<int:product_id>', methods=['DELETE'])
def api_delete_product(product_id):
    delete_product(product_id)
    return jsonify({'success': True})

@app.route('/save_invoice', methods=['POST'])
def api_save_invoice():
    try:
        data = request.get_json()
        invoice_id = save_invoice(data)
        if invoice_id:
            return jsonify({
                'success': True, 'message': 'ذخیره شد',
                'invoice_number': data.get('invoice_number', ''),
                'invoice_id': invoice_id
            })
        return jsonify({'success': False, 'message': 'خطا در ذخیره'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/get_invoices', methods=['GET'])
def api_get_invoices():
    return jsonify(get_invoices())

@app.route('/get_invoice/<int:invoice_id>', methods=['GET'])
def api_get_invoice(invoice_id):
    invoice = get_invoice_by_id(invoice_id)
    if invoice: return jsonify(invoice)
    return jsonify({'error': 'یافت نشد'}), 404

@app.route('/delete_invoice/<int:invoice_id>', methods=['DELETE'])
def api_delete_invoice(invoice_id):
    delete_invoice(invoice_id)
    return jsonify({'success': True})

@app.route('/generate_pdf/<int:invoice_id>')
def generate_pdf(invoice_id):
    invoice = get_invoice_by_id(invoice_id)
    if not invoice: return "یافت نشد", 404
    pdf_buffer = create_pdf(invoice, invoice.get('page_size', 'A5'))
    if pdf_buffer:
        filename = f"factor_{invoice['invoice_number']}.pdf"
        return send_file(pdf_buffer, as_attachment=True,
                        download_name=filename, mimetype='application/pdf')
    return "خطا در ایجاد PDF", 500


def run_server(host='127.0.0.1', port=5002, open_browser=False):
    setup_directories()
    init_database()
    if open_browser and host in ('127.0.0.1', 'localhost'):
        def launch_default_browser():
            import urllib.request
            url = f'http://{host}:{port}'
            for _ in range(40):
                try:
                    urllib.request.urlopen(url, timeout=0.5).close()
                    webbrowser.open(url, new=2)
                    return
                except Exception:
                    time.sleep(0.25)
        threading.Thread(target=launch_default_browser, daemon=True).start()
    app.run(debug=False, host=host, port=port, threaded=True, use_reloader=False)

if __name__ == '__main__':
    run_server(host='127.0.0.1', port=5002, open_browser=True)
