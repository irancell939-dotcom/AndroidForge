package com.balochi.quiz.data

import android.content.Context
import com.google.gson.Gson
import java.io.File
import com.google.gson.reflect.TypeToken

class WordRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("balochi_words_v2", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val key = "words_list"
    private val progressKey = "user_progress"

    fun getAllWords(): List<BalochiWord> {
        val json = prefs.getString(key, null)
        if (json.isNullOrBlank()) {
            val seed = loadSeedWords()
            saveWords(seed)
            return seed
        }
        return try {
            val type = object : TypeToken<List<BalochiWord>>() {}.type
            gson.fromJson<List<BalochiWord>>(json, type) ?: loadSeedWords()
        } catch (e: Exception) {
            loadSeedWords()
        }
    }

    fun saveWords(words: List<BalochiWord>) {
        prefs.edit().putString(key, gson.toJson(words)).apply()
    }

    fun addWord(word: BalochiWord) {
        val current = getAllWords().toMutableList()
        current.add(0, word)
        saveWords(current)
    }

    fun updateWord(word: BalochiWord) {
        val current = getAllWords().toMutableList()
        val index = current.indexOfFirst { it.id == word.id }
        if (index >= 0) {
            current[index] = word
            saveWords(current)
        }
    }

    fun deleteWord(id: String) {
        val current = getAllWords().toMutableList()
        current.removeAll { it.id == id }
        saveWords(current)
    }

    fun recordAnswer(wordId: String, isCorrect: Boolean) {
        val current = getAllWords().toMutableList()
        val index = current.indexOfFirst { it.id == wordId }
        if (index >= 0) {
            val w = current[index]
            current[index] = w.copy(
                correctCount = w.correctCount + if (isCorrect) 1 else 0,
                wrongCount = w.wrongCount + if (isCorrect) 0 else 1,
                lastSeen = System.currentTimeMillis()
            )
            saveWords(current)
        }
    }

    data class UserProgress(
        val totalQuizzes: Int = 0,
        val totalCorrect: Int = 0,
        val totalAnswered: Int = 0,
        val level: Int = 1
    )

    fun getProgress(): UserProgress {
        val json = prefs.getString(progressKey, null) ?: return UserProgress()
        return try {
            gson.fromJson(json, UserProgress::class.java) ?: UserProgress()
        } catch (e: Exception) {
            UserProgress()
        }
    }

    fun updateProgress(correct: Int, answered: Int) {
        val p = getProgress()
        val newTotalCorrect = p.totalCorrect + correct
        val newTotalAnswered = p.totalAnswered + answered
        val newQuizzes = p.totalQuizzes + 1
        val level = when {
            newTotalCorrect >= 500 -> 5
            newTotalCorrect >= 250 -> 4
            newTotalCorrect >= 100 -> 3
            newTotalCorrect >= 40 -> 2
            else -> 1
        }
        val updated = UserProgress(newQuizzes, newTotalCorrect, newTotalAnswered, level)
        prefs.edit().putString(progressKey, gson.toJson(updated)).apply()
    }

    
    data class BackupData(
        val words: List<BalochiWord>,
        val progress: UserProgress,
        val exportedAt: Long = System.currentTimeMillis()
    )

    /** پوشه مخصوص برنامه برای پشتیبان */
    private fun backupDir(): File {
        val dir = File(context.getExternalFilesDir(null), "BalochiBackup")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun exportBackup(): String? {
        return try {
            val data = BackupData(getAllWords(), getProgress())
            val file = File(backupDir(), "backup_${System.currentTimeMillis()}.json")
            file.writeText(gson.toJson(data))
            // آخرین پشتیبان با نام ثابت هم ذخیره شود
            File(backupDir(), "latest_backup.json").writeText(gson.toJson(data))
            file.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    fun importBackup(): Boolean {
        return try {
            val file = File(backupDir(), "latest_backup.json")
            if (!file.exists()) return false
            val data = gson.fromJson(file.readText(), BackupData::class.java) ?: return false
            saveWords(data.words)
            prefs.edit().putString(progressKey, gson.toJson(data.progress)).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun resetProgress() {
        val empty = UserProgress()
        prefs.edit().putString(progressKey, gson.toJson(empty)).apply()
        // ریست آمار هر کلمه
        val words = getAllWords().map {
            it.copy(correctCount = 0, wrongCount = 0, lastSeen = 0L)
        }
        saveWords(words)
    }

    fun getBackupPath(): String = backupDir().absolutePath


    private fun loadSeedWords(): List<BalochiWord> {
        try {
            val input = context.assets.open("words.json")
            val json = input.bufferedReader().use { it.readText() }
            val type = object : TypeToken<List<BalochiWord>>() {}.type
            val list = gson.fromJson<List<BalochiWord>>(json, type)
            if (!list.isNullOrEmpty()) return list
        } catch (_: Exception) { }
        return defaultSeed()
    }

    private fun defaultSeed(): List<BalochiWord> = listOf(
        w("Water", "آب", "ماء", "پانی"),
        w("Bread", "نان", "خبز", "روٹی"),
        w("House", "خانه", "منزل", "گھر"),
        w("Friend", "دوست", "صديق", "دوست"),
        w("Book", "کتاب", "كتاب", "کتاب"),
        w("Sun", "خورشید", "شمس", "سورج"),
        w("Moon", "ماه", "قمر", "چاند"),
        w("Sea", "دریا", "بحر", "سمندر"),
        w("Tree", "درخت", "شجرة", "درخت"),
        w("Flower", "گل", "زهرة", "پھول"),
        w("Mother", "مادر", "أم", "ماں"),
        w("Father", "پدر", "أب", "باپ"),
        w("Child", "کودک", "طفل", "بچہ"),
        w("Man", "مرد", "رجل", "آدمی"),
        w("Woman", "زن", "امرأة", "عورت"),
        w("Day", "روز", "يوم", "دن"),
        w("Night", "شب", "ليل", "رات"),
        w("Food", "غذا", "طعام", "کھانا"),
        w("Milk", "شیر", "حليب", "دودھ"),
        w("Fire", "آتش", "نار", "آگ"),
        w("Earth", "زمین", "أرض", "زمین"),
        w("Sky", "آسمان", "سماء", "آسمان"),
        w("Rain", "باران", "مطر", "بارش"),
        w("Wind", "باد", "ريح", "ہوا"),
        w("Mountain", "کوه", "جبل", "پہاڑ"),
        w("River", "رودخانه", "نهر", "دریا"),
        w("City", "شهر", "مدينة", "شہر"),
        w("Village", "روستا", "قرية", "گاؤں"),
        w("Road", "جاده", "طريق", "سڑک"),
        w("Car", "ماشین", "سيارة", "گاڑی"),
        w("Door", "در", "باب", "دروازہ"),
        w("Window", "پنجره", "نافذة", "کھڑکی"),
        w("Table", "میز", "طاولة", "میز"),
        w("Chair", "صندلی", "كرسي", "کرسی"),
        w("Hand", "دست", "يد", "ہاتھ"),
        w("Eye", "چشم", "عين", "آنکھ"),
        w("Head", "سر", "رأس", "سر"),
        w("Heart", "قلب", "قلب", "دل"),
        w("Love", "عشق", "حب", "محبت"),
        w("Peace", "صلح", "سلام", "امن"),
        w("War", "جنگ", "حرب", "جنگ"),
        w("Life", "زندگی", "حياة", "زندگی"),
        w("Death", "مرگ", "موت", "موت"),
        w("Time", "زمان", "وقت", "وقت"),
        w("Year", "سال", "سنة", "سال"),
        w("Month", "ماه", "شهر", "مہینہ"),
        w("Week", "هفته", "أسبوع", "ہفتہ"),
        w("Today", "امروز", "اليوم", "آج"),
        w("Tomorrow", "فردا", "غدا", "کل"),
        w("Yesterday", "دیروز", "أمس", "کل"),
        w("Good", "خوب", "جيد", "اچھا"),
        w("Bad", "بد", "سيء", "برا"),
        w("Big", "بزرگ", "كبير", "بڑا"),
        w("Small", "کوچک", "صغير", "چھوٹا"),
        w("New", "جدید", "جديد", "نیا"),
        w("Old", "قدیمی", "قديم", "پرانا"),
        w("Hot", "داغ", "حار", "گرم"),
        w("Cold", "سرد", "بارد", "ٹھنڈا"),
        w("Happy", "خوشحال", "سعيد", "خوش"),
        w("Sad", "غمگین", "حزين", "اداس"),
        w("Beautiful", "زیبا", "جميل", "خوبصورت"),
        w("Strong", "قوی", "قوي", "مضبوط"),
        w("Weak", "ضعیف", "ضعيف", "کمزور"),
        w("Rich", "ثروتمند", "غني", "امیر"),
        w("Poor", "فقیر", "فقير", "غریب"),
        w("Work", "کار", "عمل", "کام"),
        w("School", "مدرسه", "مدرسة", "اسکول"),
        w("Teacher", "معلم", "معلم", "استاد"),
        w("Student", "دانش‌آموز", "طالب", "طالب علم"),
        w("Doctor", "پزشک", "طبيب", "ڈاکٹر"),
        w("Hospital", "بیمارستان", "مستشفى", "ہسپتال"),
        w("Money", "پول", "مال", "پیسہ"),
        w("Market", "بازار", "سوق", "بازار"),
        w("Shop", "فروشگاه", "دكان", "دکان"),
        w("Price", "قیمت", "سعر", "قیمت"),
        w("Name", "نام", "اسم", "نام"),
        w("Family", "خانواده", "عائلة", "خاندان"),
        w("Brother", "برادر", "أخ", "بھائی"),
        w("Sister", "خواهر", "أخت", "بہن"),
        w("Son", "پسر", "ابن", "بیٹا"),
        w("Daughter", "دختر", "ابنة", "بیٹی"),
        w("God", "خدا", "الله", "خدا"),
        w("Prayer", "نماز", "صلاة", "نماز"),
        w("Faith", "ایمان", "إيمان", "ایمان"),
        w("Hope", "امید", "أمل", "امید"),
        w("Fear", "ترس", "خوف", "ڈر"),
        w("Dream", "رویا", "حلم", "خواب"),
        w("Truth", "حقیقت", "حقيقة", "سچ"),
        w("Lie", "دروغ", "كذب", "جھوٹ"),
        w("Help", "کمک", "مساعدة", "مدد"),
        w("Problem", "مشکل", "مشكلة", "مسئلہ"),
        w("Answer", "جواب", "جواب", "جواب"),
        w("Question", "سؤال", "سؤال", "سوال"),
        w("Language", "زبان", "لغة", "زبان"),
        w("Word", "کلمه", "كلمة", "لفظ"),
        w("Story", "داستان", "قصة", "کہانی"),
        w("Music", "موسیقی", "موسيقى", "موسیقی"),
        w("Song", "آهنگ", "أغنية", "گانا"),
        w("Color", "رنگ", "لون", "رنگ"),
        w("Red", "قرمز", "أحمر", "سرخ"),
        w("Blue", "آبی", "أزرق", "نیلا"),
        w("Green", "سبز", "أخضر", "سبز"),
        w("White", "سفید", "أبيض", "سفید"),
        w("Black", "سیاه", "أسود", "کالا"),
        w("Yellow", "زرد", "أصفر", "پیلا"),
        w("Number", "عدد", "رقم", "نمبر"),
        w("One", "یک", "واحد", "ایک"),
        w("Two", "دو", "اثنان", "دو"),
        w("Three", "سه", "ثلاثة", "تین"),
        w("Four", "چهار", "أربعة", "چار"),
        w("Five", "پنج", "خمسة", "پانچ"),
        w("Ten", "ده", "عشرة", "دس"),
        w("Hundred", "صد", "مائة", "سو"),
        w("Thousand", "هزار", "ألف", "ہزار"),
        w("Yes", "بله", "نعم", "ہاں"),
        w("No", "نه", "لا", "نہیں"),
        w("Please", "لطفاً", "من فضلك", "براہ کرم"),
        w("Thank you", "متشکرم", "شكرا", "شکریہ"),
        w("Sorry", "ببخشید", "آسف", "معاف کرنا"),
        w("Hello", "سلام", "مرحبا", "سلام"),
        w("Goodbye", "خداحافظ", "وداعا", "الوداع"),
        w("Welcome", "خوش آمدید", "أهلا", "خوش آمدید"),
        w("I", "من", "أنا", "میں"),
        w("You", "تو / شما", "أنت", "تم"),
        w("He", "او", "هو", "وہ"),
        w("She", "او", "هي", "وہ"),
        w("We", "ما", "نحن", "ہم"),
        w("They", "آنها", "هم", "وہ"),
        w("This", "این", "هذا", "یہ"),
        w("That", "آن", "ذلك", "وہ"),
        w("What", "چه", "ماذا", "کیا"),
        w("Where", "کجا", "أين", "کہاں"),
        w("When", "کی", "متى", "کب"),
        w("Why", "چرا", "لماذا", "کیوں"),
        w("How", "چگونه", "كيف", "کیسے"),
        w("Who", "کی", "من", "کون"),
        w("Come", "آمدن", "تعال", "آنا"),
        w("Go", "رفتن", "اذهب", "جانا"),
        w("See", "دیدن", "انظر", "دیکھنا"),
        w("Hear", "شنیدن", "اسمع", "سننا"),
        w("Speak", "صحبت کردن", "تكلم", "بولنا"),
        w("Eat", "خوردن", "كل", "کھانا"),
        w("Drink", "نوشیدن", "اشرب", "پینا"),
        w("Sleep", "خوابیدن", "نم", "سونا"),
        w("Walk", "راه رفتن", "امش", "چلنا"),
        w("Run", "دویدن", "اركض", "دوڑنا"),
        w("Read", "خواندن", "اقرأ", "پڑھنا"),
        w("Write", "نوشتن", "اكتب", "لکھنا"),
        w("Know", "دانستن", "اعرف", "جاننا"),
        w("Think", "فکر کردن", "فكر", "سوچنا"),
        w("Want", "خواستن", "أريد", "چاہنا"),
        w("Need", "نیاز داشتن", "أحتاج", "ضرورت"),
        w("Like", "دوست داشتن", "أحب", "پسند"),
        w("Give", "دادن", "اعط", "دینا"),
        w("Take", "گرفتن", "خذ", "لینا"),
        w("Buy", "خریدن", "اشتر", "خریدنا"),
        w("Sell", "فروختن", "بع", "بیچنا"),
        w("Open", "باز کردن", "افتح", "کھولنا"),
        w("Close", "بستن", "اغلق", "بند کرنا"),
        w("Start", "شروع کردن", "ابدأ", "شروع"),
        w("Finish", "تمام کردن", "انه", "ختم"),
        w("Learn", "یاد گرفتن", "تعلم", "سیکھنا"),
        w("Teach", "یاد دادن", "علم", "سکھانا"),
        w("Remember", "به یاد آوردن", "تذكر", "یاد رکھنا"),
        w("Forget", "فراموش کردن", "انس", "بھولنا"),
        w("Apple", "سیب", "تفاح", "سیب"),
        w("Orange", "پرتقال", "برتقال", "سنگتره"),
        w("Banana", "موز", "موز", "کیلا"),
        w("Rice", "برنج", "أرز", "چاول"),
        w("Meat", "گوشت", "لحم", "گوشت"),
        w("Fish", "ماهی", "سمك", "مچھلی"),
        w("Chicken", "مرغ", "دجاج", "مرغی"),
        w("Egg", "تخم‌مرغ", "بيضة", "انڈا"),
        w("Salt", "نمک", "ملح", "نمک"),
        w("Sugar", "شکر", "سكر", "چینی"),
        w("Oil", "روغن", "زيت", "تیل"),
        w("Tea", "چای", "شاي", "چائے"),
        w("Coffee", "قهوه", "قهوة", "کافی"),
        w("Fruit", "میوه", "فاكهة", "پھل"),
        w("Vegetable", "سبزی", "خضار", "سبزی"),
        w("Potato", "سیب‌زمینی", "بطاطس", "آلو"),
        w("Tomato", "گوجه‌فرنگی", "طماطم", "ٹماٹر"),
        w("Onion", "پیاز", "بصل", "پیاز"),
        w("Garlic", "سیر", "ثوم", "لہسن"),
        w("Bread", "نان", "خبز", "روٹی"),
        w("Clothes", "لباس", "ملابس", "کپڑے"),
        w("Shirt", "پیراهن", "قميص", "قمیض"),
        w("Pants", "شلوار", "بنطلون", "پتلون"),
        w("Shoes", "کفش", "حذاء", "جوتے"),
        w("Hat", "کلاه", "قبعة", "ٹوپی"),
        w("Bag", "کیف", "حقيبة", "بیگ"),
        w("Phone", "تلفن", "هاتف", "فون"),
        w("Computer", "کامپیوتر", "حاسوب", "کمپیوٹر"),
        w("Internet", "اینترنت", "إنترنت", "انٹرنیٹ"),
        w("Television", "تلویزیون", "تلفزيون", "ٹی وی"),
        w("Radio", "رادیو", "راديو", "ریڈیو"),
        w("Clock", "ساعت", "ساعة", "گھڑی"),
        w("Key", "کلید", "مفتاح", "چابی"),
        w("Money", "پول", "نقود", "پیسہ"),
        w("Bank", "بانک", "بنك", "بینک"),
        w("Job", "شغل", "وظيفة", "نوکری"),
        w("Office", "اداره", "مكتب", "دفتر"),
        w("Factory", "کارخانه", "مصنع", "فیکٹری"),
        w("Farm", "مزرعه", "مزرعة", "کھیت"),
        w("Animal", "حیوان", "حيوان", "جانور"),
        w("Dog", "سگ", "كلب", "کتا"),
        w("Cat", "گربه", "قطة", "بلی"),
        w("Bird", "پرنده", "طائر", "پرندہ"),
        w("Horse", "اسب", "حصان", "گھوڑا"),
        w("Cow", "گاو", "بقرة", "گائے"),
        w("Sheep", "گوسفند", "خروف", "भेड़"),
        w("Lion", "شیر", "أسد", "شیر"),
        w("Tiger", "ببر", "نمر", "باگھ"),
        w("Elephant", "فیل", "فيل", "ہاتھی"),
        w("Snake", "مار", "ثعبان", "سانپ"),
        w("Body", "بدن", "جسم", "جسم"),
        w("Face", "صورت", "وجه", "چہرہ"),
        w("Hair", "مو", "شعر", "بال"),
        w("Nose", "بینی", "أنف", "ناک"),
        w("Mouth", "دهان", "فم", "منہ"),
        w("Tooth", "دندان", "سن", "دانت"),
        w("Ear", "گوش", "أذن", "کان"),
        w("Leg", "پا", "ساق", "ٹانگ"),
        w("Foot", "پا", "قدم", "پاؤں"),
        w("Finger", "انگشت", "إصبع", "انگلی"),
        w("Blood", "خون", "دم", "خون"),
        w("Bone", "استخوان", "عظم", "ہڈی"),
        w("Skin", "پوست", "جلد", "جلد"),
        w("Medicine", "دارو", "دواء", "دوا"),
        w("Pain", "درد", "ألم", "درد"),
        w("Health", "سلامتی", "صحة", "صحت"),
        w("Sick", "بیمار", "مريض", "بیمار"),
        w("Clean", "تمیز", "نظيف", "صاف"),
        w("Dirty", "کثیف", "وسخ", "گندا"),
        w("Fast", "سریع", "سريع", "تیز"),
        w("Slow", "آهسته", "بطيء", "آہستہ"),
        w("Early", "زود", "مبكر", "جلدی"),
        w("Late", "دیر", "متأخر", "دیر"),
        w("Near", "نزدیک", "قريب", "قریب"),
        w("Far", "دور", "بعيد", "دور"),
        w("Left", "چپ", "يسار", "بائیں"),
        w("Right", "راست", "يمين", "دائیں"),
        w("Up", "بالا", "فوق", "اوپر"),
        w("Down", "پایین", "تحت", "نیچے"),
        w("Inside", "داخل", "داخل", "اندر"),
        w("Outside", "خارج", "خارج", "باہر"),
        w("Front", "جلو", "أمام", "سامنے"),
        w("Back", "عقب", "خلف", "پیچھے"),
        w("High", "بلند", "عالي", "اونچا"),
        w("Low", "پایین", "منخفض", "نیچا"),
        w("Long", "بلند", "طويل", "لمبا"),
        w("Short", "کوتاه", "قصير", "چھوٹا"),
        w("Wide", "عریض", "واسع", "چوڑا"),
        w("Narrow", "باریک", "ضيق", "تنگ"),
        w("Heavy", "سنگین", "ثقيل", "بھاری"),
        w("Light", "سبک", "خفيف", "ہلکا"),
        w("Full", "پر", "ممتلئ", "بھرا"),
        w("Empty", "خالی", "فارغ", "خالی"),
        w("Young", "جوان", "شاب", "جوان"),
        w("Old", "پیر", "عجوز", "بوڑھا"),
        w("True", "درست", "صحيح", "صحیح"),
        w("False", "غلط", "خطأ", "غلط"),
        w("Possible", "ممکن", "ممكن", "ممکن"),
        w("Impossible", "غیرممکن", "مستحيل", "ناممکن"),
        w("Important", "مهم", "مهم", "اہم"),
        w("Dangerous", "خطرناک", "خطير", "خطرناک"),
        w("Safe", "امن", "آمن", "محفوظ"),
        w("Free", "آزاد", "حر", "آزاد"),
        w("Busy", "مشغول", "مشغول", "مصروف"),
        w("Easy", "آسان", "سهل", "آسان"),
        w("Difficult", "سخت", "صعب", "مشکل"),
        w("Same", "همان", "نفس", "وہی"),
        w("Different", "متفاوت", "مختلف", "مختلف"),
        w("First", "اول", "أول", "پہلا"),
        w("Last", "آخر", "آخر", "آخری"),
        w("Next", "بعدی", "التالي", "اگلا"),
        w("Previous", "قبلی", "السابق", "پچھلا"),
        w("Always", "همیشه", "دائما", "ہمیشہ"),
        w("Never", "هرگز", "أبدا", "کبھی نہیں"),
        w("Sometimes", "گاهی", "أحيانا", "کبھی کبھی"),
        w("Often", "اغلب", "غالبا", "اکثر"),
        w("Usually", "معمولاً", "عادة", "عام طور پر"),
        w("Already", "قبلاً", "بالفعل", "پہلے ہی"),
        w("Still", "هنوز", "لا يزال", "ابھی"),
        w("Also", "همچنین", "أيضا", "بھی"),
        w("Only", "فقط", "فقط", "صرف"),
        w("Very", "خیلی", "جدا", "بہت"),
        w("Too", "خیلی", "أيضا", "بہت"),
        w("More", "بیشتر", "أكثر", "زیادہ"),
        w("Less", "کمتر", "أقل", "کم"),
        w("Many", "زیاد", "كثير", "بہت سے"),
        w("Few", "کم", "قليل", "کچھ"),
        w("All", "همه", "كل", "سب"),
        w("Some", "بعض", "بعض", "کچھ"),
        w("Every", "هر", "كل", "ہر"),
        w("Other", "دیگر", "آخر", "دوسرا"),
        w("Another", "یکی دیگر", "آخر", "ایک اور"),
        w("Both", "هر دو", "كلا", "دونوں"),
        w("Each", "هر یک", "كل", "ہر ایک"),
        w("Own", "خود", "خاص", "اپنا"),
        w("Such", "چنین", "مثل", "ایسا"),
        w("Even", "حتی", "حتى", "حتی"),
        w("Just", "فقط", "فقط", "صرف"),
        w("About", "درباره", "حول", "کے بارے میں"),
        w("Because", "چون", "لأن", "کیونکہ"),
        w("If", "اگر", "إذا", "اگر"),
        w("When", "وقتی", "عندما", "جب"),
        w("While", "در حالی که", "بينما", "جبکہ"),
        w("Before", "قبل از", "قبل", "پہلے"),
        w("After", "بعد از", "بعد", "بعد"),
        w("During", "در طول", "خلال", "دوران"),
        w("Until", "تا", "حتى", "تک"),
        w("Since", "از وقتی", "منذ", "جب سے"),
        w("Although", "اگرچه", "رغم", "حالانکہ"),
        w("However", "با این حال", "ومع ذلك", "تاہم"),
        w("Therefore", "بنابراین", "لذلك", "لہذا"),
        w("So", "پس", "لذا", "تو"),
        w("But", "اما", "لكن", "لیکن"),
        w("And", "و", "و", "اور"),
        w("Or", "یا", "أو", "یا"),
        w("Because of", "به خاطر", "بسبب", "کی وجہ سے"),
        w("According to", "طبق", "وفقا ل", "کے مطابق"),
        w("Instead of", "به جای", "بدلا من", "کی بجائے"),
        w("In order to", "به منظور", "من أجل", "کے لیے"),
        w("As well as", "و همچنین", "وكذلك", "کے ساتھ ساتھ"),
        w("Spring", "بهار", "ربيع", "بہار"),
        w("Summer", "تابستان", "صيف", "گرمی"),
        w("Autumn", "پاییز", "خريف", "خزاں"),
        w("Winter", "زمستان", "شتاء", "سردی"),
        w("Monday", "دوشنبه", "الإثنين", "پیر"),
        w("Tuesday", "سه‌شنبه", "الثلاثاء", "منگل"),
        w("Wednesday", "چهارشنبه", "الأربعاء", "بدھ"),
        w("Thursday", "پنجشنبه", "الخميس", "جمعرات"),
        w("Friday", "جمعه", "الجمعة", "جمعہ"),
        w("Saturday", "شنبه", "السبت", "ہفتہ"),
        w("Sunday", "یکشنبه", "الأحد", "اتوار"),
        w("January", "ژانویه", "يناير", "جنوری"),
        w("February", "فوریه", "فبراير", "فروری"),
        w("March", "مارس", "مارس", "مارچ"),
        w("April", "آوریل", "أبريل", "اپریل"),
        w("May", "مه", "مايو", "مئی"),
        w("June", "ژوئن", "يونيو", "جون"),
        w("July", "ژوئیه", "يوليو", "جولائی"),
        w("August", "اوت", "أغسطس", "اگست"),
        w("September", "سپتامبر", "سبتمبر", "ستمبر"),
        w("October", "اکتبر", "أكتوبر", "اکتوبر"),
        w("November", "نوامبر", "نوفمبر", "نومبر"),
        w("December", "دسامبر", "ديسمبر", "دسمبر"),
        w("North", "شمال", "شمال", "شمال"),
        w("South", "جنوب", "جنوب", "جنوب"),
        w("East", "شرق", "شرق", "مشرق"),
        w("West", "غرب", "غرب", "مغرب"),
        w("Country", "کشور", "بلد", "ملک"),
        w("Capital", "پایتخت", "عاصمة", "دارالحکومت"),
        w("Language", "زبان", "لغة", "زبان"),
        w("Religion", "دین", "دين", "مذہب"),
        w("Culture", "فرهنگ", "ثقافة", "ثقافت"),
        w("History", "تاریخ", "تاريخ", "تاریخ"),
        w("Science", "علم", "علم", "سائنس"),
        w("Art", "هنر", "فن", "فن"),
        w("Sport", "ورزش", "رياضة", "کھیل"),
        w("Football", "فوتبال", "كرة القدم", "فٹبال"),
        w("Game", "بازی", "لعبة", "کھیل"),
        w("Team", "تیم", "فريق", "ٹیم"),
        w("Win", "بردن", "فوز", "جیتنا"),
        w("Lose", "باختن", "خسارة", "ہارنا"),
        w("Play", "بازی کردن", "لعب", "کھیلنا"),
        w("Sing", "آواز خواندن", "غنى", "گانا"),
        w("Dance", "رقصیدن", "رقص", "ناچنا"),
        w("Draw", "کشیدن", "رسم", "کھینچنا"),
        w("Paint", "نقاشی کردن", "طلاء", "رنگ کرنا"),
        w("Cook", "پختن", "طبخ", "پکانا"),
        w("Wash", "شستن", "غسل", "دھونا"),
        w("Clean", "تمیز کردن", "نظف", "صاف کرنا"),
        w("Build", "ساختن", "بنى", "بنانا"),
        w("Break", "شکستن", "كسر", "توڑنا"),
        w("Fix", "درست کردن", "أصلح", "ٹھیک کرنا"),
        w("Send", "فرستادن", "أرسل", "بھیجنا"),
        w("Receive", "دریافت کردن", "استلم", "وصول کرنا"),
        w("Call", "تماس گرفتن", "اتصل", "کال کرنا"),
        w("Meet", "ملاقات کردن", "قابل", "ملنا"),
        w("Wait", "منتظر ماندن", "انتظر", "انتظار"),
        w("Stop", "ایستادن", "توقف", "رکنا"),
        w("Continue", "ادامه دادن", "استمر", "جاری رکھنا"),
        w("Begin", "شروع کردن", "بدأ", "شروع کرنا"),
        w("End", "پایان", "نهاية", "اختتام"),
        w("Change", "تغییر", "تغيير", "تبدیلی"),
        w("Stay", "ماندن", "بقي", "رہنا"),
        w("Leave", "ترک کردن", "غادر", "چھوڑنا"),
        w("Return", "بازگشتن", "عاد", "واپس آنا"),
        w("Arrive", "رسیدن", "وصل", "پہنچنا"),
        w("Travel", "سفر کردن", "سافر", "سفر"),
        w("Visit", "بازدید", "زار", "دورہ"),
        w("Live", "زندگی کردن", "عاش", "رہنا"),
        w("Die", "مردن", "مات", "مرنا"),
        w("Born", "متولد شدن", "ولد", "پیدا ہونا"),
        w("Grow", "رشد کردن", "نما", "بڑھنا"),
        w("Become", "شدن", "أصبح", "بننا"),
        w("Seem", "به نظر رسیدن", "بدا", "لگنا"),
        w("Feel", "احساس کردن", "شعر", "محسوس کرنا"),
        w("Touch", "لمس کردن", "لمس", "چھونا"),
        w("Smell", "بو کردن", "شم", "سونگھنا"),
        w("Taste", "چشیدن", "تذوق", "چکھنا"),
        w("Look", "نگاه کردن", "نظر", "دیکھنا"),
        w("Watch", "تماشا کردن", "شاهد", "دیکھنا"),
        w("Listen", "گوش دادن", "استمع", "سننا"),
        w("Understand", "فهمیدن", "فهم", "سمجھنا"),
        w("Believe", "باور کردن", "آمن", "یقین"),
        w("Hope", "امید داشتن", "أمل", "امید"),
        w("Wish", "آرزو کردن", "تمنى", "خواہش"),
        w("Decide", "تصمیم گرفتن", "قرر", "فیصلہ"),
        w("Choose", "انتخاب کردن", "اختار", "چننا"),
        w("Try", "سعی کردن", "حاول", "کوشش"),
        w("Succeed", "موفق شدن", "نجح", "کامیاب"),
        w("Fail", "شکست خوردن", "فشل", "ناکام"),
        w("Help", "کمک کردن", "ساعد", "مدد کرنا"),
        w("Need", "نیاز داشتن", "احتاج", "ضرورت"),
        w("Want", "خواستن", "أراد", "چاہنا"),
        w("Like", "دوست داشتن", "أحب", "پسند"),
        w("Hate", "متنفر بودن", "كره", "نفرت"),
        w("Love", "عاشق بودن", "أحب", "محبت"),
        w("Miss", "دلتنگ شدن", "افتقد", "یاد آنا"),
        w("Remember", "به یاد آوردن", "تذكر", "یاد رکھنا"),
        w("Forget", "فراموش کردن", "نسي", "بھولنا"),
        w("Learn", "یاد گرفتن", "تعلم", "سیکھنا"),
        w("Teach", "یاد دادن", "علم", "سکھانا"),
        w("Study", "درس خواندن", "درس", "مطالعہ"),
        w("Work", "کار کردن", "عمل", "کام کرنا"),
        w("Rest", "استراحت", "استراح", "آرام"),
        w("Sleep", "خوابیدن", "نام", "سونا"),
        w("Wake", "بیدار شدن", "استيقظ", "جاگنا"),
        w("Eat", "خوردن", "أكل", "کھانا"),
        w("Drink", "نوشیدن", "شرب", "پینا"),
        w("Hungry", "گرسنه", "جائع", "بھوکا"),
        w("Thirsty", "تشنه", "عطشان", "پیاسا"),
        w("Tired", "خسته", "متعب", "تھکا"),
        w("Sick", "بیمار", "مريض", "بیمار"),
        w("Healthy", "سالم", "صحي", "صحت مند"),
        w("Strong", "قوی", "قوي", "مضبوط"),
        w("Weak", "ضعیف", "ضعيف", "کمزور"),
        w("Brave", "شجاع", "شجاع", "بہادر"),
        w("Afraid", "ترسان", "خائف", "ڈرا ہوا"),
        w("Angry", "عصبانی", "غاضب", "غصے میں"),
        w("Happy", "خوشحال", "سعيد", "خوش"),
        w("Sad", "غمگین", "حزين", "اداس"),
        w("Surprised", "متعجب", "متفاجئ", "حیران"),
        w("Proud", "مغرور", "فخور", "فخر"),
        w("Ashamed", "شرمنده", "خجل", "شرمندہ"),
        w("Calm", "آرام", "هادئ", "پرسکون"),
        w("Nervous", "عصبی", "متوتر", "گھبرایا"),
        w("Excited", "هیجان‌زده", "متحمس", "پرجوش"),
        w("Bored", "خسته‌کننده", "ملل", "بور"),
        w("Interested", "علاقه‌مند", "مهتم", "دلچسپی"),
        w("Busy", "مشغول", "مشغول", "مصروف"),
        w("Free", "آزاد", "حر", "آزاد"),
        w("Ready", "آماده", "جاهز", "تیار"),
        w("Sure", "مطمئن", "متأكد", "یقین"),
        w("Possible", "ممکن", "ممكن", "ممکن"),
        w("Necessary", "ضروری", "ضروري", "ضروری"),
        w("Important", "مهم", "مهم", "اہم"),
        w("Special", "خاص", "خاص", "خاص"),
        w("Ordinary", "معمولی", "عادي", "عام"),
        w("Strange", "عجیب", "غريب", "عجیب"),
        w("Famous", "مشهور", "مشهور", "مشہور"),
        w("Rich", "ثروتمند", "غني", "امیر"),
        w("Poor", "فقیر", "فقير", "غریب"),
        w("Cheap", "ارزان", "رخيص", "سستا"),
        w("Expensive", "گران", "غالي", "مہنگا"),
        w("Beautiful", "زیبا", "جميل", "خوبصورت"),
        w("Ugly", "زشت", "قبيح", "بدصورت"),
        w("Clean", "تمیز", "نظيف", "صاف"),
        w("Dirty", "کثیف", "وسخ", "گندا"),
        w("Quiet", "ساکت", "هادئ", "خاموش"),
        w("Noisy", "پر سر و صدا", "صاخب", "شور"),
        w("Soft", "نرم", "ناعم", "نرم"),
        w("Hard", "سخت", "صلب", "سخت"),
        w("Smooth", "صاف", "أملس", "ہموار"),
        w("Rough", "زبر", "خشن", "کھردرا"),
        w("Bright", "روشن", "مشرق", "روشن"),
        w("Dark", "تاریک", "مظلم", "اندھیرا"),
        w("Deep", "عمیق", "عميق", "گہرا"),
        w("Shallow", "کم‌عمق", "ضحل", "کم گہرا"),
        w("Thick", "ضخیم", "سميك", "موٹا"),
        w("Thin", "نازک", "رقيق", "پتلا"),
        w("Wide", "عریض", "واسع", "چوڑا"),
        w("Narrow", "باریک", "ضيق", "تنگ"),
        w("Straight", "مستقیم", "مستقيم", "سیدھا"),
        w("Round", "گرد", "مستدير", "گول"),
        w("Square", "مربع", "مربع", "مربع"),
        w("Flat", "تخت", "مسطح", "ہموار"),
        w("Empty", "خالی", "فارغ", "خالی"),
        w("Full", "پر", "ممتلئ", "بھرا"),
        w("Open", "باز", "مفتوح", "کھلا"),
        w("Closed", "بسته", "مغلق", "بند"),
        w("Public", "عمومی", "عام", "عوامی"),
        w("Private", "خصوصی", "خاص", "نجی"),
        w("Local", "محلی", "محلي", "مقامی"),
        w("International", "بین‌المللی", "دولي", "بین الاقوامی"),
        w("Modern", "مدرن", "حديث", "جدید"),
        w("Traditional", "سنتی", "تقليدي", "روایتی"),
        w("Natural", "طبیعی", "طبيعي", "قدرتی"),
        w("Artificial", "مصنوعی", "اصطناعي", "مصنوعی")
    )

    private fun w(en: String, fa: String, ar: String, ur: String) = BalochiWord(
        english = en,
        persian = fa,
        arabic = ar,
        urdu = ur,
        balochi = ""
    )
}
