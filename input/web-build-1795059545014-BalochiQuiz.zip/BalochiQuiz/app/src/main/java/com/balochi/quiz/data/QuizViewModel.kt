package com.balochi.quiz.data

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

class QuizViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = WordRepository(application)
    private val settingsRepo = SettingsRepository(application)

    var words by mutableStateOf<List<BalochiWord>>(emptyList())
        private set

    var progress by mutableStateOf(repository.getProgress())
        private set

    var currentTheme by mutableStateOf(settingsRepo.getTheme())
        private set

    // دو زبان انتخابی برای آزمون
    var langA by mutableStateOf(QuizLanguage.ENGLISH)
        private set
    var langB by mutableStateOf(QuizLanguage.PERSIAN)
        private set

    // حالت آزمون
    var currentWord by mutableStateOf<BalochiWord?>(null)
        private set
    var questionText by mutableStateOf("")          // متن سوال (از زبان مبدأ)
    var options by mutableStateOf<List<String>>(emptyList())
        private set
    var selectedOptionIndex by mutableStateOf<Int?>(null)
        private set
    var isAnswerRevealed by mutableStateOf(false)
        private set
    var correctOptionIndex by mutableStateOf(-1)
        private set
    var score by mutableStateOf(0)
        private set
    var totalAnswered by mutableStateOf(0)
        private set
    var quizFinished by mutableStateOf(false)
        private set
    var fromLang by mutableStateOf(QuizLanguage.ENGLISH)
        private set
    var toLang by mutableStateOf(QuizLanguage.PERSIAN)
        private set

    private var usedWordIds = mutableSetOf<String>()
    private var wrongQueue = mutableListOf<String>() // برای تکرار اشتباهات

    init {
        loadWords()
    }

    fun loadWords() {
        words = repository.getAllWords()
        progress = repository.getProgress()
    }

    fun setLanguages(a: QuizLanguage, b: QuizLanguage) {
        if (a != b) {
            langA = a
            langB = b
        }
    }

    fun addWord(word: BalochiWord) {
        repository.addWord(word)
        loadWords()
    }

    fun updateWord(word: BalochiWord) {
        repository.updateWord(word)
        loadWords()
    }

    fun deleteWord(id: String) {
        repository.deleteWord(id)
        loadWords()
    }

    fun exportBackup(): String? = repository.exportBackup()

    fun importBackup(): Boolean {
        val ok = repository.importBackup()
        if (ok) loadWords()
        return ok
    }

    fun resetProgress() {
        repository.resetProgress()
        loadWords()
        progress = repository.getProgress()
    }

    fun getBackupPath(): String = repository.getBackupPath()

    fun setTheme(theme: com.balochi.quiz.ui.theme.AppTheme) {
        currentTheme = theme
        settingsRepo.setTheme(theme)
    }

    fun startQuiz() {
        score = 0
        totalAnswered = 0
        usedWordIds.clear()
        wrongQueue.clear()
        quizFinished = false
        nextQuestion()
    }

    fun nextQuestion() {
        selectedOptionIndex = null
        isAnswerRevealed = false

        // اول از صف اشتباهات اولویت بده (تکرار فاصله‌دار)
        val candidateId = wrongQueue.firstOrNull()
        val available = words.filter {
            it.hasMeaning(langA) && it.hasMeaning(langB) &&
                    (it.id !in usedWordIds || it.id == candidateId)
        }.sortedByDescending { it.priorityScore() }

        if (available.isEmpty()) {
            if (words.any { it.hasMeaning(langA) && it.hasMeaning(langB) }) {
                usedWordIds.clear()
                nextQuestion()
            } else {
                quizFinished = true
                repository.updateProgress(score, totalAnswered)
                progress = repository.getProgress()
            }
            return
        }

        val word = if (candidateId != null && available.any { it.id == candidateId }) {
            wrongQueue.removeAt(0)
            available.first { it.id == candidateId }
        } else {
            available.first()
        }

        usedWordIds.add(word.id)
        currentWord = word

        // جهت تصادفی بین دو زبان
        val directionForward = (0..1).random() == 0
        fromLang = if (directionForward) langA else langB
        toLang = if (directionForward) langB else langA

        questionText = word.getMeaning(fromLang)
        val correctMeaning = word.getMeaning(toLang)

        val wrongMeanings = words
            .filter { it.id != word.id && it.hasMeaning(toLang) }
            .map { it.getMeaning(toLang) }
            .distinct()
            .filter { it != correctMeaning }
            .shuffled()
            .take(3)

        val allOptions = (wrongMeanings + correctMeaning).shuffled()
        options = allOptions
        correctOptionIndex = allOptions.indexOf(correctMeaning)
    }

    fun selectOption(index: Int) {
        if (isAnswerRevealed) return
        selectedOptionIndex = index
        isAnswerRevealed = true
        totalAnswered++

        val isCorrect = index == correctOptionIndex
        if (isCorrect) {
            score++
        } else {
            // اضافه به صف تکرار (حداکثر ۲ بار در همین آزمون)
            currentWord?.let { w ->
                if (wrongQueue.count { it == w.id } < 3) {
                    wrongQueue.add(w.id)
                }
            }
        }
        currentWord?.let { repository.recordAnswer(it.id, isCorrect) }
    }

    fun onContinueAfterAnswer() {
        if (totalAnswered >= 20 && wrongQueue.isEmpty()) {
            quizFinished = true
            repository.updateProgress(score, totalAnswered)
            progress = repository.getProgress()
        } else {
            nextQuestion()
        }
    }
}
