#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
سیستم انبارداری موبایل‌فرندلی با Flask
تاریخ شمسی + تقویم ایرانی + طراحی زیبا
"""

import os
import sqlite3
from datetime import datetime
from functools import wraps
from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, g, jsonify, send_from_directory
)
import jdatetime

app = Flask(__name__)
app.secret_key = "anbar-secret-key-change-in-production-2026"
DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "anbar.db")


def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")
    return db


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()


def init_db():
    with app.app_context():
        db = get_db()
        db.executescript("""
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                code TEXT UNIQUE NOT NULL,
                price REAL NOT NULL DEFAULT 0,
                quantity INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                type TEXT NOT NULL CHECK(type IN ('ورود', 'خروج')),
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL DEFAULT 0,
                person TEXT NOT NULL,
                note TEXT,
                gregorian_dt TEXT NOT NULL,
                jalali_date TEXT NOT NULL,
                jalali_time TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_trans_product ON transactions(product_id);
            CREATE INDEX IF NOT EXISTS idx_trans_type ON transactions(type);
            CREATE INDEX IF NOT EXISTS idx_trans_jalali ON transactions(jalali_date);
        """)
        db.commit()


def to_jalali(dt=None):
    """Convert datetime to jalali date and time strings."""
    if dt is None:
        dt = datetime.now()
    jdt = jdatetime.datetime.fromgregorian(datetime=dt)
    return jdt.strftime("%Y/%m/%d"), jdt.strftime("%H:%M")


def jalali_to_gregorian(jdate_str, jtime_str="00:00"):
    """Convert jalali date string YYYY/MM/DD and time HH:MM to gregorian ISO."""
    try:
        parts = jdate_str.replace("-", "/").split("/")
        y, m, d = int(parts[0]), int(parts[1]), int(parts[2])
        tparts = jtime_str.split(":")
        h = int(tparts[0]) if len(tparts) > 0 else 0
        mi = int(tparts[1]) if len(tparts) > 1 else 0
        jdt = jdatetime.datetime(y, m, d, h, mi)
        gdt = jdt.togregorian()
        return gdt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def format_number(n):
    """Format number with Persian thousands separator."""
    try:
        return f"{int(n):,}".replace(",", "٬")
    except Exception:
        return str(n)


app.jinja_env.globals.update(
    format_number=format_number,
    to_jalali=to_jalali,
)


@app.route("/")
def index():
    db = get_db()
    products = db.execute(
        "SELECT COUNT(*) as cnt, COALESCE(SUM(quantity),0) as total_qty, "
        "COALESCE(SUM(quantity * price),0) as total_value FROM products"
    ).fetchone()
    recent = db.execute(
        """
        SELECT t.*, p.name as product_name, p.code as product_code
        FROM transactions t
        JOIN products p ON p.id = t.product_id
        ORDER BY t.id DESC LIMIT 8
        """
    ).fetchall()
    low_stock = db.execute(
        "SELECT * FROM products WHERE quantity <= 5 ORDER BY quantity ASC LIMIT 5"
    ).fetchall()
    return render_template(
        "index.html",
        products=products,
        recent=recent,
        low_stock=low_stock,
        page="home",
    )


@app.route("/products")
def products():
    db = get_db()
    q = request.args.get("q", "").strip()
    if q:
        rows = db.execute(
            "SELECT * FROM products WHERE name LIKE ? OR code LIKE ? ORDER BY name",
            (f"%{q}%", f"%{q}%"),
        ).fetchall()
    else:
        rows = db.execute("SELECT * FROM products ORDER BY name").fetchall()
    return render_template("products.html", products=rows, q=q, page="products")


@app.route("/products/add", methods=["GET", "POST"])
def product_add():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        code = request.form.get("code", "").strip()
        price = request.form.get("price", "0").replace(",", "").replace("٬", "")
        try:
            price = float(price)
        except ValueError:
            price = 0.0
        if not name or not code:
            flash("نام و شناسه کالا الزامی است.", "error")
            return redirect(url_for("product_add"))
        db = get_db()
        try:
            now = datetime.now().isoformat()
            db.execute(
                "INSERT INTO products (name, code, price, quantity, created_at) VALUES (?,?,?,?,?)",
                (name, code, price, 0, now),
            )
            db.commit()
            flash("کالا با موفقیت اضافه شد.", "success")
            return redirect(url_for("products"))
        except sqlite3.IntegrityError:
            flash("شناسه کالا تکراری است.", "error")
    return render_template("product_form.html", product=None, page="products")


@app.route("/products/<int:pid>/edit", methods=["GET", "POST"])
def product_edit(pid):
    db = get_db()
    product = db.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    if not product:
        flash("کالا یافت نشد.", "error")
        return redirect(url_for("products"))
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        code = request.form.get("code", "").strip()
        price = request.form.get("price", "0").replace(",", "").replace("٬", "")
        try:
            price = float(price)
        except ValueError:
            price = 0.0
        if not name or not code:
            flash("نام و شناسه کالا الزامی است.", "error")
            return redirect(url_for("product_edit", pid=pid))
        try:
            db.execute(
                "UPDATE products SET name=?, code=?, price=? WHERE id=?",
                (name, code, price, pid),
            )
            db.commit()
            flash("کالا به‌روزرسانی شد.", "success")
            return redirect(url_for("products"))
        except sqlite3.IntegrityError:
            flash("شناسه کالا تکراری است.", "error")
    return render_template("product_form.html", product=product, page="products")


@app.route("/products/<int:pid>/delete", methods=["POST"])
def product_delete(pid):
    db = get_db()
    db.execute("DELETE FROM products WHERE id=?", (pid,))
    db.commit()
    flash("کالا حذف شد.", "success")
    return redirect(url_for("products"))


@app.route("/entry", methods=["GET", "POST"])
def entry():
    db = get_db()
    products = db.execute("SELECT id, name, code, quantity FROM products ORDER BY name").fetchall()
    if request.method == "POST":
        product_id = request.form.get("product_id")
        qty = request.form.get("quantity", "0")
        person = request.form.get("person", "").strip()
        note = request.form.get("note", "").strip()
        jdate = request.form.get("jalali_date", "").strip()
        jtime = request.form.get("jalali_time", "12:00").strip()
        try:
            qty = int(qty)
        except ValueError:
            qty = 0
        if not product_id or qty <= 0 or not person or not jdate:
            flash("لطفاً همه فیلدهای ضروری را پر کنید.", "error")
            return redirect(url_for("entry"))
        product = db.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
        if not product:
            flash("کالا یافت نشد.", "error")
            return redirect(url_for("entry"))
        greg = jalali_to_gregorian(jdate, jtime)
        now = datetime.now().isoformat()
        db.execute(
            """INSERT INTO transactions
               (product_id, type, quantity, unit_price, person, note, gregorian_dt, jalali_date, jalali_time, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (product_id, "ورود", qty, product["price"], person, note, greg, jdate, jtime, now),
        )
        db.execute(
            "UPDATE products SET quantity = quantity + ? WHERE id=?",
            (qty, product_id),
        )
        db.commit()
        flash(f"ورود {qty} عدد از «{product['name']}» ثبت شد.", "success")
        return redirect(url_for("index"))
    jdate, jtime = to_jalali()
    return render_template(
        "transaction_form.html",
        products=products,
        action="ورود",
        jdate=jdate,
        jtime=jtime,
        page="entry",
    )


@app.route("/exit", methods=["GET", "POST"])
def exit_item():
    db = get_db()
    products = db.execute(
        "SELECT id, name, code, quantity FROM products WHERE quantity > 0 ORDER BY name"
    ).fetchall()
    if request.method == "POST":
        product_id = request.form.get("product_id")
        qty = request.form.get("quantity", "0")
        person = request.form.get("person", "").strip()
        note = request.form.get("note", "").strip()
        jdate = request.form.get("jalali_date", "").strip()
        jtime = request.form.get("jalali_time", "12:00").strip()
        try:
            qty = int(qty)
        except ValueError:
            qty = 0
        if not product_id or qty <= 0 or not person or not jdate:
            flash("لطفاً همه فیلدهای ضروری را پر کنید.", "error")
            return redirect(url_for("exit_item"))
        product = db.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
        if not product:
            flash("کالا یافت نشد.", "error")
            return redirect(url_for("exit_item"))
        if product["quantity"] < qty:
            flash(f"موجودی کافی نیست. موجودی فعلی: {product['quantity']}", "error")
            return redirect(url_for("exit_item"))
        greg = jalali_to_gregorian(jdate, jtime)
        now = datetime.now().isoformat()
        db.execute(
            """INSERT INTO transactions
               (product_id, type, quantity, unit_price, person, note, gregorian_dt, jalali_date, jalali_time, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (product_id, "خروج", qty, product["price"], person, note, greg, jdate, jtime, now),
        )
        db.execute(
            "UPDATE products SET quantity = quantity - ? WHERE id=?",
            (qty, product_id),
        )
        db.commit()
        flash(f"خروج {qty} عدد از «{product['name']}» ثبت شد.", "success")
        return redirect(url_for("index"))
    jdate, jtime = to_jalali()
    return render_template(
        "transaction_form.html",
        products=products,
        action="خروج",
        jdate=jdate,
        jtime=jtime,
        page="exit",
    )


@app.route("/inventory")
def inventory():
    db = get_db()
    rows = db.execute(
        "SELECT *, (quantity * price) as value FROM products ORDER BY name"
    ).fetchall()
    total_value = sum(r["value"] or 0 for r in rows)
    total_qty = sum(r["quantity"] or 0 for r in rows)
    return render_template(
        "inventory.html",
        products=rows,
        total_value=total_value,
        total_qty=total_qty,
        page="inventory",
    )


@app.route("/reports")
def reports():
    db = get_db()
    report_type = request.args.get("type", "daily")  # daily, monthly, yearly
    date_filter = request.args.get("date", "")
    jdate, _ = to_jalali()
    if not date_filter:
        if report_type == "daily":
            date_filter = jdate
        elif report_type == "monthly":
            date_filter = jdate[:7]  # YYYY/MM
        else:
            date_filter = jdate[:4]  # YYYY

    if report_type == "daily":
        like = date_filter
        title = f"گزارش روزانه {date_filter}"
    elif report_type == "monthly":
        like = date_filter + "%"
        title = f"گزارش ماهانه {date_filter}"
    else:
        like = date_filter + "%"
        title = f"گزارش سالانه {date_filter}"

    rows = db.execute(
        """
        SELECT t.*, p.name as product_name, p.code as product_code
        FROM transactions t
        JOIN products p ON p.id = t.product_id
        WHERE t.jalali_date LIKE ?
        ORDER BY t.jalali_date DESC, t.jalali_time DESC
        """,
        (like,),
    ).fetchall()

    entries = [r for r in rows if r["type"] == "ورود"]
    exits = [r for r in rows if r["type"] == "خروج"]
    total_in = sum(r["quantity"] for r in entries)
    total_out = sum(r["quantity"] for r in exits)
    value_in = sum(r["quantity"] * r["unit_price"] for r in entries)
    value_out = sum(r["quantity"] * r["unit_price"] for r in exits)

    return render_template(
        "reports.html",
        rows=rows,
        report_type=report_type,
        date_filter=date_filter,
        title=title,
        total_in=total_in,
        total_out=total_out,
        value_in=value_in,
        value_out=value_out,
        page="reports",
    )


@app.route("/transactions")
def transactions():
    db = get_db()
    rows = db.execute(
        """
        SELECT t.*, p.name as product_name, p.code as product_code
        FROM transactions t
        JOIN products p ON p.id = t.product_id
        ORDER BY t.id DESC LIMIT 100
        """
    ).fetchall()
    return render_template("transactions.html", rows=rows, page="transactions")


@app.route("/manifest.json")
def manifest():
    return send_from_directory(
        os.path.join(app.root_path, "static"),
        "manifest.json",
        mimetype="application/manifest+json",
    )


@app.route("/sw.js")
def service_worker():
    return send_from_directory(
        os.path.join(app.root_path, "static"),
        "sw.js",
        mimetype="application/javascript",
    )


if __name__ == "__main__":
    init_db()
    # برای تست روی موبایل: host=0.0.0.0
    app.run(host="0.0.0.0", port=5000, debug=True)
