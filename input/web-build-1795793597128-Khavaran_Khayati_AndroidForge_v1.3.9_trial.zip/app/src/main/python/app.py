# -*- coding: utf-8 -*-
"""برنامه دفتر مشتریان و اندازه‌های خیاطی؛ ذخیره‌سازی محلی با SQLite."""
import os
import sys
import subprocess as _bootstrap_subprocess
from pathlib import Path as _BootstrapPath

_BOOT_DIR = _BootstrapPath(__file__).resolve().parent
if os.name == "nt":
    _venv_dir = _BOOT_DIR / ".venv"
    _venv_python = _venv_dir / "Scripts" / "python.exe"
    if not _venv_python.exists():
        try:
            _bootstrap_subprocess.run([sys.executable, "-m", "venv", str(_venv_dir)], check=True)
        except Exception:
            pass
    if _venv_python.exists() and _BootstrapPath(sys.executable).resolve() != _venv_python.resolve():
        os.execv(str(_venv_python), [str(_venv_python), str(_BootstrapPath(__file__).resolve()), *sys.argv[1:]])

try:
    import flask as _flask_check  # noqa: F401
except ImportError:
    print("در حال نصب وابستگی‌های برنامه (Flask)...")
    _install_command = [sys.executable, "-m", "pip", "install", "-r", str(_BOOT_DIR / "requirements.txt")]
    _install_result = _bootstrap_subprocess.run(_install_command)
    if _install_result.returncode:
        print("مخزن اصلی در دسترس نبود؛ مخزن جایگزین امتحان می‌شود...")
        _bootstrap_subprocess.run(
            _install_command + ["-i", "https://repo.huaweicloud.com/repository/pypi/simple"],
            check=True,
        )

from flask import Flask, render_template, request, redirect, url_for, flash, send_file, session, abort, make_response
import sqlite3
from pathlib import Path
from datetime import date, timedelta
import json
import re
import shutil
import secrets
import socket
from datetime import datetime
from decimal import Decimal, InvalidOperation
import threading
import webbrowser
from collections import OrderedDict
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.serving import make_server
import hashlib
import base64
import hmac
import platform
import smtplib
import ssl
from email.message import EmailMessage
from urllib.parse import quote, urlencode
from urllib.request import Request as URLRequest, urlopen
from urllib.error import URLError, HTTPError

CODE_DIR = Path(__file__).resolve().parent
APP_DIR = Path(os.environ.get("KHAYATI_DATA_DIR", str(CODE_DIR))).expanduser().resolve()
WEB_DIR = Path(os.environ.get("KHAYATI_WEB_DIR", str(CODE_DIR))).expanduser().resolve()
APP_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = APP_DIR / "khayati.db"
UPLOAD_DIR = APP_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)
MDB_CONFIG = APP_DIR / "mdb_mapping.json"
SMTP_PASSWORD_PATH = APP_DIR / ".smtp_password"  # رمز SMTP خارج از دیتابیس پشتیبان نگهداری می‌شود.
AMOOT_TOKEN_PATH = APP_DIR / ".amoot_token"  # توکن آموت خارج از دیتابیس پشتیبان نگهداری می‌شود.

app = Flask(__name__, template_folder=str(WEB_DIR / "templates"), static_folder=str(WEB_DIR / "static"))

# توکن‌های موقت برای دریافت اسکن از Binary Eye در شبکه محلی
SCANNER_SESSIONS = {}
PC_PRINT_TOKENS = {}
_secret_path = APP_DIR / "session.secret"
if _secret_path.exists():
    app.secret_key = _secret_path.read_text(encoding="utf-8").strip()
else:
    app.secret_key = secrets.token_hex(32)
    _secret_path.write_text(app.secret_key, encoding="utf-8")
app.config["MAX_CONTENT_LENGTH"] = 250 * 1024 * 1024
def format_money(value):
    """نمایش مبالغ با جداکننده سه‌رقمی و حذف اعشار صفرِ انتهایی."""
    if value is None:
        return '—'
    raw = str(value).strip().replace(',', '').replace('٬', '').replace('٫', '.')
    raw = raw.translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789'))
    if not raw:
        return '—'
    try:
        number = Decimal(raw)
        if not number.is_finite():
            return str(value)
        text = format(number, ',f')
        if '.' in text:
            text = text.rstrip('0').rstrip('.')
        return text
    except (InvalidOperation, ValueError):
        return str(value)

app.jinja_env.filters['money'] = format_money

app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

# فیلدهایی که به پرونده دائمی مشتری و اندازه‌های او تعلق دارند.
ALL_PROFILE_FIELDS = [
    ("remarks", "ملاحظات"),
    ("fabric_meter", "متراژ پارچه"),
    ("order_quantity", "تعداد سفارش"),
    ("order_date", "تاریخ آخرین اندازه‌گیری"),
    ("height", "قد"),
    ("sleeve", "آستین"),
    ("shoulder", "شانه"),
    ("collar", "یقه"),
    ("waist", "کمر"),
    ("skirt", "دامن"),
    ("trousers", "شلوار"),
    ("hem", "دمپا"),
    ("underarm", "زیر بغل"),
    ("extra_3", "بازو"),
    ("middle", "وسط"),
    ("hem_circumference", "دور کف"),
    ("hem_model", "مدل کف"),
    ("trousers_model", "مدل شلوار"),
    ("trousers_width", "عرض شلوار"),
    ("crotch", "خشتک"),
    ("trousers_hem_model", "مدل دمپا"),
    ("pocket_model", "مدل جیب"),
    ("pocket_distance", "فاصله جیب"),
    ("pocket_height", "ارتفاع جیب"),
    ("pocket_width", "عرض جیب"),
    ("pen_holder", "جاخودکاری"),
    ("brand_type", "نوع مارک"),
    ("waist_quarter_1", "چاک کمر ۱"),
    ("waist_quarter_2", "چاک کمر ۲"),
    ("waist_quarter_3", "چاک کمر ۳"),
    ("collar_model", "مدل یقه"),
    ("pati_size", "اندازه پتی"),
    ("pati_type", "نوع پتی"),
    ("pati_button", "دکمه پتی"),
    ("extra_4", "زیر پتی"),
    ("stitch_type", "نوع دوخت"),
    ("skirt_model", "مدل دامن"),
    ("button_type", "نوع دکمه"),
    ("fabric_color", "رنگ پارچه"),
    ("description", "توضیحات"),
    ("tailor_name", "نام خیاط"),
    ("extra_1", "جیب مخفی"),
    ("extra_2", "جیب شلوار"),
    ("extra_5", "یادداشت"),
    ("extra_6", "یادداشت"),
    ("extra_7", "یادداشت"),
]
# فیلدهای حسابداری/تعداد و جدول سفارش از فرم جدید حذف شده‌اند.
PROFILE_FIELDS = ALL_PROFILE_FIELDS
PROFILE_META_FIELDS = [
    ("remarks", "ملاحظات"),
    ("fabric_meter", "متراژ پارچه"),
    ("order_quantity", "تعداد سفارش"),
    ("order_date", "تاریخ آخرین اندازه‌گیری"),
    ("tailor_name", "نام خیاط"),
]
MAIN_MEASUREMENTS = [
    ("height", "قد"), ("sleeve", "آستین"), ("shoulder", "شانه"),
    ("collar", "یقه"), ("waist", "کمر"), ("skirt", "دامن"),
    ("trousers", "شلوار"), ("hem", "دمپا"),
]
DETAIL_FIELDS = [
    (key, label) for key, label in PROFILE_FIELDS
    if key not in {"remarks", "fabric_meter", "order_quantity", "order_date", "tailor_name"}
    and key not in {k for k, _ in MAIN_MEASUREMENTS}
    and not key.startswith("extra_")
]
POCKET_FIELDS = [("extra_1", "جیب مخفی"), ("extra_2", "جیب شلوار")]
RESERVED_FIELDS = [(f"extra_{n}", f"فیلد اضافی {n}") for n in range(5, 8)]
ALL_EDITABLE_FIELDS = [("name", "نام مشتری"), ("mobile", "موبایل")] + PROFILE_FIELDS
ALL_EDITABLE_FIELD_KEYS = {key for key, _ in ALL_EDITABLE_FIELDS}
CUSTOMER_IMPORT_FIELDS = [("customer_code", "کد مشتری (ID از MDB)"), ("name", "نام مشتری"), ("mobile", "موبایل")]
MDB_FIELDS = CUSTOMER_IMPORT_FIELDS + PROFILE_FIELDS + [("total_amount", "مبلغ کل سفارش"), ("deposit_amount", "بیعانه"), ("remaining_amount", "باقیمانده")]
PRINT_DETAIL_FIELDS = [
    (key, label) for key, label in DETAIL_FIELDS + [("extra_3", "بازو")] + POCKET_FIELDS
    if key not in {"pati_size", "pati_type", "pati_button", "extra_4", "pocket_distance", "pocket_height", "pocket_width", "brand_type"}
]
OPTION_FIELDS = [(key, label) for key, label in PROFILE_FIELDS if label.startswith(("مدل", "نوع")) or key in {"extra_4", "pen_holder"}]
OPTION_FIELD_KEYS = {key for key, _ in OPTION_FIELDS}
OPTIONAL_PROFILE_KEYS = {"waist_quarter_1", "waist_quarter_2", "waist_quarter_3", "pen_holder", "extra_3", "fabric_color", "remarks", "description", "extra_5", "extra_6", "extra_7", "pocket_distance", "pocket_height", "pocket_width", "brand_type", "extra_1", "extra_2", "tailor_name", "order_date"}
REQUIRED_PROFILE_KEYS = {key for key, _ in PROFILE_FIELDS if key not in OPTIONAL_PROFILE_KEYS}
# کلید عمومی RSA؛ کلید خصوصی صدور مجوز خارج از برنامه و نزد صادرکننده نگهداری می‌شود.
LICENSE_PUBLIC_N = int("b72251b2071275f1eb3f386c7c1309ef669d5ca011ba1ce0d656c9a2c2abaa708101f5b7e717d51aba85c122dd817a7d3dd5f79f8a9479a86d5f8927e0bf7b5d5fc05d50a09339f07dc0533adca8934a2d7f58131b43e0a61239b2bf45071333ba1e47e88689e62d579c440837bc5f8ed6db44a8eeede96fd31d47a7e3b5adfc4cbae280d8a52f77fe7582131011bbfc9c94aa772340353ae868d2c5bd0059ebb74b56b27209dd32cd0f16b81cb2d57c2f5f0fec4e1570b06da5c70a40abd35752ebbbc9c609a712ed959fdf64d8ecb1f126c9e8d9f2f47cd84bb435f83892268d26e6b3a431c5f3ecb66b236c74ae45eb62a3dc14e3436e7344e3d9ef1b510b", 16)
LICENSE_PUBLIC_E = 65537
# کد عمومی فعال‌سازی که مالک برنامه تعیین کرده است. برای امنیت بالاتر، کد امضاشده اختصاصی توصیه می‌شود.
MASTER_REGISTRATION_CODE = "omar992810246600"
DEVELOPER_SMS_NUMBER = "09159499928"
TRIAL_HOURS = 72
TRIAL_CUSTOMER_LIMIT = 3
APP_EDITION = "trial-3day"


def _device_identity_seed():
    supplied = os.environ.get("KHAYATI_DEVICE_ID", "").strip()
    if supplied:
        return "android:" + supplied
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
                return "windows:" + str(winreg.QueryValueEx(key, "MachineGuid")[0])
        except Exception:
            pass
    for candidate in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
        try:
            value = candidate.read_text(encoding="utf-8").strip()
            if value:
                return "linux:" + value
        except Exception:
            pass
    return "fallback:" + platform.node() + ":" + str(getattr(os, "getuid", lambda: 0)())


def get_installation_id():
    seed = _device_identity_seed()
    if seed and not seed.startswith("fallback:"):
        return hashlib.sha256(("KHAVARAN-SOFT|" + seed).encode("utf-8")).hexdigest()[:24].upper()
    id_path = APP_DIR / "license.installation"
    if id_path.exists():
        value = id_path.read_text(encoding="utf-8").strip().upper()
        if re.fullmatch(r"[A-F0-9]{24}", value):
            return value
    value = secrets.token_hex(12).upper()
    id_path.write_text(value, encoding="utf-8")
    return value

INSTALLATION_ID = get_installation_id()
DEFAULT_DEVICE_CODE = str(int(hashlib.sha256(("KHAVARAN-DEVICE|" + INSTALLATION_ID).encode("utf-8")).hexdigest(), 16) % (10**15)).zfill(15)
# شناسه نمونه سرور پایدار در فایل — با بستن/بازکردن اپ ریست نمی‌شود
_server_instance_path = APP_DIR / "server_instance.id"
try:
    if _server_instance_path.exists():
        SERVER_INSTANCE = _server_instance_path.read_text(encoding="utf-8").strip() or secrets.token_urlsafe(18)
    else:
        SERVER_INSTANCE = secrets.token_urlsafe(18)
        _server_instance_path.write_text(SERVER_INSTANCE, encoding="utf-8")
except Exception:
    SERVER_INSTANCE = secrets.token_urlsafe(18)
_HTTP_SERVER = None


def gregorian_to_jalali(gy, gm, gd):
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
    gy2 = gy + 1 if gm > 2 else gy
    days = (355666 + 365 * gy + (gy2 + 3) // 4 - (gy2 + 99) // 100
            + (gy2 + 399) // 400 + gd + g_d_m[gm - 1])
    jy = -1595 + 33 * (days // 12053)
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    if days < 186:
        jm = 1 + days // 31
        jd = 1 + days % 31
    else:
        jm = 7 + (days - 186) // 30
        jd = 1 + (days - 186) % 30
    return jy, jm, jd


def today_jalali():
    now = date.today()
    y, m, d = gregorian_to_jalali(now.year, now.month, now.day)
    return f"{y:04d}/{m:02d}/{d:02d}"

def _validated_device_datetime(value, fallback=None):
    """زمان محلی مرورگر را بدون تبدیل منطقه زمانی دریافت می‌کند."""
    raw = normalize_digits(str(value or "").strip())
    raw = raw.replace("T", " ")[:19]
    try:
        return datetime.strptime(raw, "%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError):
        return fallback or datetime.now()


def _device_now_for_request():
    raw = request.form.get("device_datetime") or request.args.get("device_now")
    return _validated_device_datetime(raw)


def format_status_datetime(value):
    """تاریخ و ساعت میلادی ذخیره‌شده را به شمسی با ساعت محلی تبدیل می‌کند."""
    raw = str(value or "").strip()
    if not raw:
        return "—"
    try:
        stamp = datetime.strptime(raw[:19], "%Y-%m-%d %H:%M:%S")
        jy, jm, jd = gregorian_to_jalali(stamp.year, stamp.month, stamp.day)
        return f"{jy:04d}/{jm:02d}/{jd:02d} - {stamp:%H:%M}"
    except (TypeError, ValueError):
        return raw



def normalize_digits(value):
    text = str(value or "")
    return text.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))


def normalize_mobile(value):
    digits = re.sub(r"\D", "", normalize_digits(value))
    if digits.startswith("0098") and len(digits) >= 12:
        digits = "0" + digits[4:]
    elif digits.startswith("98") and len(digits) == 12:
        digits = "0" + digits[2:]
    return digits


def mobile_for_whatsapp(value):
    """شماره بین‌المللی بدون + برای wa.me (مثال: 98915...)"""
    digits = re.sub(r"\D", "", normalize_digits(value or ""))
    if digits.startswith("0098"):
        digits = digits[4:]
    elif digits.startswith("98") and len(digits) >= 12:
        digits = digits[2:]
    if digits.startswith("0"):
        digits = digits[1:]
    if not digits.startswith("98"):
        digits = "98" + digits
    return digits


def sms_deeplink(mobile, message):
    num = re.sub(r"[^0-9+]", "", normalize_mobile(mobile) or mobile or "")
    return "sms:" + num + "?body=" + quote(message or "")


def whatsapp_deeplink(mobile, message):
    return "https://wa.me/" + mobile_for_whatsapp(mobile) + "?text=" + quote(message or "")



def display_customer_code(value):
    code = str(value or "").strip()
    upper = code.upper()
    if upper.startswith("OLD-"):
        return code[4:]
    if upper.startswith("LOCAL-"):
        return code[6:]
    return code


def customer_sort_key(customer):
    code = normalize_digits(display_customer_code(customer["customer_code"] or "")).strip()
    if code.isdigit():
        return (0, int(code), int(customer["id"]))
    return (1, code.casefold(), int(customer["id"]))


class _ClosingSQLiteConnection(sqlite3.Connection):
    """اتصال SQLite که پس از خروج از بلوک with حتماً بسته می‌شود.

    در sqlite3 معمولی، with فقط commit/rollback می‌کند و اتصال را نمی‌بندد؛
    در ویندوز این موضوع می‌تواند فایل khayati.db را قفل نگه دارد و مانع جایگزینی شود.
    """
    def __exit__(self, exc_type, exc_value, traceback):
        try:
            return super().__exit__(exc_type, exc_value, traceback)
        finally:
            self.close()


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30, factory=_ClosingSQLiteConnection)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 30000")
    return conn


def init_db():
    profile_sql = ",\n".join(f'"{key}" TEXT' for key, _ in PROFILE_FIELDS)
    with get_db() as db:
        db.execute(f"""
            CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_code TEXT DEFAULT '',
                name TEXT NOT NULL,
                mobile TEXT DEFAULT '',
                {profile_sql}
            )
        """)
        customer_columns = {row[1] for row in db.execute("PRAGMA table_info(customers)").fetchall()}
        added_profile_columns = []
        for key, _ in PROFILE_FIELDS:
            if key not in customer_columns:
                db.execute(f'ALTER TABLE customers ADD COLUMN "{key}" TEXT')
                added_profile_columns.append(key)
        if "customer_code" not in customer_columns:
            db.execute("ALTER TABLE customers ADD COLUMN customer_code TEXT DEFAULT ''")
        for column in ("last_sms_text", "last_sms_at", "last_sms_type"):
            if column not in customer_columns:
                db.execute(f"ALTER TABLE customers ADD COLUMN {column} TEXT DEFAULT ''")

        # مهاجرت امن: آخرین اندازه‌های موجود هر مشتری از آخرین ردیف جدول قدیمی orders
        # به پرونده دائمی مشتری منتقل می‌شود. جدول قبلی حذف نمی‌شود تا داده‌های قدیمی محفوظ بماند.
        legacy_tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        if "orders" in legacy_tables and added_profile_columns:
            order_columns = {r[1] for r in db.execute("PRAGMA table_info(orders)").fetchall()}
            transferable = [k for k in added_profile_columns if k in order_columns]
            customer_ids = db.execute("SELECT id FROM customers ORDER BY id").fetchall()
            for c in customer_ids:
                last = db.execute("SELECT * FROM orders WHERE customer_id=? ORDER BY id DESC LIMIT 1", (c["id"],)).fetchone()
                if not last:
                    continue
                for key in transferable:
                    db.execute(f'UPDATE customers SET "{key}"=? WHERE id=?', (last[key], c["id"]))

        old_rows = db.execute("SELECT id FROM customers WHERE customer_code IS NULL OR customer_code='' ").fetchall()
        for row in old_rows:
            db.execute("UPDATE customers SET customer_code=? WHERE id=?", (f"LOCAL-{row['id']}", row["id"]))
        db.execute("""
            CREATE TABLE IF NOT EXISTS dropdown_options (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                field_key TEXT NOT NULL,
                option_value TEXT NOT NULL,
                UNIQUE(field_key, option_value)
            )
        """)
        # گزینه‌های پیش‌فرض کمبوباکس‌ها؛ INSERT OR IGNORE باعث می‌شود گزینه‌های
        # افزوده‌شده/حذف‌شده توسط کاربر در اجراهای بعدی بازنویسی نشوند.
        default_dropdown_options = {
            "pocket_model": ("راسته", "ساده بدون لایه", "کج", "کلاه دار", "بلوچی", "بدون جیب"),
            "trousers_model": ("بدون درز", "درزدار", "پاکستانی"),
            "trousers_hem_model": ("بدون لایه", "لایه دار", "پردوخت"),
            "stitch_type": ("ساده", "زنجیری", "2خط براق", "یک خط براق"),
            "skirt_model": ("گرد", "راست", "چهار تکه"),
            "extra_4": ("راست", "گرد", "نوک دار"),
            "button_type": ("کاج", "فلزی", "فلزی رولاکی"),
            "pati_type": ("1", "1/25", "1/5", "1/75"),
            "pen_holder": ("جاخودکاری بیرون", "جاخودکاری داخل", "​"),
            "brand_type": ("گلدوزی", "پارچه ای", "نمادوز"),
            "hem_model": ("2/5 چین دار",),
            "collar_model": ("ملایی",),
        }
        for field_key, values in default_dropdown_options.items():
            for default_value in values:
                db.execute(
                    "INSERT OR IGNORE INTO dropdown_options(field_key, option_value) VALUES(?,?)",
                    (field_key, default_value),
                )
        db.execute("""
            CREATE TABLE IF NOT EXISTS daily_jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                order_day TEXT NOT NULL,
                created_at TEXT NOT NULL,
                fabric_meter TEXT DEFAULT '',
                order_quantity TEXT DEFAULT '',
                barcode TEXT DEFAULT '',
                status TEXT DEFAULT 'in_progress',
                delivered_at TEXT DEFAULT '',
                FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE
            )
        """)
        job_columns = {row[1] for row in db.execute("PRAGMA table_info(daily_jobs)").fetchall()}
        for column, definition in {
            "fabric_meter": "TEXT DEFAULT ''",
            "order_quantity": "TEXT DEFAULT ''",
            "barcode": "TEXT DEFAULT ''",
            "status": "TEXT DEFAULT 'in_progress'",
            "delivered_at": "TEXT DEFAULT ''",
            "ready_at": "TEXT DEFAULT ''",
            "sent_to_sewing_at": "TEXT DEFAULT ''",
            "total_amount": "TEXT DEFAULT ''",
            "deposit_amount": "TEXT DEFAULT ''",
            "remaining_amount": "TEXT DEFAULT ''",
            "settlement_status": "TEXT DEFAULT ''",
            "finalized": "INTEGER DEFAULT 0",
        }.items():
            if column not in job_columns:
                db.execute(f"ALTER TABLE daily_jobs ADD COLUMN {column} {definition}")
        db.execute("CREATE INDEX IF NOT EXISTS idx_daily_jobs_day ON daily_jobs(order_day, id)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_daily_jobs_barcode ON daily_jobs(barcode)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_daily_jobs_status ON daily_jobs(status, order_day)")
        db.execute("UPDATE daily_jobs SET ready_at=? WHERE status='ready' AND (ready_at IS NULL OR ready_at='')", (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))
        db.execute("""
            CREATE TABLE IF NOT EXISTS app_settings (
                setting_key TEXT PRIMARY KEY,
                setting_value TEXT NOT NULL
            )
        """)
        db.execute("CREATE INDEX IF NOT EXISTS idx_customers_name ON customers(name)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_customers_mobile ON customers(mobile)")
        db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_customers_code_unique ON customers(customer_code) WHERE customer_code<>''")
        old_registration = db.execute("SELECT setting_value FROM app_settings WHERE setting_key='registration_completed'").fetchone()
        registration_version = db.execute("SELECT setting_value FROM app_settings WHERE setting_key='registration_version'").fetchone()
        if old_registration and old_registration[0] == "1" and (not registration_version or registration_version[0] not in {"rsa1", "owner-code-or-rsa1"}):
            db.execute("UPDATE app_settings SET setting_value='0' WHERE setting_key='registration_completed'")
        db.commit()


def form_value(key):
    return request.form.get(key, "").strip()


def get_all_field_options():
    with get_db() as db:
        rows = db.execute("SELECT field_key, option_value FROM dropdown_options ORDER BY option_value COLLATE NOCASE").fetchall()
    result = {key: [] for key, _ in OPTION_FIELDS}
    for row in rows:
        if row["field_key"] in result:
            result[row["field_key"]].append(row["option_value"])
    return result


def create_daily_job(db, customer_id, fabric_meter="", order_quantity=""):
    now = datetime.now()
    cur = db.execute(
        "INSERT INTO daily_jobs(customer_id, order_day, created_at, fabric_meter, order_quantity) VALUES(?,?,?,?,?)",
        (customer_id, today_jalali(), now.strftime("%H:%M"), fabric_meter or "", order_quantity or ""),
    )
    return cur.lastrowid


# Code 128 B symbol patterns. این بارکد بدون نیاز به سرویس اینترنتی یا کتابخانه اضافی تولید می‌شود.
_CODE128_PATTERNS = """BaBbBb|BbBaBb|BbBbBa|AbAbBc|AbAcBb|AcAbBb|AbBbAc|AbBcAb|AcBbAb|BbAbAc|BbAcAb|BcAbAb|AaBbCb|AbBaCb|AbBbCa|AaCbBb|AbCaBb|AbCbBa|BbCbAa|BbAaCb|BbAbCa|BaCbAb|BbCaAb|CaBaCa|CaAbBb|CbAaBb|CbAbBa|CaBbAb|CbBaAb|CbBbAa|BaBaBc|BaBcBa|BcBaBa|AaAcBc|AcAaBc|AcAcBa|AaBcAc|AcBaAc|AcBcAa|BaAcAc|BcAaAc|BcAcAa|AaBaCc|AaBcCa|AcBaCa|AaCaBc|AaCcBa|AcCaBa|CaCaBa|BaAcCa|BcAaCa|BaCaAc|BaCcAa|BaCaCa|CaAaBc|CaAcBa|CcAaBa|CaBaAc|CaBcAa|CcBaAa|CaDaAa|BbAdAa|DcAaAa|AaAbBd|AaAdBb|AbAaBd|AbAdBa|AdAaBb|AdAbBa|AaBbAd|AaBdAb|AbBaAd|AbBdAa|AdBaAb|AdBbAa|BdAbAa|BbAaAd|DaCaAa|BdAaAb|AcDaAa|AaAbDb|AbAaDb|AbAbDa|AaDbAb|AbDaAb|AbDbAa|DaAbAb|DbAaAb|DbAbAa|BaBaDa|BaDaBa|DaBaBa|AaAaDc|AaAcDa|AcAaDa|AaDaAc|AaDcAa|DaAaAc|DaAcAa|AaCaDa|AaDaCa|CaAaDa|DaAaCa|BaAdAb|BaAbAd|BaAbCb|BcCaAaB""".split("|")

def code128_svg(value):
    text_value = re.sub(r"[^0-9]", "", str(value or ""))
    if not text_value:
        return ""
    codes = [104] + [ord(ch) - 32 for ch in text_value]
    checksum = (104 + sum((idx + 1) * code for idx, code in enumerate(codes[1:]))) % 103
    codes.extend([checksum, 106])
    x = 10
    bars = []
    for code in codes:
        pattern = _CODE128_PATTERNS[code]
        for position, letter in enumerate(pattern):
            width = ord(letter.lower()) - ord('a') + 1
            if position % 2 == 0:
                bars.append(f'<rect x="{x}" y="0" width="{width}" height="42" fill="#000"/>')
            x += width
    total_width = x + 10
    return (f'<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="بارکد {text_value}" '
            f'viewBox="0 0 {total_width} 46" width="{total_width}mm" height="15mm" preserveAspectRatio="none">'
            + ''.join(bars) + '</svg>')


def job_barcode(db, job_id, customer):
    row = db.execute("SELECT barcode FROM daily_jobs WHERE id=?", (job_id,)).fetchone()
    if row and row["barcode"]:
        return row["barcode"]
    now = datetime.now()
    jy, jm, jd = gregorian_to_jalali(now.year, now.month, now.day)
    code = re.sub(r"\D", "", normalize_digits(display_customer_code(customer["customer_code"] or "")))
    if not code:
        code = str(customer["id"])
    value = f"{jy:04d}{jm:02d}{jd:02d}{now:%H%M}{code}"
    db.execute("UPDATE daily_jobs SET barcode=? WHERE id=?", (value, job_id))
    return value


def local_ipv4_addresses():
    """IPهای واقعی شبکه محلی برای اتصال کامپیوتر به گوشی."""
    found = set()
    def add(ip):
        if not ip or ip.startswith("127.") or ip.startswith("169.254."):
            return
        if ip.count(".") == 3:
            found.add(ip)
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.settimeout(0.5)
        probe.connect(("192.0.2.1", 80))
        add(probe.getsockname()[0])
        probe.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            add(info[4][0])
    except OSError:
        pass
    # فایل IP که سرویس اندروید هنگام راه‌اندازی می‌نویسد
    try:
        ip_file = APP_DIR / "server_ip.txt"
        if ip_file.exists():
            for line in ip_file.read_text(encoding="utf-8").splitlines():
                add(line.strip())
    except Exception:
        pass
    # اولویت: 192.168.* سپس 10.* سپس بقیه
    def sort_key(ip):
        if ip.startswith("192.168."):
            return (0, ip)
        if ip.startswith("10."):
            return (1, ip)
        if ip.startswith("172."):
            return (2, ip)
        return (3, ip)
    return sorted(found, key=sort_key)


def build_customer_groups(customers):
    grouped = OrderedDict()
    for customer in customers:
        mobile_key = normalize_mobile(customer["mobile"])
        key = mobile_key if mobile_key else f"no-mobile-{customer['id']}"
        grouped.setdefault(key, []).append(customer)
    groups = []
    for key, members in grouped.items():
        groups.append({
            "mobile": members[0]["mobile"] or "شماره ثبت نشده",
            "normalized_mobile": "" if key.startswith("no-mobile-") else key,
            "shared": bool(key and not key.startswith("no-mobile-") and len(members) > 1),
            "customers": members,
        })
    return groups


def _ordered_main_measurements(db=None):
    close = db is None
    if db is None:
        db = get_db()
    try:
        raw = _setting(db, "main_measurement_order")
        order = json.loads(raw) if raw else []
        lookup = dict(MAIN_MEASUREMENTS)
        keys = [k for k in order if k in lookup]
        keys += [k for k, _ in MAIN_MEASUREMENTS if k not in keys]
        return [(k, lookup[k]) for k in keys]
    finally:
        if close: db.close()

def _ordered_all_fields(db=None):
    close = db is None
    if db is None: db = get_db()
    try:
        raw = _setting(db, "all_form_field_order")
        try: order = json.loads(raw) if raw else []
        except Exception: order = []
        lookup = dict(ALL_EDITABLE_FIELDS)
        keys = [k for k in order if k in lookup]
        keys += [k for k, _ in ALL_EDITABLE_FIELDS if k not in keys]
        return [(k, lookup[k]) for k in keys]
    finally:
        if close: db.close()

def _customer_form_context(customer=None, print_after_save=False, validation_error=False, job_id=""):
    job_finance = {"total_amount": "", "deposit_amount": "", "remaining_amount": ""}
    with get_db() as db:
        ordered_main = _ordered_main_measurements(db)
        ordered_all = _ordered_all_fields(db)
        measurement_layout = _setting(db, "measurement_layout") or "tiles"
        if job_id and str(job_id).isdigit():
            row = db.execute("SELECT total_amount,deposit_amount,remaining_amount FROM daily_jobs WHERE id=?", (int(job_id),)).fetchone()
        elif customer is not None and customer.get("id") if isinstance(customer, dict) else customer is not None:
            cid = customer.get("id") if isinstance(customer, dict) else customer["id"]
            row = db.execute("SELECT total_amount,deposit_amount,remaining_amount FROM daily_jobs WHERE customer_id=? ORDER BY id DESC LIMIT 1", (cid,)).fetchone()
        else:
            row = None
        if row:
            job_finance = dict(row)
    return render_template(
        "form.html", customer=customer,
        profile_meta_fields=PROFILE_META_FIELDS,
        main_fields=ordered_main,
        all_fields=ordered_all,
        measurement_layout=measurement_layout,
        detail_fields=DETAIL_FIELDS,
        pocket_fields=POCKET_FIELDS,
        reserved_fields=RESERVED_FIELDS,
        print_after_save=print_after_save,
        validation_error=validation_error,
        job_id=job_id,
        job_finance=job_finance,
        today_date=today_jalali(),
        required_keys={"name", "mobile"} | REQUIRED_PROFILE_KEYS,
        main_keys={key for key, _ in MAIN_MEASUREMENTS},
        option_fields=OPTION_FIELD_KEYS,
        field_options=get_all_field_options(),
    )


def _setting(db, key):
    row = db.execute("SELECT setting_value FROM app_settings WHERE setting_key=?", (key,)).fetchone()
    return row["setting_value"] if row else ""


def _save_setting(db, key, value):
    db.execute("INSERT OR REPLACE INTO app_settings(setting_key,setting_value) VALUES(?,?)", (key, str(value)))


def make_activation_code(device_code):
    """ساخت کد درخواستی ۲۰ نویسه‌ای طبق الگوی توافق‌شده."""
    digits = re.sub(r"\D", "", normalize_digits(str(device_code or "")))
    if len(digits) != 15:
        return ""
    return digits[5:10] + "DOA" + digits[11:15] + "RE" + digits[:5] + digits[10]


def valid_device_code(device_code):
    return bool(re.fullmatch(r"\d{15}", re.sub(r"\D", "", normalize_digits(str(device_code or "")))))


def registration_code_valid(code, device_code="", now=None):
    expected = make_activation_code(device_code)
    if expected and hmac.compare_digest(str(code or "").strip().upper(), expected):
        return True
    if str(code or "").strip() == MASTER_REGISTRATION_CODE:
        return True
    """کد امضاشده و مختص شناسه نصب؛ کلید خصوصی فقط در ابزار صدور مجوزِ جداگانه نگهداری می‌شود."""
    parts = str(code or "").strip().split(".")
    if len(parts) != 3 or parts[0] != "KH1" or parts[1].upper() != INSTALLATION_ID:
        return False
    try:
        signature = base64.urlsafe_b64decode(parts[2] + "=" * (-len(parts[2]) % 4))
        key_size = (LICENSE_PUBLIC_N.bit_length() + 7) // 8
        if len(signature) != key_size:
            return False
        encoded = pow(int.from_bytes(signature, "big"), LICENSE_PUBLIC_E, LICENSE_PUBLIC_N).to_bytes(key_size, "big")
        payload = f"KHAVARAN-SOFT|LICENSE|V1|{INSTALLATION_ID}".encode("utf-8")
        digest_info = bytes.fromhex("3031300d060960864801650304020105000420") + hashlib.sha256(payload).digest()
        padding = b"\xff" * (key_size - len(digest_info) - 3)
        expected = b"\x00\x01" + padding + b"\x00" + digest_info
        return hmac.compare_digest(encoded, expected)
    except Exception:
        return False


def customer_count(db):
    return db.execute("SELECT COUNT(*) FROM customers").fetchone()[0]


def start_trial_if_needed(db):
    """شروع یک‌باره مهلت آزمایشی ۷۲ ساعته از اولین اجرا؛ با بستن برنامه ریست نمی‌شود."""
    started = _setting(db, "trial_started_at")
    if started:
        return started
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _save_setting(db, "trial_started_at", stamp)
    return stamp


def get_trial_info(db):
    """وضعیت مهلت آزمایشی و قفل شدن."""
    registered = _setting(db, "registration_completed") == "1"
    count = customer_count(db)
    started = start_trial_if_needed(db)
    expired = False
    remaining_seconds = 0
    try:
        t0 = datetime.strptime(str(started).strip(), "%Y-%m-%d %H:%M:%S")
        end = t0 + timedelta(hours=TRIAL_HOURS)
        remaining_seconds = int((end - datetime.now()).total_seconds())
        expired = remaining_seconds <= 0
        if remaining_seconds < 0:
            remaining_seconds = 0
    except Exception:
        expired = False
        remaining_seconds = TRIAL_HOURS * 3600
    customer_limit_reached = count >= TRIAL_CUSTOMER_LIMIT
    locked = (not registered) and (expired or customer_limit_reached)
    return {
        "registered": registered,
        "customer_count": count,
        "trial_started_at": started,
        "trial_expired": expired,
        "customer_limit_reached": customer_limit_reached,
        "remaining_seconds": remaining_seconds,
        "locked": locked,
        "trial_hours": TRIAL_HOURS,
        "customer_limit": TRIAL_CUSTOMER_LIMIT,
    }




def _trial_locked():
    """خواندن وضعیت قفل آزمایشی با اتصال تازه (امن برای خارج از with)."""
    try:
        with get_db() as db:
            return get_trial_info(db)["locked"]
    except Exception:
        return False


def is_registration_required(db):
    """نیاز به صفحه فعال‌سازی: بدون مشخصات خیاطی، یا پایان آزمایشی/سقف مشتری بدون رجیستر."""
    business_name = (_setting(db, "business_name") or "").strip()
    info = get_trial_info(db)
    if not business_name:
        return True
    return info["locked"]



def _local_request():
    host_ips = {"127.0.0.1", "::1", *local_ipv4_addresses()}
    return request.remote_addr in host_ips


@app.before_request
def require_login():
    # Binary Eye در یک فرایند/اپ جداگانه callback را ارسال می‌کند و کوکی مرورگر را ندارد؛
    # امنیت این مسیر با توکن تصادفی یک‌بارمصرف داخل URL تأمین می‌شود.
    public_endpoints = {"static", "setup_admin", "login", "forgot_pin", "health", "scanner_callback"}
    if request.endpoint in public_endpoints or request.endpoint is None:
        return None
    with get_db() as db:
        pin_hash = _setting(db, "admin_pin_hash")
    if not pin_hash:
        return redirect(url_for("setup_admin"))
    if (not session.get("khayati_authenticated") or
            session.get("server_instance") != SERVER_INSTANCE):
        session.clear()
        return redirect(url_for("login", next=request.path))

    # صفحه فعال‌سازی همیشه در دسترس است.
    # پس از پایان ۷۲ ساعت یا ثبت ۳ مشتری (بدون رجیستر کامل) همه مسیرها قفل می‌شوند.
    if request.endpoint == "register_page":
        return None
    with get_db() as db:
        start_trial_if_needed(db)
        db.commit()
        if is_registration_required(db):
            return redirect(url_for("register_page"))
    return None


@app.route("/health")
def health():
    return {"ok": True, "app": "khayati"}


@app.route("/setup", methods=["GET", "POST"])
def setup_admin():
    with get_db() as db:
        pin_hash = _setting(db, "admin_pin_hash")
    if pin_hash:
        return redirect(url_for("login"))
    if request.method == "POST":
        pin = normalize_digits(request.form.get("pin", "")).strip()
        confirm = normalize_digits(request.form.get("confirm_pin", "")).strip()
        if len(pin) < 4 or not pin.isdigit():
            flash("رمز ورود باید حداقل ۴ رقم باشد.", "error")
        elif pin != confirm:
            flash("تکرار رمز با رمز اصلی یکسان نیست.", "error")
        else:
            with get_db() as db:
                db.execute("INSERT OR REPLACE INTO app_settings(setting_key,setting_value) VALUES('admin_pin_hash',?)",
                           (generate_password_hash(pin),))
                db.commit()
            session.clear()
            session["khayati_authenticated"] = True
            session["server_instance"] = SERVER_INSTANCE
            flash("رمز مدیر با موفقیت تنظیم شد.", "success")
            return redirect(url_for("register_page"))
    return render_template("setup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    with get_db() as db:
        pin_hash = _setting(db, "admin_pin_hash")
    if not pin_hash:
        return redirect(url_for("setup_admin"))
    if request.method == "POST":
        pin = normalize_digits(request.form.get("pin", "")).strip()
        if check_password_hash(pin_hash, pin):
            session.clear()
            session["khayati_authenticated"] = True
            session["server_instance"] = SERVER_INSTANCE
            session.permanent = False
            with get_db() as db:
                has_business = bool(_setting(db, "business_name"))
                trial = get_trial_info(db)
                locked_now = trial["locked"]
            target = request.args.get("next", "")
            if not has_business or locked_now:
                target = url_for("register_page")
            elif not target.startswith("/") or target.startswith("//"):
                target = url_for("customers_page")
            return redirect(target)
        flash("رمز ورود نادرست است.", "error")
    with get_db() as db:
        login_business_name = _setting(db, "business_name") or "خیاطی"
    return render_template("login.html", business_name=login_business_name)


@app.route("/forgot-pin", methods=["GET", "POST"])
def forgot_pin():
    """بازیابی رمز مدیر با شناسه ۷ رقمی و همان الگوریتم کد رجیستر."""
    request_identifier = ""
    activation_sms_url = ""
    recovery_active = False

    if request.method == "POST":
        action = request.form.get("action", "")

        if action == "request_recovery":
            with get_db() as db:
                if not _setting(db, "admin_pin_hash"):
                    flash("هنوز رمز مدیر برای این برنامه تنظیم نشده است.", "error")
                    return redirect(url_for("setup_admin"))

            # دقیقاً مانند رجیستر: شناسه ۷ رقمی + پسوند ثابت ۸ رقمی
            request_identifier = str(secrets.randbelow(9_000_000) + 1_000_000)
            recovery_device_code = request_identifier + "10246600"
            expires_at = (datetime.now() + timedelta(hours=24)).isoformat(timespec="seconds")
            with get_db() as db:
                _save_setting(db, "pending_pin_recovery_code", recovery_device_code)
                _save_setting(db, "pin_recovery_expires_at", expires_at)
                _save_setting(db, "pin_recovery_failures", "0")
                db.commit()
            flash("شناسه بازیابی ساخته شد. آن را برای برنامه‌نویس ارسال کنید.", "success")
            return redirect(url_for("forgot_pin"))

        elif action == "reset_pin":
            code = normalize_digits(request.form.get("recovery_code", "")).strip().upper()
            new_pin = normalize_digits(request.form.get("new_pin", "")).strip()
            confirm_pin = normalize_digits(request.form.get("confirm_pin", "")).strip()

            with get_db() as db:
                recovery_device_code = _setting(db, "pending_pin_recovery_code")
                expires_at = _setting(db, "pin_recovery_expires_at")
                failures_text = _setting(db, "pin_recovery_failures") or "0"
                try:
                    failures = int(failures_text)
                except ValueError:
                    failures = 0

                if not re.fullmatch(r"\d{15}", recovery_device_code or ""):
                    flash("ابتدا شناسه درخواست بازیابی را دریافت کنید.", "error")
                elif failures >= 5:
                    flash("۵ بار کد اشتباه وارد شده است. یک شناسه درخواست جدید بسازید.", "error")
                else:
                    try:
                        is_expired = not expires_at or datetime.now() > datetime.fromisoformat(expires_at)
                    except ValueError:
                        is_expired = True

                    if is_expired:
                        _save_setting(db, "pending_pin_recovery_code", "")
                        _save_setting(db, "pin_recovery_expires_at", "")
                        db.commit()
                        flash("مهلت شناسه بازیابی تمام شده است. شناسه جدید دریافت کنید.", "error")
                    elif len(new_pin) < 4 or not new_pin.isdigit():
                        flash("رمز جدید باید حداقل ۴ رقم باشد.", "error")
                    elif new_pin != confirm_pin:
                        flash("تکرار رمز با رمز جدید یکسان نیست.", "error")
                    elif not code or not hmac.compare_digest(code, make_activation_code(recovery_device_code)):
                        _save_setting(db, "pin_recovery_failures", str(failures + 1))
                        db.commit()
                        flash("کد بازیابی صحیح نیست.", "error")
                    else:
                        _save_setting(db, "admin_pin_hash", generate_password_hash(new_pin))
                        _save_setting(db, "pending_pin_recovery_code", "")
                        _save_setting(db, "pin_recovery_expires_at", "")
                        _save_setting(db, "pin_recovery_failures", "0")
                        db.commit()
                        session.clear()
                        flash("رمز مدیر با موفقیت تغییر کرد. با رمز جدید وارد شوید.", "success")
                        return redirect(url_for("login"))

    with get_db() as db:
        recovery_device_code = _setting(db, "pending_pin_recovery_code")
        expires_at = _setting(db, "pin_recovery_expires_at")
        failures_text = _setting(db, "pin_recovery_failures") or "0"
        try:
            failures = int(failures_text)
        except ValueError:
            failures = 0

    if re.fullmatch(r"\d{7}10246600", recovery_device_code or "") and failures < 5:
        try:
            recovery_active = bool(expires_at) and datetime.now() <= datetime.fromisoformat(expires_at)
        except ValueError:
            recovery_active = False
        if recovery_active:
            request_identifier = recovery_device_code[:7]
            sms_body = (
                "درخواست بازیابی رمز مدیر خاوران سافت\n"
                f"شناسه درخواست: {request_identifier}\n"
                "لطفاً کد ۲۰ کاراکتری بازیابی را بر اساس الگوریتم رجیستر ارسال کنید."
            )
            activation_sms_url = "sms:" + DEVELOPER_SMS_NUMBER + "?body=" + quote(sms_body)

    return render_template(
        "forgot_pin.html",
        request_identifier=request_identifier,
        activation_sms_url=activation_sms_url,
        recovery_active=recovery_active,
        developer_phone=DEVELOPER_SMS_NUMBER,
        attempts_left=max(0, 5 - failures),
    )


@app.route("/register", methods=["GET", "POST"])
def register_page():
    with get_db() as db:
        shop = {
            "business_name": _setting(db, "business_name"),
            "business_address": _setting(db, "business_address"),
            "business_phone1": _setting(db, "business_phone1"),
            "business_phone2": _setting(db, "business_phone2"),
        }
        registered = _setting(db, "registration_completed") == "1"
        count = customer_count(db)
        pending_device_code = _setting(db, "pending_device_code")

    # در درخواست GET نیز مقدار پیش‌فرض تعریف می‌شود؛ در نصب اول نباید
    # به‌علت متغیر تعریف‌نشده، صفحه ثبت‌نام خطای 500 بدهد.
    device_code = pending_device_code or ""

    if request.method == "POST":
        if request.form.get("action") == "enter_trial":
            # ذخیره مشخصات خیاطی (در صورت نیاز) و ورود به محیط آزمایشی
            with get_db() as db:
                start_trial_if_needed(db)
                if not (_setting(db, "business_name") or "").strip():
                    details = {
                        "business_name": request.form.get("business_name", "").strip(),
                        "business_address": request.form.get("business_address", "").strip(),
                        "business_phone1": normalize_digits(request.form.get("business_phone1", "")).strip(),
                        "business_phone2": normalize_digits(request.form.get("business_phone2", "")).strip(),
                    }
                    missing = [label for key, label in [
                        ("business_name", "نام خیاطی"),
                        ("business_address", "آدرس"),
                        ("business_phone1", "شماره تلفن اول"),
                    ] if not details[key]]
                    if missing:
                        flash("برای ورود آزمایشی این موارد لازم است: " + "، ".join(missing), "error")
                        return redirect(url_for("register_page"))
                    for key, value in details.items():
                        _save_setting(db, key, value)
                db.commit()
                trial = get_trial_info(db)
            if trial["locked"]:
                flash("مهلت آزمایشی به پایان رسیده است. ابتدا برنامه را فعال کنید.", "error")
                return redirect(url_for("register_page"))
            flash("وارد محیط آزمایشی شدید. همه امکانات تا پایان مهلت فعال است.", "success")
            return redirect(url_for("customers_page"))

        if request.form.get("action") == "import_initial_db":
            db_file = request.files.get("initial_database")
            if db_file and db_file.filename and Path(db_file.filename).suffix.lower() in {".db", ".sqlite", ".sqlite3"}:
                temp_db = DB_PATH.with_suffix(".importing")
                db_file.save(temp_db)
                try:
                    test = sqlite3.connect(str(temp_db)); test.execute("PRAGMA integrity_check").fetchone(); test.close()
                    os.replace(temp_db, DB_PATH)
                    flash("پایگاه داده وارد شد. مشخصات خیاطی از اطلاعات آن بارگذاری می‌شود.", "success")
                except Exception:
                    temp_db.unlink(missing_ok=True)
                    flash("فایل پایگاه داده معتبر نیست.", "error")
            else:
                flash("فایل دیتابیس با پسوند DB یا SQLITE انتخاب کنید.", "error")
            return redirect(url_for("register_page"))
        # لوگوی اختیاری خیاطی؛ فایل در پوشه پایدار داده‌ها نگهداری می‌شود.
        logo_file = request.files.get("business_logo")
        if logo_file and logo_file.filename:
            ext = Path(logo_file.filename).suffix.lower()
            if ext not in {".png", ".jpg", ".jpeg", ".webp"}:
                flash("لوگو باید تصویر PNG، JPG یا WEBP باشد.", "error")
                return redirect(url_for("register_page"))
            logo_name = "business_logo" + ext
            logo_file.save(UPLOAD_DIR / logo_name)
            with get_db() as db:
                _save_setting(db, "business_logo", logo_name)
                db.commit()
        code = normalize_digits(request.form.get("registration_code", "")).strip().upper()
        device_code = re.sub(r"\D", "", normalize_digits(request.form.get("device_code", "")))
        if request.form.get("action") == "request_activation":
            if not shop["business_name"]:
                details = {
                    "business_name": request.form.get("business_name", "").strip(),
                    "business_address": request.form.get("business_address", "").strip(),
                    "business_phone1": normalize_digits(request.form.get("business_phone1", "")).strip(),
                    "business_phone2": normalize_digits(request.form.get("business_phone2", "")).strip(),
                }
                if not details["business_name"] or not details["business_address"] or not details["business_phone1"]:
                    flash("ابتدا نام خیاطی، آدرس و تلفن اول را تکمیل کنید.", "error")
                    return render_template("register.html", shop=details, registered=False, locked=_trial_locked(), installation_id=INSTALLATION_ID, developer_phone=DEVELOPER_SMS_NUMBER, default_device_code="", trial_hours=TRIAL_HOURS, customer_limit=TRIAL_CUSTOMER_LIMIT, call_url="tel:"+DEVELOPER_SMS_NUMBER)
                with get_db() as db:
                    for key, value in details.items(): _save_setting(db, key, value)
                    db.commit()
                shop = details
            # کاربر IMEI را وارد نمی‌کند: شناسه هفت‌رقمی تصادفی ساخته و
            # پسوند ثابت به آن افزوده می‌شود تا سازوکار قبلی فعال‌سازی حفظ شود.
            request_identifier = str(secrets.randbelow(9_000_000) + 1_000_000)
            device_code = request_identifier + "10246600"
            with get_db() as db:
                _save_setting(db, "pending_device_code", device_code)
                db.commit()
            request_message = (f"درخواست رجیستر خاوران سافت\nشناسه درخواست: {request_identifier}\n"
                               f"لطفاً کد رجیستر برنامه را برای این شناسه ارسال کنید.\n"
                               f"نام خیاطی: {shop['business_name']}\nآدرس: {shop['business_address']}\n"
                               f"تلفن: {shop['business_phone1']}")
            activation_sms_url = "sms:" + DEVELOPER_SMS_NUMBER + "?body=" + quote(request_message)
            with get_db() as db2:
                locked_now = get_trial_info(db2)["locked"]
                count_now = customer_count(db2)
            return render_template("register.html", shop=shop, registered=False,
                                   locked=locked_now, customer_total=count_now,
                                   installation_id=INSTALLATION_ID, developer_phone=DEVELOPER_SMS_NUMBER,
                                   default_device_code=device_code, request_identifier=request_identifier,
                                   activation_sms_url=activation_sms_url,
                                   trial_hours=TRIAL_HOURS, customer_limit=TRIAL_CUSTOMER_LIMIT)
        if not shop["business_name"]:
            details = {
                "business_name": request.form.get("business_name", "").strip(),
                "business_address": request.form.get("business_address", "").strip(),
                "business_phone1": normalize_digits(request.form.get("business_phone1", "")).strip(),
                "business_phone2": normalize_digits(request.form.get("business_phone2", "")).strip(),
            }
            missing = [label for key, label in [
                ("business_name", "نام خیاطی"), ("business_address", "آدرس"),
                ("business_phone1", "شماره تلفن اول")
            ] if not details[key]]
            if missing:
                flash("لطفاً این موارد را تکمیل کنید: " + "، ".join(missing), "error")
                return render_template("register.html", shop=details, registered=False, locked=_trial_locked(), installation_id=INSTALLATION_ID, developer_phone=DEVELOPER_SMS_NUMBER, default_device_code="", trial_hours=TRIAL_HOURS, customer_limit=TRIAL_CUSTOMER_LIMIT, call_url="tel:"+DEVELOPER_SMS_NUMBER)
            with get_db() as db:
                for key, value in details.items():
                    _save_setting(db, key, value)
                if code and registration_code_valid(code, device_code):
                    _save_setting(db, "registration_completed", "1")
                    _save_setting(db, "registration_version", "owner-code-or-rsa1")
                    _save_setting(db, "registration_code_hash", hashlib.sha256(code.encode("utf-8")).hexdigest())
                    _save_setting(db, "pending_device_code", "")
                elif code:
                    flash("کد رجیستر معتبر نیست.", "error")
                db.commit()
            flash("اطلاعات خیاطی ثبت شد.", "success")
            with get_db() as db:
                completed_now = _setting(db, "registration_completed") == "1"
            with get_db() as db_lock:
                still_locked = get_trial_info(db_lock)["locked"]
            return redirect(url_for("customers_page") if completed_now or not still_locked else url_for("register_page"))
        else:
            if registered:
                flash("ثبت برنامه قبلاً انجام شده است.", "success")
            elif registration_code_valid(code, device_code):
                with get_db() as db:
                    _save_setting(db, "registration_completed", "1")
                    _save_setting(db, "registration_version", "owner-code-or-rsa1")
                    _save_setting(db, "registration_code_hash", hashlib.sha256(code.encode("utf-8")).hexdigest())
                    _save_setting(db, "pending_device_code", "")
                    db.commit()
                flash("ثبت برنامه با موفقیت انجام شد.", "success")
                return redirect(url_for("customers_page"))
            else:
                flash("کد رجیستر معتبر نیست.", "error")

    with get_db() as db:
        shop = {
            "business_name": _setting(db, "business_name"),
            "business_address": _setting(db, "business_address"),
            "business_phone1": _setting(db, "business_phone1"),
            "business_phone2": _setting(db, "business_phone2"),
        }
        registered = _setting(db, "registration_completed") == "1"
        count = customer_count(db)
    # اگر کد فعال‌سازی اشتباه وارد شد، همان شناسه درخواست حفظ شود تا کاربر مجبور به ساخت شناسه تازه نباشد.
    request_identifier = device_code[:7] if re.fullmatch(r"\d{7}10246600", device_code or "") else ""
    activation_sms_url = ""
    if request_identifier and not registered:
        request_message = (f"درخواست رجیستر خیاطی خاوران سافت\nشناسه درخواست: {request_identifier}\n"
                           f"لطفاً کد رجیستر برنامه را برای این شناسه ارسال کنید.\n"
                           f"نام خیاطی: {shop['business_name']}\nآدرس: {shop['business_address']}\n"
                           f"تلفن: {shop['business_phone1']}")
        activation_sms_url = "sms:" + DEVELOPER_SMS_NUMBER + "?body=" + quote(request_message)
    with get_db() as db:
        start_trial_if_needed(db)
        db.commit()
        trial = get_trial_info(db)
        registered = trial["registered"]
        count = trial["customer_count"]
        locked = trial["locked"]
        shop = {
            "business_name": _setting(db, "business_name"),
            "business_address": _setting(db, "business_address"),
            "business_phone1": _setting(db, "business_phone1"),
            "business_phone2": _setting(db, "business_phone2"),
        }
        device_code = _setting(db, "pending_device_code") or ""
    request_identifier = device_code[:7] if len(device_code) >= 7 else ""
    activation_sms_url = ""
    if request_identifier:
        request_message = (
            f"درخواست فعال‌سازی خاوران سافت\n"
            f"شناسه درخواست: {request_identifier}\n"
            f"نام خیاطی: {shop.get('business_name') or '—'}\n"
            f"تلفن: {shop.get('business_phone1') or '—'}"
        )
        activation_sms_url = "sms:" + DEVELOPER_SMS_NUMBER + "?body=" + quote(request_message)
    call_url = "tel:" + DEVELOPER_SMS_NUMBER
    return render_template(
        "register.html",
        shop=shop,
        registered=registered,
        locked=locked,
        customer_total=count,
        installation_id=INSTALLATION_ID,
        developer_phone=DEVELOPER_SMS_NUMBER,
        default_device_code=device_code,
        request_identifier=request_identifier,
        activation_sms_url=activation_sms_url,
        call_url=call_url,
        trial_hours=TRIAL_HOURS,
        customer_limit=TRIAL_CUSTOMER_LIMIT,
        trial_expired=trial.get("trial_expired", False),
        customer_limit_reached=trial.get("customer_limit_reached", False),
        remaining_seconds=trial.get("remaining_seconds", 0),
    )


@app.route("/logout", methods=["POST", "GET"])
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
def index():
    return redirect(url_for("customers_page"))


@app.route("/customers")
def customers_page():
    today = today_jalali()
    with get_db() as db:
        customers = db.execute("SELECT * FROM customers").fetchall()
        latest_status = {r["customer_id"]: dict(r) for r in db.execute("""
            SELECT j.customer_id, j.status, j.order_day, j.sent_to_sewing_at, j.ready_at, j.delivered_at FROM daily_jobs j
            JOIN (SELECT customer_id, MAX(id) AS max_id FROM daily_jobs GROUP BY customer_id) x ON x.max_id=j.id
        """).fetchall()}
        today_jobs = db.execute("""
            SELECT j.id AS job_id, j.created_at, j.fabric_meter, j.order_quantity,
                   c.id AS customer_id, c.customer_code, c.name, c.mobile
            FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
            WHERE j.order_day=? AND j.finalized=1 ORDER BY j.id DESC
        """, (today,)).fetchall()
        yesterday_g = date.today() - timedelta(days=1)
        jy, jm, jd = gregorian_to_jalali(yesterday_g.year, yesterday_g.month, yesterday_g.day)
        yesterday = f"{jy:04d}/{jm:02d}/{jd:02d}"
        yesterday_jobs = db.execute("""
            SELECT j.id AS job_id, j.created_at, j.fabric_meter, j.order_quantity,
                   c.id AS customer_id, c.customer_code, c.name, c.mobile
            FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
            WHERE j.order_day=? ORDER BY j.id DESC
        """, (yesterday,)).fetchall()
    customers = sorted(customers, key=customer_sort_key)
    status_labels = {"in_progress": "ارسال جهت دوخت", "ready": "آماده تحویل", "delivered": "تحویل شد"}
    def _status_date(item, customer):
        item = item or {}
        stamp = item.get("delivered_at") if item.get("status") == "delivered" else item.get("ready_at") if item.get("status") == "ready" else item.get("sent_to_sewing_at")
        try:
            d = datetime.strptime(stamp[:10], "%Y-%m-%d").date() if stamp else date.fromisoformat(item.get("order_day", ""))
            jy, jm, jd = gregorian_to_jalali(d.year, d.month, d.day)
            return f"{jy:04d}/{jm:02d}/{jd:02d}"
        except Exception:
            return customer.get("order_date") or "—"
    customers = [dict(c) | {"latest_status_label": status_labels.get(latest_status.get(c["id"], {}).get("status"), "ثبت سفارش"),
                            "latest_status_date": _status_date(latest_status.get(c["id"]), dict(c))} for c in customers]
    groups = build_customer_groups(customers)
    return render_template("customers.html", groups=groups,
                           total_customers=len(customers), main_fields=MAIN_MEASUREMENTS,
                           all_fields=_ordered_all_fields(),
                           main_keys={key for key, _ in MAIN_MEASUREMENTS},
                           today=today, today_jobs=today_jobs, yesterday=yesterday, yesterday_jobs=yesterday_jobs,
                           business_name=business_name_for_sms())


@app.route("/customer/new", methods=["GET", "POST"])
def new_customer():
    if request.method == "POST":
        name = form_value("name")
        mobile = form_value("mobile")
        values = {key: form_value(key) for key, _ in PROFILE_FIELDS}
        values.setdefault("hem_model", "")
        values.setdefault("collar_model", "")
        if not values.get("hem_model"): values["hem_model"] = "2/5 چین دار"
        if not values.get("collar_model"): values["collar_model"] = "ملایی"
        values.setdefault("hem_model", "")
        values.setdefault("collar_model", "")
        if not values.get("hem_model"): values["hem_model"] = "2/5 چین دار"
        if not values.get("collar_model"): values["collar_model"] = "ملایی"
        required_missing = []
        if not name: required_missing.append("نام مشتری")
        if not mobile: required_missing.append("موبایل")
        required_missing.extend(label for key, label in PROFILE_FIELDS if key in REQUIRED_PROFILE_KEYS and not str(values.get(key) or "").strip())
        if required_missing:
            flash("لطفاً این قسمت‌ها را تکمیل کنید: " + "، ".join(required_missing), "error")
            form_data = {"name": name, "mobile": mobile, **values}
            return _customer_form_context(form_data, validation_error=True)
        if not values.get("order_date"):
            values["order_date"] = today_jalali()
        keys = ",".join(f'"{key}"' for key, _ in PROFILE_FIELDS)
        marks = ",".join("?" for _ in PROFILE_FIELDS)
        with get_db() as db:
            db.execute(f"INSERT INTO customers(name,mobile,{keys}) VALUES (?,?,{marks})",
                       [name, mobile] + [values[k] for k, _ in PROFILE_FIELDS])
            new_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
            db.execute("UPDATE customers SET customer_code=? WHERE id=?", (f"LOCAL-{new_id}", new_id))
            new_job_id = create_daily_job(db, new_id, values.get("fabric_meter", ""), values.get("order_quantity", ""))
            total_amount = form_value("total_amount")
            deposit_amount = form_value("deposit_amount")
            remaining_amount = form_value("remaining_amount")
            if not remaining_amount and total_amount:
                try: remaining_amount = str(max(0, float(total_amount.replace(",", "")) - float((deposit_amount or "0").replace(",", ""))))
                except Exception: remaining_amount = ""
            db.execute("UPDATE daily_jobs SET total_amount=?,deposit_amount=?,remaining_amount=? WHERE id=?",
                       (total_amount, deposit_amount, remaining_amount, new_job_id))
            db.commit()
        flash("پرونده مشتری و اندازه‌های او ذخیره شد.", "success")
        return redirect(url_for("new_customer_saved", customer_id=new_id))
    return _customer_form_context(None)


@app.route("/customer/<int:customer_id>/new-saved")
def new_customer_saved(customer_id):
    with get_db() as db:
        customer = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
    if not customer:
        flash("مشتری پیدا نشد.", "error")
        return redirect(url_for("customers_page"))
    return render_template("new_customer_saved.html", customer=customer,
                           code=display_customer_code(customer["customer_code"]),
                           welcome_sms_url=url_for("prepare_customer_welcome", customer_id=customer_id))


@app.route("/sms/welcome/<int:customer_id>")
def prepare_customer_welcome(customer_id):
    with get_db() as db: row = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
    if not row or not row["mobile"]:
        flash("شماره موبایل مشتری ثبت نشده است.", "warning")
        return redirect(url_for("customers_page"))
    return render_template("sms_confirm.html", mobile=normalize_mobile(row["mobile"]),
                           message=make_customer_message(row, "welcome"), customer_name=row["name"],
                           kind="welcome", job_id="", customer_id=row["id"], whatsapp_enabled=whatsapp_is_enabled())


@app.route("/customer/<int:customer_id>/edit", methods=["GET", "POST"])
def edit_customer(customer_id):
    print_after_save = request.args.get("print_after", "") == "1" or request.form.get("print_after_save") == "1"
    active_job_id = request.form.get("job_id", "") or request.args.get("job_id", "")
    with get_db() as db:
        customer = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
        if not customer:
            flash("مشتری پیدا نشد.", "error")
            return redirect(url_for("customers_page"))
        if request.method == "POST":
            name = form_value("name")
            mobile = form_value("mobile")
            values = {key: form_value(key) for key, _ in PROFILE_FIELDS}
            values.setdefault("hem_model", "")
            values.setdefault("collar_model", "")
            if not values.get("hem_model"): values["hem_model"] = "2/5 چین دار"
            if not values.get("collar_model"): values["collar_model"] = "ملایی"
            required_missing = []
            if not name: required_missing.append("نام مشتری")
            if not mobile: required_missing.append("موبایل")
            required_missing.extend(label for key, label in PROFILE_FIELDS if key in REQUIRED_PROFILE_KEYS and not str(values.get(key) or "").strip())
            if required_missing:
                flash("لطفاً این قسمت‌ها را تکمیل کنید: " + "، ".join(required_missing), "error")
                form_data = {"name": name, "mobile": mobile, **values, "customer_code": customer["customer_code"]}
                return _customer_form_context(form_data, print_after_save, validation_error=True, job_id=request.form.get("job_id", ""))
            if not values.get("order_date"):
                values["order_date"] = today_jalali()
            assignments = ",".join(["name=?", "mobile=?"] + [f'"{key}"=?' for key, _ in PROFILE_FIELDS])
            params = [name, mobile] + [values[k] for k, _ in PROFILE_FIELDS] + [customer_id]
            db.execute(f"UPDATE customers SET {assignments} WHERE id=?", params)
            job_id = request.form.get("job_id", "").strip()
            if job_id.isdigit():
                target_job_id = int(job_id)
            else:
                latest_job = db.execute("SELECT id FROM daily_jobs WHERE customer_id=? ORDER BY id DESC LIMIT 1", (customer_id,)).fetchone()
                target_job_id = latest_job["id"] if latest_job else create_daily_job(db, customer_id, values.get("fabric_meter", ""), values.get("order_quantity", ""))
            total_amount = form_value("total_amount")
            deposit_amount = form_value("deposit_amount")
            remaining_amount = form_value("remaining_amount")
            if not remaining_amount and total_amount:
                try: remaining_amount = str(max(0, float(total_amount.replace(",", "")) - float((deposit_amount or "0").replace(",", ""))))
                except Exception: remaining_amount = ""
            db.execute("UPDATE daily_jobs SET fabric_meter=?, order_quantity=?, total_amount=?, deposit_amount=?, remaining_amount=?, finalized=1 WHERE id=? AND customer_id=?",
                       (values.get("fabric_meter", ""), values.get("order_quantity", ""), total_amount, deposit_amount, remaining_amount, target_job_id, customer_id))
            db.commit()
            flash("اطلاعات و اندازه‌های مشتری به‌روز شد.", "success")
            if print_after_save:
                return redirect(url_for("print_customer", customer_id=customer_id, job_id=job_id if job_id.isdigit() else ""))
            return redirect(url_for("customers_page"))
    if request.args.get("new_visit") == "1" and request.method == "GET":
        form_data = {key: customer[key] for key in customer.keys()}
        form_data["fabric_meter"] = ""
        form_data["order_quantity"] = ""
        return _customer_form_context(form_data, print_after_save, job_id=active_job_id)
    return _customer_form_context(customer, print_after_save, job_id=active_job_id)


@app.route("/customer/<int:customer_id>/start-order", methods=["POST"])
def start_customer_order(customer_id):
    with get_db() as db:
        customer = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
        if not customer:
            flash("مشتری پیدا نشد.", "error")
            return redirect(url_for("customers_page"))
        db.execute("UPDATE customers SET order_date=? WHERE id=?", (today_jalali(), customer_id))
        job_id = create_daily_job(db, customer_id, customer["fabric_meter"], customer["order_quantity"])
        db.commit()
        customer = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
    return render_template("prepare_print.html", customer=customer,
                           code=display_customer_code(customer["customer_code"]), job_id=job_id)




def open_pc_print_window(url):
    """روی ویندوز، Chrome را با چاپ بی‌صدا به چاپگر پیش‌فرض اجرا کند؛ در غیر این صورت مرورگر عادی."""
    if os.name == "nt":
        candidates = [
            shutil.which("chrome"),
            os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
        ]
        chrome = next((x for x in candidates if x and os.path.isfile(x)), None)
        if chrome:
            try:
                _bootstrap_subprocess.Popen([chrome, "--kiosk-printing", "--new-window", url], close_fds=True)
                return True
            except Exception:
                pass
    return webbrowser.open(url)


def windows_has_installed_printer():
    """وجود حداقل یک چاپگر نصب‌شده در ویندوز را بررسی می‌کند."""
    if os.name != "nt":
        return True
    try:
        import win32print  # type: ignore
        return bool(win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS))
    except Exception:
        try:
            result = _bootstrap_subprocess.run(
                ["powershell", "-NoProfile", "-Command", "@(Get-Printer -ErrorAction SilentlyContinue).Count"],
                capture_output=True, text=True, timeout=8, creationflags=getattr(_bootstrap_subprocess, "CREATE_NO_WINDOW", 0)
            )
            return int((result.stdout or "0").strip().splitlines()[-1]) > 0
        except Exception:
            # اگر بررسی سیستم ممکن نبود، رفتار قبلی حفظ شود و چاپ از راه لپ‌تاپ انجام شود.
            return True


@app.route("/customer/<int:customer_id>/print")
def print_customer(customer_id):
    requested_job_id = request.args.get("job_id", "")
    with get_db() as db:
        record = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
        if not record:
            flash("مشتری پیدا نشد.", "error")
            return redirect(url_for("customers_page"))
        job = None
        if requested_job_id.isdigit():
            job = db.execute("SELECT * FROM daily_jobs WHERE id=? AND customer_id=?", (int(requested_job_id), customer_id)).fetchone()
        if job is None:
            job = db.execute("SELECT * FROM daily_jobs WHERE customer_id=? AND order_day=? ORDER BY id DESC LIMIT 1",
                             (customer_id, today_jalali())).fetchone()
        if job is None:
            new_job_id = create_daily_job(db, customer_id, record["fabric_meter"], record["order_quantity"])
            job = db.execute("SELECT * FROM daily_jobs WHERE id=?", (new_job_id,)).fetchone()
        barcode_value = job_barcode(db, job["id"], record)
        printed_at = _device_now_for_request().strftime("%Y-%m-%d %H:%M:%S")
        db.execute("""UPDATE daily_jobs
                     SET finalized=1,
                         sent_to_sewing_at=CASE
                           WHEN status='in_progress' AND (sent_to_sewing_at IS NULL OR sent_to_sewing_at='') THEN ?
                           ELSE sent_to_sewing_at END
                     WHERE id=?""", (printed_at, job["id"]))
        db.commit()
    with get_db() as db:
        logo_name = _setting(db, "business_logo")
    with get_db() as db:
        diagram_names = {k: _setting(db, "print_diagram_" + k) for k in ("sleeve", "pocket", "pati", "trousers", "waist_slit")}
        print_text_color = _setting(db, "print_text_color") or "#111111"
        print_label_color = _setting(db, "print_label_color") or "#333333"
        print_accent_color = _setting(db, "print_accent_color") or "#1a56db"
    diagram_images = {k: (url_for("uploaded_file", filename=v) if v else "") for k,v in diagram_names.items()}
    print_record = dict(record)
    if job is not None:
        for financial_key in ("total_amount", "deposit_amount", "remaining_amount"):
            try:
                print_record[financial_key] = job[financial_key]
            except (KeyError, IndexError):
                print_record[financial_key] = ""
    # تشخیص محیط اندروید (اپ خاوران) و درخواست موبایل
    is_android_app = os.environ.get("KHAVARAN_ANDROID") == "1"
    mobile_request = "Android" in request.headers.get("User-Agent", "")

    # روی اپ اندروید همیشه صفحه چاپ روی خود گوشی باز می‌شود (چاپگر موبایل / PDF)
    # و پیام «ارسال به لپ‌تاپ» نشان داده نمی‌شود.
    if is_android_app or (mobile_request and request.args.get("pc_auto_print") != "1" and not windows_has_installed_printer()):
        return render_template("print_order.html", record=print_record,
                               business_logo_url=(url_for("uploaded_file", filename=logo_name) if logo_name else ""),
                               main_fields=MAIN_MEASUREMENTS, detail_fields=PRINT_DETAIL_FIELDS,
                               code=display_customer_code(record["customer_code"]), barcode_value=barcode_value,
                               barcode_svg=code128_svg(barcode_value), diagram_images=diagram_images,
                               home_url=url_for("customers_page"), pc_auto_print=False, pdf_fallback=False,
                               customer_id=customer_id, job_id=(job["id"] if job else ""),
                               print_text_color=print_text_color, print_label_color=print_label_color, print_accent_color=print_accent_color)

    # فقط وقتی واقعاً از مرورگر موبایل به سرور ویندوز وصل شده و چاپگر ویندوز موجود است،
    # درخواست به لپ‌تاپ فرستاده می‌شود (نه در اپ اندروید).
    if mobile_request and request.args.get("pc_auto_print") != "1" and not is_android_app:
        token = secrets.token_urlsafe(24)
        PC_PRINT_TOKENS[token] = {"customer_id": customer_id, "job_id": str(job["id"] if job else ""), "created": datetime.now().timestamp()}
        local_url = url_for("pc_print_once", token=token, _external=True)
        threading.Thread(target=lambda: open_pc_print_window(local_url), daemon=True).start()
        return "<!doctype html><meta charset='utf-8'><div dir='rtl' style='font:18px Tahoma;padding:30px'>درخواست چاپ به لپ‌تاپ ارسال شد. پنجره چاپ روی کامپیوتر باز می‌شود؛ چاپگر متصل به لپ‌تاپ را انتخاب کنید.</div>"

    return render_template("print_order.html", record=print_record,
                           business_logo_url=(url_for("uploaded_file", filename=logo_name) if logo_name else ""),
                           main_fields=MAIN_MEASUREMENTS,
                           detail_fields=PRINT_DETAIL_FIELDS,
                           code=display_customer_code(record["customer_code"]),
                           barcode_value=barcode_value, barcode_svg=code128_svg(barcode_value),
                           diagram_images=diagram_images,
                           home_url=url_for("customers_page"), pc_auto_print=request.args.get("pc_auto_print")=="1", pdf_fallback=False, customer_id=customer_id, job_id=(job["id"] if job else ""),
                           print_text_color=print_text_color, print_label_color=print_label_color, print_accent_color=print_accent_color)


@app.get("/request-pc-print/<int:customer_id>")
def request_pc_print(customer_id):
    job_id=request.args.get("job_id", "")
    token=secrets.token_urlsafe(24)
    PC_PRINT_TOKENS[token]={"customer_id":customer_id,"job_id":job_id,"created":datetime.now().timestamp()}
    local_url=url_for("pc_print_once", token=token, _external=True)
    # این مرورگر روی خود لپ‌تاپ باز می‌شود؛ چاپگر متصل به لپ‌تاپ از پنجره چاپ ویندوز انتخاب می‌شود.
    threading.Thread(target=lambda: open_pc_print_window(local_url), daemon=True).start()
    return "<!doctype html><meta charset='utf-8'><div dir='rtl' style='font:18px Tahoma;padding:30px'>درخواست چاپ به لپ‌تاپ ارسال شد. پنجره چاپ روی کامپیوتر باز می‌شود؛ چاپگر متصل به لپ‌تاپ را انتخاب کنید.</div>"


@app.get("/pc-print/<token>")
def pc_print_once(token):
    info=PC_PRINT_TOKENS.pop(token,None)
    if not info or datetime.now().timestamp()-info["created"]>180: abort(404)
    with app.test_request_context():
        pass
    return redirect(url_for("print_customer",customer_id=info["customer_id"],job_id=info["job_id"],pc_auto_print="1"))


@app.route("/reports")
def reports_page():
    today = today_jalali()
    month_prefix = today[:7]
    year_prefix = today[:4]
    with get_db() as db:
        total_customers = db.execute("SELECT COUNT(*) FROM customers").fetchone()[0]
        today_orders = db.execute("SELECT COUNT(*) FROM daily_jobs WHERE order_day=?", (today,)).fetchone()[0]
        month_orders = db.execute("SELECT COUNT(*) FROM daily_jobs WHERE order_day LIKE ?", (month_prefix + "%",)).fetchone()[0]
        year_rows = db.execute("SELECT substr(order_day,1,4) AS year, COUNT(*) AS total FROM daily_jobs GROUP BY substr(order_day,1,4) ORDER BY year DESC").fetchall()
        sewing_count = db.execute("SELECT COUNT(*) FROM daily_jobs WHERE status='in_progress'").fetchone()[0]
        ready_count = db.execute("SELECT COUNT(*) FROM daily_jobs WHERE status='ready'").fetchone()[0]
        ready_rows = db.execute("""SELECT j.id, j.ready_at, j.order_day, c.name, c.customer_code, c.mobile
            FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
            WHERE j.status='ready' ORDER BY j.ready_at ASC, j.id ASC""").fetchall()
    waiting = []
    for row in ready_rows:
        item = dict(row)
        try:
            stamp = datetime.strptime(item.get('ready_at') or '', '%Y-%m-%d %H:%M:%S').date()
            item['waiting_days'] = max(0, (date.today() - stamp).days)
        except Exception:
            item['waiting_days'] = 0
        waiting.append(item)
    waiting.sort(key=lambda x: x['waiting_days'], reverse=True)
    return render_template('reports.html', today=today, total_customers=total_customers,
        today_orders=today_orders, month_orders=month_orders, year_rows=year_rows,
        sewing_count=sewing_count, ready_count=ready_count, waiting=waiting)


@app.route("/options", methods=["GET", "POST"])
def manage_options():
    is_ajax = request.headers.get("X-Requested-With", "").lower() == "xmlhttprequest"
    if not session.get("settings_unlocked"):
        if is_ajax:
            response = make_response({"ok": False, "message": "دسترسی تنظیمات منقضی شده است. دوباره رمز تنظیمات را وارد کنید."}, 401)
            response.headers["Content-Type"] = "application/json; charset=utf-8"
            return response
        flash("برای افزودن یا حذف گزینه‌ها ابتدا وارد تنظیمات شوید.", "error")
        return redirect(url_for("appearance_settings"))
    if request.method != "POST":
        return redirect(url_for("appearance_settings"))

    action = request.form.get("action", "")
    try:
        if action == "add":
            field_key = request.form.get("field_key", "")
            value = request.form.get("option_value", "").strip()
            if field_key not in OPTION_FIELD_KEYS:
                if is_ajax: return {"ok": False, "message": "فیلد انتخاب‌شده معتبر نیست."}, 400
                flash("فیلد انتخاب‌شده معتبر نیست.", "error")
            elif not value:
                if is_ajax: return {"ok": False, "message": "متن گزینه را وارد کنید."}, 400
                flash("متن گزینه را وارد کنید.", "error")
            else:
                with get_db() as db:
                    db.execute("INSERT INTO dropdown_options(field_key, option_value) VALUES(?,?)", (field_key, value))
                    db.commit()
                    row = db.execute("SELECT id FROM dropdown_options WHERE field_key=? AND option_value=?", (field_key, value)).fetchone()
                    if is_ajax:
                        return {"ok": True, "message": "گزینه جدید اضافه شد.", "id": row[0], "value": value}, 200
                flash("گزینه جدید اضافه شد.", "success")
        elif action == "delete":
            option_id = request.form.get("option_id", "")
            with get_db() as db:
                db.execute("DELETE FROM dropdown_options WHERE id=?", (option_id,))
                db.commit()
            if is_ajax:
                return {"ok": True, "message": "گزینه حذف شد."}, 200
            flash("گزینه حذف شد. اطلاعات قبلی مشتریان تغییر نمی‌کند.", "success")
        else:
            if is_ajax: return {"ok": False, "message": "درخواست نامعتبر است."}, 400
        return redirect(url_for("appearance_settings"))
    except sqlite3.IntegrityError:
        if is_ajax:
            return {"ok": False, "message": "این گزینه قبلاً برای همین فیلد ثبت شده است."}, 409
        flash("این گزینه قبلاً برای همین فیلد ثبت شده است.", "error")
        return redirect(url_for("appearance_settings"))
    except Exception as exc:
        app.logger.exception("manage_options failed")
        if is_ajax:
            return {"ok": False, "message": "ذخیره گزینه انجام نشد: " + str(exc)}, 500
        flash("ذخیره گزینه انجام نشد.", "error")
        return redirect(url_for("appearance_settings"))


@app.get("/scanner-start/<action>")
def scanner_start(action):
    if action not in {"sewing_scan", "ready_scan", "deliver_scan"}:
        abort(400)
    token = secrets.token_urlsafe(24)
    SCANNER_SESSIONS[token] = {"action": action, "created": datetime.now().timestamp()}
    callback = url_for("scanner_callback", token=token, _external=True)
    ret = url_for("ready_to_deliver", _external=True)
    # Binary Eye callback در حالت continuous نتیجه را مستقیماً به ویندوز می‌فرستد.
    deep_link = "binaryeye://scan?continuous=true&callback=" + __import__('urllib.parse').parse.quote(callback, safe="") + "&ret=" + __import__('urllib.parse').parse.quote(ret, safe="")
    return {"url": deep_link}


@app.post("/scanner-callback/<token>")
def scanner_callback(token):
    info = SCANNER_SESSIONS.get(token)
    if not info:
        return {"ok": False, "error": "جلسه اسکن معتبر نیست"}, 410
    payload = request.get_json(silent=True) or {}
    barcode_value = re.sub(r"\D", "", normalize_digits(str(payload.get("content", ""))))
    if not barcode_value:
        return {"ok": False, "error": "بارکد دریافت نشد"}, 400
    action = info["action"]
    with get_db() as db:
        # ابتدا تطبیق دقیق بارکد سفارش؛ این مطمئن‌ترین حالت است.
        job = db.execute(
            "SELECT id,status,customer_id,order_day FROM daily_jobs WHERE barcode=? ORDER BY id DESC LIMIT 1",
            (barcode_value,),
        ).fetchone()

        if not job:
            # نسخه‌های قدیمی بارکد ممکن است شامل تاریخ شمسی + کد مشتری باشند
            # و در بعضی نسخه‌ها بخش زمان/پیشوند با قالب فعلی تفاوت داشته باشد.
            # در این حالت کد مشتری را از انتهای بارکد تطبیق می‌دهیم.
            customers = db.execute("SELECT id, customer_code FROM customers").fetchall()
            candidates = []
            for customer_row in customers:
                raw_code = re.sub(
                    r"\D", "", normalize_digits(display_customer_code(customer_row["customer_code"] or ""))
                )
                if raw_code and len(barcode_value) > len(raw_code) and barcode_value.endswith(raw_code):
                    candidates.append((len(raw_code), customer_row["id"]))
            # در صورت وجود کدهای پسوندی مشابه، کد طولانی‌تر اولویت دارد.
            candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
            if not candidates:
                # پشتیبانی از بارکدهای قدیمی که در انتهای آن‌ها شناسه داخلی مشتری درج شده است.
                for customer_row in customers:
                    customer_id_code = str(customer_row["id"])
                    if len(barcode_value) > len(customer_id_code) and barcode_value.endswith(customer_id_code):
                        candidates.append((len(customer_id_code), customer_row["id"]))
                candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)

            if candidates:
                longest = candidates[0][0]
                candidate_customer_ids = list(dict.fromkeys(
                    customer_id for length, customer_id in candidates if length == longest
                ))
                # سفارش مناسب مرحله را انتخاب می‌کنیم تا اسکن دوم/سوم به سفارش دیگری نرود.
                preferred_status = {
                    "sewing_scan": "in_progress",
                    "ready_scan": "in_progress",
                    "deliver_scan": "ready",
                }.get(action)
                for customer_id in candidate_customer_ids:
                    if preferred_status:
                        job = db.execute(
                            "SELECT id,status,customer_id,order_day FROM daily_jobs "
                            "WHERE customer_id=? AND status=? ORDER BY id DESC LIMIT 1",
                            (customer_id, preferred_status),
                        ).fetchone()
                    if not job:
                        job = db.execute(
                            "SELECT id,status,customer_id,order_day FROM daily_jobs "
                            "WHERE customer_id=? AND status<>'delivered' ORDER BY id DESC LIMIT 1",
                            (customer_id,),
                        ).fetchone()
                    if job:
                        break

        if not job:
            return {"ok": False, "error": "سفارشی با این بارکد یا کد مشتری پیدا نشد. کد مشتری انتهای بارکد نیز بررسی شد."}, 404
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if action == "sewing_scan":
            if job["status"] == "delivered": return {"ok": False, "error": "لباس قبلاً تحویل شده"}, 409
            db.execute("UPDATE daily_jobs SET status='in_progress', sent_to_sewing_at=? WHERE id=?", (now, job["id"]))
        elif action == "ready_scan":
            if job["status"] == "delivered": return {"ok": False, "error": "لباس قبلاً تحویل شده"}, 409
            db.execute("UPDATE daily_jobs SET status='ready', ready_at=? WHERE id=?", (now, job["id"]))
        else:
            if job["status"] != "ready": return {"ok": False, "error": "ابتدا اسکن دوم (آماده تحویل) را انجام دهید"}, 409
            db.execute("UPDATE daily_jobs SET status='delivered', delivered_at=? WHERE id=?", (now, job["id"]))
        db.commit()
    # یک توکن فقط برای یک اسکن؛ از دریافت دوباره نتیجه جلوگیری می‌شود.
    SCANNER_SESSIONS.pop(token, None)
    return {"ok": True, "barcode": barcode_value, "status": action}, 200


@app.route("/ready", methods=["GET", "POST"])
def ready_to_deliver():
    """مدیریت سه وضعیت اصلی سفارش‌ها با ساعت محلی دستگاه کاربر."""
    if request.method == "POST":
        action = (request.form.get("action") or "").strip()
        now = _device_now_for_request().strftime("%Y-%m-%d %H:%M:%S")

        if action == "set_ready":
            barcode_value = re.sub(r"\D", "", normalize_digits(request.form.get("barcode", "")))
            customer_lookup = re.sub(r"\s+", "", normalize_digits(request.form.get("customer_code", "")))
            if not barcode_value and not customer_lookup:
                flash("کد مشتری یا بارکد لباس را وارد یا اسکن کنید.", "error")
                return redirect(url_for("ready_to_deliver", tab="ready"))
            with get_db() as db:
                if barcode_value:
                    job = db.execute("SELECT j.id,j.status FROM daily_jobs j WHERE j.barcode=? ORDER BY j.id DESC LIMIT 1", (barcode_value,)).fetchone()
                else:
                    customer = db.execute("SELECT id FROM customers WHERE customer_code=? OR CAST(id AS TEXT)=? ORDER BY id DESC LIMIT 1", (customer_lookup, customer_lookup)).fetchone()
                    # آخرین سفارش فعال/آماده انتخاب شود؛ سفارش تحویل‌شده مانع انتخاب سفارش فعال قبلی نشود.
                    job = db.execute("SELECT id,status FROM daily_jobs WHERE customer_id=? AND status IN ('in_progress','ready') ORDER BY id DESC LIMIT 1", (customer["id"],)).fetchone() if customer else None
                if not job:
                    flash("سفارش فعالی با این کد مشتری یا بارکد پیدا نشد. ابتدا برگه سفارش را چاپ کنید.", "error")
                    return redirect(url_for("ready_to_deliver", tab="ready"))
                if job["status"] == "delivered":
                    flash("این لباس قبلاً تحویل مشتری شده است.", "warning")
                    return redirect(url_for("ready_to_deliver", tab="ready"))
                db.execute("UPDATE daily_jobs SET status='ready', ready_at=? WHERE id=?", (now, job["id"]))
                db.commit()
            flash("لباس با موفقیت به فهرست آماده تحویل اضافه شد.", "success")
            return redirect(url_for("ready_to_deliver", tab="ready", focus=job["id"]))

        if action == "confirm_delivery":
            # صفحه تأیید تحویل با نمایش باقیمانده
            job_id = request.form.get("job_id", "")
            if not job_id.isdigit():
                flash("سفارش انتخاب‌شده معتبر نیست.", "error")
                return redirect(url_for("ready_to_deliver", tab="ready"))
            return redirect(url_for("delivery_confirm", job_id=int(job_id)))

        if action == "mark_delivered":
            job_id = request.form.get("job_id", "")
            settlement = (request.form.get("settlement") or "").strip()  # settled | unsettled
            if not job_id.isdigit():
                flash("سفارش انتخاب‌شده معتبر نیست.", "error")
                return redirect(url_for("ready_to_deliver", tab="ready"))
            if settlement not in {"settled", "unsettled"}:
                # اگر از مسیر قدیمی آمد، به صفحه تأیید بفرست
                return redirect(url_for("delivery_confirm", job_id=int(job_id)))
            with get_db() as db:
                job = db.execute("SELECT id, status, remaining_amount, customer_id FROM daily_jobs WHERE id=?", (int(job_id),)).fetchone()
                if not job or job["status"] != "ready":
                    flash("این سفارش دیگر در فهرست آماده تحویل نیست.", "warning")
                    return redirect(url_for("ready_to_deliver", tab="ready"))
                remaining = str(job["remaining_amount"] or "").strip()
                if settlement == "settled":
                    remaining = "0"
                    status_flag = "settled"
                else:
                    status_flag = "unsettled"
                    if not remaining:
                        remaining = remaining or "0"
                db.execute(
                    "UPDATE daily_jobs SET status='delivered', delivered_at=?, remaining_amount=?, settlement_status=? WHERE id=? AND status='ready'",
                    (now, remaining, status_flag, int(job_id)),
                )
                db.commit()
            if settlement == "settled":
                flash("تحویل ثبت شد و باقیمانده تسویه گردید.", "success")
            else:
                flash("تحویل بدون تسویه ثبت شد؛ این مشتری در فهرست بدهکاران می‌ماند.", "warning")
            return redirect(url_for("prepare_customer_sms", job_id=int(job_id), kind="delivered"))

        flash("درخواست نامعتبر است.", "error")
        return redirect(url_for("ready_to_deliver"))

    tab = request.args.get("tab", "sewing")
    if tab not in {"sewing", "ready", "delivered"}:
        tab = "sewing"
    period = request.args.get("period", "today")
    selected_year = re.sub(r"\D", "", normalize_digits(request.args.get("year", "")))
    device_now = _validated_device_datetime(request.args.get("device_now")) if request.args.get("device_now") else datetime.now()
    today = device_now.date()
    today_text = today.strftime("%Y-%m-%d")
    month_text = today.strftime("%Y-%m")
    year_text = today.strftime("%Y")

    with get_db() as db:
        sewing_db_rows = db.execute("""SELECT j.id AS job_id,j.order_day,j.created_at,j.sent_to_sewing_at,j.barcode,
                                             j.fabric_meter,j.order_quantity,
                                             c.id AS customer_id,c.customer_code,c.name,c.mobile,c.stitch_type
                                      FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
                                      WHERE j.finalized=1 AND j.status='in_progress' AND j.sent_to_sewing_at<>''
                                      ORDER BY j.sent_to_sewing_at DESC,j.id DESC""").fetchall()
        sewing_rows = []
        for row in sewing_db_rows:
            item = dict(row)
            item["sent_to_sewing_display"] = format_status_datetime(item.get("sent_to_sewing_at"))
            sewing_rows.append(item)

        ready_db_rows = db.execute("""SELECT j.id AS job_id,j.order_day,j.created_at,j.ready_at,j.barcode,
                                            j.total_amount,j.deposit_amount,j.remaining_amount,
                                            c.id AS customer_id,c.customer_code,c.name,c.mobile
                                     FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
                                     WHERE j.status='ready' ORDER BY j.ready_at DESC,j.id DESC""").fetchall()
        year_rows = db.execute("SELECT DISTINCT substr(delivered_at,1,4) AS y FROM daily_jobs WHERE status='delivered' AND delivered_at<>'' ORDER BY y DESC").fetchall()

        delivered_where = "j.status='delivered' AND j.delivered_at<>''"
        params = []
        if period == "month":
            delivered_where += " AND substr(j.delivered_at,1,7)=?"; params.append(month_text)
        elif period == "year":
            delivered_where += " AND substr(j.delivered_at,1,4)=?"; params.append(year_text)
        elif period == "previous":
            if selected_year and len(selected_year) == 4:
                delivered_where += " AND substr(j.delivered_at,1,4)=?"; params.append(selected_year)
            else:
                delivered_where += " AND substr(j.delivered_at,1,4)<?"; params.append(year_text)
        else:
            period = "today"
            delivered_where += " AND substr(j.delivered_at,1,10)=?"; params.append(today_text)
        delivered_db_rows = db.execute(f"""SELECT j.id AS job_id,j.order_day,j.created_at,j.delivered_at,j.barcode,
                                                  c.id AS customer_id,c.customer_code,c.name,c.mobile
                                           FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
                                           WHERE {delivered_where} ORDER BY j.delivered_at DESC,j.id DESC""", params).fetchall()

    ready_rows = []
    for row in ready_db_rows:
        item = dict(row)
        item["ready_sms_url"] = url_for("prepare_customer_sms", job_id=row["job_id"], kind="ready") if row["mobile"] else ""
        item["ready_at_display"] = format_status_datetime(item.get("ready_at"))
        ready_rows.append(item)
    delivered_rows = []
    for row in delivered_db_rows:
        item = dict(row)
        item["delivered_at_display"] = format_status_datetime(item.get("delivered_at"))
        delivered_rows.append(item)
    years = [str(r["y"]) for r in year_rows if r["y"]]
    jy, jm, jd = gregorian_to_jalali(today.year, today.month, today.day)
    today_jalali_text = f"{jy:04d}/{jm:02d}/{jd:02d}"
    return render_template("ready.html", sewing_rows=sewing_rows, ready_rows=ready_rows,
                           delivered_rows=delivered_rows, active_tab=tab, period=period,
                           selected_year=selected_year, years=years, current_year=year_text,
                           focus_id=request.args.get("focus", ""),
                           device_today=today_text, device_today_jalali=today_jalali_text)



@app.route("/ready/delivery-confirm/<int:job_id>", methods=["GET", "POST"])
def delivery_confirm(job_id):
    """تأیید تحویل با نمایش باقیمانده و انتخاب تسویه / بدون تسویه."""
    with get_db() as db:
        row = db.execute("""
            SELECT j.id AS job_id, j.status, j.order_day, j.ready_at,
                   j.total_amount, j.deposit_amount, j.remaining_amount, j.barcode,
                   c.id AS customer_id, c.customer_code, c.name, c.mobile
            FROM daily_jobs j
            JOIN customers c ON c.id = j.customer_id
            WHERE j.id=?
        """, (job_id,)).fetchone()
    if not row:
        flash("سفارش پیدا نشد.", "error")
        return redirect(url_for("ready_to_deliver", tab="ready"))
    if row["status"] != "ready":
        flash("این سفارش در فهرست آماده تحویل نیست.", "warning")
        return redirect(url_for("ready_to_deliver", tab="ready"))

    remaining = str(row["remaining_amount"] or "").strip() or "0"
    try:
        remaining_num = float(str(remaining).replace(",", "").replace("،", ""))
    except Exception:
        remaining_num = 0.0

    if request.method == "POST":
        settlement = (request.form.get("settlement") or "").strip()
        if settlement not in {"settled", "unsettled"}:
            flash("نوع تسویه را انتخاب کنید.", "error")
            return redirect(url_for("delivery_confirm", job_id=job_id))
        # ارسال به همان اکشن mark_delivered با settlement
        # مستقیم انجام می‌دهیم تا فرم دوباره ساخته نشود
        now = _device_now_for_request().strftime("%Y-%m-%d %H:%M:%S")
        with get_db() as db:
            job = db.execute("SELECT id, status, remaining_amount FROM daily_jobs WHERE id=?", (job_id,)).fetchone()
            if not job or job["status"] != "ready":
                flash("این سفارش دیگر آماده تحویل نیست.", "warning")
                return redirect(url_for("ready_to_deliver", tab="ready"))
            rem = str(job["remaining_amount"] or "").strip() or "0"
            if settlement == "settled":
                rem = "0"
                flag = "settled"
            else:
                flag = "unsettled"
            db.execute(
                "UPDATE daily_jobs SET status='delivered', delivered_at=?, remaining_amount=?, settlement_status=? WHERE id=? AND status='ready'",
                (now, rem, flag, job_id),
            )
            db.commit()
        if settlement == "settled":
            flash("تحویل ثبت شد و باقیمانده صفر گردید.", "success")
        else:
            flash("تحویل بدون تسویه ثبت شد؛ مشتری در فهرست بدهکاران می‌ماند.", "warning")
        return redirect(url_for("prepare_customer_sms", job_id=job_id, kind="delivered"))

    return render_template(
        "delivery_confirm.html",
        item=dict(row),
        remaining=remaining,
        remaining_num=remaining_num,
        code=display_customer_code(row["customer_code"]),
    )


@app.route("/ready/unsettled")
def unsettled_debts():
    """فهرست کسانی که لباس را تحویل گرفته‌اند اما تسویه نکرده‌اند."""
    init_db()  # اطمینان از وجود ستون‌های نسخه‌های جدید روی دیتابیس قدیمی
    with get_db() as db:
        job_cols = {r[1] for r in db.execute("PRAGMA table_info(daily_jobs)").fetchall()}
        has_settlement = "settlement_status" in job_cols
        has_remaining = "remaining_amount" in job_cols
        select_settlement = "j.settlement_status" if has_settlement else "'' AS settlement_status"
        select_remaining = "j.remaining_amount" if has_remaining else "'' AS remaining_amount"
        select_total = "j.total_amount" if "total_amount" in job_cols else "'' AS total_amount"
        select_deposit = "j.deposit_amount" if "deposit_amount" in job_cols else "'' AS deposit_amount"
        if has_settlement and has_remaining:
            where_extra = """AND (
                    j.settlement_status='unsettled'
                    OR (
                        (j.settlement_status IS NULL OR j.settlement_status='')
                        AND CAST(REPLACE(REPLACE(COALESCE(j.remaining_amount,'0'), ',', ''), '،', '') AS REAL) > 0
                    )
              )"""
        elif has_remaining:
            where_extra = "AND CAST(REPLACE(REPLACE(COALESCE(j.remaining_amount,'0'), ',', ''), '،', '') AS REAL) > 0"
        else:
            where_extra = "AND 0"  # ستون باقیمانده نیست؛ فهرستی نداریم
        rows = db.execute(f"""
            SELECT j.id AS job_id, j.order_day, j.delivered_at, {select_remaining},
                   {select_total}, {select_deposit}, {select_settlement}, j.barcode,
                   c.id AS customer_id, c.customer_code, c.name, c.mobile
            FROM daily_jobs j
            JOIN customers c ON c.id = j.customer_id
            WHERE j.status='delivered'
              {where_extra}
            ORDER BY j.delivered_at DESC, j.id DESC
        """).fetchall()
    items = []
    total_debt = 0.0
    for row in rows:
        item = dict(row)
        item["delivered_at_display"] = format_status_datetime(item.get("delivered_at"))
        try:
            item["remaining_num"] = float(str(item.get("remaining_amount") or "0").replace(",", "").replace("،", ""))
        except Exception:
            item["remaining_num"] = 0.0
        total_debt += item["remaining_num"]
        items.append(item)
    return render_template("unsettled_debts.html", rows=items, total_debt=total_debt)


@app.get("/ready/unsettled/print")
def print_unsettled_debts():
    init_db()
    with get_db() as db:
        job_cols = {r[1] for r in db.execute("PRAGMA table_info(daily_jobs)").fetchall()}
        has_settlement = "settlement_status" in job_cols
        has_remaining = "remaining_amount" in job_cols
        select_remaining = "j.remaining_amount" if has_remaining else "'' AS remaining_amount"
        select_total = "j.total_amount" if "total_amount" in job_cols else "'' AS total_amount"
        select_deposit = "j.deposit_amount" if "deposit_amount" in job_cols else "'' AS deposit_amount"
        if has_settlement and has_remaining:
            where_extra = """AND (
                    j.settlement_status='unsettled'
                    OR (
                        (j.settlement_status IS NULL OR j.settlement_status='')
                        AND CAST(REPLACE(REPLACE(COALESCE(j.remaining_amount,'0'), ',', ''), '،', '') AS REAL) > 0
                    )
              )"""
        elif has_remaining:
            where_extra = "AND CAST(REPLACE(REPLACE(COALESCE(j.remaining_amount,'0'), ',', ''), '،', '') AS REAL) > 0"
        else:
            where_extra = "AND 0"
        rows = db.execute(f"""
            SELECT j.id AS job_id, j.order_day, j.delivered_at, {select_remaining},
                   {select_total}, {select_deposit}, c.customer_code, c.name, c.mobile
            FROM daily_jobs j
            JOIN customers c ON c.id = j.customer_id
            WHERE j.status='delivered'
              {where_extra}
            ORDER BY j.delivered_at DESC, j.id DESC
        """).fetchall()
    items = []
    total_debt = 0.0
    for row in rows:
        item = dict(row)
        item["sent_display"] = format_status_datetime(item.get("delivered_at"))
        try:
            val = float(str(item.get("remaining_amount") or "0").replace(",", "").replace("،", ""))
        except Exception:
            val = 0.0
        total_debt += val
        items.append(item)
    today = date.today(); jy, jm, jd = gregorian_to_jalali(today.year, today.month, today.day)
    return render_template(
        "sewing_daily_print.html",
        rows=items,
        report_date=f"{jy:04d}/{jm:02d}/{jd:02d}",
        report_date_gregorian=today.strftime("%Y-%m-%d"),
        total=len(items),
        report_title="فهرست بدهکاران (تحویل بدون تسویه)",
        report_subtitle=f"جمع باقیمانده: {total_debt:g}",
        report_time_label="زمان تحویل",
    )


def _is_unsettled_job(job):
    """آیا این سفارش تحویل‌شده هنوز بدهی دارد؟"""
    if not job:
        return False
    try:
        status = job["status"]
    except Exception:
        status = job.get("status") if hasattr(job, "get") else None
    if status != "delivered":
        return False
    try:
        keys = job.keys() if hasattr(job, "keys") else list(job)
    except Exception:
        keys = []
    settlement = ""
    if "settlement_status" in keys:
        try:
            settlement = job["settlement_status"] or ""
        except Exception:
            settlement = ""
    if settlement == "settled":
        return False
    if settlement == "unsettled":
        return True
    try:
        remaining = job["remaining_amount"] if "remaining_amount" in keys else "0"
        return float(str(remaining or "0").replace(",", "").replace("،", "")) > 0
    except Exception:
        return False


@app.post("/ready/unsettled/<int:job_id>/settle")
def settle_unsettled_debt(job_id):
    init_db()
    """تسویه کامل باقیمانده بدهکار."""
    with get_db() as db:
        job = db.execute(
            "SELECT id, status, remaining_amount, settlement_status, customer_id FROM daily_jobs WHERE id=?",
            (job_id,),
        ).fetchone()
        if not job or job["status"] != "delivered":
            flash("سفارش پیدا نشد.", "error")
            return redirect(url_for("unsettled_debts"))
        if not _is_unsettled_job(job):
            flash("این مورد در فهرست بدهکاران نیست.", "warning")
            return redirect(url_for("unsettled_debts"))
        db.execute(
            "UPDATE daily_jobs SET remaining_amount=?, settlement_status=? WHERE id=?",
            ("0", "settled", job_id),
        )
        db.commit()
    flash("بدهی با موفقیت تسویه و از فهرست بدهکاران حذف شد.", "success")
    return redirect(url_for("unsettled_debts"))


@app.post("/ready/unsettled/<int:job_id>/edit")
def edit_unsettled_debt(job_id):
    init_db()
    """ویرایش مبلغ باقیمانده بدهی."""
    raw = (request.form.get("remaining_amount") or "").strip()
    note = (request.form.get("note") or "").strip()
    if not raw:
        flash("مبلغ باقیمانده را وارد کنید.", "error")
        return redirect(url_for("unsettled_debts"))
    # نرمال‌سازی اعداد فارسی
    trans = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
    cleaned = raw.translate(trans).replace(",", "").replace("،", "").replace(" ", "")
    try:
        value = float(cleaned)
        if value < 0:
            raise ValueError("negative")
    except Exception:
        flash("مبلغ باقیمانده نامعتبر است.", "error")
        return redirect(url_for("unsettled_debts"))
    with get_db() as db:
        job = db.execute(
            "SELECT id, status, remaining_amount, settlement_status FROM daily_jobs WHERE id=?",
            (job_id,),
        ).fetchone()
        if not job or job["status"] != "delivered":
            flash("سفارش پیدا نشد.", "error")
            return redirect(url_for("unsettled_debts"))
        if value == 0:
            db.execute(
                "UPDATE daily_jobs SET remaining_amount=?, settlement_status=? WHERE id=?",
                ("0", "settled", job_id),
            )
            db.commit()
            flash("مبلغ صفر شد و بدهی تسویه‌شده ثبت گردید.", "success")
        else:
            # مقدار را بدون اعشار اضافه در صورت عدد صحیح نگه می‌داریم
            amount_text = str(int(value)) if value == int(value) else str(value)
            db.execute(
                "UPDATE daily_jobs SET remaining_amount=?, settlement_status=? WHERE id=?",
                (amount_text, "unsettled", job_id),
            )
            db.commit()
            flash("مبلغ باقیمانده به‌روزرسانی شد.", "success")
    return redirect(url_for("unsettled_debts"))


@app.post("/ready/unsettled/<int:job_id>/delete")
def delete_unsettled_debt(job_id):
    init_db()
    """حذف از فهرست بدهکاران (بدون حذف کل سفارش تحویل‌شده)."""
    with get_db() as db:
        job = db.execute(
            "SELECT id, status, settlement_status, remaining_amount FROM daily_jobs WHERE id=?",
            (job_id,),
        ).fetchone()
        if not job or job["status"] != "delivered":
            flash("سفارش پیدا نشد.", "error")
            return redirect(url_for("unsettled_debts"))
        # از فهرست بدهکاران خارج می‌شود؛ سابقه تحویل حفظ می‌ماند
        db.execute(
            "UPDATE daily_jobs SET remaining_amount=?, settlement_status=? WHERE id=?",
            ("0", "settled", job_id),
        )
        db.commit()
    flash("این مورد از فهرست بدهکاران حذف شد.", "success")
    return redirect(url_for("unsettled_debts"))


@app.route("/sewing/select-print", methods=["GET", "POST"])
def sewing_select_print():
    """انتخاب لباس‌های ارسال‌شده به کارگاه و چاپ فهرست با نوع دوخت و تعداد."""
    if request.method == "POST":
        job_ids = request.form.getlist("job_ids")
        job_ids = [x for x in job_ids if str(x).isdigit()]
        if not job_ids:
            flash("حداقل یک سفارش را برای چاپ انتخاب کنید.", "warning")
            return redirect(url_for("sewing_select_print"))
        placeholders = ",".join("?" for _ in job_ids)
        with get_db() as db:
            rows = db.execute(
                f"""SELECT j.id AS job_id, j.order_day, j.sent_to_sewing_at, j.barcode,
                           j.fabric_meter, j.order_quantity,
                           c.id AS customer_id, c.customer_code, c.name, c.mobile, c.stitch_type
                    FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
                    WHERE j.id IN ({placeholders})
                      AND j.finalized=1 AND j.status='in_progress' AND j.sent_to_sewing_at<>''
                    ORDER BY j.sent_to_sewing_at ASC, j.id ASC""",
                tuple(int(x) for x in job_ids),
            ).fetchall()
        items = []
        for row in rows:
            item = dict(row)
            item["sent_to_sewing_display"] = format_status_datetime(item.get("sent_to_sewing_at"))
            item["stitch_type"] = (item.get("stitch_type") or "—").strip() or "—"
            item["order_quantity"] = (item.get("order_quantity") or "—").strip() or "—"
            item["fabric_meter"] = (item.get("fabric_meter") or "—").strip() or "—"
            items.append(item)
        # خلاصه تعداد هر نوع دوخت
        stitch_summary = {}
        for it in items:
            key = it["stitch_type"]
            try:
                qty = int(re.sub(r"\D", "", normalize_digits(str(it["order_quantity"]))) or "0")
            except Exception:
                qty = 0
            stitch_summary[key] = stitch_summary.get(key, 0) + (qty if qty > 0 else 1)
        return render_template(
            "sewing_daily_print.html",
            rows=items,
            report_title="لیست انتخابی ارسال به کارگاه",
            report_date=today_jalali(),
            stitch_summary=stitch_summary,
            show_stitch_qty=True,
        )

    with get_db() as db:
        rows = db.execute("""SELECT j.id AS job_id, j.order_day, j.sent_to_sewing_at, j.barcode,
                                    j.fabric_meter, j.order_quantity,
                                    c.id AS customer_id, c.customer_code, c.name, c.mobile, c.stitch_type
                             FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
                             WHERE j.finalized=1 AND j.status='in_progress' AND j.sent_to_sewing_at<>''
                             ORDER BY j.sent_to_sewing_at DESC, j.id DESC""").fetchall()
    items = []
    for row in rows:
        item = dict(row)
        item["sent_to_sewing_display"] = format_status_datetime(item.get("sent_to_sewing_at"))
        items.append(item)
    return render_template("sewing_select.html", rows=items)


def print_ready_clothes_list():
    """فهرست قابل چاپ همه لباس‌هایی که اکنون آماده تحویل هستند."""
    with get_db() as db:
        rows = db.execute("""SELECT j.id AS job_id,j.order_day,j.ready_at,j.barcode,
                                   c.id AS customer_id,c.customer_code,c.name,c.mobile
                            FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
                            WHERE j.status='ready'
                            ORDER BY j.ready_at ASC,j.id ASC""").fetchall()
    items=[]
    for row in rows:
        item=dict(row)
        item["sent_display"] = format_status_datetime(item.get("ready_at"))
        items.append(item)
    today=date.today(); jy,jm,jd=gregorian_to_jalali(today.year,today.month,today.day)
    return render_template("sewing_daily_print.html", rows=items,
        report_date=f"{jy:04d}/{jm:02d}/{jd:02d}", report_date_gregorian=today.strftime("%Y-%m-%d"),
        total=len(items), report_title="فهرست لباس‌های آماده تحویل",
        report_subtitle="تمام لباس‌هایی که در حال حاضر آماده تحویل به مشتری هستند", report_time_label="زمان آماده‌شدن")


@app.route("/ready/labels", methods=["GET"])
def ready_labels_select():
    """انتخاب از تمام لباس‌های آماده تحویل برای چاپ لیبل (با امکان تیک زدن/برداشتن)."""
    with get_db() as db:
        # remaining_amount ممکن است در دیتابیس خیلی قدیمی نباشد؛ ستون‌ها با init_db اضافه می‌شوند
        try:
            rows = db.execute("""
                SELECT
                    j.id AS job_id,
                    j.order_day,
                    j.ready_at,
                    j.fabric_meter,
                    c.customer_code,
                    c.name,
                    c.mobile
                FROM daily_jobs j
                JOIN customers c ON c.id = j.customer_id
                WHERE j.status = 'ready'
                ORDER BY j.ready_at ASC, j.id ASC
            """).fetchall()
        except Exception:
            rows = []
    items = []
    for row in rows:
        item = dict(row)
        item["ready_display"] = format_status_datetime(item.get("ready_at"))
        items.append(item)
    return render_template(
        "ready_labels_select.html",
        rows=items,
    )


@app.route("/ready/labels/print", methods=["POST"])
def print_ready_labels():
    """چاپ لیبل سفارش‌های آماده تحویل انتخاب‌شده."""

    raw_ids = request.form.getlist("job_ids")
    ids = []

    for value in raw_ids:
        value = str(value or "").strip()

        if value.isdigit() and int(value) not in ids:
            ids.append(int(value))

    if not ids:
        flash("حداقل یک لیبل را برای چاپ انتخاب کنید.", "warning")
        return redirect(url_for("ready_labels_select"))

    placeholders = ",".join("?" for _ in ids)

    with get_db() as db:
        rows = db.execute(f"""
            SELECT
                j.id AS job_id,
                j.order_day,
                j.ready_at,
                j.fabric_meter,
                c.customer_code,
                c.name,
                c.mobile
            FROM daily_jobs j
            JOIN customers c ON c.id = j.customer_id
            WHERE j.status = 'ready'
              AND j.id IN ({placeholders})
            ORDER BY j.ready_at ASC, j.id ASC
        """, ids).fetchall()

    items = []

    for row in rows:
        item = dict(row)
        item["ready_display"] = format_status_datetime(
            item.get("ready_at")
        )
        items.append(item)

    return render_template(
        "ready_labels_print.html",
        rows=items,
        business_name=business_name_for_sms(),
        business_phones=business_phones_for_sms(),
        business_address=business_address_for_sms(),
    )


@app.route("/settings/theme", methods=["GET", "POST"])
def theme_settings():
    """انتخاب سریع تم‌های آماده بدون دست‌زدن به سایر تنظیمات برنامه."""
    palettes = [
        ("آبی روشن", "#eef4fb"), ("سرمه‌ای ملایم", "#e9eef7"),
        ("سبز روشن", "#edf6f0"), ("یاسی", "#f3eff9"),
        ("کرم", "#f7f1e6"), ("فیروزه‌ای", "#eaf4f4"),
        ("خاکستری روشن", "#f0f2f5"), ("صورتی ملایم", "#f9eff1"),
        ("آبی آسمانی", "#e4f3ff"), ("سبز نعنایی", "#e1f5ec"),
        ("هلویی", "#fff0e5"), ("طلایی روشن", "#fff6d9"),
        ("بنفش ملایم", "#eee8ff"), ("مرجانی", "#ffe8e5"),
        ("سبز زیتونی روشن", "#eef0df"), ("نقره‌ای", "#e9edf2")]
    if request.method == "POST":
        selected=(request.form.get("theme_color") or "").lower()
        allowed={color for _,color in palettes}
        if selected not in allowed:
            flash("لطفاً یکی از تم‌های پیشنهادی را انتخاب کنید.", "error")
        else:
            with get_db() as db:
                _save_setting(db, "theme_color", selected)
                _save_setting(db, "theme_mode", "light")
                db.commit()
            flash("رنگ‌بندی برنامه با موفقیت تغییر کرد.", "success")
            return redirect(url_for("theme_settings"))
    with get_db() as db:
        current=_setting(db,"theme_color") or "#f4eddc"
        shop=_setting(db,"business_name") or "خیاطی"
    return render_template("theme_settings.html", palettes=palettes, current_theme=current, business_name=shop)


@app.get("/ready/sewing/print")
def print_today_sewing_list():
    """چاپ فقط لباس‌های امروز که هنوز در فهرست جاری ارسال به کارگاه هستند."""
    raw_date = normalize_digits(request.args.get("device_date", ""))
    try:
        selected_date = datetime.strptime(raw_date, "%Y-%m-%d").date()
    except ValueError:
        selected_date = date.today()
    date_text = selected_date.strftime("%Y-%m-%d")
    jy, jm, jd = gregorian_to_jalali(selected_date.year, selected_date.month, selected_date.day)
    with get_db() as db:
        rows = db.execute("""SELECT j.id AS job_id,j.order_day,j.sent_to_sewing_at,j.barcode,
                                   c.id AS customer_id,c.customer_code,c.name,c.mobile
                            FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
                            WHERE j.finalized=1 AND j.status='in_progress'
                              AND j.sent_to_sewing_at<>''
                              AND substr(j.sent_to_sewing_at,1,10)=?
                            ORDER BY j.sent_to_sewing_at ASC,j.id ASC""", (date_text,)).fetchall()
    items = []
    for row in rows:
        item = dict(row)
        item["sent_display"] = format_status_datetime(item.get("sent_to_sewing_at"))
        items.append(item)
    return render_template("sewing_daily_print.html", rows=items,
                           report_date=f"{jy:04d}/{jm:02d}/{jd:02d}",
                           report_date_gregorian=date_text, total=len(items),
                           report_title="فهرست ارسال امروز به کارگاه",
                           report_subtitle="فقط لباس‌هایی که امروز ارسال شده و هنوز در فهرست جاری کارگاه هستند", business_name=business_name_for_sms())


@app.get("/ready/sewing/print-all")
def print_all_sewing_list():
    """چاپ همه سفارش‌هایی که تاکنون به کارگاه ارسال شده‌اند، با هر وضعیت فعلی."""
    with get_db() as db:
        rows = db.execute("""SELECT j.id AS job_id,j.order_day,j.sent_to_sewing_at,j.barcode,j.status,
                                   c.id AS customer_id,c.customer_code,c.name,c.mobile
                            FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
                            WHERE j.finalized=1 AND j.sent_to_sewing_at<>''
                            ORDER BY j.sent_to_sewing_at ASC,j.id ASC""").fetchall()
    items = []
    for row in rows:
        item = dict(row)
        item["sent_display"] = format_status_datetime(item.get("sent_to_sewing_at"))
        items.append(item)
    today = date.today()
    jy, jm, jd = gregorian_to_jalali(today.year, today.month, today.day)
    return render_template("sewing_daily_print.html", rows=items,
                           report_date=f"تهیه‌شده در {jy:04d}/{jm:02d}/{jd:02d}",
                           report_date_gregorian=today.strftime("%Y-%m-%d"), total=len(items),
                           report_title="فهرست کامل لباس‌های ارسال‌شده به کارگاه",
                           report_subtitle="تمام سفارش‌هایی که تاکنون به کارگاه ارسال شده‌اند، حتی اگر آماده یا تحویل شده باشند", business_name=business_name_for_sms())



@app.route("/customer/<int:customer_id>/message", methods=["GET", "POST"])
def customer_message(customer_id):
    with get_db() as db:
        customer = db.execute("SELECT id,name,mobile FROM customers WHERE id=?", (customer_id,)).fetchone()
        job = db.execute("SELECT id FROM daily_jobs WHERE customer_id=? ORDER BY id DESC LIMIT 1", (customer_id,)).fetchone()
    if not customer:
        flash("مشتری پیدا نشد.", "error")
        return redirect(url_for("customers_page"))
    if not customer["mobile"]:
        flash("برای این مشتری شماره موبایل ثبت نشده است.", "warning")
        return redirect(url_for("customers_page"))
    if request.method == "POST":
        kind = request.form.get("kind", "welcome")
        if kind not in {"eid", "welcome", "ready", "reminder", "delivered"}:
            abort(400)
        if job:
            return redirect(url_for("prepare_customer_sms", job_id=job["id"], kind=kind))
        if kind not in {"welcome", "eid"}:
            flash("برای پیام‌های وضعیت، ابتدا باید سفارش ثبت شود.", "warning")
            return redirect(url_for("customers_page"))
        row = {"id": 0, "customer_id": customer["id"], "name": customer["name"], "mobile": customer["mobile"], "status": "", "order_day": today_jalali()}
        message = make_customer_message(row, kind)
        return render_template("sms_confirm.html", mobile=normalize_mobile(customer["mobile"]), message=message, customer_name=customer["name"], kind=kind, job_id=0, customer_id=customer["id"], whatsapp_enabled=whatsapp_is_enabled())
    return render_template("customer_message.html", customer=customer)


@app.route("/sms/prepare/<int:job_id>/<kind>")
def prepare_customer_sms(job_id, kind):
    if kind not in {"ready", "reminder", "delivered", "welcome", "eid"}: abort(404)
    with get_db() as db:
        row = db.execute("""SELECT j.*, c.id AS customer_id, c.name, c.mobile FROM daily_jobs j
                            JOIN customers c ON c.id=j.customer_id WHERE j.id=?""", (job_id,)).fetchone()
        if not row or not row["mobile"]:
            flash("برای این مشتری شماره موبایل ثبت نشده است.", "warning")
            return redirect(url_for("ready_to_deliver"))
        message = make_customer_message(row, kind)
    return render_template("sms_confirm.html", mobile=normalize_mobile(row["mobile"]), message=message,
                           customer_name=row["name"], kind=kind, job_id=job_id, customer_id=row["customer_id"], whatsapp_enabled=whatsapp_is_enabled())


def make_customer_message(row, kind):
    """متن پیام آماده: دقیقاً همان الگوی تنظیمات با جایگزینی متغیرها؛ هیچ متن اضافه‌ای الحاق نمی‌شود."""
    shop, address, phones = business_name_for_sms(), business_address_for_sms(), business_phones_for_sms()
    name = str(row["name"] if hasattr(row, "keys") and "name" in row.keys() else "مشتری گرامی")
    code, order_date = "", today_jalali()
    try:
        if hasattr(row, "keys"):
            keys = row.keys()
            if "customer_code" in keys:
                code = display_customer_code(row["customer_code"])
            if "order_date" in keys and row["order_date"]:
                order_date = row["order_date"]
            elif "customer_id" in keys:
                with get_db() as db:
                    customer = db.execute(
                        "SELECT customer_code, order_date FROM customers WHERE id=?",
                        (row["customer_id"],),
                    ).fetchone()
                if customer:
                    code = display_customer_code(customer["customer_code"])
                    order_date = customer["order_date"] or order_date
    except Exception:
        pass

    with get_db() as db:
        custom = (_setting(db, "message_" + kind) or "").strip()

    if custom:
        return (
            custom
            .replace("{نام}", name)
            .replace("{نام_خیاطی}", shop)
            .replace("{آدرس}", address)
            .replace("{تلفن}", phones)
            .replace("{کد_مشتری}", code or "—")
            .replace("{تاریخ}", order_date)
        )

    if kind == "eid":
        body = "چنانچه قصد سفارش لباس برای عید را دارید، از هم‌اکنون مراجعه نمایید."
    elif kind == "welcome":
        body = "به خیاطی ما خوش آمدید. از اعتماد شما سپاسگزاریم."
    elif kind == "delivered":
        body = f"لباس شما در تاریخ {today_jalali()} تحویل گردید."
    elif kind == "ready":
        body = "لباس شما آماده تحویل است. لطفاً برای دریافت مراجعه فرمایید."
    else:
        body = "لباس شما آماده تحویل است. لطفاً برای دریافت مراجعه کنید."
    return f"{name}، {body}"



def whatsapp_is_enabled():
    with get_db() as db:
        return _setting(db, "whatsapp_enabled") == "1"


@app.route("/sms/eid", methods=["GET", "POST"])
def eid_campaign():
    with get_db() as db:
        rows = db.execute("SELECT name,mobile FROM customers WHERE mobile IS NOT NULL AND mobile<>'' ORDER BY name").fetchall()
    phones = [normalize_mobile(r["mobile"]) for r in rows if normalize_mobile(r["mobile"])]
    message = make_customer_message({"name":"مشتری گرامی"}, "eid")
    if request.method == "POST":
        selected = request.form.getlist("mobiles")
        selected = [normalize_mobile(x) for x in selected if normalize_mobile(x)]
        if not selected:
            flash("حداقل یک مشتری را انتخاب کنید.", "warning")
            return redirect(url_for("eid_campaign"))
        text_message = request.form.get("message", message).strip()
        if request.form.get("method") == "amoot":
            sent = 0
            for phone in selected:
                ok, _detail = send_amoot_sms(phone, text_message)
                if ok:
                    sent += 1
            flash(f"درخواست ارسال آموت برای {sent} از {len(selected)} شماره ثبت شد؛ وضعیت نهایی را در پنل آموت بررسی کنید.", "success" if sent else "error")
            return redirect(url_for("customers_page"))
        return redirect("sms:" + ",".join(selected) + "?body=" + quote(text_message))
    return render_template("eid_campaign.html", rows=rows, message=message, whatsapp_enabled=whatsapp_is_enabled())

@app.route("/sms/group", methods=["GET", "POST"])
def group_message_campaign():
    if request.method == "GET":
        with get_db() as db:
            rows = db.execute("SELECT id,name,mobile,customer_code FROM customers WHERE mobile IS NOT NULL AND mobile<>'' ORDER BY name COLLATE NOCASE").fetchall()
        return render_template("group_message.html", rows=rows)
    selected_ids = request.form.getlist("customer_ids")
    message_text = request.form.get("message", "").strip()
    method = request.form.get("method", "phone")
    if not selected_ids or not message_text:
        flash("حداقل یک مشتری و متن پیام را انتخاب و وارد کنید.", "warning")
        return redirect(url_for("group_message_campaign"))
    placeholders = ",".join("?" for _ in selected_ids)
    with get_db() as db:
        rows = db.execute(f"SELECT id,name,mobile,customer_code FROM customers WHERE id IN ({placeholders}) ORDER BY name COLLATE NOCASE", tuple(selected_ids)).fetchall()
    recipients = []
    for row in rows:
        phone = normalize_mobile(row["mobile"] or "")
        if phone:
            recipients.append({"id": row["id"], "name": row["name"], "mobile": phone, "code": display_customer_code(row["customer_code"]), "message": (message_text.replace("{نام}", row["name"] or "مشتری گرامی")
                    .replace("{نام_خیاطی}", business_name_for_sms()).replace("{آدرس}", business_address_for_sms())
                    .replace("{تلفن}", business_phones_for_sms()).replace("{کد_مشتری}", display_customer_code(row["customer_code"]))
                    .replace("{تاریخ}", today_jalali()))})
    if not recipients:
        flash("شماره معتبر برای مشتریان انتخاب‌شده پیدا نشد.", "error")
        return redirect(url_for("group_message_campaign"))
    if method == "amoot":
        sent = 0
        for person in recipients:
            ok, _detail = send_amoot_sms(person["mobile"], person["message"])
            if ok:
                sent += 1
        flash(f"درخواست ارسال آموت برای {sent} از {len(recipients)} شماره ثبت شد؛ وضعیت نهایی را در پنل آموت بررسی کنید.", "success" if sent else "error")
        return redirect(url_for("group_message_campaign"))

    if method == "whatsapp":
        return render_template(
            "group_whatsapp.html",
            recipients=recipients,
            message_text=message_text,
        )

    # پیامک گوشی: ساخت لینک برای هر مخاطب
    for person in recipients:
        person["sms_url"] = sms_deeplink(person["mobile"], person["message"])
    return render_template(
        "group_message.html",
        rows=[],
        prepared=recipients,
        message_text=message_text,
        send_ready=True,
    )


def send_amoot_sms(mobile, message):
    """ارسال پیامک از وب‌سرویس آموت. خروجی: (ok: bool, detail: str)"""
    token = ""
    if AMOOT_TOKEN_PATH.exists():
        token = AMOOT_TOKEN_PATH.read_text(encoding="utf-8").strip()
    with get_db() as db:
        line = (_setting(db, "amoot_line_number") or "").strip()
    if not token:
        return False, "توکن آموت در تنظیمات ذخیره نشده است. از تنظیمات → آموت توکن را وارد و ذخیره کنید."
    if not line:
        return False, "شماره خط آموت در تنظیمات خالی است. شماره خط پنل آموت را وارد و ذخیره کنید."
    digits = re.sub(r"\D", "", normalize_digits(str(mobile or "")))
    if digits.startswith("98") and len(digits) >= 12:
        digits = "0" + digits[2:]
    elif digits.startswith("0098") and len(digits) >= 14:
        digits = "0" + digits[4:]
    if not digits:
        return False, "شماره موبایل معتبر نیست."
    payload = urlencode({
        "SendDateTime": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "SMSMessageText": message,
        "LineNumber": line,
        "Mobiles": digits,
    }).encode("utf-8")
    headers = {
        "Authorization": token,
        "Content-Type": "application/x-www-form-urlencoded",
    }
    try:
        req = URLRequest(
            "https://portal.amootsms.com/rest/SendSimple",
            data=payload,
            headers=headers,
        )
        with urlopen(req, timeout=25) as response:
            raw = response.read().decode("utf-8", "replace")
        try:
            result = json.loads(raw) if raw else {}
        except Exception:
            result = {"raw": raw}
        status = result.get("Status", result.get("status", ""))
        status_s = str(status).strip().lower()
        ok = (
            status_s in {"success", "true", "1", "200", "0", "ok"}
            or status is True
            or status == 0
            or status == 1
            or bool(result.get("Data"))
            or bool(result.get("data"))
        )
        if ok:
            return True, str(result.get("Message") or result.get("message") or "ارسال شد")
        detail = result.get("StatusText") or result.get("Message") or result.get("message") or result.get("explanation") or result
        return False, f"خط ارسالی: {line} | {str(detail)[:250]}"
    except Exception as exc:
        return False, str(exc)[:220]


@app.route("/sms/send", methods=["POST"])
def send_customer_sms():
    mobile = re.sub(r"[^0-9+]", "", normalize_mobile(request.form.get("mobile", "")))
    message = request.form.get("message", "").strip()
    kind = request.form.get("kind", "")
    job_id = request.form.get("job_id", "")
    customer_id = request.form.get("customer_id", "")
    method = request.form.get("method", "phone")
    if not mobile or not message:
        flash("شماره یا متن پیام خالی است.", "error")
        return redirect(url_for("ready_to_deliver"))

    # ثبت متن آماده‌شده
    with get_db() as db:
        customer = db.execute("SELECT id FROM customers WHERE id=?", (int(customer_id),)).fetchone() if str(customer_id).isdigit() else None
        if customer:
            db.execute(
                "UPDATE customers SET last_sms_text=?, last_sms_at=?, last_sms_type=? WHERE id=?",
                (message, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), (kind or "message") + ("_sent" if method == "amoot" else "_prepared"), customer["id"]),
            )
            db.commit()

    if method == "amoot":
        ok, detail = send_amoot_sms(mobile, message)
        if not ok:
            flash("ارسال از آموت انجام نشد: " + detail, "error")
            return redirect(url_for("ready_to_deliver"))
        flash("درخواست ارسال به سامانه آموت ثبت شد. وضعیت نهایی را در پنل آموت بررسی کنید.", "success")
        return redirect(url_for("ready_to_deliver"))

    if method == "whatsapp":
        return redirect(whatsapp_deeplink(mobile, message))

    # پیش‌فرض: باز کردن برنامه پیامک گوشی با متن آماده
    return redirect(sms_deeplink(mobile, message))


def business_name_for_sms():
    with get_db() as db: return _setting(db, "business_name") or "خیاطی"
def business_address_for_sms():
    with get_db() as db: return _setting(db, "business_address") or ""
def business_phones_for_sms():
    with get_db() as db:
        p1, p2 = _setting(db, "business_phone1"), _setting(db, "business_phone2")
    return " - ".join(x for x in (p1, p2) if x)


@app.route("/ready/<int:job_id>/delivered", methods=["POST"])
def mark_delivered(job_id):
    with get_db() as db:
        changed = db.execute("UPDATE daily_jobs SET status='delivered', delivered_at=? WHERE id=? AND status='ready'",
                             (_device_now_for_request().strftime("%Y-%m-%d %H:%M:%S"), job_id)).rowcount
        db.commit()
    if changed:
        return redirect(url_for("prepare_customer_sms", job_id=job_id, kind="delivered"))
    flash("این مورد در فهرست آماده تحویل نبود.", "warning")
    return redirect(url_for("ready_to_deliver"))



@app.route("/settings/measurement-order", methods=["POST"])
def save_measurement_order():
    if not session.get("settings_unlocked"):
        abort(403)
    data = request.get_json(silent=True) or {}
    allowed = ALL_EDITABLE_FIELD_KEYS
    order = [k for k in data.get("order", []) if k in allowed]
    order += [k for k, _ in ALL_EDITABLE_FIELDS if k not in order]
    with get_db() as db:
        _save_setting(db, "all_form_field_order", json.dumps(order, ensure_ascii=False))
        db.commit()
    return {"ok": True}

def export_database_to_mdb(destination):
    """Export the SQLite customer/order data to a Microsoft Access MDB using the installed Access ODBC driver."""
    if os.name != "nt":
        raise RuntimeError("ساخت فایل MDB در نسخه اندروید مستقیماً پشتیبانی نمی‌شود؛ این عملیات را از نسخه ویندوز انجام دهید.")
    try:
        import pyodbc
    except Exception as exc:
        raise RuntimeError("برای ساخت MDB، pyodbc و Microsoft Access Database Engine (ODBC) باید نصب باشند.") from exc
    drivers = [d for d in pyodbc.drivers() if "Access" in d and ("*.mdb" in d or "*.accdb" in d)]
    if not drivers:
        raise RuntimeError("درایور Microsoft Access ODBC پیدا نشد. Microsoft Access Database Engine را نصب کنید.")
    driver = drivers[0]
    target = Path(destination).resolve()
    if target.exists():
        target.unlink()
    # ODBC attribute به نام CREATE_DB پشتیبانی نمی‌شود؛ ابتدا فایل Jet 4.0
    # را با ADOX می‌سازیم و سپس با ODBC معمولی به آن متصل می‌شویم.
    try:
        # ابتدا از pywin32 استفاده می‌کنیم؛ اگر نصب نبود، خود COM را از PowerShell صدا می‌زنیم.
        created = False
        try:
            import win32com.client
            catalog = win32com.client.Dispatch("ADOX.Catalog")
            try:
                catalog.Create(f"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={target};Jet OLEDB:Engine Type=5;")
            except Exception:
                catalog.Create(f"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={target};Jet OLEDB:Engine Type=5;")
            catalog = None
            created = True
        except Exception:
            import base64
            ps_path = str(target).replace("'", "''")
            ps = "$c=New-Object -ComObject ADOX.Catalog; try{$c.Create('Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ps_path + ";Jet OLEDB:Engine Type=5;')}catch{$c.Create('Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + ps_path + ";Jet OLEDB:Engine Type=5;')}; [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($c)"
            encoded = base64.b64encode(ps.encode("utf-16le")).decode("ascii")
            _bootstrap_subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded], check=True, capture_output=True, text=True, timeout=45)
            created = True
        if not created or not target.exists():
            raise RuntimeError("ایجاد فایل MDB توسط موتور Microsoft Jet انجام نشد.")
        conn = pyodbc.connect(f'DRIVER={{{driver}}};DBQ={target};', autocommit=True)
    except Exception as exc:
        try:
            target.unlink(missing_ok=True)
        except Exception:
            pass
        raise RuntimeError("ساخت فایل MDB ناموفق بود. Microsoft Access Database Engine (نسخه هم‌معماری با Python) و مؤلفه ADOX و درایور ODBC باید نصب باشند. جزئیات: " + str(exc)) from exc
    try:
        cur = conn.cursor()
        with get_db() as src:
            customer_cols = [r[1] for r in src.execute("PRAGMA table_info(customers)").fetchall()]
            job_cols = [r[1] for r in src.execute("PRAGMA table_info(daily_jobs)").fetchall()]
            # Access table names and column names are quoted to preserve Persian/underscored names.
            for table, cols in (("customers", customer_cols), ("daily_jobs", job_cols)):
                definitions = []
                for col in cols:
                    if col == "id": definitions.append("[id] LONG")
                    elif col in {"customer_id"}: definitions.append(f"[{col}] LONG")
                    else: definitions.append(f"[{col}] MEMO")
                cur.execute(f"CREATE TABLE [{table}] ({', '.join(definitions)})")
                rows = src.execute(f'SELECT * FROM "{table}"').fetchall()
                if rows:
                    names = ",".join(f"[{c}]" for c in cols)
                    marks = ",".join("?" for _ in cols)
                    cur.executemany(f"INSERT INTO [{table}] ({names}) VALUES ({marks})", [tuple(row[c] for c in cols) for row in rows])
        conn.commit()
    finally:
        conn.close()
    return target


@app.route("/settings", methods=["GET", "POST"])
def appearance_settings():
    if request.method == "POST" and request.form.get("action") == "export_mdb":
        if not session.get("settings_unlocked"):
            abort(403)
        try:
            output = APP_DIR / ("khavaran_export_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".mdb")
            export_database_to_mdb(output)
            return send_file(output, as_attachment=True, download_name=output.name)
        except Exception as exc:
            flash(str(exc), "error")
            return redirect(url_for("appearance_settings"))
    if request.method == "POST" and request.form.get("action") == "unlock_settings":
        if normalize_digits(request.form.get("settings_password", "")).strip() == "10446600":
            session["settings_unlocked"] = True
            return redirect(url_for("appearance_settings"))
        flash("رمز ورود تنظیمات نادرست است.", "error")
        return redirect(url_for("appearance_settings"))
    if not session.get("settings_unlocked"):
        return render_template("settings.html", settings_locked=True)
    if request.method == "POST":
        color = request.form.get("theme_color", "").strip()
        print_text_color = request.form.get("print_text_color", "").strip()
        print_label_color = request.form.get("print_label_color", "").strip()
        print_accent_color = request.form.get("print_accent_color", "").strip()
        theme_mode = request.form.get("theme_mode", "light").strip().lower()
        if theme_mode not in {"light", "dark", "black"}: theme_mode = "light"
        backup_email = request.form.get("backup_email", "").strip()
        smtp_host = request.form.get("smtp_host", "smtp.gmail.com").strip()
        smtp_port_text = normalize_digits(request.form.get("smtp_port", "587")).strip()
        smtp_username = request.form.get("smtp_username", "").strip()
        smtp_security = request.form.get("smtp_security", "starttls").strip().lower()
        smtp_password = re.sub(r"\s+", "", request.form.get("smtp_password", ""))
        clear_smtp_password = request.form.get("clear_smtp_password") == "1"
        # تصاویر راهنمای چاپ؛ فایل قبلی در صورت انتخاب‌نشدن حفظ می‌شود.
        diagram_uploads = {}
        for diagram_key, _diagram_label in (("sleeve", "آستین"), ("pocket", "جیب"), ("pati", "پتی"), ("trousers", "شلوار"), ("waist_slit", "چاک کمر")):
            uploaded_diagram = request.files.get("diagram_" + diagram_key)
            if uploaded_diagram and uploaded_diagram.filename:
                ext = Path(uploaded_diagram.filename).suffix.lower()
                if ext not in {".png", ".jpg", ".jpeg", ".webp"}:
                    flash("تصاویر نمونه باید PNG، JPG یا WEBP باشند.", "error")
                else:
                    safe_name = "print_" + diagram_key + "_" + secrets.token_hex(6) + ext
                    uploaded_diagram.save(UPLOAD_DIR / safe_name)
                    diagram_uploads[diagram_key] = safe_name
        amoot_token = request.form.get("amoot_token", "").strip()
        # خط آموت می‌تواند عددی یا متنی مثل service باشد
        amoot_line_raw = normalize_digits(request.form.get("amoot_line_number", "") or "").strip()
        amoot_line_number = "".join(amoot_line_raw.split())
        clear_amoot_token = request.form.get("clear_amoot_token") == "1"
        try:
            requested_order = json.loads(request.form.get("main_measurement_order", "[]"))
        except Exception:
            requested_order = []
        allowed_order = {k for k, _ in MAIN_MEASUREMENTS}
        requested_order = [k for k in requested_order if k in allowed_order]
        requested_order += [k for k, _ in MAIN_MEASUREMENTS if k not in requested_order]
        try: all_field_order = json.loads(request.form.get("all_form_field_order", "[]"))
        except Exception: all_field_order = []
        all_field_order = [k for k in all_field_order if k in ALL_EDITABLE_FIELD_KEYS]
        all_field_order += [k for k, _ in ALL_EDITABLE_FIELDS if k not in all_field_order]
        whatsapp_code = request.form.get("whatsapp_activation_code", "")
        whatsapp_enabled = request.form.get("enable_whatsapp") == "1"
        measurement_layout = request.form.get("measurement_layout", "tiles")
        if measurement_layout not in {"tiles", "list"}: measurement_layout = "tiles"
        message_lock_code = request.form.get("message_lock_code", "")
        message_lock_ok = message_lock_code == "10346600"
        custom_messages = {k: request.form.get("msg_"+k, "").strip() for k in ("welcome","ready","delivered","reminder","eid")}
        if any(custom_messages.values()) and not message_lock_ok:
            flash("برای تغییر متن پیام‌ها، کد قفل ۱۰۳۴۶۶۰۰ را وارد کنید.", "error")
            custom_messages = {}
        errors = []
        current_admin_pin = normalize_digits(request.form.get("current_admin_pin", "")).strip()
        new_admin_pin = normalize_digits(request.form.get("new_admin_pin", "")).strip()
        confirm_admin_pin = normalize_digits(request.form.get("confirm_admin_pin", "")).strip()
        change_admin_pin = bool(current_admin_pin or new_admin_pin or confirm_admin_pin)
        if change_admin_pin:
            with get_db() as pin_db:
                saved_pin_hash = _setting(pin_db, "admin_pin_hash")
            if not current_admin_pin or not saved_pin_hash or not check_password_hash(saved_pin_hash, current_admin_pin):
                errors.append("رمز فعلی ورود برنامه صحیح نیست.")
            if not re.fullmatch(r"[0-9]{4,}", new_admin_pin):
                errors.append("رمز جدید باید حداقل ۴ رقم باشد.")
            if new_admin_pin != confirm_admin_pin:
                errors.append("تکرار رمز جدید با رمز اصلی یکسان نیست.")
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
            errors.append("رنگ زمینه معتبر نیست.")
        if backup_email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", backup_email):
            errors.append("نشانی ایمیل مقصد معتبر نیست.")
        try:
            smtp_port = int(smtp_port_text)
            if not 1 <= smtp_port <= 65535:
                raise ValueError
        except Exception:
            smtp_port = 587
            errors.append("شماره درگاه SMTP باید بین ۱ تا ۶۵۵۳۵ باشد.")
        if smtp_security not in {"starttls", "ssl"}:
            smtp_security = "starttls"
            errors.append("نوع اتصال ایمیل معتبر نیست.")
        if backup_email and (not smtp_host or not smtp_username):
            errors.append("برای ارسال ایمیل، سرور SMTP و ایمیل فرستنده را نیز وارد کنید.")
        # ذخیره آموت همیشه انجام شود (وابسته به سایر خطاهای فرم نباشد)
        try:
            with get_db() as db_amoot:
                _save_setting(db_amoot, "amoot_line_number", amoot_line_number)
                db_amoot.commit()
            if amoot_token:
                temp_token = AMOOT_TOKEN_PATH.with_name(AMOOT_TOKEN_PATH.name + ".tmp")
                temp_token.write_text(amoot_token, encoding="utf-8")
                try:
                    os.chmod(temp_token, 0o600)
                except Exception:
                    pass
                os.replace(temp_token, AMOOT_TOKEN_PATH)
            elif clear_amoot_token:
                AMOOT_TOKEN_PATH.unlink(missing_ok=True)
            saved_line = amoot_line_number or "(خالی)"
            token_state = "ذخیره شد" if amoot_token else ("حذف شد" if clear_amoot_token else ("قبلی حفظ شد" if AMOOT_TOKEN_PATH.exists() else "ثبت نشده"))
            flash(f"تنظیمات آموت: شماره خط «{saved_line}» — توکن: {token_state}", "success")
        except Exception as exc:
            flash("ذخیره تنظیمات آموت انجام نشد: " + str(exc)[:200], "error")

        if errors:
            for error in errors:
                flash(error, "error")
        else:
            with get_db() as db:
                _save_setting(db, "theme_color", color.lower())
                if re.fullmatch(r"#[0-9a-fA-F]{6}", print_text_color or ""):
                    _save_setting(db, "print_text_color", print_text_color.lower())
                if re.fullmatch(r"#[0-9a-fA-F]{6}", print_label_color or ""):
                    _save_setting(db, "print_label_color", print_label_color.lower())
                if re.fullmatch(r"#[0-9a-fA-F]{6}", print_accent_color or ""):
                    _save_setting(db, "print_accent_color", print_accent_color.lower())
                _save_setting(db, "theme_mode", theme_mode)
                if change_admin_pin:
                    _save_setting(db, "admin_pin_hash", generate_password_hash(new_admin_pin))
                _save_setting(db, "backup_email", backup_email)
                _save_setting(db, "smtp_host", smtp_host)
                _save_setting(db, "smtp_port", smtp_port)
                _save_setting(db, "smtp_username", smtp_username)
                _save_setting(db, "smtp_security", smtp_security)
                _save_setting(db, "main_measurement_order", json.dumps(requested_order, ensure_ascii=False))
                _save_setting(db, "all_form_field_order", json.dumps(all_field_order, ensure_ascii=False))
                _save_setting(db, "measurement_layout", measurement_layout)
                for diagram_key, diagram_filename in diagram_uploads.items():
                    _save_setting(db, "print_diagram_" + diagram_key, diagram_filename)
                if whatsapp_code == "10246600":
                    _save_setting(db, "whatsapp_enabled", "1")
                elif request.form.get("disable_whatsapp") == "1":
                    _save_setting(db, "whatsapp_enabled", "0")
                elif whatsapp_enabled and _setting(db, "whatsapp_enabled") != "1":
                    flash("کد فعال‌سازی واتس‌اپ صحیح نیست؛ این قابلیت غیرفعال ماند.", "error")
                if message_lock_ok:
                    for k,v in custom_messages.items():
                        if v: _save_setting(db, "message_"+k, v)
                db.commit()
            if smtp_password:
                temp_password_path = SMTP_PASSWORD_PATH.with_name(SMTP_PASSWORD_PATH.name + ".tmp")
                temp_password_path.write_text(smtp_password, encoding="utf-8")
                try:
                    os.chmod(temp_password_path, 0o600)
                except Exception:
                    pass
                os.replace(temp_password_path, SMTP_PASSWORD_PATH)
            elif clear_smtp_password:
                SMTP_PASSWORD_PATH.unlink(missing_ok=True)
            if amoot_token:
                temp_token = AMOOT_TOKEN_PATH.with_name(AMOOT_TOKEN_PATH.name + ".tmp")
                temp_token.write_text(amoot_token, encoding="utf-8")
                try: os.chmod(temp_token, 0o600)
                except Exception: pass
                os.replace(temp_token, AMOOT_TOKEN_PATH)
            elif clear_amoot_token:
                AMOOT_TOKEN_PATH.unlink(missing_ok=True)
            flash("تنظیمات ذخیره شد.", "success")
            return redirect(url_for("customers_page"))
        return redirect(url_for("appearance_settings"))
    with get_db() as db:
        settings = {
            "theme_color": _setting(db, "theme_color") or "#f4eddc",
            "print_text_color": _setting(db, "print_text_color") or "#111111",
            "print_label_color": _setting(db, "print_label_color") or "#333333",
            "print_accent_color": _setting(db, "print_accent_color") or "#1a56db",
            "theme_mode": _setting(db, "theme_mode") or "light",
            "backup_email": _setting(db, "backup_email"),
            "smtp_host": _setting(db, "smtp_host") or "smtp.gmail.com",
            "smtp_port": _setting(db, "smtp_port") or "587",
            "smtp_username": _setting(db, "smtp_username"),
            "smtp_security": _setting(db, "smtp_security") or "starttls",
            "amoot_line_number": _setting(db, "amoot_line_number"),
            "main_measurement_order": json.dumps([k for k,_ in _ordered_main_measurements(db)]),
            "measurement_layout": _setting(db, "measurement_layout") or "tiles",
            "main_measurement_labels": MAIN_MEASUREMENTS,
            "all_form_field_labels": _ordered_all_fields(db),
            "all_form_field_order": json.dumps([k for k, _ in _ordered_all_fields(db)]),
            "whatsapp_enabled": _setting(db, "whatsapp_enabled") == "1",
            "print_diagrams": {k: _setting(db, "print_diagram_" + k) for k in ("sleeve", "pocket", "pati", "trousers", "waist_slit")},
            "custom_messages": {k: _setting(db, "message_"+k) for k in ("welcome","ready","delivered","reminder","eid")},
        }
        option_rows = db.execute("SELECT * FROM dropdown_options ORDER BY field_key, option_value COLLATE NOCASE").fetchall()
        grouped_options = {key: [] for key, _ in OPTION_FIELDS}
        for option_row in option_rows: grouped_options[option_row["field_key"]].append(option_row)
        settings["option_fields"] = OPTION_FIELDS
        settings["grouped_options"] = grouped_options
    default_messages = {k: f"آقای {{نام}}، پیام مربوط به سفارش شما.\\nنام خیاطی: {{نام_خیاطی}}\\nکد مشتری: {{کد_مشتری}}\\nتلفن مغازه: {{تلفن}}\\nآدرس: {{آدرس}}\\nتاریخ سفارش: {{تاریخ}}" for k in ("welcome","ready","delivered","reminder","eid")}
    rendered = render_template("settings.html", **settings, default_messages=default_messages, smtp_password_set=SMTP_PASSWORD_PATH.exists(), amoot_token_set=AMOOT_TOKEN_PATH.exists())
    # افزودن چند تم آماده به همان بخش رنگ‌های تنظیمات؛ اسکریپت موجود صفحه با data-color آن‌ها را اعمال می‌کند.
    extra_palettes = [
        ("آبی آسمانی", "#e4f3ff"), ("سبز نعنایی", "#e1f5ec"),
        ("هلویی", "#fff0e5"), ("طلایی روشن", "#fff6d9"),
        ("بنفش ملایم", "#eee8ff"), ("مرجانی", "#ffe8e5"),
        ("سبز زیتونی", "#eef0df"), ("نقره‌ای", "#e9edf2"),
        ("آبی دریایی", "#e4f0f3"), ("صورتی چرک", "#f5e8ef")]
    extra_html = "".join(f'<button type="button" data-color="{color}" style="--swatch:{color}">{label}</button>' for label, color in extra_palettes)
    rendered = rendered.replace('<div class="color-presets">', '<div class="color-presets">' + extra_html, 1)
    return rendered


@app.route("/settings/business-identity", methods=["GET", "POST"])
def business_identity_settings():
    if request.method == "POST" and not session.get("identity_settings_unlocked"):
        if normalize_digits(request.form.get("identity_code", "")).strip() == "8910000912":
            session["identity_settings_unlocked"] = True
            return redirect(url_for("business_identity_settings"))
        flash("رمز نادرست است.", "error")
        return redirect(url_for("appearance_settings"))
    if not session.get("identity_settings_unlocked"):
        abort(404)
    if request.method == "POST":
        logo_file = request.files.get("business_logo")
        if logo_file and logo_file.filename:
            ext = Path(logo_file.filename).suffix.lower()
            if ext not in {".png", ".jpg", ".jpeg", ".webp"}:
                flash("لوگو باید PNG، JPG یا WEBP باشد.", "error")
                return redirect(url_for("business_identity_settings"))
            logo_name = "business_logo" + ext
            logo_file.save(UPLOAD_DIR / logo_name)
            with get_db() as db:
                _save_setting(db, "business_logo", logo_name)
                db.commit()
        values = {
            "business_name": request.form.get("business_name", "").strip(),
            "business_address": request.form.get("business_address", "").strip(),
            "business_phone1": normalize_digits(request.form.get("business_phone1", "")).strip(),
            "business_phone2": normalize_digits(request.form.get("business_phone2", "")).strip(),
        }
        if not values["business_name"] or not values["business_address"] or not values["business_phone1"]:
            flash("نام خیاطی، آدرس و تلفن اول الزامی است.", "error")
        else:
            with get_db() as db:
                for key, value in values.items(): _save_setting(db, key, value)
                db.commit()
            flash("مشخصات خیاطی به‌روزرسانی شد.", "success")
            return redirect(url_for("business_identity_settings"))
    with get_db() as db:
        values = {k: _setting(db, k) for k in ("business_name", "business_address", "business_phone1", "business_phone2")}
    return render_template("business_identity.html", **values)

@app.route("/exit", methods=["POST"])
def exit_app():
    global _HTTP_SERVER
    if not _local_request():
        abort(403)
    # بدون وابستگی به context processor / دیتابیس تا خطای داخلی ندهد
    html = """<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>خروج از برنامه</title>
<style>body{font-family:Tahoma;background:#f5eedf;display:grid;place-items:center;min-height:100vh;margin:0;color:#493b2e}
.box{background:#fffaf0;border:1px solid #e6d8bd;border-radius:22px;padding:35px;text-align:center;box-shadow:0 10px 35px #6d543018}
h1{font-size:24px}p{color:#766b5d;line-height:2}</style></head>
<body><div class="box"><div style="font-size:48px">✂️</div><h1>خاوران سافت</h1>
<p>برنامه با موفقیت متوقف شد.<br>می‌توانید این صفحه را ببندید.</p></div>
<script>
setTimeout(function(){
  try {
    if (window.KhavaranNative && window.KhavaranNative.exitApp) { window.KhavaranNative.exitApp(); return; }
    if (window.KhayatiAndroid && window.KhayatiAndroid.exitApp) { window.KhayatiAndroid.exitApp(); return; }
    window.close();
  } catch (e) { try { window.close(); } catch (e2) {} }
}, 900);
</script></body></html>"""
    response = make_response(html)
    response.headers["Content-Type"] = "text/html; charset=utf-8"

    def stop_server():
        try:
            if _HTTP_SERVER is not None:
                _HTTP_SERVER.shutdown()
                return
        except Exception:
            pass
        try:
            controller = sys.modules.get("server_control")
            if controller is not None:
                if hasattr(controller, "stop_server"):
                    controller.stop_server()
                elif hasattr(controller, "stop"):
                    controller.stop()
        except Exception:
            pass
        try:
            import main as main_mod
            if hasattr(main_mod, "stop_server"):
                main_mod.stop_server()
        except Exception:
            pass

    threading.Timer(0.7, stop_server).start()
    return response


@app.route("/connection")
def connection_info():
    ips = local_ipv4_addresses()
    port = None
    # پورت واقعی سرویس در حال اجرا
    try:
        if os.environ.get("KHAVARAN_ANDROID") == "1":
            from main import get_port
            port = get_port()
    except Exception:
        port = None
    if not port:
        try:
            port_file = APP_DIR / "server_port.txt"
            if port_file.exists():
                port = int(port_file.read_text(encoding="utf-8").strip())
        except Exception:
            port = None
    if not port:
        try:
            port = int(os.environ.get("PORT", "5000"))
        except Exception:
            port = 5000
    primary_ip = ips[0] if ips else None
    primary_url = f"http://{primary_ip}:{port}" if primary_ip else f"http://127.0.0.1:{port}"
    return render_template(
        "connection.html",
        ips=ips,
        port=port,
        primary_ip=primary_ip,
        primary_url=primary_url,
        is_android=os.environ.get("KHAVARAN_ANDROID") == "1",
    )


def load_mdb_config():
    if MDB_CONFIG.exists():
        try:
            return json.loads(MDB_CONFIG.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def save_mdb_config(config):
    MDB_CONFIG.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")


class AccessODBCAdapter:
    """خواندن MDB از طریق درایور رسمی Access در ویندوز، در صورت نصب بودن."""
    def __init__(self, path):
        import pyodbc
        drivers = [d for d in pyodbc.drivers() if "Access" in d and "*.mdb" in d]
        if not drivers:
            raise RuntimeError("درایور ODBC مایکروسافت اکسس نصب نیست")
        self.connection = pyodbc.connect(
            f"DRIVER={{{drivers[0]}}};DBQ={str(path)};ReadOnly=1;", timeout=8
        )
        self.catalog = {}
        cur = self.connection.cursor()
        for row in cur.tables(tableType="TABLE"):
            name = str(row.table_name)
            if not name.lower().startswith("msys"):
                self.catalog[name] = True

    def read_table(self, table_name):
        cur = self.connection.cursor()
        # نام جدول از فهرست خود دیتابیس انتخاب می‌شود؛ برای اطمینان کوتیشن می‌شود.
        safe_name = table_name.replace("]", "]]" )
        cur.execute(f"SELECT * FROM [{safe_name}]")
        columns = [d[0] for d in (cur.description or [])]
        rows = []
        for record in cur.fetchall():
            rows.append({col: _plain_value(val) for col, val in zip(columns, record)})
        return columns, rows


def access_parser_for_file(path):
    # ODBC درایور رسمی Access معمولاً با MDBهای قدیمی و ساختارهای متنوع سازگارتر است.
    try:
        return AccessODBCAdapter(path)
    except Exception:
        from access_parser import AccessParser
        return AccessParser(str(path))


def access_table_rows(parser, table_name):
    """نام ستون‌ها را حتی برای جدول خالی استخراج می‌کند و شکل‌های مختلف داده را می‌پذیرد."""
    if isinstance(parser, AccessODBCAdapter):
        return parser.read_table(table_name)
    table_object = None
    raw_data = None
    # نگه‌داشتن table_object مهم است: اگر parse باگ داشت، هنوز می‌توان metadata را خواند.
    try:
        table_object = parser.get_table(table_name)
    except Exception:
        table_object = None
    if table_object is not None:
        try:
            raw_data = table_object.parse()
        except Exception:
            raw_data = None
    if raw_data is None:
        try:
            raw_data = parser.parse_table(table_name)
        except Exception as exc:
            # برای جدول خراب، تلاش می‌کنیم دست‌کم نام ستون‌ها را از metadata برگردانیم.
            metadata_columns = []
            if table_object is not None:
                try:
                    metadata_columns = [str(col.col_name_str) for col in table_object.columns.values()]
                except Exception:
                    metadata_columns = []
            if metadata_columns:
                return metadata_columns, []
            raise RuntimeError(f"جدول «{table_name}» قابل خواندن نیست: {exc}") from exc

    columns = []
    if isinstance(raw_data, dict):
        columns = [str(k) for k in raw_data.keys()]
    if not columns and table_object is not None:
        try:
            columns = [str(col.col_name_str) for col in table_object.columns.values()]
        except Exception:
            columns = []

    rows = []
    if isinstance(raw_data, dict) and columns:
        series = []
        for col in columns:
            value = raw_data.get(col, [])
            if isinstance(value, (list, tuple)):
                series.append(list(value))
            elif value in (None, ""):
                series.append([])
            else:
                series.append([value])
        row_count = max((len(values) for values in series), default=0)
        for row_index in range(row_count):
            row = {}
            for col, values in zip(columns, series):
                value = values[row_index] if row_index < len(values) else ""
                if value is None:
                    value = ""
                elif isinstance(value, bytes):
                    try:
                        value = value.decode("utf-8").strip("\x00")
                    except UnicodeDecodeError:
                        value = value.hex()
                else:
                    value = str(value)
                row[col] = value.strip() if isinstance(value, str) else value
            rows.append(row)
    elif isinstance(raw_data, (list, tuple)):
        for item in raw_data:
            if isinstance(item, dict):
                if not columns:
                    columns = [str(k) for k in item.keys()]
                rows.append({str(k): str(v if v is not None else "") for k, v in item.items()})
    return columns, rows


def _plain_value(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8").strip("\x00").strip()
        except UnicodeDecodeError:
            return value.hex()
    text = str(value).strip()
    # برای ID عددی، مقدارهایی مثل 27.0 به 27 تبدیل شوند.
    if re.fullmatch(r"\d+\.0+", text):
        text = text.split(".", 1)[0]
    return text


def _read_mdb_state(config, selected_table=""):
    mdb_path = UPLOAD_DIR / config.get("filename", "") if config.get("filename") else None
    if not mdb_path or not mdb_path.exists():
        return [], [], [], None
    parser = access_parser_for_file(mdb_path)
    catalog = getattr(parser, "catalog", {})
    if isinstance(catalog, dict):
        tables = [str(name) for name in catalog.keys()]
    elif isinstance(catalog, (list, tuple, set)):
        tables = [str(name) for name in catalog]
    else:
        tables = []
    tables = sorted([name for name in tables if not name.lower().startswith("msys")], key=str.casefold)
    columns, preview = [], []
    if selected_table and selected_table in tables:
        columns, rows = access_table_rows(parser, selected_table)
        preview = rows[:3]
    return tables, columns, preview, parser


@app.route("/mdb", methods=["GET", "POST"])
def mdb_mapping():
    config = load_mdb_config()
    selected_table = config.get("table", "")
    try:
        if request.method == "POST":
            action = request.form.get("action", "")
            if action == "upload":
                uploaded = request.files.get("mdb_file")
                if not uploaded or not uploaded.filename.lower().endswith((".mdb", ".accdb")):
                    flash("لطفاً یک فایل MDB یا ACCDB انتخاب کنید.", "error")
                else:
                    filename = secure_filename(uploaded.filename)
                    if not filename:
                        flash("نام فایل معتبر نیست.", "error")
                    else:
                        uploaded.save(UPLOAD_DIR / filename)
                        config = {"filename": filename, "table": "", "mapping": {}}
                        save_mdb_config(config)
                        flash("فایل بارگذاری شد. حالا جدول را انتخاب کنید.", "success")
                return redirect(url_for("mdb_mapping"))

            if action == "select_table":
                selected_table = request.form.get("table", "").strip()
                config["table"] = selected_table
                save_mdb_config(config)
                return redirect(url_for("mdb_mapping"))

        tables, columns, preview, parser = _read_mdb_state(config, selected_table)

        if request.method == "POST" and request.form.get("action") == "save_mapping":
            selected_table = request.form.get("table", selected_table).strip()
            # ستون‌ها مجدداً از خود جدول خوانده می‌شوند تا انتخاب نامعتبر ذخیره نشود.
            tables, columns, preview, parser = _read_mdb_state(config, selected_table)
            if not columns:
                flash("از جدول انتخاب‌شده ستونی استخراج نشد. لطفاً جدول دیگری را امتحان کنید.", "error")
            else:
                config["table"] = selected_table
                config["mapping"] = {key: request.form.get("map_" + key, "") for key, _ in MDB_FIELDS}
                save_mdb_config(config)
                flash("اتصال ستون‌ها ذخیره شد.", "success")
                return redirect(url_for("mdb_mapping"))

        if request.method == "POST" and request.form.get("action") == "import":
            selected_table = request.form.get("table", selected_table).strip()
            tables, columns, preview, parser = _read_mdb_state(config, selected_table)
            mapping = config.get("mapping", {})
            if not mapping.get("customer_code") or not mapping.get("name"):
                flash("ابتدا اتصال ID و نام مشتری را ذخیره کنید.", "error")
            elif not columns:
                flash("ستون‌های جدول شناسایی نشدند؛ انتقال انجام نشد.", "error")
            else:
                source_columns, all_rows = access_table_rows(parser, selected_table)
                # قبل از شروع، مطمئن شویم ستون‌های انتخاب‌شده هنوز در جدول وجود دارند.
                missing_mappings = [
                    label for key, label in MDB_FIELDS
                    if mapping.get(key) and mapping.get(key) not in source_columns
                ]
                if missing_mappings:
                    flash("ستون‌های انتخاب‌شده در جدول فعلی پیدا نشدند: " + "، ".join(missing_mappings) + "؛ اتصال ستون‌ها را دوباره ذخیره کنید.", "error")
                    return redirect(url_for("mdb_mapping"))
                if not all_rows:
                    flash(f"جدول «{selected_table}» باز شد، اما هیچ رکوردی از آن خوانده نشد. احتمالاً جدول اشتباه انتخاب شده یا درایور Access نتوانسته رکوردها را بخواند. جدول و پیش‌نمایش را بررسی کنید.", "error")
                    return redirect(url_for("mdb_mapping"))
                total_rows = len(all_rows)
                imported = skipped = 0
                limit_reached = False
                with get_db() as db:
                    registered_for_import = _setting(db, "registration_completed") == "1"
                    for source in all_rows:
                        code = _plain_value(source.get(mapping.get("customer_code", ""), ""))
                        name = _plain_value(source.get(mapping.get("name", ""), ""))
                        if not code or not name:
                            skipped += 1
                            continue
                        mobile = _plain_value(source.get(mapping.get("mobile", ""), "")) if mapping.get("mobile") else ""
                        field_values = {}
                        for key, _ in PROFILE_FIELDS:
                            col = mapping.get(key, "")
                            if col:
                                field_values[key] = _plain_value(source.get(col, ""))
                        if not field_values.get("order_date"):
                            field_values["order_date"] = today_jalali()
                        existing = db.execute("SELECT id FROM customers WHERE customer_code=?", (code,)).fetchone()
                        if not existing and not registered_for_import and customer_count(db) >= 5:
                            skipped += 1
                            limit_reached = True
                            continue
                        if existing:
                            cid = existing["id"]
                            updates = {"name": name, "mobile": mobile, **field_values}
                            assignment = ",".join(f'"{key}"=?' for key in updates)
                            db.execute(f"UPDATE customers SET {assignment} WHERE id=?",
                                       list(updates.values()) + [cid])
                        else:
                            insert_values = {"customer_code": code, "name": name, "mobile": mobile, **field_values}
                            # تمام ستون‌های پروفایل را وارد می‌کنیم؛ ستون‌های بدون اتصال خالی می‌مانند.
                            for key, _ in PROFILE_FIELDS:
                                insert_values.setdefault(key, "")
                            insert_keys = list(insert_values.keys())
                            quoted = ",".join(f'"{k}"' for k in insert_keys)
                            marks = ",".join("?" for _ in insert_keys)
                            db.execute(f"INSERT INTO customers({quoted}) VALUES ({marks})",
                                       [insert_values[k] for k in insert_keys])
                            cid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
                        # اطلاعات مالی MDB به آخرین سفارش مشتری متصل می‌شود؛ اگر سفارشی ندارد، یک سفارش می‌سازیم.
                        finance_values = {
                            key: (_plain_value(source.get(mapping.get(key, ""), "")) if mapping.get(key) else "")
                            for key in ("total_amount", "deposit_amount", "remaining_amount")
                        }
                        if any(finance_values.values()):
                            last_job = db.execute("SELECT id FROM daily_jobs WHERE customer_id=? ORDER BY id DESC LIMIT 1", (cid,)).fetchone()
                            if last_job:
                                db.execute("UPDATE daily_jobs SET total_amount=?, deposit_amount=?, remaining_amount=? WHERE id=?",
                                           (finance_values["total_amount"], finance_values["deposit_amount"], finance_values["remaining_amount"], last_job["id"]))
                            else:
                                create_daily_job(db, cid, field_values.get("fabric_meter", ""), field_values.get("order_quantity", ""))
                                new_job = db.execute("SELECT id FROM daily_jobs WHERE customer_id=? ORDER BY id DESC LIMIT 1", (cid,)).fetchone()
                                db.execute("UPDATE daily_jobs SET total_amount=?, deposit_amount=?, remaining_amount=? WHERE id=?",
                                           (finance_values["total_amount"], finance_values["deposit_amount"], finance_values["remaining_amount"], new_job["id"]))
                        imported += 1
                    db.commit()
                if limit_reached:
                    flash(f"انتقال از {total_rows} ردیف خوانده‌شده متوقف شد: {imported} مشتری ثبت/به‌روزرسانی شد و {skipped} ردیف رد شد؛ برای ادامه، کد رجیستر لازم است.", "warning")
                elif imported == 0:
                    flash(f"از جدول {total_rows} ردیف خوانده شد، اما هیچ مشتری ثبت نشد. {skipped} ردیف به دلیل خالی بودن کد مشتری یا نام رد شد. اتصال ستون‌های ID و نام را بررسی و دوباره ذخیره کنید.", "error")
                else:
                    flash(f"انتقال تمام شد: از {total_rows} ردیف، {imported} مشتری ثبت/به‌روزرسانی و {skipped} ردیف رد شد.", "success")
                # در صفحه MDB می‌مانیم تا نتیجه دقیق انتقال و امکان اصلاح اتصال ستون‌ها دیده شود.
                return redirect(url_for("mdb_mapping"))

    except ModuleNotFoundError:
        flash("کتابخانه access-parser نصب نشده است. run_app.bat را اجرا کنید تا وابستگی‌ها نصب شوند.", "error")
        tables, columns, preview = [], [], []
    except sqlite3.IntegrityError:
        flash("کد مشتری تکراری است یا با یک شناسه موجود تعارض دارد. مقدار ID در MDB را بررسی کنید.", "error")
        try:
            tables, columns, preview, _ = _read_mdb_state(config, selected_table)
        except Exception:
            tables, columns, preview = [], [], []
    except Exception as exc:
        # خطای خواندن یک جدول نباید کل صفحه و فهرست جدول‌ها را از دسترس خارج کند.
        flash(f"خواندن جدول MDB با خطا روبه‌رو شد: {exc}. اگر درایور Access نصب نیست، Microsoft Access Database Engine را نصب کنید.", "error")
        tables, columns, preview = [], [], []
        try:
            safe_config = dict(config)
            safe_config["table"] = ""
            tables, _, _, _ = _read_mdb_state(safe_config, "")
        except Exception:
            pass

    return render_template("mdb.html", config=config, tables=tables,
                           selected_table=selected_table, columns=columns,
                           preview=preview, mapping=config.get("mapping", {}),
                           fields=MDB_FIELDS)


@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_file(UPLOAD_DIR / secure_filename(filename))


def _windows_removable_drives():
    if os.name != "nt": return []
    import ctypes
    drives=[]
    for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        root_path=f"{letter}:\\"
        if os.path.exists(root_path) and ctypes.windll.kernel32.GetDriveTypeW(root_path) == 2:
            drives.append({"path": f"{letter}:\\", "label": f"درایو {letter}:"})
    return drives


@app.post("/backup-to-usb")
def backup_to_usb():
    if not DB_PATH.exists():
        flash("پایگاه داده‌ای برای پشتیبان‌گیری وجود ندارد.", "error")
        return redirect(url_for("backup_info"))
    selected = request.form.get("usb_drive", "")
    allowed = {d["path"] for d in _windows_removable_drives()}
    if selected not in allowed or not os.path.isdir(selected):
        flash("فلش USB شناسایی نشد؛ آن را وصل کنید و دوباره صفحه را باز کنید.", "error")
        return redirect(url_for("backup_info"))
    folder = Path(selected) / "Khavaran"
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"khayati_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    source = sqlite3.connect(str(DB_PATH)); dest = sqlite3.connect(str(target))
    try: source.backup(dest)
    finally: dest.close(); source.close()
    flash(f"پشتیبان با موفقیت در فلش ذخیره شد: {target}", "success")
    return redirect(url_for("backup_info"))


@app.route("/backup")
def backup_info():
    with get_db() as db:
        backup_email = _setting(db, "backup_email")
    is_android = os.environ.get("KHAVARAN_ANDROID") == "1"
    return render_template(
        "backup.html",
        db_exists=DB_PATH.exists(),
        db_name=DB_PATH.name,
        backup_email=backup_email,
        usb_drives=[] if is_android else _windows_removable_drives(),
        is_android=is_android,
    )


@app.route("/email-backup", methods=["POST"])
def email_backup():
    """ساخت snapshot سازگار SQLite و ارسال آن به ایمیل پشتیبان از طریق SMTP."""
    with get_db() as db:
        cfg = {
            "recipient": _setting(db, "backup_email"),
            "host": _setting(db, "smtp_host") or "smtp.gmail.com",
            "port": _setting(db, "smtp_port") or "587",
            "username": _setting(db, "smtp_username"),
            "security": _setting(db, "smtp_security") or "starttls",
        }
    if not DB_PATH.exists():
        flash("فایل دیتابیس برای پشتیبان‌گیری وجود ندارد.", "error")
        return redirect(url_for("backup_info"))
    if not cfg["recipient"] or not cfg["username"] or not SMTP_PASSWORD_PATH.exists():
        flash("ابتدا ایمیل مقصد، ایمیل فرستنده و رمز اختصاصی SMTP را در صفحه تنظیمات ثبت کنید.", "error")
        return redirect(url_for("backup_info"))
    temp_backup = APP_DIR / ("email_backup_" + secrets.token_hex(8) + ".db")
    try:
        # از SQLite backup API استفاده می‌کنیم تا هنگام بازبودن برنامه نیز snapshot سالم ساخته شود.
        source_db = sqlite3.connect(str(DB_PATH), timeout=20)
        target_db = sqlite3.connect(str(temp_backup))
        try:
            source_db.backup(target_db)
        finally:
            target_db.close()
            source_db.close()
        password = SMTP_PASSWORD_PATH.read_text(encoding="utf-8")
        message = EmailMessage()
        message["Subject"] = f"نسخه پشتیبان خاوران سافت - {today_jalali()}"
        message["From"] = cfg["username"]
        message["To"] = cfg["recipient"]
        message.set_content(
            "سلام،\n\nفایل نسخه پشتیبان پایگاه داده خاوران سافت به این ایمیل پیوست شده است.\n"
            f"زمان تهیه: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            "لطفاً این فایل را در محل امن نگهداری کنید."
        )
        message.add_attachment(temp_backup.read_bytes(), maintype="application", subtype="octet-stream",
                               filename=f"khavaran_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db")
        port = int(cfg["port"])
        context = ssl.create_default_context()
        if cfg["security"] == "ssl":
            mail_server = smtplib.SMTP_SSL(cfg["host"], port, timeout=30, context=context)
        else:
            mail_server = smtplib.SMTP(cfg["host"], port, timeout=30)
        with mail_server as server:
            if cfg["security"] != "ssl":
                server.ehlo()
                server.starttls(context=context)
                server.ehlo()
            server.login(cfg["username"], password)
            server.send_message(message)
        flash("نسخه پشتیبان با موفقیت به ایمیل ثبت‌شده ارسال شد.", "success")
    except Exception as exc:
        # جزئیات فنی مفید است، اما هیچ‌گاه رمز SMTP در پیام خطا نمایش داده نمی‌شود.
        flash("ارسال ایمیل انجام نشد. تنظیمات SMTP، رمز اختصاصی و اتصال اینترنت را بررسی کنید. "
              f"جزئیات: {type(exc).__name__}: {exc}", "error")
    finally:
        temp_backup.unlink(missing_ok=True)
    return redirect(url_for("backup_info"))



@app.get("/backup/prepare-whatsapp")
def prepare_whatsapp_backup():
    """Snapshot دیتابیس برای اشتراک از اندروید."""
    if not DB_PATH.exists():
        return {"ok": False, "error": "no db"}, 404
    dest = APP_DIR / "share_ready.db"
    try:
        src = sqlite3.connect(str(DB_PATH))
        dst = sqlite3.connect(str(dest))
        try:
            src.backup(dst)
            dst.commit()
        finally:
            dst.close()
            src.close()
        marker = APP_DIR / "db_path.txt"
        marker.write_text(str(dest), encoding="utf-8")
        return {"ok": True, "path": str(dest), "size": dest.stat().st_size}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}, 500


@app.route("/download-backup")
def download_backup():
    if not DB_PATH.exists():
        flash("هنوز پایگاه داده‌ای ایجاد نشده است.", "error")
        return redirect(url_for("backup_info"))
    # snapshot سازگار تا دانلود فایل قفل‌شده را خراب نکند
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    temp_copy = APP_DIR / f"khayati_backup_{stamp}.db"
    source = sqlite3.connect(str(DB_PATH))
    dest = sqlite3.connect(str(temp_copy))
    try:
        source.backup(dest)
    finally:
        dest.close()
        source.close()
    return send_file(
        temp_copy,
        as_attachment=True,
        download_name=f"khayati_backup_{stamp}.db",
        mimetype="application/octet-stream",
    )


def _sqlite_snapshot(src_path, dest_path):
    """ساخت snapshot امن SQLite بدون shutil.copy2 (مناسب اندروید و فایل قفل‌شده)."""
    dest_path = Path(dest_path)
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    # اگر فایل مقصد از قبل نیمه‌کاره باشد پاک شود
    try:
        if dest_path.exists():
            dest_path.unlink()
    except Exception:
        pass
    source = sqlite3.connect(str(src_path), timeout=30)
    dest = sqlite3.connect(str(dest_path), timeout=30)
    try:
        source.execute("PRAGMA busy_timeout = 30000")
        dest.execute("PRAGMA busy_timeout = 30000")
        source.backup(dest)
        dest.commit()
    finally:
        try:
            dest.close()
        except Exception:
            pass
        try:
            source.close()
        except Exception:
            pass
    return dest_path


@app.route("/upload-database", methods=["POST"])
def upload_database():
    uploaded = request.files.get("database_file")
    if not uploaded or not uploaded.filename:
        flash("فایل پایگاه داده را انتخاب کنید.", "error")
        return redirect(url_for("backup_info"))
    filename = secure_filename(uploaded.filename) or "upload.db"
    suffix = Path(filename).suffix.lower()
    if suffix not in {".db", ".sqlite", ".sqlite3"}:
        # بعضی گوشی‌ها پسوند را نگه نمی‌دارند
        suffix = ".db"
    # در اندروید گاهی نوشتن کنار فایل اصلی مشکل دارد؛ از پوشه موقت برنامه استفاده می‌کنیم
    work_dir = APP_DIR / "restore_tmp"
    try:
        work_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        work_dir = APP_DIR
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    temp_path = work_dir / f"upload_{secrets.token_hex(6)}{suffix}"
    backup_path = work_dir / f"before_upload_{stamp}.db"
    staged_path = work_dir / f"staged_{stamp}.db"
    try:
        uploaded.save(str(temp_path))
        if not temp_path.exists() or temp_path.stat().st_size < 64:
            raise ValueError("فایل انتخاب‌شده خالی یا ناقص است.")

        # اعتبارسنجی فایل آپلودی
        check_db = sqlite3.connect(f"file:{temp_path.as_posix()}?mode=ro", uri=True, timeout=30)
        try:
            integrity = check_db.execute("PRAGMA integrity_check").fetchone()[0]
            tables = {r[0] for r in check_db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        finally:
            check_db.close()
        if integrity != "ok" or "customers" not in tables:
            raise ValueError("فایل انتخاب‌شده یک پایگاه داده معتبر برنامه خیاطی نیست.")

        # پشتیبان از دیتابیس فعلی (اختیاری؛ اگر شکست بخورد ادامه می‌دهیم)
        backup_ok = False
        if DB_PATH.exists():
            try:
                _sqlite_snapshot(DB_PATH, backup_path)
                backup_ok = True
            except Exception:
                # تلاش دوم با خواندن باینری
                try:
                    with open(DB_PATH, "rb") as src, open(backup_path, "wb") as dst:
                        dst.write(src.read())
                    backup_ok = True
                except Exception:
                    backup_ok = False

        # محتوای معتبر را به فایل staged منتقل کن، سپس روی DB_PATH بنویس
        _sqlite_snapshot(temp_path, staged_path)

        import time
        replace_error = None
        for attempt in range(10):
            try:
                # ابتدا سعی می‌کنیم با snapshot مستقیم روی DB_PATH بنویسیم
                # (روی اندروید امن‌تر از os.replace روی فایل باز است)
                if DB_PATH.exists():
                    # فایل فعلی را با محتوای جدید بازنویسی کن
                    live = sqlite3.connect(str(DB_PATH), timeout=30)
                    staged = sqlite3.connect(str(staged_path), timeout=30)
                    try:
                        live.execute("PRAGMA busy_timeout = 30000")
                        # پاک‌سازی اشیای فعلی و جایگزینی از staged
                        staged.backup(live)
                        live.commit()
                    finally:
                        staged.close()
                        live.close()
                else:
                    _sqlite_snapshot(staged_path, DB_PATH)
                replace_error = None
                break
            except Exception as exc:
                replace_error = exc
                time.sleep(0.25 * (attempt + 1))

        if replace_error is not None:
            # آخرین تلاش: os.replace
            try:
                os.replace(str(staged_path), str(DB_PATH))
                replace_error = None
            except Exception as exc:
                replace_error = exc

        if replace_error is not None:
            raise PermissionError(
                "جایگزینی پایگاه داده ممکن نشد. برنامه را کامل ببندید و دوباره باز کنید، سپس بازیابی را تکرار کنید. "
                f"جزئیات: {replace_error}"
            )

        init_db()
        session.clear()
        if backup_ok:
            flash("پایگاه داده با موفقیت جایگزین شد. از دیتابیس قبلی نسخه پشتیبان خودکار گرفته شد؛ دوباره وارد شوید.", "success")
        else:
            flash("پایگاه داده با موفقیت جایگزین شد. (پشتیبان خودکار از فایل قبلی ساخته نشد) دوباره وارد شوید.", "success")
    except Exception as exc:
        flash(f"بارگذاری پایگاه داده انجام نشد: {exc}", "error")
    finally:
        for path in (temp_path, staged_path):
            try:
                if path.exists():
                    path.unlink()
            except Exception:
                pass
    return redirect(url_for("backup_info"))


@app.context_processor
def inject_helpers():
    brand = "خیاطی"
    address = ""
    phone1 = ""
    phone2 = ""
    theme_bg_color = "#f4eddc"
    theme_mode = "light"
    registration_locked = False
    registration_pending = False
    try:
        with get_db() as db:
            brand = _setting(db, "business_name") or "خیاطی"
            registered = _setting(db, "registration_completed") == "1"
            has_business = bool(_setting(db, "business_name"))
            address = _setting(db, "business_address")
            phone1 = _setting(db, "business_phone1")
            phone2 = _setting(db, "business_phone2")
            theme_bg_color = _setting(db, "theme_color") or "#f4eddc"
            theme_mode = _setting(db, "theme_mode") or "light"
            if theme_mode not in {"light", "dark", "black"}:
                theme_mode = "light"
            if not re.fullmatch(r"#[0-9a-fA-F]{6}", theme_bg_color):
                theme_bg_color = "#f4eddc"
            trial = get_trial_info(db)
            registration_locked = (not has_business) or trial["locked"]
            registration_pending = has_business and not registered
    except Exception:
        # در خروج/خاموشی سرور نباید کل صفحه 500 شود
        pass
    return {
        "display_customer_code": display_customer_code,
        "installation_id": INSTALLATION_ID,
        "theme_bg_color": theme_bg_color,
        "theme_mode": theme_mode,
        "business_name": brand,
        "business_address": address,
        "business_phone1": phone1,
        "business_phone2": phone2,
        "registration_locked": registration_locked,
        "registration_pending": registration_pending,
        "is_local_host": _local_request(),
    }


init_db()


def _open_browser_when_ready():
    webbrowser.open("http://localhost:5000", new=2)


if __name__ == "__main__":
    _PORT = int(os.environ.get("PORT", "5000"))
    _HOST = os.environ.get("HOST", "0.0.0.0")
    print("\nخاوران سافت در حال اجراست.")
    print(f"نشانی برنامه: http://127.0.0.1:{_PORT}")
    if os.name == "nt" and os.environ.get("KHAVARAN_NO_BROWSER") != "1":
        print("برای خروج کامل، از منوی برنامه گزینه «خروج کامل از برنامه» را بزنید.\n")
        threading.Timer(1.2, _open_browser_when_ready).start()
    _HTTP_SERVER = make_server(_HOST, _PORT, app, threaded=True)
    try:
        _HTTP_SERVER.serve_forever()
    finally:
        _HTTP_SERVER.server_close()
