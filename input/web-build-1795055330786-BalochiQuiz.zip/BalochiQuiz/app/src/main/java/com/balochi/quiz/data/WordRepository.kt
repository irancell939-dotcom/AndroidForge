package com.balochi.quiz.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class WordRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("balochi_words_v2", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val key = "words_list"
    private val progressKey = "user_progress"

    fun getAllWords(): List<BalochiWord> {
        val json = prefs.getString(key, null)
        if (json.isNullOrBlank()) {
            val seed = loadSeedWords()
            saveWords(seed)
            return seed
        }
        return try {
            val type = object : TypeToken<List<BalochiWord>>() {}.type
            gson.fromJson<List<BalochiWord>>(json, type) ?: loadSeedWords()
        } catch (e: Exception) {
            loadSeedWords()
        }
    }

    fun saveWords(words: List<BalochiWord>) {
        prefs.edit().putString(key, gson.toJson(words)).apply()
    }

    fun addWord(word: BalochiWord) {
        val current = getAllWords().toMutableList()
        current.add(0, word)
        saveWords(current)
    }

    fun updateWord(word: BalochiWord) {
        val current = getAllWords().toMutableList()
        val index = current.indexOfFirst { it.id == word.id }
        if (index >= 0) {
            current[index] = word
            saveWords(current)
        }
    }

    fun deleteWord(id: String) {
        val current = getAllWords().toMutableList()
        current.removeAll { it.id == id }
        saveWords(current)
    }

    fun recordAnswer(wordId: String, isCorrect: Boolean) {
        val current = getAllWords().toMutableList()
        val index = current.indexOfFirst { it.id == wordId }
        if (index >= 0) {
            val w = current[index]
            current[index] = w.copy(
                correctCount = w.correctCount + if (isCorrect) 1 else 0,
                wrongCount = w.wrongCount + if (isCorrect) 0 else 1,
                lastSeen = System.currentTimeMillis()
            )
            saveWords(current)
        }
    }

    data class UserProgress(
        val totalQuizzes: Int = 0,
        val totalCorrect: Int = 0,
        val totalAnswered: Int = 0,
        val level: Int = 1
    )

    fun getProgress(): UserProgress {
        val json = prefs.getString(progressKey, null) ?: return UserProgress()
        return try {
            gson.fromJson(json, UserProgress::class.java) ?: UserProgress()
        } catch (e: Exception) {
            UserProgress()
        }
    }

    fun updateProgress(correct: Int, answered: Int) {
        val p = getProgress()
        val newTotalCorrect = p.totalCorrect + correct
        val newTotalAnswered = p.totalAnswered + answered
        val newQuizzes = p.totalQuizzes + 1
        val level = when {
            newTotalCorrect >= 500 -> 5
            newTotalCorrect >= 250 -> 4
            newTotalCorrect >= 100 -> 3
            newTotalCorrect >= 40 -> 2
            else -> 1
        }
        val updated = UserProgress(newQuizzes, newTotalCorrect, newTotalAnswered, level)
        prefs.edit().putString(progressKey, gson.toJson(updated)).apply()
    }

    private fun loadSeedWords(): List<BalochiWord> {
        try {
            val input = context.assets.open("words.json")
            val json = input.bufferedReader().use { it.readText() }
            val type = object : TypeToken<List<BalochiWord>>() {}.type
            val list = gson.fromJson<List<BalochiWord>>(json, type)
            if (!list.isNullOrEmpty()) return list
        } catch (_: Exception) { }
        return defaultSeed()
    }

    private fun defaultSeed(): List<BalochiWord> = listOf(
        w("Water", "آب", "ماء", "پانی"),
        w("Bread", "نان", "خبز", "روٹی"),
        w("House", "خانه", "منزل", "گھر"),
        w("Friend", "دوست", "صديق", "دوست"),
        w("Book", "کتاب", "كتاب", "کتاب"),
        w("Sun", "خورشید", "شمس", "سورج"),
        w("Moon", "ماه", "قمر", "چاند"),
        w("Sea", "دریا", "بحر", "سمندر"),
        w("Tree", "درخت", "شجرة", "درخت"),
        w("Flower", "گل", "زهرة", "پھول"),
        w("Mother", "مادر", "أم", "ماں"),
        w("Father", "پدر", "أب", "باپ"),
        w("Child", "کودک", "طفل", "بچہ"),
        w("Man", "مرد", "رجل", "آدمی"),
        w("Woman", "زن", "امرأة", "عورت"),
        w("Day", "روز", "يوم", "دن"),
        w("Night", "شب", "ليل", "رات"),
        w("Food", "غذا", "طعام", "کھانا"),
        w("Milk", "شیر", "حليب", "دودھ"),
        w("Fire", "آتش", "نار", "آگ"),
        w("Earth", "زمین", "أرض", "زمین"),
        w("Sky", "آسمان", "سماء", "آسمان"),
        w("Rain", "باران", "مطر", "بارش"),
        w("Wind", "باد", "ريح", "ہوا"),
        w("Mountain", "کوه", "جبل", "پہاڑ"),
        w("River", "رودخانه", "نهر", "دریا"),
        w("City", "شهر", "مدينة", "شہر"),
        w("Village", "روستا", "قرية", "گاؤں"),
        w("Road", "جاده", "طريق", "سڑک"),
        w("Car", "ماشین", "سيارة", "گاڑی"),
        w("Door", "در", "باب", "دروازہ"),
        w("Window", "پنجره", "نافذة", "کھڑکی"),
        w("Table", "میز", "طاولة", "میز"),
        w("Chair", "صندلی", "كرسي", "کرسی"),
        w("Hand", "دست", "يد", "ہاتھ"),
        w("Eye", "چشم", "عين", "آنکھ"),
        w("Head", "سر", "رأس", "سر"),
        w("Heart", "قلب", "قلب", "دل"),
        w("Love", "عشق", "حب", "محبت"),
        w("Peace", "صلح", "سلام", "امن"),
        w("War", "جنگ", "حرب", "جنگ"),
        w("Life", "زندگی", "حياة", "زندگی"),
        w("Death", "مرگ", "موت", "موت"),
        w("Time", "زمان", "وقت", "وقت"),
        w("Year", "سال", "سنة", "سال"),
        w("Month", "ماه", "شهر", "مہینہ"),
        w("Week", "هفته", "أسبوع", "ہفتہ"),
        w("Today", "امروز", "اليوم", "آج"),
        w("Tomorrow", "فردا", "غدا", "کل"),
        w("Yesterday", "دیروز", "أمس", "کل"),
        w("Good", "خوب", "جيد", "اچھا"),
        w("Bad", "بد", "سيء", "برا"),
        w("Big", "بزرگ", "كبير", "بڑا"),
        w("Small", "کوچک", "صغير", "چھوٹا"),
        w("New", "جدید", "جديد", "نیا"),
        w("Old", "قدیمی", "قديم", "پرانا"),
        w("Hot", "داغ", "حار", "گرم"),
        w("Cold", "سرد", "بارد", "ٹھنڈا"),
        w("Happy", "خوشحال", "سعيد", "خوش"),
        w("Sad", "غمگین", "حزين", "اداس"),
        w("Beautiful", "زیبا", "جميل", "خوبصورت"),
        w("Strong", "قوی", "قوي", "مضبوط"),
        w("Weak", "ضعیف", "ضعيف", "کمزور"),
        w("Rich", "ثروتمند", "غني", "امیر"),
        w("Poor", "فقیر", "فقير", "غریب"),
        w("Work", "کار", "عمل", "کام"),
        w("School", "مدرسه", "مدرسة", "اسکول"),
        w("Teacher", "معلم", "معلم", "استاد"),
        w("Student", "دانش‌آموز", "طالب", "طالب علم"),
        w("Doctor", "پزشک", "طبيب", "ڈاکٹر"),
        w("Hospital", "بیمارستان", "مستشفى", "ہسپتال"),
        w("Money", "پول", "مال", "پیسہ"),
        w("Market", "بازار", "سوق", "بازار"),
        w("Shop", "فروشگاه", "دكان", "دکان"),
        w("Price", "قیمت", "سعر", "قیمت"),
        w("Name", "نام", "اسم", "نام"),
        w("Family", "خانواده", "عائلة", "خاندان"),
        w("Brother", "برادر", "أخ", "بھائی"),
        w("Sister", "خواهر", "أخت", "بہن"),
        w("Son", "پسر", "ابن", "بیٹا"),
        w("Daughter", "دختر", "ابنة", "بیٹی"),
        w("God", "خدا", "الله", "خدا"),
        w("Prayer", "نماز", "صلاة", "نماز"),
        w("Faith", "ایمان", "إيمان", "ایمان"),
        w("Hope", "امید", "أمل", "امید"),
        w("Fear", "ترس", "خوف", "ڈر"),
        w("Dream", "رویا", "حلم", "خواب"),
        w("Truth", "حقیقت", "حقيقة", "سچ"),
        w("Lie", "دروغ", "كذب", "جھوٹ"),
        w("Help", "کمک", "مساعدة", "مدد"),
        w("Problem", "مشکل", "مشكلة", "مسئلہ"),
        w("Answer", "جواب", "جواب", "جواب"),
        w("Question", "سؤال", "سؤال", "سوال"),
        w("Language", "زبان", "لغة", "زبان"),
        w("Word", "کلمه", "كلمة", "لفظ"),
        w("Story", "داستان", "قصة", "کہانی"),
        w("Music", "موسیقی", "موسيقى", "موسیقی"),
        w("Song", "آهنگ", "أغنية", "گانا"),
        w("Color", "رنگ", "لون", "رنگ"),
        w("Red", "قرمز", "أحمر", "سرخ"),
        w("Blue", "آبی", "أزرق", "نیلا"),
        w("Green", "سبز", "أخضر", "سبز"),
        w("White", "سفید", "أبيض", "سفید"),
        w("Black", "سیاه", "أسود", "کالا"),
        w("Yellow", "زرد", "أصفر", "پیلا"),
        w("Number", "عدد", "رقم", "نمبر"),
        w("One", "یک", "واحد", "ایک"),
        w("Two", "دو", "اثنان", "دو"),
        w("Three", "سه", "ثلاثة", "تین"),
        w("Four", "چهار", "أربعة", "چار"),
        w("Five", "پنج", "خمسة", "پانچ"),
        w("Ten", "ده", "عشرة", "دس"),
        w("Hundred", "صد", "مائة", "سو"),
        w("Thousand", "هزار", "ألف", "ہزار"),
        w("Yes", "بله", "نعم", "ہاں"),
        w("No", "نه", "لا", "نہیں"),
        w("Please", "لطفاً", "من فضلك", "براہ کرم"),
        w("Thank you", "متشکرم", "شكرا", "شکریہ"),
        w("Sorry", "ببخشید", "آسف", "معاف کرنا"),
        w("Hello", "سلام", "مرحبا", "سلام"),
        w("Goodbye", "خداحافظ", "وداعا", "الوداع"),
        w("Welcome", "خوش آمدید", "أهلا", "خوش آمدید"),
        w("I", "من", "أنا", "میں"),
        w("You", "تو / شما", "أنت", "تم"),
        w("He", "او", "هو", "وہ"),
        w("She", "او", "هي", "وہ"),
        w("We", "ما", "نحن", "ہم"),
        w("They", "آنها", "هم", "وہ"),
        w("This", "این", "هذا", "یہ"),
        w("That", "آن", "ذلك", "وہ"),
        w("What", "چه", "ماذا", "کیا"),
        w("Where", "کجا", "أين", "کہاں"),
        w("When", "کی", "متى", "کب"),
        w("Why", "چرا", "لماذا", "کیوں"),
        w("How", "چگونه", "كيف", "کیسے"),
        w("Who", "کی", "من", "کون"),
        w("Come", "آمدن", "تعال", "آنا"),
        w("Go", "رفتن", "اذهب", "جانا"),
        w("See", "دیدن", "انظر", "دیکھنا"),
        w("Hear", "شنیدن", "اسمع", "سننا"),
        w("Speak", "صحبت کردن", "تكلم", "بولنا"),
        w("Eat", "خوردن", "كل", "کھانا"),
        w("Drink", "نوشیدن", "اشرب", "پینا"),
        w("Sleep", "خوابیدن", "نم", "سونا"),
        w("Walk", "راه رفتن", "امش", "چلنا"),
        w("Run", "دویدن", "اركض", "دوڑنا"),
        w("Read", "خواندن", "اقرأ", "پڑھنا"),
        w("Write", "نوشتن", "اكتب", "لکھنا"),
        w("Know", "دانستن", "اعرف", "جاننا"),
        w("Think", "فکر کردن", "فكر", "سوچنا"),
        w("Want", "خواستن", "أريد", "چاہنا"),
        w("Need", "نیاز داشتن", "أحتاج", "ضرورت"),
        w("Like", "دوست داشتن", "أحب", "پسند"),
        w("Give", "دادن", "اعط", "دینا"),
        w("Take", "گرفتن", "خذ", "لینا"),
        w("Buy", "خریدن", "اشتر", "خریدنا"),
        w("Sell", "فروختن", "بع", "بیچنا"),
        w("Open", "باز کردن", "افتح", "کھولنا"),
        w("Close", "بستن", "اغلق", "بند کرنا"),
        w("Start", "شروع کردن", "ابدأ", "شروع"),
        w("Finish", "تمام کردن", "انه", "ختم"),
        w("Learn", "یاد گرفتن", "تعلم", "سیکھنا"),
        w("Teach", "یاد دادن", "علم", "سکھانا"),
        w("Remember", "به یاد آوردن", "تذكر", "یاد رکھنا"),
        w("Forget", "فراموش کردن", "انس", "بھولنا")
    )

    private fun w(en: String, fa: String, ar: String, ur: String) = BalochiWord(
        english = en,
        persian = fa,
        arabic = ar,
        urdu = ur,
        balochi = ""
    )
}
