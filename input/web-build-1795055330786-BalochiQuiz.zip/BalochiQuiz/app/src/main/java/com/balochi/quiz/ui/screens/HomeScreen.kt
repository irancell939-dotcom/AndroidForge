package com.balochi.quiz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.QuizLanguage
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.theme.*

@Composable
fun HomeScreen(
    viewModel: QuizViewModel,
    onStartQuiz: () -> Unit,
    onAddWord: () -> Unit,
    onWordList: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmNightParchment)
            .padding(horizontal = 20.dp)
            .statusBarsPadding()
            .navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(28.dp))

        Text(
            text = "لغت بلوچی",
            fontSize = 38.sp,
            fontWeight = FontWeight.Bold,
            color = SaffronGold
        )
        Text(
            text = "آزمون هوشمند چندزبانه",
            fontSize = 16.sp,
            color = TextSecondary,
            modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(modifier = Modifier.height(18.dp))

        // پیشرفت
        ProgressCard(viewModel)

        Spacer(modifier = Modifier.height(20.dp))

        // انتخاب دو زبان
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(CardBackground)
                .border(1.dp, BorderSubtle, RoundedCornerShape(18.dp))
                .padding(16.dp)
        ) {
            Text(
                text = "زبان‌های آزمون (دو زبان انتخاب کنید)",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = Cream,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // زبان اول
            Text("زبان اول", fontSize = 13.sp, color = TextMuted, modifier = Modifier.padding(bottom = 6.dp))
            LanguageRow(
                selected = viewModel.langA,
                other = viewModel.langB,
                onSelect = { viewModel.setLanguages(it, viewModel.langB) }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // زبان دوم
            Text("زبان دوم", fontSize = 13.sp, color = TextMuted, modifier = Modifier.padding(bottom = 6.dp))
            LanguageRow(
                selected = viewModel.langB,
                other = viewModel.langA,
                onSelect = { viewModel.setLanguages(viewModel.langA, it) }
            )
        }

        Spacer(modifier = Modifier.height(22.dp))

        MainButton(
            text = "شروع آزمون تصادفی",
            icon = Icons.Default.PlayArrow,
            onClick = onStartQuiz,
            enabled = viewModel.words.any {
                it.hasMeaning(viewModel.langA) && it.hasMeaning(viewModel.langB)
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedMainButton(
            text = "افزودن / ویرایش کلمه",
            icon = Icons.Default.Add,
            onClick = onAddWord
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedMainButton(
            text = "لیست کلمات (${viewModel.words.size})",
            icon = Icons.Default.List,
            onClick = onWordList
        )

        Spacer(modifier = Modifier.weight(1f))

        Text(
            text = "برنامه‌نویس: محمدعمر خاوران\n۰۹۱۵۹۴۹۹۹۲۸",
            fontSize = 13.sp,
            color = TextMuted,
            textAlign = TextAlign.Center,
            lineHeight = 20.sp
        )
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun ProgressCard(viewModel: QuizViewModel) {
    val p = viewModel.progress
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardBackground)
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        ProgressItem("سطح", "${p.level}")
        ProgressItem("آزمون‌ها", "${p.totalQuizzes}")
        ProgressItem("پاسخ درست", "${p.totalCorrect}")
    }
}

@Composable
private fun ProgressItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = SaffronGold)
        Text(text = label, fontSize = 12.sp, color = TextSecondary)
    }
}

@Composable
private fun LanguageRow(
    selected: QuizLanguage,
    other: QuizLanguage,
    onSelect: (QuizLanguage) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        QuizLanguage.entries.forEach { lang ->
            val isSelected = selected == lang
            val isDisabled = other == lang
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        when {
                            isSelected -> SaffronGold
                            isDisabled -> ChipBackground.copy(alpha = 0.4f)
                            else -> ChipBackground
                        }
                    )
                    .clickable(enabled = !isDisabled) { onSelect(lang) }
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = lang.displayName,
                    color = when {
                        isSelected -> WarmNightParchment
                        isDisabled -> TextMuted
                        else -> Cream
                    },
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun MainButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(58.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = SaffronGold,
            contentColor = WarmNightParchment,
            disabledContainerColor = CardBackground,
            disabledContentColor = TextMuted
        )
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun OutlinedMainButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream),
        border = ButtonDefaults.outlinedButtonBorder.copy(
            width = 1.5.dp,
            brush = androidx.compose.ui.graphics.SolidColor(BorderSubtle)
        )
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
    }
}
