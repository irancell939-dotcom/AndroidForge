package com.balochi.quiz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.BalochiWord
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.theme.*

@Composable
fun AddWordScreen(
    viewModel: QuizViewModel,
    existingWord: BalochiWord? = null,
    onBack: () -> Unit
) {
    var balochi by remember { mutableStateOf(existingWord?.balochi ?: "") }
    var persian by remember { mutableStateOf(existingWord?.persian ?: "") }
    var english by remember { mutableStateOf(existingWord?.english ?: "") }
    var arabic by remember { mutableStateOf(existingWord?.arabic ?: "") }
    var urdu by remember { mutableStateOf(existingWord?.urdu ?: "") }
    var example by remember { mutableStateOf(existingWord?.example ?: "") }
    var showError by remember { mutableStateOf(false) }

    val isEdit = existingWord != null

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmNightParchment)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت", tint = Cream)
            }
            Text(
                text = if (isEdit) "ویرایش کلمه" else "افزودن کلمه جدید",
                color = Cream,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            WordTextField(balochi, { balochi = it; showError = false }, "کلمه بلوچی", showError && balochi.isBlank() && english.isBlank())
            Spacer(Modifier.height(12.dp))
            WordTextField(persian, { persian = it }, "معنی فارسی")
            Spacer(Modifier.height(12.dp))
            WordTextField(english, { english = it }, "English")
            Spacer(Modifier.height(12.dp))
            WordTextField(arabic, { arabic = it }, "المعنى بالعربية")
            Spacer(Modifier.height(12.dp))
            WordTextField(urdu, { urdu = it }, "معنی اردو")
            Spacer(Modifier.height(12.dp))
            WordTextField(example, { example = it }, "مثال (اختیاری)", singleLine = false)

            if (showError) {
                Spacer(Modifier.height(8.dp))
                Text("حداقل یک کلمه و یک معنی وارد کنید", color = WrongRed, fontSize = 13.sp)
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = {
                    if ((balochi.isBlank() && english.isBlank()) ||
                        (persian.isBlank() && english.isBlank() && arabic.isBlank() && urdu.isBlank() && balochi.isBlank())
                    ) {
                        showError = true
                        return@Button
                    }
                    val word = BalochiWord(
                        id = existingWord?.id ?: java.util.UUID.randomUUID().toString(),
                        balochi = balochi.trim(),
                        persian = persian.trim(),
                        english = english.trim(),
                        arabic = arabic.trim(),
                        urdu = urdu.trim(),
                        example = example.trim(),
                        correctCount = existingWord?.correctCount ?: 0,
                        wrongCount = existingWord?.wrongCount ?: 0,
                        lastSeen = existingWord?.lastSeen ?: 0L,
                        createdAt = existingWord?.createdAt ?: System.currentTimeMillis()
                    )
                    if (isEdit) viewModel.updateWord(word) else viewModel.addWord(word)
                    onBack()
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SaffronGold, contentColor = WarmNightParchment)
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.width(8.dp))
                Text(if (isEdit) "ذخیره تغییرات" else "ذخیره کلمه", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun WordTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    isError: Boolean = false,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = singleLine,
        isError = isError,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = SaffronGold,
            unfocusedBorderColor = TextSecondary.copy(alpha = 0.4f),
            focusedLabelColor = SaffronGold,
            unfocusedLabelColor = TextSecondary,
            cursorColor = SaffronGold,
            focusedTextColor = Cream,
            unfocusedTextColor = Cream,
            errorBorderColor = WrongRed,
            errorLabelColor = WrongRed
        )
    )
}
