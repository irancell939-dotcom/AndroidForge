package com.balochi.quiz.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette — لوغت بلوچی
val WarmNightParchment = Color(0xFF14110E)   // پس‌زمینه اصلی خیلی تیره
val SaffronGold = Color(0xFFE2A45A)          // طلایی زعفرانی
val Cream = Color(0xFFF6EFE2)                // کرم روشن برای متن اصلی
val Sage = Color(0xFF8EAE86)                 // سبز مریم‌گلی

// سطوح و کارت‌ها (متفاوت از پس‌زمینه)
val DarkSurface = Color(0xFF1C1814)
val CardBackground = Color(0xFF2A241E)       // کارت تیره‌تر و متمایز
val CardBackgroundLight = Color(0xFF332C25)  // کارت کمی روشن‌تر برای گزینه‌ها
val ChipBackground = Color(0xFF3A322A)

// متن‌ها با کنتراست بالا
val TextPrimary = Color(0xFFF8F1E3)          // تقریباً سفید کرم
val TextSecondary = Color(0xFFC9B8A4)        // ثانویه روشن‌تر
val TextMuted = Color(0xFF9A8B78)

// بازخورد
val CorrectGreen = Color(0xFF66BB6A)
val WrongRed = Color(0xFFEF5350)
val OptionSelected = SaffronGold.copy(alpha = 0.22f)
val BorderSubtle = Color(0xFF4A4036)
