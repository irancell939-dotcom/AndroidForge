package com.balochi.quiz.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val BalochiColorScheme = darkColorScheme(
    primary = SaffronGold,
    onPrimary = WarmNightParchment,
    secondary = Sage,
    onSecondary = WarmNightParchment,
    tertiary = Cream,
    background = WarmNightParchment,
    onBackground = Cream,
    surface = DarkSurface,
    onSurface = Cream,
    surfaceVariant = CardBackground,
    onSurfaceVariant = TextSecondary,
    error = WrongRed,
    onError = Cream
)

@Composable
fun BalochiQuizTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = BalochiColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = WarmNightParchment.toArgb()
            window.navigationBarColor = WarmNightParchment.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
