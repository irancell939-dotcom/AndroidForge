package com.balochi.quiz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.screens.AppNavigation
import com.balochi.quiz.ui.theme.BalochiQuizTheme
import com.balochi.quiz.ui.theme.WarmNightParchment

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BalochiQuizTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = WarmNightParchment
                ) {
                    val viewModel: QuizViewModel = viewModel()
                    AppNavigation(viewModel = viewModel)
                }
            }
        }
    }
}
