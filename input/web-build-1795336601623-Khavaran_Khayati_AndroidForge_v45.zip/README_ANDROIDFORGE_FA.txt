خیاطی خاوران - نسخه ۴۵ - پروژه کامل Gradle برای AndroidForge

این بسته ریشه ZIP شامل settings.gradle و build.gradle و پوشه app است تا دستور gradle assembleDebug در مسیر workspace پروژه را تشخیص دهد و APK بسازد.

تغییرات نسخه ۴۵ (نسبت به v33):
- اصلاح پیدا کردن سفارش از روی بارکد Binary Eye
- جست‌وجوی دقیق بارکد سفارش اولویت اول است
- برای بارکدهای قدیمی/کوتاه‌تر، کد مشتری یا شناسه داخلی از انتهای بارکد استخراج و تطبیق داده می‌شود
- سفارش متناسب با مرحله اسکن انتخاب می‌شود
- پیام خطای ۴۰۴ واضح‌تر شده است
- به‌روزرسانی قالب‌ها و استایل از نسخه ویندوز ۴۵

ساختار:
- app/src/main/python/app.py          ← هسته Flask
- app/src/main/python/templates/      ← قالب‌ها
- app/src/main/python/static/         ← استایل
- app/src/main/java/.../MainActivity.java ← WebView + پل جاوا به پایتون + اسکنر
- آیکون‌ها در res/mipmap-*

نسخه: 45.0 (versionCode 45)
