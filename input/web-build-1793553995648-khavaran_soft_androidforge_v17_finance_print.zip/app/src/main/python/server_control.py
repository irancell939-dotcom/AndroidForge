# -*- coding: utf-8 -*-
"""Runs and stops the shared Flask server inside the Android foreground service."""
import os
import threading
from pathlib import Path

_started = False
_lock = threading.Lock()
_server_instance = None


def start(data_dir: str, web_dir: str, device_id: str = ""):
    global _started, _server_instance
    with _lock:
        if _started:
            return "already-started"
        data_path = Path(data_dir)
        web_path = Path(web_dir)
        data_path.mkdir(parents=True, exist_ok=True)
        os.environ["KHAYATI_DATA_DIR"] = str(data_path)
        os.environ["KHAYATI_WEB_DIR"] = str(web_path)
        os.environ["KHAYATI_ANDROID"] = "1"
        if device_id:
            os.environ["KHAYATI_DEVICE_ID"] = str(device_id)

        from werkzeug.serving import make_server
        from app import app

        def serve():
            global _server_instance, _started
            status_file = data_path / "server_status.txt"
            try:
                server = make_server("0.0.0.0", 5000, app, threaded=True)
                _server_instance = server
                status_file.write_text("ready", encoding="utf-8")
                server.serve_forever()
                status_file.write_text("stopped", encoding="utf-8")
            except Exception as exc:
                status_file.write_text("error: " + repr(exc), encoding="utf-8")
            finally:
                if _server_instance is not None:
                    try:
                        _server_instance.server_close()
                    except Exception:
                        pass
                _server_instance = None
                _started = False

        worker = threading.Thread(target=serve, name="KhayatiHTTPServer", daemon=True)
        worker.start()
        _started = True
        return "starting"


def stop():
    global _server_instance
    server = _server_instance
    if server is not None:
        server.shutdown()
        try:
            server.server_close()
        except Exception:
            pass
    return "stopped"
