package com.example.phoneregistration

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.UUID

data class Contact(
    val id: String,
    var name: String,
    var phone: String,
    var note: String = "",
    var category: String = ""
)

data class CallRecord(
    val id: String,
    val name: String,
    val phone: String,
    val timestamp: Long
)

class MainActivity : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var rvList: RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var tvCount: TextView
    private lateinit var fabAdd: FloatingActionButton
    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: ContactAdapter

    private val allContacts = mutableListOf<Contact>()
    private val filteredContacts = mutableListOf<Contact>()
    private var currentCategoryFilter = ""

    private val defaultCategories = listOf("همکاران", "دوستان", "خانواده", "مشتریان", "سایر")

    companion object {
        private const val REQ_IMPORT_VCF = 2001
        private const val REQ_RESTORE = 2002
        private const val REQ_EXCEL_CSV = 2003
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.title = getString(R.string.app_name)

        etSearch = findViewById(R.id.etSearch)
        rvList = findViewById(R.id.rvList)
        tvEmpty = findViewById(R.id.tvEmpty)
        tvCount = findViewById(R.id.tvCount)
        fabAdd = findViewById(R.id.fabAdd)

        prefs = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)

        adapter = ContactAdapter(
            filteredContacts,
            onCall = { initiateCall(it) },
            onSms = { sendSms(it) },
            onEdit = { showContactDialog(it) },
            onDelete = { confirmDelete(it) }
        )
        rvList.layoutManager = LinearLayoutManager(this)
        rvList.adapter = adapter

        loadContacts()
        applyFilter("")

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                applyFilter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        fabAdd.setOnClickListener { showContactDialog(null) }

        // Long press on title area or count to filter by category
        tvCount.setOnClickListener { showCategoryFilterDialog() }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_history -> {
                startActivity(Intent(this, HistoryActivity::class.java))
                return true
            }
            R.id.action_export_vcf -> {
                exportVcf()
                return true
            }
            R.id.action_import_vcf -> {
                pickFile(REQ_IMPORT_VCF, arrayOf("text/vcard", "text/x-vcard", "*/*"))
                return true
            }
            R.id.action_backup -> {
                exportBackup()
                return true
            }
            R.id.action_restore -> {
                pickFile(REQ_RESTORE, arrayOf("application/json", "text/plain", "*/*"))
                return true
            }
            R.id.action_excel_vcf -> {
                AlertDialog.Builder(this)
                    .setTitle(R.string.excel_to_vcf)
                    .setMessage("فایل اکسل را به صورت CSV ذخیره کنید (Save As → CSV)، سپس آن را انتخاب کنید.\nستون‌ها: نام، شماره، دسته (اختیاری)، یادداشت (اختیاری)")
                    .setPositiveButton("انتخاب فایل") { _, _ ->
                        pickFile(REQ_EXCEL_CSV, arrayOf("text/csv", "text/comma-separated-values", "*/*"))
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun pickFile(requestCode: Int, mimeTypes: Array<String>) {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "انتخاب فایل"), requestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            REQ_IMPORT_VCF -> importVcf(uri)
            REQ_RESTORE -> restoreBackup(uri)
            REQ_EXCEL_CSV -> convertCsvToVcf(uri)
        }
    }

    private fun showContactDialog(existing: Contact?) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_contact, null)
        val etName = view.findViewById<TextInputEditText>(R.id.etName)
        val etPhone = view.findViewById<TextInputEditText>(R.id.etPhone)
        val etNote = view.findViewById<TextInputEditText>(R.id.etNote)
        val etCategory = view.findViewById<AutoCompleteTextView>(R.id.etCategory)
        val tvTitle = view.findViewById<TextView>(R.id.tvDialogTitle)
        val btnSave = view.findViewById<MaterialButton>(R.id.btnSave)
        val btnCancel = view.findViewById<MaterialButton>(R.id.btnCancel)

        // Category suggestions
        val cats = (defaultCategories + allContacts.map { it.category }.filter { it.isNotBlank() }).distinct()
        etCategory.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, cats))

        if (existing != null) {
            tvTitle.text = getString(R.string.edit)
            etName.setText(existing.name)
            etPhone.setText(existing.phone)
            etNote.setText(existing.note)
            etCategory.setText(existing.category)
        } else {
            tvTitle.text = getString(R.string.add_contact)
        }

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .setCancelable(true)
            .create()

        btnCancel.setOnClickListener { dialog.dismiss() }
        btnSave.setOnClickListener {
            val name = etName.text?.toString()?.trim().orEmpty()
            val phone = etPhone.text?.toString()?.trim().orEmpty()
            val note = etNote.text?.toString()?.trim().orEmpty()
            val category = etCategory.text?.toString()?.trim().orEmpty()

            if (name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, R.string.error_empty, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (existing != null) {
                existing.name = name
                existing.phone = phone
                existing.note = note
                existing.category = category
            } else {
                allContacts.add(0, Contact(UUID.randomUUID().toString(), name, phone, note, category))
            }
            saveContacts()
            applyFilter(etSearch.text.toString())
            Toast.makeText(this, R.string.success_save, Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun showCategoryFilterDialog() {
        val cats = listOf(getString(R.string.all_categories)) +
                (defaultCategories + allContacts.map { it.category }.filter { it.isNotBlank() }).distinct().sorted()
        AlertDialog.Builder(this)
            .setTitle("فیلتر دسته‌بندی")
            .setItems(cats.toTypedArray()) { _, which ->
                currentCategoryFilter = if (which == 0) "" else cats[which]
                applyFilter(etSearch.text.toString())
            }
            .show()
    }

    private fun confirmDelete(contact: Contact) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete)
            .setMessage("«${contact.name}» حذف شود؟")
            .setPositiveButton(R.string.delete) { _, _ ->
                allContacts.removeAll { it.id == contact.id }
                saveContacts()
                applyFilter(etSearch.text.toString())
                Toast.makeText(this, R.string.success_delete, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun initiateCall(contact: Contact) {
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contact.phone}")))
            addCallHistory(contact.name, contact.phone)
        } catch (e: Exception) {
            Toast.makeText(this, "امکان تماس وجود ندارد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendSms(contact: Contact) {
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${contact.phone}")))
        } catch (e: Exception) {
            Toast.makeText(this, "امکان ارسال پیامک وجود ندارد", Toast.LENGTH_SHORT).show()
        }
    }

    // ========== VCF Export ==========
    private fun exportVcf() {
        if (allContacts.isEmpty()) {
            Toast.makeText(this, "مخاطبی برای صادر کردن وجود ندارد", Toast.LENGTH_SHORT).show()
            return
        }
        val sb = StringBuilder()
        allContacts.forEach { c ->
            sb.append("BEGIN:VCARD\n")
            sb.append("VERSION:3.0\n")
            sb.append("FN:${c.name}\n")
            sb.append("TEL;TYPE=CELL:${c.phone}\n")
            if (c.note.isNotBlank()) sb.append("NOTE:${c.note}\n")
            if (c.category.isNotBlank()) sb.append("CATEGORIES:${c.category}\n")
            sb.append("END:VCARD\n")
        }
        shareTextFile("contacts.vcf", sb.toString(), "text/vcard")
        Toast.makeText(this, R.string.export_success, Toast.LENGTH_SHORT).show()
    }

    // ========== VCF Import ==========
    private fun importVcf(uri: Uri) {
        try {
            val reader = BufferedReader(InputStreamReader(contentResolver.openInputStream(uri)))
            val content = reader.readText()
            reader.close()
            val cards = content.split("BEGIN:VCARD")
            var count = 0
            cards.forEach { card ->
                if (card.isBlank()) return@forEach
                var name = ""
                var phone = ""
                var note = ""
                var category = ""
                card.lines().forEach { line ->
                    when {
                        line.startsWith("FN:") -> name = line.removePrefix("FN:").trim()
                        line.startsWith("TEL") -> {
                            val p = line.substringAfter(":").trim()
                            if (p.isNotBlank()) phone = p
                        }
                        line.startsWith("NOTE:") -> note = line.removePrefix("NOTE:").trim()
                        line.startsWith("CATEGORIES:") -> category = line.removePrefix("CATEGORIES:").trim()
                    }
                }
                if (name.isNotBlank() && phone.isNotBlank()) {
                    // avoid exact duplicates
                    if (allContacts.none { it.phone == phone && it.name == name }) {
                        allContacts.add(Contact(UUID.randomUUID().toString(), name, phone, note, category))
                        count++
                    }
                }
            }
            saveContacts()
            applyFilter(etSearch.text.toString())
            Toast.makeText(this, "$count مخاطب وارد شد", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در خواندن فایل VCF", Toast.LENGTH_SHORT).show()
        }
    }

    // ========== Backup (JSON) ==========
    private fun exportBackup() {
        val arr = JSONArray()
        allContacts.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id)
            obj.put("name", c.name)
            obj.put("phone", c.phone)
            obj.put("note", c.note)
            obj.put("category", c.category)
            arr.put(obj)
        }
        shareTextFile("phonebook_backup.json", arr.toString(2), "application/json")
        Toast.makeText(this, R.string.backup_success, Toast.LENGTH_SHORT).show()
    }

    private fun restoreBackup(uri: Uri) {
        try {
            val reader = BufferedReader(InputStreamReader(contentResolver.openInputStream(uri)))
            val json = reader.readText()
            reader.close()
            val arr = JSONArray(json)
            var count = 0
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val name = obj.optString("name")
                val phone = obj.optString("phone")
                if (name.isNotBlank() && phone.isNotBlank()) {
                    if (allContacts.none { it.phone == phone && it.name == name }) {
                        allContacts.add(
                            Contact(
                                obj.optString("id", UUID.randomUUID().toString()),
                                name, phone,
                                obj.optString("note", ""),
                                obj.optString("category", "")
                            )
                        )
                        count++
                    }
                }
            }
            saveContacts()
            applyFilter(etSearch.text.toString())
            Toast.makeText(this, "$count مخاطب بازیابی شد", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در بازیابی فایل", Toast.LENGTH_SHORT).show()
        }
    }

    // ========== CSV / Excel-exported → VCF ==========
    private fun convertCsvToVcf(uri: Uri) {
        try {
            val reader = BufferedReader(InputStreamReader(contentResolver.openInputStream(uri)))
            val lines = reader.readLines()
            reader.close()
            if (lines.isEmpty()) {
                Toast.makeText(this, "فایل خالی است", Toast.LENGTH_SHORT).show()
                return
            }
            val sb = StringBuilder()
            var count = 0
            // Skip header if looks like header
            val start = if (lines[0].contains("نام") || lines[0].lowercase().contains("name") ||
                lines[0].lowercase().contains("phone")) 1 else 0
            for (i in start until lines.size) {
                val parts = lines[i].split(",", ";", "\t").map { it.trim().removeSurrounding("\"") }
                if (parts.size < 2) continue
                val name = parts[0]
                val phone = parts[1]
                val category = if (parts.size > 2) parts[2] else ""
                val note = if (parts.size > 3) parts[3] else ""
                if (name.isBlank() || phone.isBlank()) continue
                sb.append("BEGIN:VCARD\nVERSION:3.0\n")
                sb.append("FN:$name\n")
                sb.append("TEL;TYPE=CELL:$phone\n")
                if (note.isNotBlank()) sb.append("NOTE:$note\n")
                if (category.isNotBlank()) sb.append("CATEGORIES:$category\n")
                sb.append("END:VCARD\n")
                count++
            }
            if (count == 0) {
                Toast.makeText(this, "هیچ مخاطب معتبری پیدا نشد", Toast.LENGTH_SHORT).show()
                return
            }
            shareTextFile("converted_contacts.vcf", sb.toString(), "text/vcard")
            Toast.makeText(this, "$count مخاطب به VCF تبدیل شد", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در تبدیل فایل", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareTextFile(filename: String, content: String, mime: String) {
        try {
            val dir = File(cacheDir, "shares")
            dir.mkdirs()
            val file = File(dir, filename)
            file.writeText(content)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "اشتراک‌گذاری فایل"))
        } catch (e: Exception) {
            // fallback: just copy to clipboard or toast
            Toast.makeText(this, "فایل آماده شد اما اشتراک‌گذاری با مشکل مواجه شد: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun addCallHistory(name: String, phone: String) {
        val records = loadCallHistory().toMutableList()
        records.add(0, CallRecord(UUID.randomUUID().toString(), name, phone, System.currentTimeMillis()))
        val limited = records.take(100)
        val arr = JSONArray()
        limited.forEach { r ->
            val obj = JSONObject()
            obj.put("id", r.id)
            obj.put("name", r.name)
            obj.put("phone", r.phone)
            obj.put("timestamp", r.timestamp)
            arr.put(obj)
        }
        prefs.edit().putString("call_history", arr.toString()).apply()
    }

    private fun loadCallHistory(): List<CallRecord> {
        val json = prefs.getString("call_history", "[]") ?: "[]"
        val list = mutableListOf<CallRecord>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(CallRecord(obj.getString("id"), obj.getString("name"), obj.getString("phone"), obj.getLong("timestamp")))
            }
        } catch (_: Exception) {}
        return list
    }

    private fun applyFilter(query: String) {
        filteredContacts.clear()
        val q = query.trim().lowercase()
        val base = if (currentCategoryFilter.isBlank()) allContacts
        else allContacts.filter { it.category == currentCategoryFilter }
        if (q.isEmpty()) {
            filteredContacts.addAll(base)
        } else {
            filteredContacts.addAll(base.filter {
                it.name.lowercase().contains(q) ||
                it.phone.contains(q) ||
                it.note.lowercase().contains(q) ||
                it.category.lowercase().contains(q)
            })
        }
        adapter.notifyDataSetChanged()
        updateEmptyState(query)
        val catLabel = if (currentCategoryFilter.isBlank()) "" else " ($currentCategoryFilter)"
        tvCount.text = "${filteredContacts.size} مخاطب$catLabel"
    }

    private fun updateEmptyState(query: String) {
        if (filteredContacts.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            rvList.visibility = View.GONE
            tvEmpty.text = if (query.isBlank() && currentCategoryFilter.isBlank()) getString(R.string.empty_list)
            else getString(R.string.empty_search)
        } else {
            tvEmpty.visibility = View.GONE
            rvList.visibility = View.VISIBLE
        }
    }

    private fun saveContacts() {
        val arr = JSONArray()
        allContacts.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id)
            obj.put("name", c.name)
            obj.put("phone", c.phone)
            obj.put("note", c.note)
            obj.put("category", c.category)
            arr.put(obj)
        }
        prefs.edit().putString("contacts", arr.toString()).apply()
    }

    private fun loadContacts() {
        allContacts.clear()
        val json = prefs.getString("contacts", "[]") ?: "[]"
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                allContacts.add(
                    Contact(
                        obj.getString("id"),
                        obj.getString("name"),
                        obj.getString("phone"),
                        obj.optString("note", ""),
                        obj.optString("category", "")
                    )
                )
            }
        } catch (_: Exception) {}
    }
}

class ContactAdapter(
    private val items: List<Contact>,
    private val onCall: (Contact) -> Unit,
    private val onSms: (Contact) -> Unit,
    private val onEdit: (Contact) -> Unit,
    private val onDelete: (Contact) -> Unit
) : RecyclerView.Adapter<ContactAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvAvatar: TextView = view.findViewById(R.id.tvAvatar)
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvPhone: TextView = view.findViewById(R.id.tvPhone)
        val tvNote: TextView = view.findViewById(R.id.tvNote)
        val btnCall: MaterialButton = view.findViewById(R.id.btnCall)
        val btnSms: MaterialButton = view.findViewById(R.id.btnSms)
        val btnMore: ImageButton = view.findViewById(R.id.btnMore)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_contact, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvName.text = if (item.category.isNotBlank()) "${item.name}  •  ${item.category}" else item.name
        holder.tvPhone.text = item.phone
        holder.tvAvatar.text = item.name.take(1).uppercase()

        if (item.note.isNotBlank()) {
            holder.tvNote.visibility = View.VISIBLE
            holder.tvNote.text = item.note
        } else {
            holder.tvNote.visibility = View.GONE
        }

        holder.btnCall.setOnClickListener { onCall(item) }
        holder.btnSms.setOnClickListener { onSms(item) }

        holder.btnMore.setOnClickListener { view ->
            val popup = PopupMenu(view.context, view)
            popup.menu.add(0, 1, 0, view.context.getString(R.string.edit))
            popup.menu.add(0, 2, 1, view.context.getString(R.string.delete))
            popup.setOnMenuItemClickListener { menuItem ->
                when (menuItem.itemId) {
                    1 -> { onEdit(item); true }
                    2 -> { onDelete(item); true }
                    else -> false
                }
            }
            popup.show()
        }
    }

    override fun getItemCount(): Int = items.size
}
