package com.aamal.roozaneh;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.core.app.NotificationCompat;

public class NotificationReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;

        String action = intent.getAction();

        // Handle action buttons from notification
        if ("ACTION_JAMAAT".equals(action) || "ACTION_FARDI".equals(action) || "ACTION_NOT_YET".equals(action)) {
            handleAction(context, intent, action);
            return;
        }

        // Normal alarm
        try {
            String type = intent.getStringExtra("type");
            String message = intent.getStringExtra("message");
            String prayerKey = intent.getStringExtra("prayerKey");
            int reqCode = intent.getIntExtra("reqCode", 2100);
            int hour = intent.getIntExtra("hour", -1);
            int minute = intent.getIntExtra("minute", -1);
            if (message == null) message = "کارنامه اعمالت را تکمیل کن";
            if (prayerKey == null) prayerKey = "";

            String title = "اعمال روزانه";
            if ("before".equals(type)) title = "وقت نماز نزدیک است 🕌";
            else if ("after".equals(type)) title = "پیگیری نماز 📿";
            else if ("night".equals(type)) title = "کارنامه امروز";

            Intent open = new Intent(context, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            open.putExtra("from_notif", true);
            open.putExtra("prayerKey", prayerKey);
            PendingIntent contentPi = PendingIntent.getActivity(context, reqCode + 100, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, MainActivity.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setContentIntent(contentPi)
                .setAutoCancel(true)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC);

            // Action buttons only for "after" (follow-up) notifications
            if ("after".equals(type) && prayerKey != null && prayerKey.length() > 0 && !"test".equals(prayerKey)) {
                builder.addAction(0, "جماعت", actionPi(context, "ACTION_JAMAAT", prayerKey, reqCode + 10));
                builder.addAction(0, "انفرادی", actionPi(context, "ACTION_FARDI", prayerKey, reqCode + 11));
                builder.addAction(0, "هنوز نخواندم", actionPi(context, "ACTION_NOT_YET", prayerKey, reqCode + 12));
            }

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(reqCode, builder.build());

            // Reschedule for next day if fixed clock time
            if (hour >= 0 && minute >= 0) {
                MainActivity.scheduleAlarm(context, hour, minute, reqCode, type, prayerKey, message);
            } else if ("night".equals(type)) {
                MainActivity.scheduleAlarm(context, 21, 0, 9000, "night", "night",
                    "امروزت چگونه گذشت؟ کارنامه اعمالت را تکمیل کن");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private PendingIntent actionPi(Context ctx, String action, String prayerKey, int code) {
        Intent i = new Intent(ctx, NotificationReceiver.class);
        i.setAction(action);
        i.putExtra("prayerKey", prayerKey);
        return PendingIntent.getBroadcast(ctx, code, i,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void handleAction(Context context, Intent intent, String action) {
        String prayerKey = intent.getStringExtra("prayerKey");
        if (prayerKey == null) prayerKey = "";

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Cancel related notifications for this prayer
        // after codes are 2000+index, before 1000+index
        if (nm != null) {
            // dismiss a range of possible ids
            for (int i = 0; i < 5; i++) {
                nm.cancel(2000 + i);
                nm.cancel(1000 + i);
            }
        }

        String[] keys = {"fajr", "zuhr", "asr", "maghrib", "isha"};
        String[] names = {"صبح", "ظهر", "عصر", "مغرب", "عشاء"};
        String name = prayerKey;
        for (int i = 0; i < keys.length; i++) {
            if (keys[i].equals(prayerKey)) { name = names[i]; break; }
        }

        if ("ACTION_NOT_YET".equals(action)) {
            // Ask again in 20 minutes
            MainActivity.scheduleInMinutes(context, 20, 3000 + Math.abs(prayerKey.hashCode() % 100),
                "after", prayerKey,
                "۲۰ دقیقه گذشت — نماز " + name + " را خواندید؟ وضعیت را مشخص کنید");
            // Small confirmation toast-like notification
            showSimple(context, 8800, "یادآوری تنظیم شد", "۲۰ دقیقه دیگر دوباره می‌پرسیم: نماز " + name);
        } else {
            // Saved choice for app to pick up
            String status = "ACTION_JAMAAT".equals(action) ? "jamaat" : "done";
            SharedPreferences sp = context.getSharedPreferences("aamal", Context.MODE_PRIVATE);
            sp.edit().putString("pending_prayer_" + prayerKey, status)
                .putLong("pending_prayer_ts", System.currentTimeMillis())
                .apply();

            String label = "jamaat".equals(status) ? "با جماعت" : "انفرادی";
            showSimple(context, 8801, "ثبت شد ✓", "نماز " + name + " — " + label + " (با باز کردن برنامه همگام می‌شود)");
        }
    }

    private void showSimple(Context ctx, int id, String title, String msg) {
        try {
            Intent open = new Intent(ctx, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(ctx, id + 50, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, MainActivity.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
                .setContentTitle(title)
                .setContentText(msg)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pi)
                .setAutoCancel(true);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(id, b.build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
