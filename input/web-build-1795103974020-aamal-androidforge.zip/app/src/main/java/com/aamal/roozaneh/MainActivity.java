package com.aamal.roozaneh;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONObject;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    public static final String CHANNEL_ID = "aamal_prayer";
    private static final int NOTIF_REQ = 1001;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createNotificationChannel();
        requestNotifPermission();
        requestIgnoreBatteryOptimizations();

        scheduleNightReminder();
        restorePrayerAlarms(this);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new WebAppInterface(this), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "اعلان نماز و اعمال", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("یادآوری قبل و بعد نماز حتی وقتی برنامه بسته است");
            channel.enableVibration(true);
            channel.setShowBadge(true);
            channel.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(channel);
            }
        }
    }

    private void requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQ);
            }
        }
    }

    private void requestIgnoreBatteryOptimizations() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void scheduleNightReminder() {
        scheduleAlarm(this, 21, 0, 9000, "night", "night",
            "امروزت چگونه گذشت؟ کارنامه اعمالت را تکمیل کن");
    }

    /**
     * Schedule alarm using device local time. Works even when app is killed.
     * Uses setAlarmClock (most reliable on modern Android).
     */
    public static void scheduleAlarm(Context ctx, int hour, int minute, int reqCode,
                                     String type, String prayerKey, String message) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            Intent intent = new Intent(ctx, NotificationReceiver.class);
            intent.setAction("com.aamal.roozaneh.ALARM");
            intent.putExtra("type", type);
            intent.putExtra("prayerKey", prayerKey != null ? prayerKey : "");
            intent.putExtra("message", message);
            intent.putExtra("reqCode", reqCode);
            intent.putExtra("hour", hour);
            intent.putExtra("minute", minute);

            PendingIntent pi = PendingIntent.getBroadcast(
                ctx, reqCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Calendar cal = Calendar.getInstance(); // device timezone
            cal.set(Calendar.HOUR_OF_DAY, hour);
            cal.set(Calendar.MINUTE, minute);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            long trigger = cal.getTimeInMillis();
            if (trigger <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1);
                trigger = cal.getTimeInMillis();
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                AlarmManager.AlarmClockInfo info = new AlarmManager.AlarmClockInfo(trigger, pi);
                am.setAlarmClock(info, pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, trigger, pi);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void scheduleInMinutes(Context ctx, int minutes, int reqCode,
                                         String type, String prayerKey, String message) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            Intent intent = new Intent(ctx, NotificationReceiver.class);
            intent.setAction("com.aamal.roozaneh.ALARM");
            intent.putExtra("type", type);
            intent.putExtra("prayerKey", prayerKey != null ? prayerKey : "");
            intent.putExtra("message", message);
            intent.putExtra("reqCode", reqCode);
            intent.putExtra("hour", -1);
            intent.putExtra("minute", -1);

            PendingIntent pi = PendingIntent.getBroadcast(
                ctx, reqCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            long trigger = System.currentTimeMillis() + minutes * 60L * 1000L;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                AlarmManager.AlarmClockInfo info = new AlarmManager.AlarmClockInfo(trigger, pi);
                am.setAlarmClock(info, pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, trigger, pi);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void restorePrayerAlarms(Context ctx) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("aamal", Context.MODE_PRIVATE);
            String json = sp.getString("prayer_times", null);
            if (json == null || json.length() < 5) return;

            JSONObject obj = new JSONObject(json);
            String[] keys = {"fajr", "zuhr", "asr", "maghrib", "isha"};
            String[] names = {"صبح", "ظهر", "عصر", "مغرب", "عشاء"};

            for (int i = 0; i < keys.length; i++) {
                if (!obj.has(keys[i])) continue;
                String time = obj.optString(keys[i], "");
                if (time.length() < 3) continue;
                String[] parts = time.split(":");
                if (parts.length < 2) continue;
                int h, m;
                try {
                    h = Integer.parseInt(parts[0].trim());
                    m = Integer.parseInt(parts[1].trim());
                } catch (NumberFormatException e) {
                    continue;
                }
                if (h < 0 || h > 23 || m < 0 || m > 59) continue;

                // 15 min before
                int bM = m - 15, bH = h;
                if (bM < 0) { bM += 60; bH -= 1; if (bH < 0) bH = 23; }
                scheduleAlarm(ctx, bH, bM, 1000 + i, "before", keys[i],
                    "۱۵ دقیقه تا نماز " + names[i] + " — وضو بگیر و آماده شو");

                // 30 min after
                int aM = m + 30, aH = h;
                if (aM >= 60) { aM -= 60; aH += 1; if (aH > 23) aH = 0; }
                scheduleAlarm(ctx, aH, aM, 2000 + i, "after", keys[i],
                    "نیم‌ساعت از وقت نماز " + names[i] + " گذشته — وضعیت را مشخص کنید");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class WebAppInterface {
        Context ctx;
        WebAppInterface(Context c) { ctx = c; }

        @JavascriptInterface
        public void savePrayerTimes(String json) {
            try {
                SharedPreferences sp = ctx.getSharedPreferences("aamal", MODE_PRIVATE);
                sp.edit().putString("prayer_times", json)
                    .putLong("times_saved_at", System.currentTimeMillis())
                    .apply();
                restorePrayerAlarms(ctx);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @JavascriptInterface
        public void testNotification() {
            // Fire a test notification in 1 minute for debugging
            scheduleInMinutes(ctx, 1, 9999, "after", "test",
                "این یک اعلان آزمایشی است — اگر این را دیدید اعلان‌ها کار می‌کنند");
        }

        @JavascriptInterface
        public String getDeviceTime() {
            Calendar c = Calendar.getInstance();
            return String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
        }

        @JavascriptInterface
        public String getPendingPrayers() {
            SharedPreferences sp = ctx.getSharedPreferences("aamal", MODE_PRIVATE);
            String[] keys = {"fajr", "zuhr", "asr", "maghrib", "isha"};
            StringBuilder sb = new StringBuilder("{");
            boolean first = true;
            for (String k : keys) {
                String v = sp.getString("pending_prayer_" + k, null);
                if (v != null) {
                    if (!first) sb.append(",");
                    sb.append("\"").append(k).append("\":\"").append(v).append("\"");
                    first = false;
                }
            }
            sb.append("}");
            return sb.toString();
        }

        @JavascriptInterface
        public void clearPendingPrayers() {
            SharedPreferences sp = ctx.getSharedPreferences("aamal", MODE_PRIVATE);
            SharedPreferences.Editor ed = sp.edit();
            String[] keys = {"fajr", "zuhr", "asr", "maghrib", "isha"};
            for (String k : keys) ed.remove("pending_prayer_" + k);
            ed.remove("pending_prayer_ts");
            ed.apply();
        }

        @JavascriptInterface
        public long getTimesSavedAt() {
            SharedPreferences sp = ctx.getSharedPreferences("aamal", MODE_PRIVATE);
            return sp.getLong("times_saved_at", 0);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
