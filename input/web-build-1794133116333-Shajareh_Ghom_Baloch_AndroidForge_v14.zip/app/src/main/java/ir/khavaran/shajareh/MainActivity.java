package ir.khavaran.shajareh;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.CookieManager;
import android.graphics.Color;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private ProgressBar progress;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int attempts = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16, 38, 62));
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(246, 247, 249));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                status.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
            }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (failingUrl != null && failingUrl.startsWith("http://127.0.0.1")) retryLoad();
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        progress = new ProgressBar(this);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(100, 100, android.view.Gravity.CENTER);
        root.addView(progress, pp);
        status = new TextView(this);
        status.setText("در حال راه‌اندازی شجره‌نامه...");
        status.setTextColor(Color.rgb(25, 55, 78));
        status.setTextSize(16);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, android.view.Gravity.CENTER_HORIZONTAL | android.view.Gravity.CENTER_VERTICAL);
        sp.topMargin = 95;
        root.addView(status, sp);
        webView.setVisibility(View.INVISIBLE);
        setContentView(root);
        try {
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            Python.getInstance().getModule("android_entry").callAttr("start_server", getFilesDir().getAbsolutePath());
            // هر بار که برنامه از نو باز می‌شود، کوکی ورود قبلی پاک می‌شود.
            CookieManager cookies = CookieManager.getInstance();
            cookies.removeAllCookies(removed -> {
                cookies.flush();
                handler.postDelayed(() -> webView.loadUrl("http://127.0.0.1:5006"), 1800);
            });
        } catch (Exception e) {
            status.setText("راه‌اندازی برنامه ناموفق بود: " + e.getMessage());
            progress.setVisibility(View.GONE);
        }
    }

    private void retryLoad() {
        if (attempts++ < 12) handler.postDelayed(() -> webView.loadUrl("http://127.0.0.1:5006"), 700);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
