package com.khavaran.khayati;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_CHOOSER = 501;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        webView.addJavascriptInterface(new KhavaranBridge(), "KhavaranAndroid");
        webView.addJavascriptInterface(new KhavaranBridge(), "KhayatiAndroid");
        webView.addJavascriptInterface(new KhavaranBridge(), "KhavaranPrint");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                try {
                    Uri uri = Uri.parse(url);
                    String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                    if (scheme.equals("sms") || scheme.equals("smsto") || scheme.equals("mms") || scheme.equals("mmsto")) {
                        Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                        startActivity(intent); return true;
                    }
                    if (scheme.equals("whatsapp")) {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true;
                    }
                    if (scheme.equals("https") && ("wa.me".equalsIgnoreCase(uri.getHost()) || "api.whatsapp.com".equalsIgnoreCase(uri.getHost()))) {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true;
                    }
                    if (!scheme.equals("http") && !scheme.equals("https")) {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true;
                    }
                } catch (Exception e) { Toast.makeText(MainActivity.this, "برنامه پیام‌رسان در دسترس نیست", Toast.LENGTH_LONG).show(); return true; }
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("(function(){window.print=function(){KhavaranAndroid.printPage();};})();", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER); return true; }
                catch (Exception e) { uploadCallback = null; Toast.makeText(MainActivity.this, "انتخاب فایل ممکن نیست", Toast.LENGTH_LONG).show(); return false; }
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimeType); request.addRequestHeader("User-Agent", userAgent);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "khavaran-backup.db");
                ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                Toast.makeText(this, "دانلود پشتیبان آغاز شد", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "دانلود انجام نشد", Toast.LENGTH_LONG).show(); }
        });
        try {
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            PyObject server = Python.getInstance().getModule("server");
            server.callAttr("start_server", getFilesDir().getAbsolutePath());
            new Handler(Looper.getMainLooper()).postDelayed(() -> webView.loadUrl("http://127.0.0.1:5000"), 1200);
        } catch (Exception e) { Toast.makeText(this, "خطا در راه‌اندازی برنامه: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    public class KhavaranBridge {
        @JavascriptInterface public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
                    android.print.PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("Khavaran-Khayati-A5");
                    PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A5)
                        .setResolution(new PrintAttributes.Resolution("khavaran", "Khavaran 300dpi", 300, 300))
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
                    pm.print("چاپ سفارش خیاطی ـ A5", adapter, attrs);
                } catch (Exception e) { Toast.makeText(MainActivity.this, "چاپ در دسترس نیست", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void startBarcodeScanner() {
            runOnUiThread(() -> {
                try {
                    GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                        .setBarcodeFormats(Barcode.FORMAT_CODE_128, Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8,
                            Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E, Barcode.FORMAT_QR_CODE, Barcode.FORMAT_ITF, Barcode.FORMAT_CODABAR)
                        .enableAutoZoom().build();
                    GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(MainActivity.this, options);
                    scanner.startScan().addOnSuccessListener(barcode -> {
                        String value = barcode.getRawValue();
                        if (value != null) webView.evaluateJavascript("window.onKhavaranBarcodeScanned && window.onKhavaranBarcodeScanned(" + org.json.JSONObject.quote(value) + ");", null);
                    }).addOnCanceledListener(() -> Toast.makeText(MainActivity.this, "اسکن لغو شد", Toast.LENGTH_SHORT).show())
                      .addOnFailureListener(e -> Toast.makeText(MainActivity.this, "اسکنر اجرا نشد؛ بارکد را دستی وارد کنید", Toast.LENGTH_LONG).show());
                } catch (Exception e) { Toast.makeText(MainActivity.this, "اسکنر در دسترس نیست", Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && uploadCallback != null) {
            Uri[] result = (resultCode == RESULT_OK && data != null) ? new Uri[]{data.getData()} : null;
            uploadCallback.onReceiveValue(result); uploadCallback = null;
        }
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
