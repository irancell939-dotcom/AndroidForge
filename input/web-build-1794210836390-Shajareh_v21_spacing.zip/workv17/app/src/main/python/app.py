# -*- coding: utf-8 -*-
"""سامانه شجره‌نامه خانوادگی - نسخه تازه
اجرای محلی: pip install flask ; python app.py
"""
import os, sqlite3, shutil, tempfile, re, json, secrets
from datetime import datetime, date
from werkzeug.security import generate_password_hash, check_password_hash
from flask import Flask, request, jsonify, render_template_string, send_file, abort, session, redirect, url_for

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get('SHAJAREH_DATA_DIR', BASE_DIR)
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, 'shajareh.db')
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024
_secret_file = os.path.join(DATA_DIR, '.session_secret')
if os.environ.get('SECRET_KEY'):
    app.secret_key = os.environ['SECRET_KEY']
else:
    if not os.path.exists(_secret_file):
        with open(_secret_file, 'w', encoding='utf-8') as _sf:
            _sf.write(secrets.token_hex(32))
    with open(_secret_file, 'r', encoding='utf-8') as _sf:
        app.secret_key = _sf.read().strip()
app.config['JSON_AS_ASCII'] = False
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'


def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    return c


def init_db():
    # دیتابیس موجود نشانه نصب قبلی است؛ برای ارتقا، فعال‌سازی دوباره مطالبه نمی‌شود.
    existing_install = os.path.exists(DB_PATH) and os.path.getsize(DB_PATH) > 0
    with db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS people (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          person_code TEXT UNIQUE,
          first_name TEXT NOT NULL,
          last_name TEXT DEFAULT '',
          gender TEXT NOT NULL CHECK(gender IN ('مرد','زن')),
          birth_date TEXT DEFAULT '', death_date TEXT DEFAULT '',
          tribe TEXT DEFAULT '', job TEXT DEFAULT '', phone TEXT DEFAULT '',
          city TEXT DEFAULT '', notes TEXT DEFAULT '', photo BLOB, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS marriages (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          husband_id INTEGER NOT NULL REFERENCES people(id) ON DELETE CASCADE,
          wife_id INTEGER NOT NULL REFERENCES people(id) ON DELETE CASCADE,
          start_date TEXT DEFAULT '', end_date TEXT DEFAULT '',
          end_reason TEXT DEFAULT '', notes TEXT DEFAULT '',
          CHECK(husband_id <> wife_id)
        );
        CREATE TABLE IF NOT EXISTS parent_links (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          parent_id INTEGER NOT NULL REFERENCES people(id) ON DELETE CASCADE,
          child_id INTEGER NOT NULL REFERENCES people(id) ON DELETE CASCADE,
          relation TEXT NOT NULL CHECK(relation IN ('پدر','مادر')),
          UNIQUE(parent_id, child_id), CHECK(parent_id <> child_id)
        );
        CREATE INDEX IF NOT EXISTS idx_parent_child ON parent_links(child_id);
        CREATE INDEX IF NOT EXISTS idx_marriage_husband ON marriages(husband_id);
        CREATE INDEX IF NOT EXISTS idx_marriage_wife ON marriages(wife_id);
        ''')
        # ارتقای امن دیتابیس‌های قدیمی برای نگهداری تصویر شخص
        cols = {r['name'] for r in c.execute('PRAGMA table_info(people)')}
        if 'photo' not in cols: c.execute('ALTER TABLE people ADD COLUMN photo BLOB')
        # رمز پیش‌فرض مدیر فقط در اولین اجرا ساخته می‌شود؛ تغییر رمز در جدول تنظیمات نگهداری می‌شود.
        if not c.execute("SELECT 1 FROM app_settings WHERE key='admin_password_hash'").fetchone():
            c.execute("INSERT INTO app_settings(key,value) VALUES('admin_password_hash',?)", (generate_password_hash('123456'),))
        admin_hash = c.execute("SELECT value FROM app_settings WHERE key='admin_password_hash'").fetchone()['value']
        if not c.execute("SELECT 1 FROM users WHERE username='admin'").fetchone():
            c.execute("INSERT INTO users(username,password_hash,role) VALUES('admin',?,'admin')", (admin_hash,))
        c.execute("INSERT OR IGNORE INTO app_settings(key,value) VALUES('license_activated',?)", ('1' if existing_install else '0',))
        c.execute("INSERT OR IGNORE INTO app_settings(key,value) VALUES('app_title',?)", ('شجره‌نامه قوم بلوچ',))
        # شناسه افراد موجود در همین دیتابیس تازه
        rows = c.execute("SELECT id FROM people WHERE person_code IS NULL OR person_code='' ").fetchall()
        for row in rows:
            c.execute('UPDATE people SET person_code=? WHERE id=?', (f'P-{row[0]:06d}', row[0]))
        # اصلاح داده‌های قدیمی: برای فرزندانی که فقط پدر دارند و پدر دقیقاً یک همسر ثبت‌شده دارد،
        # رابطه مادر نیز به‌صورت خودکار ثبت می‌شود تا اتصال از نقطه مشترک زوج قابل رسم باشد.
        c.execute('''INSERT OR IGNORE INTO parent_links(parent_id,child_id,relation)
                     SELECT m.wife_id, f.child_id, 'مادر'
                     FROM parent_links f
                     JOIN marriages m ON m.husband_id=f.parent_id
                     WHERE f.relation='پدر'
                       AND (SELECT COUNT(DISTINCT m2.wife_id) FROM marriages m2 WHERE m2.husband_id=f.parent_id)=1
                       AND NOT EXISTS (SELECT 1 FROM parent_links x WHERE x.child_id=f.child_id AND x.relation='مادر')''')


def norm(s):
    s = str(s or '').strip().lower().replace('ي','ی').replace('ى','ی').replace('ك','ک')
    return re.sub(r'[\s\u200c\u200f]+', '', s)


def person(c, pid):
    return c.execute('SELECT * FROM people WHERE id=?', (pid,)).fetchone()


def active_marriages(c, pid):
    return c.execute('''SELECT m.*, h.first_name||' '||h.last_name AS husband_name,
      w.first_name||' '||w.last_name AS wife_name
      FROM marriages m JOIN people h ON h.id=m.husband_id JOIN people w ON w.id=m.wife_id
      WHERE (m.husband_id=? OR m.wife_id=?) AND COALESCE(m.end_date,'')='' ORDER BY m.id''', (pid,pid)).fetchall()


def validate_parent(c, parent_id, child_id, relation):
    p, ch = person(c,parent_id), person(c,child_id)
    if not p or not ch: return 'شخص موردنظر پیدا نشد.'
    if parent_id == child_id: return 'یک شخص نمی‌تواند والد خودش باشد.'
    expected = 'مرد' if relation == 'پدر' else 'زن'
    if p['gender'] != expected: return f'برای رابطه {relation} جنسیت باید {expected} باشد.'
    existing = c.execute('SELECT relation,parent_id FROM parent_links WHERE child_id=? AND relation=?', (child_id,relation)).fetchone()
    if existing and existing['parent_id'] != parent_id: return f'برای این فرزند قبلاً {relation} ثبت شده است.'
    # جلوگیری از چرخه: فرزند نباید از قبل جدّ/والدِ والد جدید باشد.
    q = '''WITH RECURSIVE descendants(id) AS (
             SELECT child_id FROM parent_links WHERE parent_id=?
             UNION SELECT pl.child_id FROM parent_links pl JOIN descendants d ON pl.parent_id=d.id
           ) SELECT 1 FROM descendants WHERE id=? LIMIT 1'''
    if c.execute(q,(child_id,parent_id)).fetchone(): return 'این رابطه باعث ایجاد چرخه در شجره‌نامه می‌شود.'
    return None


def decode_person_photo(data):
    raw = data.get('photo_data') or ''
    if not raw: return None
    if not raw.startswith('data:image/jpeg;base64,'): raise ValueError('تصویر باید JPEG باشد.')
    import base64, binascii
    try: blob = base64.b64decode(raw.split(',',1)[1], validate=True)
    except (binascii.Error, ValueError): raise ValueError('اطلاعات تصویر معتبر نیست.')
    if len(blob) > 50 * 1024: raise ValueError('حجم تصویر فشرده‌شده باید حداکثر ۵۰ کیلوبایت باشد.')
    if not blob.startswith(b'\xff\xd8\xff'): raise ValueError('فایل تصویر JPEG معتبر نیست.')
    return blob


def make_person(c, data, forced_gender=None):
    first = (data.get('first_name') or '').strip()
    last = (data.get('last_name') or '').strip()
    gender = forced_gender or data.get('gender')
    if not first: raise ValueError('نام الزامی است.')
    if gender not in ('مرد','زن'): raise ValueError('جنسیت را مشخص کنید.')
    cur = c.execute('''INSERT INTO people(first_name,last_name,gender,birth_date,tribe,job,phone,city,notes,photo)
      VALUES(?,?,?,?,?,?,?,?,?,?)''', (first,last,gender,data.get('birth_date',''),data.get('tribe',''),data.get('job',''),data.get('phone',''),data.get('city',''),data.get('notes',''),decode_person_photo(data)))
    pid = cur.lastrowid
    code = f'P-{pid:06d}'
    c.execute('UPDATE people SET person_code=? WHERE id=?',(code,pid))
    return pid


ACTIVATE_PAGE = r'''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#142b45"><title>فعال‌سازی | شجره قوم بلوچ</title><style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:18px;background:radial-gradient(circle at 15% 10%,#426b84,#10263e 68%);font-family:Tahoma,Arial,sans-serif}.card{width:min(470px,100%);background:#fff;border-radius:25px;padding:27px;box-shadow:0 25px 80px #0005}.logo{width:68px;height:68px;margin:0 auto 13px;border-radius:21px;background:linear-gradient(135deg,#e5c16e,#a87927);display:grid;place-items:center;font-size:35px}.card h1{text-align:center;color:#173650;font-size:21px;margin:0 0 10px}.card p{text-align:center;color:#66788a;font-size:13px;line-height:2;margin:0 0 17px}.card label{display:block;margin:13px 0 6px;color:#40546a;font-size:13px}.card input{width:100%;padding:14px;border:1px solid #d8e0e9;border-radius:12px;font:inherit;font-size:16px;direction:ltr;text-align:center;letter-spacing:1px}.card button{width:100%;margin-top:18px;padding:14px;border:0;border-radius:12px;background:#173b58;color:#fff;font:inherit;font-weight:bold}.err{display:none;color:#a52835;background:#fff0f1;border-radius:10px;padding:10px;font-size:12px;line-height:1.9;margin-top:12px;text-align:center}.contact{text-align:center;color:#718095;font-size:12px;margin-top:14px}.credit{text-align:center;color:#9aa8b5;font-size:11px;margin-top:17px}.top{position:relative;direction:rtl;padding-left:78px}.menu-toggle{position:absolute;left:18px;top:50%;transform:translateY(-50%);z-index:42}.actions{position:fixed!important;z-index:41;left:0;right:auto;top:0;bottom:0;width:min(310px,84vw)!important;height:100dvh;display:flex!important;flex-direction:column;align-items:stretch;justify-content:flex-start;gap:9px;padding:18px 14px calc(18px + env(safe-area-inset-bottom));border:0;border-radius:0 18px 18px 0;background:#142b45;box-shadow:12px 0 35px #0003;transform:translateX(-110%);transition:transform .25s ease;overflow:auto}.actions.open{transform:translateX(0)}.actions .btn{width:100%;justify-content:flex-start;color:#173650;background:#f3f6f9}.actions .btn.primary{background:#c89b42;color:white}.drawer-title{display:flex;justify-content:space-between;align-items:center;color:white;font-weight:bold;font-size:17px;padding:7px 5px 16px;border-bottom:1px solid #ffffff30;margin-bottom:6px}.drawer-title button{border:0;background:#ffffff20;color:white;border-radius:8px;font-size:24px;width:36px;height:36px}.menu-shade{display:none;position:fixed;inset:0;background:#07142188;z-index:40}.menu-shade.open{display:block}@media(max-width:650px){.top{display:flex;min-height:84px;padding-right:12px;padding-left:70px}.top .actions{display:flex!important;grid-template-columns:none;width:min(310px,84vw)!important}.top .actions.open{display:flex!important}.menu-toggle{left:14px}}


</style></head><body><form class="card" method="post" action="/activate"><div class="logo">🌳</div><h1>برنامه شجره قوم بلوچ</h1><p>برای خرید برنامه و فعال‌سازی با برنامه‌نویس تماس بگیرید.</p>{% if error %}<div class="err" style="display:block">{{ error }}</div>{% endif %}<label>کد ریجستر 1</label><input name="code1" inputmode="numeric" maxlength="15" pattern="[0-9]{15}" required><label>کد ریجستر 2</label><input name="code2" autocomplete="off" required><button type="submit">فعال‌سازی</button><div class="contact">برای فعال‌سازی با شماره 09159499928 تماس بگیرید.</div><div class="credit">طراحی و برنامه‌نویسی: محمد عمر خاوران</div></form></body></html>'''

LOGIN_PAGE = r'''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover"><meta name="theme-color" content="#142b45"><title>ورود | شجره قوم بلوچ</title><style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:20px;background:radial-gradient(circle at top right,#315d7a,#10263e 65%);font-family:Tahoma,Arial,sans-serif}.login{width:min(420px,100%);background:#fff;border-radius:24px;padding:30px;box-shadow:0 25px 80px #0005}.logo{width:70px;height:70px;margin:0 auto 15px;border-radius:22px;background:linear-gradient(135deg,#d9b35e,#9b7026);display:grid;place-items:center;font-size:36px}.login h1{text-align:center;color:#173650;font-size:22px;margin:0 0 8px}.login p{text-align:center;color:#718095;font-size:13px;margin:0 0 24px}.login label{display:block;font-size:13px;margin:12px 0 7px;color:#40546a}.login input{width:100%;padding:14px;border:1px solid #d9e1e9;border-radius:12px;font:inherit;font-size:16px}.login button{width:100%;margin-top:18px;padding:13px;border:0;border-radius:12px;background:#173b58;color:#fff;font:inherit;font-weight:bold}.err{color:#b83242;background:#fff0f1;border-radius:9px;padding:9px;font-size:12px;margin-bottom:10px}.credit{text-align:center;color:#9aa8b5;font-size:11px;margin-top:20px}.top{position:relative;direction:rtl;padding-left:78px}.menu-toggle{position:absolute;left:18px;top:50%;transform:translateY(-50%);z-index:42}.actions{position:fixed!important;z-index:41;left:0;right:auto;top:0;bottom:0;width:min(310px,84vw)!important;height:100dvh;display:flex!important;flex-direction:column;align-items:stretch;justify-content:flex-start;gap:9px;padding:18px 14px calc(18px + env(safe-area-inset-bottom));border:0;border-radius:0 18px 18px 0;background:#142b45;box-shadow:12px 0 35px #0003;transform:translateX(-110%);transition:transform .25s ease;overflow:auto}.actions.open{transform:translateX(0)}.actions .btn{width:100%;justify-content:flex-start;color:#173650;background:#f3f6f9}.actions .btn.primary{background:#c89b42;color:white}.drawer-title{display:flex;justify-content:space-between;align-items:center;color:white;font-weight:bold;font-size:17px;padding:7px 5px 16px;border-bottom:1px solid #ffffff30;margin-bottom:6px}.drawer-title button{border:0;background:#ffffff20;color:white;border-radius:8px;font-size:24px;width:36px;height:36px}.menu-shade{display:none;position:fixed;inset:0;background:#07142188;z-index:40}.menu-shade.open{display:block}@media(max-width:650px){.top{display:flex;min-height:84px;padding-right:12px;padding-left:70px}.top .actions{display:flex!important;grid-template-columns:none;width:min(310px,84vw)!important}.top .actions.open{display:flex!important}.menu-toggle{left:14px}}</style></head><body><form class="login" method="post"><div class="logo">🌳</div><h1>شجره‌نامه قوم بلوچ</h1><p>نام کاربری و رمز عبور را وارد کنید</p>{% if error %}<div class="err">{{ error }}</div>{% endif %}<label>نام کاربری</label><input name="username" required autofocus autocomplete="username"><label>رمز عبور</label><input type="password" name="password" required autocomplete="current-password"><button type="submit">ورود به سامانه</button><div class="credit">طراحی و برنامه‌نویسی: محمد عمر خاوران</div></form></body></html>'''

@app.before_request
def require_login():
    if request.endpoint in {'activate','login','static'} or request.endpoint is None:
        with db() as c: row=c.execute("SELECT value FROM app_settings WHERE key='license_activated'").fetchone()
        if (not row or row['value']!='1') and request.endpoint!='activate': return redirect(url_for('activate'))
        return None
    with db() as c: row=c.execute("SELECT value FROM app_settings WHERE key='license_activated'").fetchone()
    if not row or row['value']!='1': return redirect(url_for('activate'))
    if not session.get('logged_in'):
        if request.path.startswith('/api/'): return jsonify(error='برای ادامه ابتدا وارد سامانه شوید.'),401
        return redirect(url_for('login'))

@app.route('/activate',methods=['GET','POST'])
def activate():
    with db() as c: row=c.execute("SELECT value FROM app_settings WHERE key='license_activated'").fetchone()
    if row and row['value']=='1': return redirect(url_for('login'))
    error=''
    if request.method=='POST':
        code1=(request.form.get('code1') or '').strip(); code2=(request.form.get('code2') or '').strip().upper()
        if not re.fullmatch(r'\d{15}',code1): error='کد ریجستر 1 باید دقیقاً ۱۵ رقم باشد.'
        else:
            expected=code1[5:10]+'DOA'+code1[11:15]+'RE'+code1[0:5]+code1[10]
            if secrets.compare_digest(expected,code2):
                with db() as c: c.execute("INSERT INTO app_settings(key,value) VALUES('license_activated','1') ON CONFLICT(key) DO UPDATE SET value='1'")
                return redirect(url_for('login'))
            error='کد شما نامعتبر است. لطفاً برای فعال‌سازی با شماره 09159499928 تماس بگیرید.'
    return render_template_string(ACTIVATE_PAGE,error=error)

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        username=(request.form.get('username') or '').strip(); password=request.form.get('password','')
        with db() as c: row=c.execute('SELECT id,username,password_hash,role FROM users WHERE username=?',(username,)).fetchone()
        if row and check_password_hash(row['password_hash'],password):
            session.clear();session.update(logged_in=True,user_id=row['id'],username=row['username'],role=row['role'])
            return redirect(url_for('index'))
        return render_template_string(LOGIN_PAGE,error='نام کاربری یا رمز عبور نادرست است.')
    return render_template_string(LOGIN_PAGE,error='')

@app.get('/logout')
def logout(): session.clear();return redirect(url_for('login'))

@app.post('/api/change-password')
def change_password():
    data=request.get_json(force=True);old=data.get('old_password','');new=data.get('new_password','');username=(data.get('username') or session.get('username','')).strip()
    if len(new)<6:return jsonify(error='رمز جدید باید حداقل ۶ کاراکتر باشد.'),400
    if not username:return jsonify(error='نام کاربری الزامی است.'),400
    with db() as c:
        row=c.execute('SELECT * FROM users WHERE id=?',(session.get('user_id'),)).fetchone()
        if not row or not check_password_hash(row['password_hash'],old):return jsonify(error='رمز فعلی صحیح نیست.'),400
        try:c.execute('UPDATE users SET username=?,password_hash=? WHERE id=?',(username,generate_password_hash(new),row['id']))
        except sqlite3.IntegrityError:return jsonify(error='این نام کاربری قبلاً استفاده شده است.'),409
    session['username']=username;return jsonify(ok=True)

@app.post('/api/settings/title')
def update_app_title():
    data=request.get_json(force=True)
    if str(data.get('settings_password','')) != '10246600':
        return jsonify(error='رمز ورود به تنظیمات صحیح نیست.'),403
    title=(data.get('title') or '').strip()
    if not title or len(title)>60:
        return jsonify(error='عنوان باید بین ۱ تا ۶۰ نویسه باشد.'),400
    hide_women = '1' if data.get('hide_women') else '0'
    main_tribe_only = '1' if data.get('main_tribe_only') else '0'
    with db() as c:
        c.execute("INSERT INTO app_settings(key,value) VALUES('app_title',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(title,))
        c.execute("INSERT INTO app_settings(key,value) VALUES('hide_women',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(hide_women,))
        c.execute("INSERT INTO app_settings(key,value) VALUES('main_tribe_only',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(main_tribe_only,))
    return jsonify(ok=True,title=title,hide_women=hide_women=='1',main_tribe_only=main_tribe_only=='1')

@app.get('/api/users')
def list_users():
    if session.get('role')!='admin':return jsonify(error='فقط مدیر اجازه مدیریت کاربران را دارد.'),403
    with db() as c:rows=[dict(x) for x in c.execute('SELECT id,username,role,created_at FROM users ORDER BY id')]
    return jsonify(rows)

@app.post('/api/users')
def create_user():
    if session.get('role')!='admin':return jsonify(error='فقط مدیر اجازه افزودن کاربر را دارد.'),403
    data=request.get_json(force=True);username=(data.get('username') or '').strip();password=data.get('password') or '';role=data.get('role') or 'user'
    if len(username)<3:return jsonify(error='نام کاربری باید حداقل ۳ نویسه باشد.'),400
    if len(password)<6:return jsonify(error='رمز عبور باید حداقل ۶ نویسه باشد.'),400
    if role not in ('user','admin'):return jsonify(error='سطح دسترسی نامعتبر است.'),400
    try:
        with db() as c:c.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)',(username,generate_password_hash(password),role))
    except sqlite3.IntegrityError:return jsonify(error='این نام کاربری قبلاً ثبت شده است.'),409
    return jsonify(ok=True)

@app.delete('/api/users/<int:uid>')
def delete_user(uid):
    if session.get('role')!='admin':return jsonify(error='فقط مدیر اجازه حذف کاربر را دارد.'),403
    if uid==session.get('user_id'):return jsonify(error='نمی‌توانید حسابی را که با آن وارد شده‌اید حذف کنید.'),400
    with db() as c:
        row=c.execute('SELECT role FROM users WHERE id=?',(uid,)).fetchone()
        if not row:return jsonify(error='کاربر پیدا نشد.'),404
        if row['role']=='admin' and c.execute("SELECT COUNT(*) n FROM users WHERE role='admin'").fetchone()['n']<=1:return jsonify(error='حداقل یک مدیر باید باقی بماند.'),400
        c.execute('DELETE FROM users WHERE id=?',(uid,))
    return jsonify(ok=True)

USERS_PAGE = r'''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>مدیریت کاربران</title><style>*{box-sizing:border-box}body{margin:0;background:#f3f6fa;color:#20364b;font-family:Tahoma,Arial,sans-serif}.head{background:#173b58;color:white;padding:18px 20px;display:flex;justify-content:space-between;align-items:center}.wrap{max-width:850px;margin:22px auto;padding:0 14px}.card{background:white;border:1px solid #e0e7ef;border-radius:16px;padding:18px;margin-bottom:15px;box-shadow:0 5px 18px #173b580c}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}input,select{width:100%;padding:12px;border:1px solid #d3dce6;border-radius:10px;font:inherit;margin-top:6px}button,.back{border:0;border-radius:10px;padding:11px 15px;background:#173b58;color:white;font:inherit;cursor:pointer;text-decoration:none;display:inline-block}.danger{background:#b83c48}.user{padding:12px;border-bottom:1px solid #edf1f5;display:flex;justify-content:space-between;align-items:center;gap:10px}.muted{color:#75869a;font-size:12px}@media(max-width:500px){.user{align-items:flex-start;flex-direction:column}}.top{position:relative;direction:rtl;padding-left:78px}.menu-toggle{position:absolute;left:18px;top:50%;transform:translateY(-50%);z-index:42}.actions{position:fixed!important;z-index:41;left:0;right:auto;top:0;bottom:0;width:min(310px,84vw)!important;height:100dvh;display:flex!important;flex-direction:column;align-items:stretch;justify-content:flex-start;gap:9px;padding:18px 14px calc(18px + env(safe-area-inset-bottom));border:0;border-radius:0 18px 18px 0;background:#142b45;box-shadow:12px 0 35px #0003;transform:translateX(-110%);transition:transform .25s ease;overflow:auto}.actions.open{transform:translateX(0)}.actions .btn{width:100%;justify-content:flex-start;color:#173650;background:#f3f6f9}.actions .btn.primary{background:#c89b42;color:white}.drawer-title{display:flex;justify-content:space-between;align-items:center;color:white;font-weight:bold;font-size:17px;padding:7px 5px 16px;border-bottom:1px solid #ffffff30;margin-bottom:6px}.drawer-title button{border:0;background:#ffffff20;color:white;border-radius:8px;font-size:24px;width:36px;height:36px}.menu-shade{display:none;position:fixed;inset:0;background:#07142188;z-index:40}.menu-shade.open{display:block}@media(max-width:650px){.top{display:flex;min-height:84px;padding-right:12px;padding-left:70px}.top .actions{display:flex!important;grid-template-columns:none;width:min(310px,84vw)!important}.top .actions.open{display:flex!important}.menu-toggle{left:14px}}</style></head><body><header class="head"><b>مدیریت کاربران</b><a class="back" href="/">بازگشت به شجره‌نامه</a></header><main class="wrap"><section class="card"><h3>افزودن کاربر جدید</h3><div class="grid"><label>نام کاربری<input id="un" autocomplete="off"></label><label>رمز عبور<input id="pw" type="password"></label><label>سطح دسترسی<select id="role"><option value="user">کاربر</option><option value="admin">مدیر</option></select></label></div><p class="muted">نام کاربری حداقل ۳ و رمز عبور حداقل ۶ نویسه باشد.</p><button onclick="addUser()">ثبت کاربر</button></section><section class="card"><h3>فهرست کاربران</h3><div id="list">در حال دریافت...</div></section></main><script>async function api(u,o={}){let r=await fetch(u,{headers:{'Content-Type':'application/json'},...o});let j=await r.json();if(!r.ok)throw Error(j.error||'خطا');return j}async function load(){try{let a=await api('/api/users');document.getElementById('list').innerHTML=a.map(x=>`<div class="user"><span><b>${x.username}</b> <small class="muted">· ${x.role==='admin'?'مدیر':'کاربر'}</small></span>${x.id!=={{ session.get('user_id',0) }}?`<button class="danger" onclick="removeUser(${x.id})">حذف</button>`:'<small class="muted">حساب فعلی</small>'}</div>`).join('')||'کاربری ثبت نشده است.'}catch(e){document.getElementById('list').textContent=e.message}}async function addUser(){try{await api('/api/users',{method:'POST',body:JSON.stringify({username:document.getElementById('un').value,password:document.getElementById('pw').value,role:document.getElementById('role').value})});document.getElementById('un').value='';document.getElementById('pw').value='';alert('کاربر ثبت شد.');load()}catch(e){alert(e.message)}}async function removeUser(id){if(!confirm('کاربر حذف شود؟'))return;try{await api('/api/users/'+id,{method:'DELETE'});load()}catch(e){alert(e.message)}}load();</script></body></html>'''

@app.get('/users')
def users_page():
    if session.get('role')!='admin': abort(403)
    return render_template_string(USERS_PAGE)

@app.get('/')
def index():
    with db() as c:
        row=c.execute("SELECT value FROM app_settings WHERE key='app_title'").fetchone()
    return render_template_string(PAGE, app_title=(row['value'] if row else 'شجره‌نامه قوم بلوچ'))


@app.get('/api/tree')
def tree_data():
    with db() as c:
        people = [dict(r) for r in c.execute('SELECT id,person_code,first_name,last_name,gender,birth_date,death_date,tribe,job,phone,city,notes,created_at, CASE WHEN photo IS NULL THEN 0 ELSE 1 END AS has_photo FROM people ORDER BY id')]
        marriages = [dict(r) for r in c.execute('SELECT * FROM marriages ORDER BY id')]
        parents = [dict(r) for r in c.execute('SELECT * FROM parent_links ORDER BY id')]
        settings = {r['key']:r['value'] for r in c.execute("SELECT key,value FROM app_settings WHERE key IN ('hide_women','main_tribe_only')")}
    return jsonify(people=people, marriages=marriages, parents=parents, settings={'hide_women':settings.get('hide_women')=='1','main_tribe_only':settings.get('main_tribe_only')=='1'})


@app.get('/api/search')
def search_people():
    # جستجوی برنامه عمداً فقط روی سه فیلد کارت انجام می‌شود:
    # نام، نام خانوادگی و قوم/طایفه. شناسه، تلفن، شغل و روابط خانوادگی جستجو نمی‌شوند.
    q = norm(request.args.get('q', ''))
    with db() as c:
        rows = c.execute('''SELECT id,person_code,first_name,last_name,gender,tribe FROM people ORDER BY first_name,last_name''').fetchall()
        out = []
        for r in rows:
            searchable = norm(' '.join((r['first_name'] or '', r['last_name'] or '', r['tribe'] or '')))
            if not q or q in searchable:
                out.append({
                    'id': r['id'], 'person_code': r['person_code'],
                    'first_name': r['first_name'], 'last_name': r['last_name'],
                    'gender': r['gender'], 'tribe': r['tribe'] or ''
                })
    return jsonify(items=out, count=len(out))


@app.post('/api/person')
def add_person():
    data=request.get_json(force=True)
    try:
        with db() as c: pid=make_person(c,data)
        return jsonify(ok=True,id=pid)
    except Exception as e: return jsonify(error=str(e)),400


@app.put('/api/person/<int:pid>')
def edit_person(pid):
    data=request.get_json(force=True)
    try:
        with db() as c:
            p=person(c,pid)
            if not p: return jsonify(error='شخص پیدا نشد.'),404
            gender=data.get('gender',p['gender'])
            first=(data.get('first_name',p['first_name']) or '').strip()
            if not first: raise ValueError('نام الزامی است.')
            if gender not in ('مرد','زن'): raise ValueError('جنسیت نامعتبر است.')
            # تغییر جنسیت با روابط ثبت‌شده می‌تواند ناسازگاری ایجاد کند.
            if gender != p['gender']:
                if c.execute('SELECT 1 FROM parent_links WHERE parent_id=? LIMIT 1',(pid,)).fetchone() or c.execute('SELECT 1 FROM marriages WHERE husband_id=? OR wife_id=? LIMIT 1',(pid,pid)).fetchone():
                    raise ValueError('برای تغییر جنسیت، ابتدا روابط ثبت‌شده این شخص را اصلاح کنید.')
            photo = decode_person_photo(data) if data.get('photo_data') else None
            if photo is not None:
                c.execute('''UPDATE people SET first_name=?,last_name=?,gender=?,birth_date=?,tribe=?,job=?,phone=?,city=?,notes=?,photo=? WHERE id=?''',
                  (first,(data.get('last_name',p['last_name']) or '').strip(),gender,data.get('birth_date',''),data.get('tribe',''),data.get('job',''),data.get('phone',''),data.get('city',''),data.get('notes',''),photo,pid))
            elif data.get('remove_photo'):
                c.execute('''UPDATE people SET first_name=?,last_name=?,gender=?,birth_date=?,tribe=?,job=?,phone=?,city=?,notes=?,photo=NULL WHERE id=?''',
                  (first,(data.get('last_name',p['last_name']) or '').strip(),gender,data.get('birth_date',''),data.get('tribe',''),data.get('job',''),data.get('phone',''),data.get('city',''),data.get('notes',''),pid))
            else:
                c.execute('''UPDATE people SET first_name=?,last_name=?,gender=?,birth_date=?,tribe=?,job=?,phone=?,city=?,notes=? WHERE id=?''',
                  (first,(data.get('last_name',p['last_name']) or '').strip(),gender,data.get('birth_date',''),data.get('tribe',''),data.get('job',''),data.get('phone',''),data.get('city',''),data.get('notes',''),pid))
        return jsonify(ok=True)
    except Exception as e: return jsonify(error=str(e)),400


@app.post('/api/related')
def related_person():
    data=request.get_json(force=True)
    try:
        base_id=int(data.get('base_id'))
        rel=data.get('relation')
        with db() as c:
            base=person(c,base_id)
            if not base: raise ValueError('شخص پایه پیدا نشد.')
            if rel not in ('پدر','مادر','همسر','پسر','دختر'): raise ValueError('نوع رابطه نامعتبر است.')
            forced={'پدر':'مرد','مادر':'زن','پسر':'مرد','دختر':'زن'}.get(rel)
            if rel=='همسر': forced='زن' if base['gender']=='مرد' else 'مرد'
            if data.get('existing_id'):
                target_id=int(data['existing_id'])
                target=person(c,target_id)
                if not target: raise ValueError('شخص انتخاب‌شده وجود ندارد.')
                if target['gender']!=forced: raise ValueError('جنسیت شخص انتخاب‌شده با این رابطه سازگار نیست.')
            else:
                target_id=make_person(c,data,forced)
            err=apply_relation(c,base_id,target_id,rel,data)
            if err: raise ValueError(err)
        return jsonify(ok=True,id=target_id)
    except Exception as e:
        return jsonify(error=str(e)),400


@app.post('/api/relation')
def add_existing_relation():
    data=request.get_json(force=True)
    try:
        base_id=int(data.get('base_id')); target_id=int(data.get('target_id')); rel=data.get('relation')
        with db() as c:
            if not person(c,base_id) or not person(c,target_id): raise ValueError('شخص انتخاب‌شده پیدا نشد.')
            err=apply_relation(c,base_id,target_id,rel,data)
            if err: raise ValueError(err)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)),400


def apply_relation(c,base_id,target_id,rel,data):
    base,target=person(c,base_id),person(c,target_id)
    if not base or not target: return 'شخص پیدا نشد.'
    if base_id==target_id: return 'یک شخص نمی‌تواند با خودش رابطه داشته باشد.'
    if rel in ('پدر','مادر'):
        err=validate_parent(c,target_id,base_id,rel)
        if err: return err
        c.execute('INSERT OR IGNORE INTO parent_links(parent_id,child_id,relation) VALUES(?,?,?)',(target_id,base_id,rel))
        if rel=='پدر':
            wives=c.execute('''SELECT DISTINCT w.id,w.first_name,w.last_name,w.person_code FROM marriages m
                               JOIN people w ON w.id=m.wife_id WHERE m.husband_id=? ORDER BY w.id''',(target_id,)).fetchall()
            mother_id=data.get('mother_id')
            if len(wives)==1:
                mother_id=wives[0]['id']
            elif len(wives)>1:
                if not mother_id or int(mother_id) not in [x['id'] for x in wives]:
                    return 'این پدر چند همسر دارد؛ مادر این فرزند را از فهرست انتخاب کنید.'
            if mother_id:
                mother_id=int(mother_id)
                err=validate_parent(c,mother_id,base_id,'مادر')
                if err: return err
                c.execute('INSERT OR IGNORE INTO parent_links(parent_id,child_id,relation) VALUES(?,?,?)',(mother_id,base_id,'مادر'))
        else:  # مادر ثبت شده؛ پدر را از میان شوهران او پیدا می‌کنیم.
            husbands=c.execute('''SELECT DISTINCT h.id,h.first_name,h.last_name,h.person_code FROM marriages m
                                  JOIN people h ON h.id=m.husband_id WHERE m.wife_id=? ORDER BY h.id''',(target_id,)).fetchall()
            father_id=data.get('father_id')
            if len(husbands)==1:
                father_id=husbands[0]['id']
            elif len(husbands)>1:
                if not father_id or int(father_id) not in [x['id'] for x in husbands]:
                    return 'این مادر چند ازدواج ثبت‌شده دارد؛ پدر این فرزند را انتخاب کنید.'
            if father_id:
                father_id=int(father_id)
                err=validate_parent(c,father_id,base_id,'پدر')
                if err: return err
                c.execute('INSERT OR IGNORE INTO parent_links(parent_id,child_id,relation) VALUES(?,?,?)',(father_id,base_id,'پدر'))
    elif rel in ('پسر','دختر'):
        expected_gender='مرد' if rel=='پسر' else 'زن'
        if target['gender']!=expected_gender: return f'جنسیت فرزند باید {expected_gender} باشد.'
        parent_role='پدر' if base['gender']=='مرد' else 'مادر'
        err=validate_parent(c,base_id,target_id,parent_role)
        if err: return err
        c.execute('INSERT OR IGNORE INTO parent_links(parent_id,child_id,relation) VALUES(?,?,?)',(base_id,target_id,parent_role))
        # اگر شخص پایه پدر است، مادر فرزند را از میان همسران او تعیین می‌کنیم.
        # یک همسر: ثبت خودکار؛ چند همسر: انتخاب صریح کاربر الزامی است.
        if parent_role == 'پدر':
            wives=c.execute('''SELECT DISTINCT w.id FROM marriages m JOIN people w ON w.id=m.wife_id
                               WHERE m.husband_id=? ORDER BY w.id''',(base_id,)).fetchall()
            mother_id=data.get('mother_id')
            if len(wives)==1:
                mother_id=wives[0]['id']
            elif len(wives)>1:
                if not mother_id or int(mother_id) not in [x['id'] for x in wives]:
                    return 'این پدر چند همسر دارد؛ مادر این فرزند را انتخاب کنید.'
            if mother_id:
                mother_id=int(mother_id)
                err=validate_parent(c,mother_id,target_id,'مادر')
                if err: return err
                c.execute('INSERT OR IGNORE INTO parent_links(parent_id,child_id,relation) VALUES(?,?,?)',(mother_id,target_id,'مادر'))
        else:
            husbands=c.execute('''SELECT DISTINCT h.id FROM marriages m JOIN people h ON h.id=m.husband_id
                                  WHERE m.wife_id=? ORDER BY h.id''',(base_id,)).fetchall()
            father_id=data.get('father_id')
            if len(husbands)==1:
                father_id=husbands[0]['id']
            elif len(husbands)>1:
                if not father_id or int(father_id) not in [x['id'] for x in husbands]:
                    return 'این مادر چند ازدواج ثبت‌شده دارد؛ پدر این فرزند را انتخاب کنید.'
            if father_id:
                father_id=int(father_id)
                err=validate_parent(c,father_id,target_id,'پدر')
                if err: return err
                c.execute('INSERT OR IGNORE INTO parent_links(parent_id,child_id,relation) VALUES(?,?,?)',(father_id,target_id,'پدر'))
    elif rel=='همسر':
        if base['gender']==target['gender']: return 'جنسیت دو همسر باید متفاوت باشد.'
        husband=base_id if base['gender']=='مرد' else target_id
        wife=target_id if base['gender']=='مرد' else base_id
        if active_marriages(c,wife): return 'این زن در حال حاضر ازدواج فعال دارد؛ ابتدا طلاق یا فوت همسر قبلی را ثبت کنید.'
        if c.execute("SELECT 1 FROM marriages WHERE husband_id=? AND wife_id=? AND COALESCE(end_date,'')=''",(husband,wife)).fetchone():
            return 'این ازدواج قبلاً ثبت شده است.'
        c.execute('INSERT INTO marriages(husband_id,wife_id,start_date) VALUES(?,?,?)',(husband,wife,data.get('start_date','')))
    else:
        return 'نوع رابطه نامعتبر است.'
    # نام طایفه از پدر به فرزند به ارث می‌رسد؛ چه فرزند تازه ساخته شده باشد
    # و چه از فهرست افراد موجود انتخاب شده باشد.
    child_id = target_id if rel in ('پسر','دختر') else base_id
    if rel in ('پدر','مادر','پسر','دختر'):
        father_link = c.execute(
            "SELECT p.tribe FROM parent_links l JOIN people p ON p.id=l.parent_id "
            "WHERE l.child_id=? AND l.relation='پدر'", (child_id,)
        ).fetchone()
        if father_link is not None:
            c.execute('UPDATE people SET tribe=? WHERE id=?', (father_link['tribe'] or '', child_id))
    return None


@app.get('/api/person/<int:pid>')
def get_person(pid):
    try:
        with db() as c:
            p=person(c,pid)
            if not p: return jsonify(ok=False,error='شخص موردنظر پیدا نشد.'),404
            result={k:p[k] for k in p.keys() if k!='photo'}
            result['has_photo']=bool(p['photo'])
            return jsonify(result)
    except Exception as e:
        app.logger.exception('get_person failed for id=%s', pid)
        return jsonify(ok=False,error='خطا در خواندن اطلاعات شخص: '+str(e)),500


@app.get('/api/person/<int:pid>/photo')
def person_photo(pid):
    from flask import Response
    with db() as c: row=c.execute('SELECT photo FROM people WHERE id=?',(pid,)).fetchone()
    if not row or not row['photo']: abort(404)
    return Response(row['photo'], mimetype='image/jpeg', headers={'Cache-Control':'no-store'})


@app.get('/api/person/<int:pid>/family')
def get_person_family(pid):
    with db() as c:
        p = person(c, pid)
        if not p:
            return jsonify(error='شخص پیدا نشد.'), 404
        def rows(sql, args):
            return [{k:x[k] for k in x.keys() if k!='photo'} for x in c.execute(sql, args).fetchall()]
        father = c.execute("""SELECT p.* FROM parent_links l JOIN people p ON p.id=l.parent_id
                              WHERE l.child_id=? AND l.relation='پدر' LIMIT 1""", (pid,)).fetchone()
        mother = c.execute("""SELECT p.* FROM parent_links l JOIN people p ON p.id=l.parent_id
                              WHERE l.child_id=? AND l.relation='مادر' LIMIT 1""", (pid,)).fetchone()
        children = rows("""SELECT DISTINCT p.*, l.relation AS parent_role FROM parent_links l
                           JOIN people p ON p.id=l.child_id WHERE l.parent_id=? ORDER BY p.first_name,p.last_name""", (pid,))
        spouses = rows("""SELECT p.*,m.id AS marriage_id,m.start_date,m.end_date,m.end_reason
                         FROM marriages m JOIN people p ON p.id=CASE WHEN m.husband_id=? THEN m.wife_id ELSE m.husband_id END
                         WHERE m.husband_id=? OR m.wife_id=? ORDER BY m.id""", (pid,pid,pid))
        siblings = rows("""SELECT DISTINCT s.* FROM parent_links mine
                          JOIN parent_links theirs ON theirs.parent_id=mine.parent_id
                          JOIN people s ON s.id=theirs.child_id
                          WHERE mine.child_id=? AND theirs.child_id<>? ORDER BY s.first_name,s.last_name""", (pid,pid))
        return jsonify(person={k:p[k] for k in p.keys() if k!='photo'}, father={k:father[k] for k in father.keys() if k!='photo'} if father else None,
                       mother={k:mother[k] for k in mother.keys() if k!='photo'} if mother else None, children=children,
                       spouses=spouses, siblings=siblings)


@app.get('/api/person/<int:pid>/marriages')
def get_marriages(pid):
    with db() as c:
        return jsonify([dict(x) for x in active_marriages(c,pid)])


@app.post('/api/death/<int:pid>')
def death(pid):
    data=request.get_json(force=True); d=data.get('death_date') or date.today().isoformat()
    with db() as c:
        if not person(c,pid): return jsonify(error='شخص پیدا نشد.'),404
        c.execute('UPDATE people SET death_date=? WHERE id=?',(d,pid))
        c.execute("UPDATE marriages SET end_date=?,end_reason='وفات' WHERE (husband_id=? OR wife_id=?) AND COALESCE(end_date,'')=''",(d,pid,pid))
    return jsonify(ok=True)


@app.post('/api/divorce/<int:mid>')
def divorce(mid):
    data=request.get_json(force=True); d=data.get('end_date') or date.today().isoformat()
    with db() as c:
        m=c.execute('SELECT * FROM marriages WHERE id=?',(mid,)).fetchone()
        if not m or m['end_date']: return jsonify(error='ازدواج فعال پیدا نشد.'),404
        c.execute("UPDATE marriages SET end_date=?,end_reason='طلاق' WHERE id=?",(d,mid))
    return jsonify(ok=True)


@app.post('/api/marriage/restore-divorce/<int:mid>')
def restore_divorce(mid):
    # حذف نشان طلاق فقط وقتی مجاز است که این ازدواج با طلاق پایان یافته باشد.
    with db() as c:
        m=c.execute('SELECT * FROM marriages WHERE id=?',(mid,)).fetchone()
        if not m or m['end_reason']!='طلاق':
            return jsonify(error='رابطه طلاق‌شده پیدا نشد.'),404
        # زن نمی‌تواند هم‌زمان دو ازدواج فعال داشته باشد؛ قبل از بازگردانی این شرط بررسی می‌شود.
        other=c.execute("SELECT 1 FROM marriages WHERE wife_id=? AND id<>? AND COALESCE(end_date,'')='' LIMIT 1",(m['wife_id'],mid)).fetchone()
        if other:
            return jsonify(error='این زن در حال حاضر ازدواج فعال دیگری دارد. ابتدا وضعیت آن ازدواج را مشخص کنید.'),409
        c.execute("UPDATE marriages SET end_date='',end_reason='' WHERE id=?",(mid,))
    return jsonify(ok=True)


@app.delete('/api/person/<int:pid>')
def delete_person(pid):
    with db() as c:
        if not person(c,pid): return jsonify(error='شخص پیدا نشد.'),404
        c.execute('DELETE FROM people WHERE id=?',(pid,))
    return jsonify(ok=True)


@app.get('/backup')
def backup():
    if not os.path.exists(DB_PATH): abort(404)
    return send_file(DB_PATH,as_attachment=True,download_name='shajareh-backup.db')


@app.post('/restore')
def restore():
    f=request.files.get('database')
    if not f: return 'فایل دیتابیس انتخاب نشده است.',400
    tmp=DB_PATH+'.upload'
    f.save(tmp)
    try:
        test=sqlite3.connect(tmp)
        names={r[0] for r in test.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        test.close()
        if not {'people','marriages','parent_links'}.issubset(names): raise ValueError('ساختار فایل دیتابیس معتبر نیست.')
        # نسخه فعلی پیش از بازیابی نگهداری می‌شود.
        if os.path.exists(DB_PATH): shutil.copy2(DB_PATH,DB_PATH+'.before-restore')
        os.replace(tmp,DB_PATH)
        return '<script>alert("بازیابی انجام شد.");location.href="/";</script>'
    except Exception as e:
        if os.path.exists(tmp): os.remove(tmp)
        return f'خطا در بازیابی: {e}',400


PAGE = r'''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#142b45"><title>شجره‌نامه خانوادگی خاوران</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&display=swap');
:root{--navy:#142b45;--gold:#c89b42;--bg:#f4f6fa;--line:#b8c4d2}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Vazirmatn,Tahoma,sans-serif;color:#243247}.top{background:linear-gradient(120deg,#10263e,#244b69);color:white;padding:22px 26px;display:flex;align-items:center;justify-content:space-between;gap:15px;flex-wrap:wrap}.top h1{margin:0;font-size:23px;cursor:pointer;user-select:none}.top p{margin:5px 0 0;color:#d7e4ed}.actions{display:none;gap:8px;flex-wrap:wrap;width:100%;padding:12px;background:#ffffff12;border:1px solid #ffffff2a;border-radius:13px}.actions.open{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr))}.btn{border:0;border-radius:10px;padding:10px 15px;font:inherit;cursor:pointer;background:#e9eef4;color:#18334d}.btn.primary{background:var(--gold);color:#fff}.btn.dark{background:#183b58;color:white}.btn.danger{background:#b83c48;color:white}.layout{padding:18px;max-width:1600px;margin:auto}.toolbar{background:white;border:1px solid #e2e8ef;border-radius:14px;padding:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;box-shadow:0 4px 15px #2432470a}.toolbar input{flex:1;min-width:220px}.input,select,textarea{width:100%;padding:10px 12px;border:1px solid #d4dde7;border-radius:9px;font:inherit;background:white}.treebox{position:relative;margin-top:15px;background:#fff;border:1px solid #e1e7ee;border-radius:16px;min-height:610px;height:auto;overflow:visible;box-shadow:0 5px 20px #1a2d430b}.treecanvas{position:relative;width:100%;height:78vh;min-height:610px;overflow:auto;background-image:radial-gradient(#dce3eb 1px,transparent 1px);background-size:22px 22px}.world-space{position:relative;display:block;flex:none;left:0;top:0;pointer-events:none;z-index:0;min-width:1px;min-height:1px}.world{position:absolute;left:0;top:0;min-width:100%;min-height:100%;transform-origin:0 0;z-index:1}.nodes{position:absolute;left:0;top:0;width:100%;height:100%;z-index:4}.node{position:absolute;width:190px;min-height:122px;border-radius:13px;background:#fff;border:2px solid #d4dce6;box-shadow:0 5px 15px #26384b16;padding:11px 12px;cursor:pointer;z-index:4}.node.male{border-color:#6b9ec8;background:#f2f8ff}.node.female{border-color:#d78aaa;background:#fff5f9}.node.dead{opacity:.68;filter:grayscale(.45)}.node.selected{outline:3px solid var(--gold);outline-offset:3px}.node-zoom{position:absolute;left:5px;top:5px;width:27px;height:27px;border:0;border-radius:8px;background:#173b58;color:#fff;font-size:17px;line-height:1;z-index:8;cursor:pointer;touch-action:manipulation}.node .name{font-weight:800;font-size:14px;margin:4px 0}.node .code{font-size:11px;color:#65768a;direction:ltr;text-align:right}.node .meta{font-size:11px;color:#5d6d7d}.node .tribe{font-size:11px;color:#7b5b22;margin-top:5px;padding-top:4px;border-top:1px dashed #d9dfe6}.badge{display:inline-block;border-radius:20px;background:#e7edf4;padding:2px 7px;font-size:10px}.edges{position:absolute;left:0;top:0;right:auto;bottom:auto;display:block;z-index:3;overflow:visible;pointer-events:none}.edges .divorce-marker{pointer-events:all;cursor:pointer}.edges .divorce-marker:hover path{stroke-width:4.5}.edge-marriage{stroke:#c99a3b;stroke-width:2.5;fill:none}.edge-father{stroke:#4284b8;stroke-width:2;fill:none}.edge-mother{stroke:#d47a9d;stroke-width:2;fill:none}.zoomtools{position:absolute;left:14px;top:14px;z-index:5;display:flex;gap:5px}.zoomtools button{width:38px;height:38px;border:0;border-radius:9px;background:#173b58;color:#fff;font-size:20px;cursor:pointer}.hint{font-size:12px;color:#718095;margin:12px 4px}.empty{padding:90px 20px;text-align:center;color:#8290a0}.modal{display:none;position:fixed;inset:0;background:#101e2c88;z-index:20;align-items:center;justify-content:center;padding:14px}.dialog{background:white;border-radius:17px;width:min(620px,100%);max-height:92vh;overflow:auto;padding:20px;box-shadow:0 20px 70px #0004}.dialog h3{margin:0 0 15px;color:#193650}.formgrid{display:grid;grid-template-columns:1fr 1fr;gap:11px}.field label{display:block;font-size:12px;color:#536477;margin-bottom:5px}.field.full{grid-column:1/-1}.modalfoot{display:flex;gap:8px;justify-content:flex-start;margin-top:16px}.context{display:none;position:fixed;z-index:30;background:white;border:1px solid #dce3ea;box-shadow:0 12px 35px #142b4533;border-radius:12px;min-width:190px;padding:6px}.context button{display:block;width:100%;border:0;background:white;text-align:right;padding:9px 11px;border-radius:7px;font:inherit;cursor:pointer}.context button:hover{background:#edf3f8}.context .sep{border-top:1px solid #e8edf2;margin:4px}.searchresults{border:1px solid #e0e6ed;border-radius:9px;max-height:170px;overflow:auto;margin-top:7px}.result{padding:8px 10px;cursor:pointer;border-bottom:1px solid #edf0f4;font-size:13px}.result:hover,.result.active{background:#eef5fa}.person-detail-head{background:#f1f5f9;border-radius:12px;padding:13px 15px;margin-bottom:12px}.person-detail-head h2{margin:5px 0;font-size:20px;color:#173b58}.detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin:12px 0}.detail-grid>div{background:#f8fafc;border:1px solid #e6ebf1;border-radius:9px;padding:9px}.detail-grid b,.detail-grid span{display:block}.detail-grid b{font-size:11px;color:#728196;margin-bottom:4px}.detail-grid span{font-size:13px}.detail-grid .wide{grid-column:1/-1}.family-section{border-top:1px solid #e7edf2;padding:10px 0}.family-section h4{margin:0 0 7px;color:#234661}.family-list{padding:0 20px 0 0;margin:0}.family-list li{padding:5px 0;border-bottom:1px dashed #e7edf2}.family-list small{display:block;color:#718095;margin-top:3px}.family-none{font-size:12px;color:#929eab}.stats{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.stat{background:white;border:1px solid #e3e9ef;border-radius:10px;padding:7px 12px;font-size:12px;color:#536477} .node.dead::before{content:"";position:absolute;left:0;top:0;width:0;height:0;border-top:34px solid #15191f;border-right:34px solid transparent;border-radius:0 0 5px 0;z-index:6}.creditline{text-align:center;color:#8290a0;font-size:11px;padding:10px 0 4px}.top{padding-top:max(16px,env(safe-area-inset-top));}.btn,a.btn{min-height:42px;display:inline-flex;align-items:center;justify-content:center;text-decoration:none}.node{touch-action:none;user-select:none;-webkit-user-select:none}.treecanvas{display:block;direction:ltr;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;touch-action:none;overflow-x:auto!important;overflow-y:auto!important;max-width:100%;max-height:none;position:relative;contain:layout style}.world{direction:rtl}.node{direction:rtl}.modal{padding: max(10px,env(safe-area-inset-top)) 10px max(10px,env(safe-area-inset-bottom))}.dialog{width:min(620px,100%);border-radius:18px}.login{padding:28px 22px}.menu-toggle{display:inline-grid;place-items:center;border:1px solid #ffffff55;background:#ffffff16;color:white;border-radius:11px;width:44px;height:42px;font-size:24px;cursor:pointer}.search-panel{display:none;background:#fff;border:1px solid #e0e6ed;border-radius:12px;margin-top:7px;max-height:min(58vh,520px);overflow-y:auto;box-shadow:0 8px 25px #1b304515}.search-panel.show{display:block}.search-drawer>#search{height:40px;padding:8px 11px;font-size:13px;margin-bottom:7px}.search-drawer{display:flex;flex-direction:column}.search-drawer .search-panel{flex:1;min-height:90px;max-height:calc(100dvh - 190px);overflow-y:auto}.search-count{padding:8px 11px;background:#f3f6f9;color:#526579;font-size:12px;font-weight:bold;position:sticky;top:0}.search-hit{padding:9px 12px;border-bottom:1px solid #edf1f5;cursor:pointer;font-size:13px}.search-hit:hover{background:#eef5fa}.search-hit small{display:inline-block;margin-right:8px;color:#7b5b22}.toolbar-wrap{flex:1;min-width:100%}.toolbar .search-control{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.toolbar .search-control .input{flex:1;min-width:200px}@media(max-width:650px){.treecanvas{height:78dvh;min-height:560px}.menu-toggle{display:inline-grid;place-items:center}.top{display:grid;grid-template-columns:1fr auto;align-items:center}.top .actions{display:none;grid-column:1/-1;width:100%;grid-template-columns:1fr 1fr}.top .actions.open{display:grid}.toolbar .search-control{display:grid;grid-template-columns:1fr 1fr}.toolbar .search-control .input{grid-column:1/-1}.search-panel{max-height:210px}}
@media(max-width:650px){.top{padding:14px 12px}.top h1{font-size:18px}.top p{font-size:11px}.actions{width:100%;grid-template-columns:repeat(2,minmax(0,1fr))}.actions.open{display:grid}.actions .btn{padding:9px 7px;font-size:12px}.layout{padding:8px}.toolbar{padding:9px;gap:7px}.toolbar input{min-width:100%;flex-basis:100%}.treebox{height:auto;min-height:610px;border-radius:12px}.treecanvas{height:610px;min-height:610px}.node{width:165px;min-height:118px;padding:9px}.node .name{font-size:13px}.node .tribe{font-size:10px}.formgrid{grid-template-columns:1fr}.field.full{grid-column:auto}.dialog{padding:15px;max-height:88dvh}.modalfoot .btn{flex:1}.zoomtools{left:8px;top:8px}.zoomtools button{width:36px;height:36px}.hint{font-size:11px}.stats{gap:5px}.stat{font-size:10px;padding:6px 8px}}
.top{position:relative;direction:rtl;padding-left:78px}.menu-toggle{position:absolute;left:18px;top:50%;transform:translateY(-50%);z-index:42}.actions{position:fixed!important;z-index:41;left:0;right:auto;top:0;bottom:0;width:min(310px,84vw)!important;height:100dvh;display:flex!important;flex-direction:column;align-items:stretch;justify-content:flex-start;gap:9px;padding:18px 14px calc(18px + env(safe-area-inset-bottom));border:0;border-radius:0 18px 18px 0;background:#142b45;box-shadow:12px 0 35px #0003;transform:translateX(-110%);transition:transform .25s ease;overflow:auto}.actions.open{transform:translateX(0)}.actions .btn{width:100%;justify-content:flex-start;color:#173650;background:#f3f6f9}.actions .btn.primary{background:#c89b42;color:white}.drawer-title{display:flex;justify-content:space-between;align-items:center;color:white;font-weight:bold;font-size:17px;padding:7px 5px 16px;border-bottom:1px solid #ffffff30;margin-bottom:6px}.drawer-title button{border:0;background:#ffffff20;color:white;border-radius:8px;font-size:24px;width:36px;height:36px}.menu-shade{display:none;position:fixed;inset:0;background:#07142188;z-index:40}.menu-shade.open{display:block}@media(max-width:650px){.top{display:flex;min-height:84px;padding-right:12px;padding-left:70px}.top .actions{display:flex!important;grid-template-columns:none;width:min(310px,84vw)!important}.top .actions.open{display:flex!important}.menu-toggle{left:14px}}/* نسخه ۷: سربرگ ثابت، پنل جستجوی راست و کارت تصویر */
#fixedHeader{position:sticky;top:0;z-index:35;min-height:86px;flex-wrap:nowrap}#fixedHeader>div:first-child{flex:1}.layout{padding-top:12px}.toolbar{justify-content:flex-start;min-height:58px}
.search-shade{display:none;position:fixed;inset:0;background:#07142188;z-index:45}.search-shade.open{display:block}.search-drawer{position:fixed;z-index:46;right:0;top:0;bottom:0;width:min(360px,88vw);background:#fff;box-shadow:-12px 0 35px #0003;padding:18px 15px calc(20px + env(safe-area-inset-bottom));transform:translateX(110%);transition:transform .25s ease;overflow:auto;display:flex;flex-direction:column;gap:12px;border-radius:18px 0 0 18px}.search-drawer.open{transform:translateX(0)}.search-drawer .drawer-title{color:#173b58;border-bottom-color:#e6ebf0}.search-drawer .drawer-title button{background:#edf2f6;color:#173b58}.search-drawer .search-panel{display:block;flex:1;min-height:90px;max-height:calc(100dvh - 190px);overflow-y:auto;box-shadow:none;margin:0}
.node .person-photo{display:block;width:58px;height:58px;object-fit:cover;object-position:center;border-radius:50%;margin:0 auto 8px;border:3px solid #d5b15e;background:#fff;box-shadow:0 2px 7px #173b5830}.node:after{content:'';display:block;clear:both}.node{touch-action:none}
.context{max-width:min(260px,calc(100vw - 20px));max-height:calc(100dvh - 20px);overflow:auto;overscroll-behavior:contain}.context button{min-height:43px;padding:10px 12px}
@media(max-width:650px){ #fixedHeader{position:sticky;top:0;z-index:35;display:flex;grid-template-columns:none;min-height:78px;padding:12px 12px 12px 68px}#fixedHeader h1{font-size:17px}#fixedHeader p{font-size:10px}.toolbar{display:flex}.search-drawer{width:min(340px,90vw)}.node .person-photo{width:52px;height:52px}}
.stats-wrap{background:#fff;border:1px solid #e2e8ef;border-radius:13px;margin:8px 0 12px;overflow:hidden;box-shadow:0 3px 12px #24324708}.stats-heading{width:100%;display:flex;align-items:center;justify-content:space-between;border:0;background:#edf3f8;color:#183b58;padding:11px 14px;font-family:Tahoma,sans-serif;font-size:14px;font-weight:700;cursor:pointer;text-align:right}.stats{padding:10px 12px;margin:0;display:flex}.stats.collapsed{display:none}.stats-wrap:empty{display:none}.stats-summary{display:flex;gap:8px;flex-wrap:wrap;width:100%}.stats-controls{display:flex;gap:14px;flex-wrap:wrap;width:100%;padding:8px 12px 12px;border-top:1px solid #edf1f5;font-size:12px;color:#40556b}.stats-controls label{display:flex;align-items:center;gap:6px;cursor:pointer}.stats-controls input{width:17px;height:17px;accent-color:#1d587d}.floating-search{position:fixed;right:18px;bottom:calc(20px + env(safe-area-inset-bottom));z-index:38;border:0;border-radius:28px;background:#173b58;color:white;padding:12px 19px;min-height:50px;box-shadow:0 6px 22px #07142155;font-family:Tahoma,sans-serif;font-size:14px;font-weight:700;display:flex;align-items:center;gap:8px;cursor:pointer}.floating-search:active{transform:scale(.97)}@media(max-width:650px){.floating-search{right:14px;bottom:calc(16px + env(safe-area-inset-bottom));min-height:48px;padding:11px 16px}.stats-heading{padding:10px 12px}}</style></head><body>
<header class="top" id="fixedHeader"><div><h1 id="appTitleToggle" onclick="toggleStats()" title="نمایش یا بستن آمار">🌳 {{ app_title }}</h1><p>ثبت دقیق پیوندهای خانوادگی، نسل‌ها و ازدواج‌ها</p></div><button class="menu-toggle" aria-label="باز کردن منو" onclick="toggleMenu()">☰</button><div class="menu-shade" id="menuShade" onclick="toggleMenu(false)"></div><nav class="actions" id="mainMenu"><div class="drawer-title">منوی برنامه <button onclick="toggleMenu(false)" aria-label="بستن">×</button></div><button class="btn primary" onclick="openPerson();toggleMenu(false)">＋ افزودن شخص</button><button class="btn" onclick="changePassword();toggleMenu(false)">حساب کاربری</button><a class="btn" href="/users" id="usersMenuBtn">مدیریت کاربران</a><button class="btn" onclick="openSettings();toggleMenu(false)">تنظیمات عنوان</button><button class="btn" onclick="downloadBackup()">پشتیبان‌گیری</button><button class="btn" onclick="document.getElementById('restoreFile').click()">بازیابی دیتابیس</button><a class="btn" href="/logout">خروج</a><div class="drawer-credit">برنامه‌نویس: محمدعمر خاوران<br>09159499928</div><form id="restoreForm" action="/restore" method="post" enctype="multipart/form-data" style="display:none"><input id="restoreFile" name="database" type="file" accept=".db,.sqlite" onchange="document.getElementById('restoreForm').submit()"></form></nav></header>
<main class="layout"><div class="stats-wrap"><div class="stats" id="stats"></div></div><div class="search-shade" id="searchShade" onclick="toggleSearch(false)"></div><aside class="search-drawer" id="searchDrawer"><div class="drawer-title">جستجوی افراد <button onclick="toggleSearch(false)">×</button></div><input id="search" class="input" autocomplete="off" placeholder="نام، نام خانوادگی یا طایفه" oninput="searchInTree()"><button class="btn" onclick="clearSearch()">پاک کردن جستجو</button><div id="mainSearchResults" class="search-panel"></div></aside><div class="treebox" id="treebox"><div class="zoomtools"><button onclick="zoom(1.15)" title="بزرگ‌نمایی">＋</button><button onclick="zoom(.87)" title="کوچک‌نمایی">−</button><button onclick="fitTree()" title="تنظیم نما">⌂</button></div><div class="treecanvas" id="treecanvas"><div class="world-space" id="worldSpace"></div><div class="world" id="world"><svg class="edges" id="edges"></svg><div class="nodes" id="nodes"></div></div></div><div id="empty" class="empty" style="display:none">هنوز شخصی ثبت نشده است.<br>برای شروع روی «افزودن شخص» بزنید.</div></div><div class="hint">برای مدیریت هر فرد، روی کارت او راست‌کلیک کنید؛ در موبایل انگشت را حدود نیم‌ثانیه روی کارت نگه دارید. برای جابه‌جایی درخت، با یک انگشت به چهار جهت بکشید؛ برای بزرگ‌نمایی و کوچک‌نمایی از حرکت دو انگشت استفاده کنید؛ با یک انگشت در چهار جهت پیمایش کنید.</div><div class="hint" style="display:flex;gap:14px;flex-wrap:wrap;justify-content:center"><span>🟡 ازدواج فعال</span><span style="color:#d71920">✖ طلاق</span><span style="color:#111820">● وفات همسر</span><span>◢ روبان مشکی: فرد درگذشته</span></div><div class="creditline">طراحی و برنامه‌نویسی: <b>محمد عمر خاوران</b></div></main><button class="floating-search" onclick="toggleSearch(true)" aria-label="جستجوی افراد">⌕ <span>جستجو</span></button>
<div class="context" id="context"><button onclick="ctxAction('پدر')">＋ افزودن پدر</button><button onclick="ctxAction('مادر')">＋ افزودن مادر</button><button onclick="ctxAction('همسر')">＋ افزودن همسر</button><button onclick="ctxAction('پسر')">＋ افزودن پسر</button><button onclick="ctxAction('دختر')">＋ افزودن دختر</button><div class="sep"></div><button onclick="ctxAction('ویرایش')">✎ ویرایش اطلاعات</button><button onclick="ctxAction('روابط')">⇄ ویرایش روابط</button><button onclick="ctxAction('فوت')">✝ ثبت فوت</button><button onclick="ctxAction('طلاق')">⚖ ثبت طلاق</button><button onclick="ctxAction('مشاهده')">◉ مشاهده مشخصات</button><div class="sep"></div><button style="color:#b33" onclick="ctxAction('حذف')">حذف شخص</button></div>
<div class="modal" id="modal"><div class="dialog"><h3 id="modalTitle">ثبت اطلاعات</h3><div id="modalBody"></div><div class="modalfoot"><button class="btn primary" id="saveBtn" onclick="saveModal()">ذخیره</button><button class="btn" onclick="closeModal()">انصراف</button></div></div></div>
<script>
let DATA={people:[],marriages:[],parents:[]}, selectedId=null, modalMode='', relation='', existingId=null, scale=1, positions={};
const $=id=>document.getElementById(id);
window.CURRENT_USERNAME='{{ session.get('username','') }}';window.CURRENT_USER_ID={{ session.get('user_id',0) }};window.CURRENT_ROLE='{{ session.get('role','user') }}';
function toggleSearch(force){let d=$('searchDrawer'),sh=$('searchShade'),o=force===undefined?!d.classList.contains('open'):!!force;d.classList.toggle('open',o);sh.classList.toggle('open',o);if(o)setTimeout(()=>$('search').focus(),220)}
function toggleMenu(force){let m=$('mainMenu'),shade=$('menuShade');let open=force===undefined?!m.classList.contains('open'):!!force;if(m)m.classList.toggle('open',open);if(shade)shade.classList.toggle('open',open)}
let mainSearchTimer=null,mainSearchMatches=new Set();async function searchInTree(){let q=$('search').value.trim();clearTimeout(mainSearchTimer);let panel=$('mainSearchResults');if(!q){mainSearchMatches.clear();renderTree('');panel.classList.remove('show');panel.innerHTML='';return}mainSearchMatches.clear();renderTree(q);mainSearchTimer=setTimeout(async()=>{try{let res=await api('/api/search?q='+encodeURIComponent(q));mainSearchMatches=new Set((res.items||[]).map(x=>x.id));renderTree(q);panel.innerHTML='<div class="search-count">تعداد موارد یافته‌شده: '+(res.count||0)+'</div>'+((res.items||[]).map(x=>'<div class="search-hit" onclick="goToSearchPerson('+x.id+')"><b>'+esc(x.first_name+' '+x.last_name)+'</b><small>&nbsp;&nbsp;—&nbsp;&nbsp;'+esc([x.tribe].filter(Boolean).join(' · '))+'</small></div>').join('')||'<div class="search-hit">موردی یافت نشد.</div>');panel.classList.add('show')}catch(e){panel.innerHTML='<div class="search-hit">'+esc(e.message)+'</div>';panel.classList.add('show')}},220)}
function goToSearchPerson(id){toggleSearch(false);selectNode(Number(id));let el=document.querySelector('.node[data-id="'+id+'"]');if(el){let cv=$('treecanvas');cv.scrollTo({left:Math.max(0,el.offsetLeft-cv.clientWidth/2),top:Math.max(0,el.offsetTop-cv.clientHeight/2),behavior:'smooth'})}$('mainSearchResults').classList.remove('show')}
function clearSearch(){$('search').value='';mainSearchMatches.clear();$('mainSearchResults').classList.remove('show');renderTree()}
function normText(s){return String(s??'').toLowerCase().replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/[\s\u200c\u200f]/g,'')}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function api(url,opts={}){let r;try{r=await fetch(url,{credentials:'same-origin',headers:{'Content-Type':'application/json','Accept':'application/json'},...opts})}catch(net){throw Error('ارتباط با سرور برقرار نشد: '+(net.message||net))}let raw=await r.text();let j;try{j=raw?JSON.parse(raw):{}}catch(_){let detail=raw.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,220);if(r.status===401){location.href='/login';throw Error('نشست ورود پایان یافته است؛ دوباره وارد شوید.')}throw Error('سرور پاسخ JSON نفرستاد (HTTP '+r.status+'). '+(detail||'پاسخ خالی بود.'))}if(r.status===401){location.href='/login';throw Error(j.error||'ابتدا وارد شوید.')}if(!r.ok)throw Error(j.error||('خطای سرور '+r.status));return j}
async function changePassword(){let un=prompt('نام کاربری جدید:',window.CURRENT_USERNAME||'admin');if(un===null)return;let oldp=prompt('رمز فعلی را وارد کنید:');if(oldp===null)return;let np=prompt('رمز جدید (حداقل ۶ کاراکتر):');if(np===null)return;let cp=prompt('رمز جدید را دوباره وارد کنید:');if(cp===null)return;if(np!==cp){alert('تکرار رمز با رمز جدید یکسان نیست.');return}try{await api('/api/change-password',{method:'POST',body:JSON.stringify({username:un,old_password:oldp,new_password:np})});alert('نام کاربری و رمز عبور تغییر کرد.');location.reload()}catch(e){alert(e.message)}}
async function openSettings(){let pin=prompt('رمز ورود به تنظیمات را وارد کنید:');if(pin===null)return;if(pin!=='10246600'){alert('رمز تنظیمات نادرست است.');return}let current=document.querySelector('.top h1')?.textContent?.replace(/^🌳\s*/, '')||'شجره‌نامه قوم بلوچ';let st=DATA.settings||{};let html=`<div class="field"><label>عنوان بالای صفحه</label><input class="input" id="settingTitle" maxlength="60" value="${esc(current)}"></div><p class="hint">گزینه‌های نمایش زنان و قوم اصلی اکنون در بخش آمار صفحه اصلی قرار دارند.</p>`;showModal('تنظیمات شجره‌نامه',html,'settings');$('saveBtn').onclick=saveSettings;}
async function saveSettings(){let pin='10246600',title=$('settingTitle').value.trim();if(!title||title.length>60){alert('عنوان باید بین ۱ تا ۶۰ نویسه باشد.');return}try{await api('/api/settings/title',{method:'POST',body:JSON.stringify({settings_password:pin,title,hide_women:!!DATA.settings?.hide_women,main_tribe_only:!!DATA.settings?.main_tribe_only})});closeModal();$('saveBtn').onclick=saveModal;await loadTree();alert('تنظیمات ذخیره شد.')}catch(e){alert(e.message)}}
async function manageUsers(){try{let users=await api('/api/users');let html='<div class="formgrid"><div class="field"><label>نام کاربری جدید</label><input class="input" id="newUserName"></div><div class="field"><label>رمز عبور جدید</label><input class="input" id="newUserPass" type="password"></div><div class="field"><label>سطح دسترسی</label><select id="newUserRole" class="input"><option value="user">کاربر</option><option value="admin">مدیر</option></select></div></div><button class="btn primary" style="margin:10px 0" onclick="addUser()">افزودن کاربر</button><hr><h4>کاربران ثبت‌شده</h4><div>'+users.map(u=>'<div class="result">'+esc(u.username)+' · '+(u.role==='admin'?'مدیر':'کاربر')+(u.id!==window.CURRENT_USER_ID?' <button class="btn danger" onclick="removeUser('+u.id+')">حذف</button>':' (حساب فعلی)')+'</div>').join('')+'</div>';showModal('مدیریت کاربران',html,'users');$('saveBtn').style.display='none'}catch(e){alert(e.message)}}
async function addUser(){try{await api('/api/users',{method:'POST',body:JSON.stringify({username:$('newUserName').value,password:$('newUserPass').value,role:$('newUserRole').value})});alert('کاربر اضافه شد.');manageUsers()}catch(e){alert(e.message)}}
async function removeUser(id){if(!confirm('این کاربر حذف شود؟'))return;try{await api('/api/users/'+id,{method:'DELETE'});manageUsers()}catch(e){alert(e.message)}}
async function downloadBackup(){try{const r=await fetch('/backup',{credentials:'same-origin'});if(!r.ok)throw Error('دریافت فایل پشتیبان ناموفق بود: '+r.status);const blob=await r.blob();if(window.AndroidBackup&&window.AndroidBackup.saveBackup){const reader=new FileReader();reader.onload=()=>{const b64=String(reader.result).split(',')[1]||'';window.AndroidBackup.saveBackup(b64)};reader.readAsDataURL(blob);}else{const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='shajareh-backup.db';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),3000);}}catch(e){alert('پشتیبان‌گیری انجام نشد: '+e.message)}}
async function loadTree(){try{DATA=await api('/api/tree');$('stats').innerHTML=`<div class="stats-summary"><span class="stat">کل افراد: ${DATA.people.length}</span><span class="stat">مردان: ${DATA.people.filter(x=>x.gender==='مرد').length}</span><span class="stat">زنان: ${DATA.people.filter(x=>x.gender==='زن').length}</span><span class="stat">زنده‌ها: ${DATA.people.filter(x=>!x.death_date).length}</span><span class="stat">درگذشتگان: ${DATA.people.filter(x=>x.death_date).length}</span><span class="stat">ازدواج‌های فعال: ${DATA.marriages.filter(x=>!x.end_date).length}</span></div><div class="stats-controls"><label><input type="checkbox" id="homeHideWomen" ${DATA.settings?.hide_women?'checked':''} onchange="updateHomeSetting('hide_women',this.checked)"> مخفی کردن زنان در شجره‌نامه</label><label><input type="checkbox" id="homeMainTribe" ${DATA.settings?.main_tribe_only?'checked':''} onchange="updateHomeSetting('main_tribe_only',this.checked)"> فقط نمایش قوم اصلی (پرتعدادترین طایفه)</label></div>`;renderTree();}catch(e){alert(e.message)}}
function toggleStats(){let box=$('stats');box.classList.toggle('collapsed');let title=$('appTitleToggle');if(title)title.setAttribute('aria-expanded',String(!box.classList.contains('collapsed')))}
async function updateHomeSetting(key,value){let title=document.querySelector('.top h1')?.textContent?.replace(/^🌳\s*/,'')||'شجره‌نامه قوم بلوچ';let settings={hide_women:!!DATA.settings?.hide_women,main_tribe_only:!!DATA.settings?.main_tribe_only};settings[key]=!!value;try{await api('/api/settings/title',{method:'POST',body:JSON.stringify({settings_password:'10246600',title,hide_women:settings.hide_women,main_tribe_only:settings.main_tribe_only})});DATA.settings=settings;renderTree()}catch(e){alert(e.message);await loadTree()}}
function layoutPeople(list){
 const ids=new Set(list.map(p=>p.id));
 const parents=DATA.parents.filter(e=>ids.has(e.parent_id)&&ids.has(e.child_id));
 const marriages=DATA.marriages.filter(m=>ids.has(m.husband_id)&&ids.has(m.wife_id));
 const depth={}; list.forEach(p=>depth[p.id]=0);
 for(let k=0;k<list.length;k++){
   let changed=false;
   parents.forEach(e=>{const d=(depth[e.parent_id]||0)+1;if(d>(depth[e.child_id]||0)){depth[e.child_id]=d;changed=true;}});
   if(!changed)break;
 }
 for(let k=0;k<list.length+2;k++){
   let changed=false;
   marriages.forEach(m=>{const d=Math.max(depth[m.husband_id]||0,depth[m.wife_id]||0);if(depth[m.husband_id]!==d||depth[m.wife_id]!==d){depth[m.husband_id]=d;depth[m.wife_id]=d;changed=true;}});
   parents.forEach(e=>{const d=(depth[e.parent_id]||0)+1;if(d>(depth[e.child_id]||0)){depth[e.child_id]=d;changed=true;}});
   if(!changed)break;
 }
 // تعداد خانواده‌های زوجی در هر نسل برای ایجاد فضای کافی جهت مسیرهای منشعب و جلوگیری از روی‌هم‌افتادگی
 const familyByDepth=new Map();
 const parentByChild=new Map();
 parents.forEach(e=>{if(!parentByChild.has(e.child_id))parentByChild.set(e.child_id,{});parentByChild.get(e.child_id)[e.relation]=e.parent_id;});
 parentByChild.forEach((v,childId)=>{if(v['پدر']&&v['مادر']){const d=depth[childId]||1;if(!familyByDepth.has(d))familyByDepth.set(d,new Set());familyByDepth.get(d).add([v['پدر'],v['مادر']].sort((a,b)=>a-b).join(':'));}});
 const maxFamilies=Math.max(1,...[...familyByDepth.values()].map(x=>x.size));
 const rowStep=Math.max(295,255+maxFamilies*52);
 const groups={}; list.forEach(p=>(groups[depth[p.id]]??=[]).push(p));
 const pos={}; let maxW=0;
 Object.keys(groups).forEach(d=>{
   const row=groups[d].slice().sort((a,b)=>a.id-b.id), byId=new Map(row.map(p=>[p.id,p]));
   const spouseMap=new Map();
   marriages.forEach(m=>{
     if(!byId.has(m.husband_id)||!byId.has(m.wife_id))return;
     if(!spouseMap.has(m.husband_id))spouseMap.set(m.husband_id,[]);
     if(!spouseMap.has(m.wife_id))spouseMap.set(m.wife_id,[]);
     spouseMap.get(m.husband_id).push(m.wife_id);spouseMap.get(m.wife_id).push(m.husband_id);
   });
   const ordered=[],used=new Set();
   // چیدمان خانواده‌های چندهمسری: همسر اول در سمت راست شوهر؛ همسر دوم بلافاصله
   // سمت چپ شوهر؛ همسر سوم و چهارم به ترتیب در سمت چپ همسر قبلی قرار می‌گیرند.
   // هر کارت فقط یک بار وارد ردیف می‌شود.
   const men=row.filter(p=>p.gender==='مرد').sort((a,b)=>a.id-b.id);
   men.forEach(man=>{
     if(used.has(man.id))return;
     const wives=DATA.marriages.filter(m=>m.husband_id===man.id&&byId.has(m.wife_id))
       .sort((a,b)=>a.id-b.id).map(m=>m.wife_id).filter((id,i,arr)=>arr.indexOf(id)===i&&!used.has(id));
     if(!wives.length)return;
     const orderedWives=[...wives.slice(1).reverse(),man.id,wives[0]];
     orderedWives.forEach(id=>{if(!used.has(id)){const x=byId.get(id);if(x)ordered.push(x);used.add(id);}});
     used.add(man.id);
   });
   // افراد بدون همسر ثبت‌شده و اشخاصی که به‌علت ازدواج‌های قبلی در گروه بالا قرار نگرفتند.
   row.forEach(person=>{if(!used.has(person.id)){ordered.push(person);used.add(person.id);}});
   // اولویت چیدمان هر نسل با جایگاه پدر/مادر است؛ فرزندان هر خانواده کنار هم
   // و تا حد امکان درست زیر محور والدین قرار می‌گیرند، نه صرفاً بر اساس شناسه ثبت.
   if(Number(d)>0){
     const parentLinks=new Map();
     parents.filter(e=>depth[e.child_id]===Number(d)).forEach(e=>{if(!parentLinks.has(e.child_id))parentLinks.set(e.child_id,[]);parentLinks.get(e.child_id).push(e.parent_id);});
     const familyAnchor=person=>{const ps=parentLinks.get(person.id)||[];const xs=ps.map(id=>pos[id]?.x).filter(x=>Number.isFinite(x));return xs.length?xs.reduce((a,b)=>a+b,0)/xs.length+95:person.id*100000;};
     // بلوک‌های زوجی در کنار هم باقی می‌مانند؛ ترتیب بلوک‌ها با مرکز والدین تعیین می‌شود.
     const blocks=[],seenBlock=new Set();
     ordered.forEach(person=>{if(seenBlock.has(person.id))return;const spouseIds=DATA.marriages.filter(m=>m.husband_id===person.id||m.wife_id===person.id).flatMap(m=>[m.husband_id,m.wife_id]).filter(id=>byId.has(id)&&!seenBlock.has(id));const block=spouseIds.length?ordered.filter(x=>spouseIds.includes(x.id)): [person];block.forEach(x=>seenBlock.add(x.id));blocks.push(block);});
     blocks.sort((a,b)=>familyAnchor(a[0])-familyAnchor(b[0]));
     ordered.length=0;blocks.forEach(b=>b.forEach(x=>ordered.push(x)));
   }
   ordered.forEach((person,i)=>{pos[person.id]={x:45+i*270,y:22+Number(d)*rowStep};maxW=Math.max(maxW,45+i*225+205);});
 });
 // نخستین فرد ثبت‌شده در بالای درخت و وسط ردیف قرار می‌گیرد.
 // کل ردیف جابه‌جا می‌شود، نه فقط کارت ریشه؛ بنابراین همسر/افراد همان نسل
 // با کارت ریشه برخورد نمی‌کنند و فاصله استاندارد بین کارت‌ها حفظ می‌شود.
 const firstPerson=list.reduce((a,b)=>a.id<b.id?a:b,list[0]);
 if(firstPerson && pos[firstPerson.id]){
   const rootDepth=depth[firstPerson.id]||0;
   const rootRow=list.filter(p=>(depth[p.id]||0)===rootDepth);
   const currentWidth=Math.max(maxW+55,650);
   let delta=(currentWidth/2)-(pos[firstPerson.id].x+95);
   const minX=Math.min(...rootRow.map(p=>pos[p.id].x));
   if(minX+delta<45)delta=45-minX;
   rootRow.forEach(p=>{pos[p.id].x+=delta;maxW=Math.max(maxW,pos[p.id].x+205);});
 }
 // کنترل نهایی: هیچ دو کارتی در یک ردیف مختصات افقی هم‌پوشان نداشته باشند.
 // فاصله 270 پیکسل، فضای تنفس بیشتری بین کارت‌ها ایجاد می‌کند.
 Object.keys(groups).forEach(d=>{
   const row=groups[d].slice().sort((a,b)=>pos[a.id].x-pos[b.id].x);
   for(let i=1;i<row.length;i++){
     const prev=row[i-1],cur=row[i];
     const required=270;
     if(pos[cur.id].x<pos[prev.id].x+required){
       const shift=pos[prev.id].x+required-pos[cur.id].x;
       for(let j=i;j<row.length;j++)pos[row[j].id].x+=shift;
       maxW=Math.max(maxW,...row.map(p=>pos[p.id].x+205));
     }
   }
 });
 const maxDepth=Math.max(0,...Object.values(depth));
 return {pos,width:Math.max(maxW+55,650),height:Math.max(280,(maxDepth+1)*rowStep+80),rowStep};
}
let treeBaseWidth=650,treeBaseHeight=610;
function updateWorldSpace(){let sp=$('worldSpace'),world=$('world');if(sp){const w=Math.max(1,Math.ceil(treeBaseWidth*scale)),h=Math.max(1,Math.ceil(treeBaseHeight*scale));sp.style.width=w+'px';sp.style.minWidth=w+'px';sp.style.height=h+'px';sp.style.minHeight=h+'px';sp.style.flex='0 0 auto';sp.style.display='block';if(world){world.style.width=treeBaseWidth+'px';world.style.height=treeBaseHeight+'px';world.style.transformOrigin='0 0';world.style.transform=`scale(${scale})`;}}}
function renderTree(filter=''){
 let list=DATA.people.slice();const settings=DATA.settings||{};
 if(settings.hide_women)list=list.filter(p=>p.gender!=='زن');
 if(settings.main_tribe_only){const counts={};DATA.people.forEach(p=>{let t=(p.tribe||'').trim();if(t)counts[t]=(counts[t]||0)+1});const main=Object.keys(counts).sort((a,b)=>counts[b]-counts[a]||a.localeCompare(b,'fa'))[0];if(main)list=list.filter(p=>(p.tribe||'').trim()===main);}
 $('empty').style.display=list.length?'none':'block';$('world').style.display=list.length?'block':'none';if(!list.length)return;
 let {pos,width,height}=layoutPeople(list);positions=pos;$('world').style.width=width+'px';$('world').style.height=height+'px';
 treeBaseWidth=Math.max(650,width+30);treeBaseHeight=Math.max(610,height+60);const canvasHeight=Math.max(610,height+60);$('treecanvas').style.height='78dvh';$('treecanvas').style.minHeight='560px';$('treebox')?.style.setProperty('min-height','610px');$('world').style.width=treeBaseWidth+'px';$('world').style.height=treeBaseHeight+'px';updateWorldSpace();
 $('nodes').innerHTML=list.map(p=>{let match=!filter||(mainSearchMatches&&mainSearchMatches.size?mainSearchMatches.has(p.id):normText(`${p.first_name} ${p.last_name} ${p.tribe}`).includes(normText(filter)));return `<div class="node ${p.gender==='مرد'?'male':'female'} ${p.death_date?'dead':''} ${match&&filter?'selected':''}" data-id="${p.id}" style="left:${pos[p.id].x}px;top:${pos[p.id].y}px;opacity:${filter&&!match?'.35':'1'}" oncontextmenu="showContext(event,${p.id})" onclick="cardClick(${p.id})">${p.has_photo?`<img class="person-photo" src="/api/person/${p.id}/photo" loading="lazy" alt="">`:''}<div class="code">${esc(p.person_code)}</div><div class="name">${esc(p.first_name+' '+p.last_name)}</div><div class="meta">${esc(p.gender)} ${p.birth_date?'· تولد '+esc(p.birth_date):''}</div><div class="tribe">قومیت: ${esc(p.tribe||'ثبت نشده')}</div>${p.death_date?'<span class="badge">درگذشته</span>':'<span class="badge">زنده</span>'}</div>`}).join('');
 drawEdges(list,pos,width,height);
}
function drawEdges(list,pos,w,h){
 const ids=new Set(list.map(p=>p.id)),svg=$('edges');
 svg.setAttribute('width',w);svg.setAttribute('height',h);svg.style.width=w+'px';svg.style.height=h+'px';svg.setAttribute('viewBox',`0 0 ${w} ${h}`);
 // ابعاد واقعی کارت‌ها خوانده می‌شود؛ بنابراین وجود قومیت یا متن اضافه مختصات خطوط را خراب نمی‌کند.
 const box=id=>{const el=document.querySelector(`.node[data-id="${id}"]`);if(!el)return null;const x=el.offsetLeft,y=el.offsetTop,cw=el.offsetWidth,ch=el.offsetHeight;return {id:Number(id),x,y,w:cw,h:ch,cx:x+cw/2,cy:y+ch/2,top:y,bottom:y+ch,left:x,right:x+cw};};
 const pairKey=(a,b)=>[Number(a),Number(b)].sort((x,y)=>x-y).join(':');
 const colors=['#2476c7','#d34d72','#16866b','#9561c7','#d17a24','#168b9a','#b34d9b','#6675c9'];
 const childColor=id=>colors[Math.abs(Number(id))%colors.length];
 let paths='',marriagePoints=new Map(),drawnPairs=new Set();
 // برای هر زوج، آخرین وضعیت ازدواج مبناست: ازدواج فعال=نقطه طلایی، طلاق=ضربدر قرمز، وفات=نقطه مشکی.
 const latestMarriage=new Map();
 DATA.marriages.filter(m=>ids.has(m.husband_id)&&ids.has(m.wife_id)).forEach(m=>latestMarriage.set(pairKey(m.husband_id,m.wife_id),m));
 [...latestMarriage.entries()].forEach(([key,m])=>{
   const a=box(m.husband_id),b=box(m.wife_id);if(!a||!b)return;
   const husband=a,wife=b;
   const y=(a.cy+b.cy)/2;
   let join;
   if(wife.cx>husband.cx){
     // همسر اول در سمت راست شوهر: اتصال مستقیم و خوانا.
     join={x:(husband.right+wife.left)/2,y};
     paths+=`<path class="edge-marriage" d="M ${husband.right} ${y} H ${wife.left}"/>`;
   }else{
     // همسر دوم و همسران بعدی در سمت چپ شوهر. برای همسر سوم به بعد،
     // مسیر از بالای کارت‌های میانی عبور می‌کند تا خط از روی کارت همسر دیگر نگذرد.
     const wivesForMan=DATA.marriages.filter(x=>x.husband_id===m.husband_id)
       .sort((x,y)=>x.id-y.id);
     const wifeIndex=wivesForMan.findIndex(x=>x.id===m.id)+1;
     const laneY=Math.min(husband.top,wife.top)-14-Math.max(0,wifeIndex-2)*14;
     if(wifeIndex<=2){
       join={x:(wife.right+husband.left)/2,y};
       paths+=`<path class="edge-marriage" d="M ${wife.right} ${y} H ${husband.left}"/>`;
     }else{
       join={x:(wife.cx+husband.cx)/2,y:laneY};
       paths+=`<path class="edge-marriage" d="M ${husband.left} ${y} V ${laneY} H ${wife.cx} V ${wife.top}"/>`;
     }
   }
   marriagePoints.set(key,join);
   if(m.end_reason==='طلاق'){
     // ناحیه کلیک بزرگ‌تر از خود ضربدر است تا روی موبایل هم به‌آسانی انتخاب شود.
     paths+=`<g class="divorce-marker" data-marriage-id="${m.id}" onclick="restoreDivorce(${m.id})" style="pointer-events:all;cursor:pointer"><circle cx="${join.x}" cy="${join.y}" r="13" fill="transparent"/><path d="M ${join.x-5.5} ${join.y-5.5} L ${join.x+5.5} ${join.y+5.5} M ${join.x+5.5} ${join.y-5.5} L ${join.x-5.5} ${join.y+5.5}" stroke="#d71920" stroke-width="3.2" stroke-linecap="round" fill="none"/></g>`;
   }else if(m.end_reason==='وفات'){
     paths+=`<circle cx="${join.x}" cy="${join.y}" r="5.8" fill="#111820" stroke="#fff" stroke-width="1.5"/>`;
   }else{
     paths+=`<circle cx="${join.x}" cy="${join.y}" r="5.5" fill="#c99a3b" stroke="#fff" stroke-width="1.8"/>`;
   }
 });
 const byChild={};
 DATA.parents.filter(e=>ids.has(e.parent_id)&&ids.has(e.child_id)).forEach(e=>(byChild[e.child_id]??=[]).push(e));
 const familyGroups=new Map(),singleParent=[];
 Object.entries(byChild).forEach(([childId,links])=>{
   const father=links.find(x=>x.relation==='پدر'),mother=links.find(x=>x.relation==='مادر');
   if(father&&mother){const key=pairKey(father.parent_id,mother.parent_id);if(!familyGroups.has(key))familyGroups.set(key,{father,mother,children:[]});const child=box(Number(childId));if(child)familyGroups.get(key).children.push(child);}
   else links.forEach(e=>{const child=box(Number(childId));if(child)singleParent.push({edge:e,child});});
 });
 // خانواده‌هایی که بازه افقی‌شان با هم تداخل دارد در مسیرهای ارتفاعی جداگانه قرار می‌گیرند.
 // به این ترتیب شاخه فرزندان دو زوج روی یک خط نمی‌افتد و با هم اشتباه نمی‌شود.
 const routed=[...familyGroups.entries()].map(([key,g])=>{
   const f=box(g.father.parent_id),m=box(g.mother.parent_id);if(!f||!m)return null;
   const join=marriagePoints.get(key)||{x:(f.cx+m.cx)/2,y:(f.cy+m.cy)/2};
   const children=g.children.sort((a,b)=>a.cx-b.cx);if(!children.length)return null;
   // بازه مسیر شامل خود نقطه ازدواج و تمام فرزندان است؛ نه فقط بازه کارت‌های فرزند.
   // در نتیجه حتی اگر دو شاخه از یک محدوده عبور کنند، خط افقی هیچ‌کدام روی دیگری نمی‌افتد.
   const childMin=Math.min(...children.map(c=>c.cx)),childMax=Math.max(...children.map(c=>c.cx));
   return {key,join,children,min:Math.min(join.x,childMin)-18,max:Math.max(join.x,childMax)+18,top:Math.min(...children.map(c=>c.top))};
 }).filter(Boolean).sort((a,b)=>a.min-b.min||a.max-b.max);
 const lanes=[];
 routed.forEach(g=>{
   let lane=0;
   while(lanes[lane]&&lanes[lane].some(r=>!(g.max<r.min||g.min>r.max)))lane++;
   if(!lanes[lane])lanes[lane]=[];
   lanes[lane].push({min:g.min,max:g.max});g.lane=lane;
 });
 routed.forEach(g=>{
   // فاصله بیشتر بین مسیرهای موازی باعث خوانایی شاخه‌های خانوادگی می‌شود.
   const branchY=g.top-42-g.lane*50;
   const xs=[g.join.x,...g.children.map(ch=>ch.cx)];
   const leftX=Math.min(...xs),rightX=Math.max(...xs);
   // انشعاب دقیقاً از دایره وسط خط ازدواج پدر و مادر آغاز می‌شود.
   paths+=`<path d="M ${g.join.x} ${g.join.y+5.5} V ${branchY}" fill="none" stroke="#77899b" stroke-width="3" stroke-linecap="round"/>`;
   // خط افقی برای هر خانواده رسم می‌شود؛ حتی اگر فقط یک فرزند داشته باشد.
   // این خط از نقطه انشعاب تا محور فرزند/فرزندان امتداد دارد.
   if(Math.abs(rightX-leftX)>1)paths+=`<path d="M ${leftX} ${branchY} H ${rightX}" fill="none" stroke="#77899b" stroke-width="3" stroke-linecap="round"/>`;
   g.children.forEach(ch=>{paths+=`<path d="M ${ch.cx} ${branchY} V ${ch.top}" fill="none" stroke="${childColor(ch.id)}" stroke-width="3.2" stroke-linecap="round"/>`;});
   paths+=`<circle cx="${g.join.x}" cy="${g.join.y}" r="4.8" fill="#c99a3b" stroke="#fff" stroke-width="1.4"/>`;
 });
 singleParent.forEach(({edge,child})=>{
   const a=box(edge.parent_id);if(!a)return;
   const mid=a.bottom+Math.max(24,(child.top-a.bottom)/2),color=childColor(child.id);
   paths+=`<path d="M ${a.cx} ${a.bottom} V ${mid} H ${child.cx} V ${child.top}" fill="none" stroke="${color}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>`;
 });
 svg.innerHTML=paths;
}
function selectNode(id){selectedId=id;document.querySelectorAll('.node').forEach(n=>n.classList.toggle('selected',Number(n.dataset.id)===id));}
let suppressCardClick=false;function cardClick(id){if(suppressCardClick){suppressCardClick=false;return}selectNode(id);}
function placeContext(x,y){let c=$('context');c.style.display='block';c.style.left='8px';c.style.top='8px';requestAnimationFrame(()=>{let r=c.getBoundingClientRect();c.style.left=Math.max(8,Math.min(x,innerWidth-r.width-8))+'px';c.style.top=Math.max(8,Math.min(y,innerHeight-r.height-8))+'px'})}function showContext(e,id){e.preventDefault();selectedId=id;selectNode(id);placeContext(e.clientX,e.clientY)}
document.addEventListener('click',e=>{if(!$('context').contains(e.target))$('context').style.display='none'});
let touchTimer=null,touchStart=null;document.addEventListener('touchstart',e=>{let n=e.target.closest('.node');if(!n)return;touchStart={x:e.touches[0].clientX,y:e.touches[0].clientY,id:Number(n.dataset.id)};touchTimer=setTimeout(()=>{suppressCardClick=true;selectedId=touchStart.id;selectNode(selectedId);placeContext(touchStart.x,touchStart.y)},550)},{passive:true});document.addEventListener('touchmove',e=>{if(touchStart&&Math.hypot(e.touches[0].clientX-touchStart.x,e.touches[0].clientY-touchStart.y)>12){clearTimeout(touchTimer);touchStart=null}},{passive:true});document.addEventListener('touchend',()=>{clearTimeout(touchTimer);touchStart=null});
function ctxAction(a){$('context').style.display='none';if(!selectedId)return;if(['پدر','مادر','همسر','پسر','دختر'].includes(a)){relation=a;openRelated();}else if(a==='ویرایش')editPerson();else if(a==='روابط')editRelations();else if(a==='فوت')registerDeath();else if(a==='طلاق')registerDivorce();else if(a==='حذف')deletePerson();else if(a==='مشاهده')viewPerson();}
function showModal(title,body,mode){compressedPhotoData='';photoCompressionPromise=Promise.resolve();$('saveBtn').onclick=saveModal;$('saveBtn').style.display='';$('modalTitle').textContent=title;$('modalBody').innerHTML=body;$('modal').style.display='flex';modalMode=mode;}
function closeModal(){$('modal').style.display='none';modalMode='';}
function fields(p={}){return `<div class="formgrid"><div class="field"><label>نام *</label><input class="input" id="f_first_name" value="${esc(p.first_name||'')}"></div><div class="field"><label>نام خانوادگی</label><input class="input" id="f_last_name" value="${esc(p.last_name||'')}"></div><div class="field"><label>جنسیت</label><select id="f_gender"><option ${p.gender==='مرد'?'selected':''}>مرد</option><option ${p.gender==='زن'?'selected':''}>زن</option></select></div><div class="field"><label>تاریخ تولد</label><input class="input" id="f_birth_date" placeholder="مثلاً ۱۳۶۰/۰۲/۱۵" value="${esc(p.birth_date||'')}"></div><div class="field"><label>قوم / طایفه</label><input class="input" id="f_tribe" value="${esc(p.tribe||'')}"></div><div class="field"><label>شغل</label><input class="input" id="f_job" value="${esc(p.job||'')}"></div><div class="field"><label>تلفن</label><input class="input" id="f_phone" value="${esc(p.phone||'')}"></div><div class="field"><label>شهر محل سکونت</label><input class="input" id="f_city" value="${esc(p.city||'')}"></div><div class="field full"><label>تصویر شخص (پس از فشرده‌سازی حداکثر ۵۰ کیلوبایت)</label><input class="input" id="f_photo" type="file" accept="image/*" onchange="compressPersonPhoto(this)"><div id="photoPreview" style="margin-top:8px">${p.has_photo?`<img src="/api/person/${p.id}/photo" style="width:90px;height:90px;object-fit:cover;border-radius:12px"><label><input type="checkbox" id="f_remove_photo"> حذف تصویر فعلی (در صورت نیاز)</label><small style="display:block;color:#64748b;margin-top:5px">برای تعویض، عکس جدید را از کادر انتخاب تصویر برگزینید؛ عکس جدید جایگزین عکس قبلی می‌شود.</small>`:''}</div></div><div class="field full"><label>توضیحات</label><textarea id="f_notes" rows="2">${esc(p.notes||'')}</textarea></div></div>`}
let compressedPhotoData='',photoCompressionPromise=Promise.resolve();
function compressPersonPhoto(input){
 compressedPhotoData='';const removeToggle=$('f_remove_photo');if(removeToggle)removeToggle.checked=false;const f=input.files?.[0];if(!f){photoCompressionPromise=Promise.resolve();return}
 photoCompressionPromise=new Promise((resolve,reject)=>{const img=new Image(),url=URL.createObjectURL(f);const finish=()=>URL.revokeObjectURL(url);
 img.onload=()=>{try{const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');let w=img.naturalWidth||img.width,h=img.naturalHeight||img.height,maxSide=1200;let ratio=Math.min(1,maxSide/Math.max(w,h));w=Math.max(1,Math.round(w*ratio));h=Math.max(1,Math.round(h*ratio));let data='';
 for(let pass=0;pass<7;pass++){canvas.width=w;canvas.height=h;ctx.clearRect(0,0,w,h);ctx.drawImage(img,0,0,w,h);let q=.86;data=canvas.toDataURL('image/jpeg',q);while(data.length*0.75>50*1024&&q>.28){q=Math.max(.28,q-.08);data=canvas.toDataURL('image/jpeg',q)}if(data.length*0.75<=50*1024)break;w=Math.max(180,Math.round(w*.82));h=Math.max(180,Math.round(h*.82));}
 const bytes=Math.floor((data.length-data.indexOf(',')-1)*3/4);if(!data.startsWith('data:image/jpeg;base64,')||bytes>50*1024)throw Error('فشرده‌سازی تصویر به حجم ۵۰ کیلوبایت نرسید؛ لطفاً عکس دیگری انتخاب کنید.');
 compressedPhotoData=data;$('photoPreview').innerHTML=`<img src="${data}" style="width:90px;height:90px;object-fit:cover;border-radius:12px"><div><small>تصویر آماده ذخیره · ${Math.ceil(bytes/1024)} کیلوبایت</small></div>`;finish();resolve();
 }catch(err){finish();input.value='';compressedPhotoData='';alert(err.message||'فشرده‌سازی تصویر ناموفق بود.');reject(err)}};
 img.onerror=()=>{finish();input.value='';alert('خواندن تصویر ممکن نیست یا فرمت آن پشتیبانی نمی‌شود.');reject(Error('خواندن تصویر ناموفق بود.'))};img.src=url;
 });photoCompressionPromise.catch(()=>{});
}
function readFields(){let o={};['first_name','last_name','gender','birth_date','tribe','job','phone','city','notes'].forEach(k=>o[k]=$('f_'+k)?.value||'');if(compressedPhotoData)o.photo_data=compressedPhotoData;if($('f_remove_photo')?.checked&&!compressedPhotoData)o.remove_photo=true;return o}
function openPerson(){selectedId=null;showModal('افزودن شخص جدید',fields(),'newperson')}
async function openRelated(){let base=DATA.people.find(p=>p.id===selectedId);let forced=relation==='همسر'?(base.gender==='مرد'?'زن':'مرد'):(['پدر','پسر'].includes(relation)?'مرد':'زن');showModal('افزودن '+relation,`<p class="hint">شخص جدید به عنوان ${relation} برای «${esc(base.first_name+' '+base.last_name)}» ثبت می‌شود. جنسیت به‌صورت خودکار ${forced} است.</p>${fields({gender:forced})}<hr><h4>اتصال به فرد ثبت‌شده (بدون ساخت شخص جدید)</h4><label>نام یا شناسه فرد موجود را جستجو کنید و از نتایج انتخاب کنید</label><input class="input" id="existingSearch" placeholder="نام یا شناسه شخص را جستجو کنید" oninput="searchExisting()"><div id="existingResults" class="searchresults"></div><input type="hidden" id="existing_id"><div id="motherPickWrap" class="field" style="display:none;margin-top:10px"><label>این فرزند از کدام همسر پدر است؟</label><select id="mother_id" class="input"></select><small>چون این پدر چند همسر دارد، مادر فرزند را مشخص کنید.</small></div><div id="fatherPickWrap" class="field" style="display:none;margin-top:10px"><label>این فرزند از کدام شوهر مادر است؟</label><select id="father_id" class="input"></select><small>چون برای مادر چند ازدواج ثبت شده است، پدر این فرزند را مشخص کنید.</small></div><div class="field" style="margin-top:10px"><label>تاریخ شروع ازدواج (در صورت همسر)</label><input class="input" id="start_date" placeholder="مثلاً ۱۴۰۰/۰۱/۰۱"></div>`,'related');if(['پسر','دختر'].includes(relation)&&base.gender==='مرد')updateMotherChoices(base.id)}
let searchTimer=null;async function searchExisting(){if($('existing_id'))$('existing_id').value='';clearTimeout(searchTimer);searchTimer=setTimeout(async()=>{let q=$('existingSearch').value;let resp=await api('/api/search?q='+encodeURIComponent(q));let arr=resp.items||[];let base=DATA.people.find(p=>p.id===selectedId);let g=relation==='همسر'?(base.gender==='مرد'?'زن':'مرد'):(['پدر','پسر'].includes(relation)?'مرد':'زن');$('existingResults').innerHTML=arr.filter(p=>p.gender===g&&p.id!==selectedId).map(p=>`<div class="result" onclick="chooseExisting(${p.id},'${esc(p.first_name+' '+p.last_name)}')">${esc(p.first_name+' '+p.last_name)} · ${esc(p.tribe||'بدون طایفه')} (${p.gender})</div>`).join('')||'<div class="result">موردی یافت نشد.</div>'},180)}function chooseExisting(id,label){$('existing_id').value=id;$('existingSearch').value=label;$('existingResults').innerHTML='<div class="result active">انتخاب شد: '+esc(label)+'</div>';updateMotherChoices(id)}
function updateMotherChoices(personId){
 let mw=$('motherPickWrap'),fw=$('fatherPickWrap');if(!mw||!fw)return;mw.style.display='none';fw.style.display='none';
 let fatherId=null,motherId=null,base=DATA.people.find(p=>p.id===selectedId);
 if(relation==='پدر')fatherId=Number(personId);
 else if(relation==='مادر')motherId=Number(personId);
 else if(['پسر','دختر'].includes(relation)){if(base?.gender==='مرد')fatherId=base.id;else motherId=base.id;}
 if(fatherId){let wives=DATA.marriages.filter(m=>m.husband_id===fatherId).map(m=>DATA.people.find(p=>p.id===m.wife_id)).filter(Boolean);if(wives.length>1){mw.style.display='block';$('mother_id').innerHTML=wives.map(w=>`<option value="${w.id}">${esc(w.person_code+' - '+w.first_name+' '+w.last_name)}</option>`).join('')}}
 if(motherId){let husbands=DATA.marriages.filter(m=>m.wife_id===motherId).map(m=>DATA.people.find(p=>p.id===m.husband_id)).filter(Boolean);if(husbands.length>1){fw.style.display='block';$('father_id').innerHTML=husbands.map(h=>`<option value="${h.id}">${esc(h.person_code+' - '+h.first_name+' '+h.last_name)}</option>`).join('')}}
}
async function editPerson(){try{if(!selectedId)throw Error('ابتدا شخص را انتخاب کنید.');let p=await api('/api/person/'+selectedId);showModal('ویرایش اطلاعات شخص',fields(p),'editperson');$('saveBtn').onclick=saveModal;$('saveBtn').style.display='';}catch(e){alert('باز کردن ویرایش ناموفق بود: '+e.message)}}
async function editRelations(){let p=DATA.people.find(x=>x.id===selectedId);let rels=DATA.parents.filter(x=>x.child_id===selectedId||x.parent_id===selectedId);let ms=DATA.marriages.filter(x=>x.husband_id===selectedId||x.wife_id===selectedId);let html='<p><b>روابط والدین و فرزندان</b></p>'+rels.map(x=>{let other=DATA.people.find(p=>p.id===(x.child_id===selectedId?x.parent_id:x.child_id));return `<div class="result">${x.relation}: ${esc(other?.person_code+' '+other?.first_name+' '+other?.last_name)} <button class="btn" onclick="removeParent(${x.id})">حذف رابطه</button></div>`}).join('');html+='<p style="margin-top:15px"><b>ازدواج‌ها</b></p>'+ms.map(x=>{let other=DATA.people.find(p=>p.id===(x.husband_id===selectedId?x.wife_id:x.husband_id));return `<div class="result">${esc(other?.person_code+' '+other?.first_name+' '+other?.last_name)} · ${x.end_date?'پایان‌یافته':'فعال'} <button class="btn" onclick="endMarriage(${x.id})">ثبت طلاق</button></div>`}).join('');html+=`<hr><h4>ثبت رابطه با شخصی که قبلاً ثبت شده است</h4><div class="field"><label>نوع رابطه با ${esc(p.first_name+' '+p.last_name)}</label><select id="editRelType" class="input" onchange="resetEditRelationSearch()"><option value="پدر">پدر</option><option value="مادر">مادر</option><option value="همسر">همسر</option><option value="پسر">پسر</option><option value="دختر">دختر</option></select></div><div class="field" style="margin-top:8px"><label>جستجوی شخص بر اساس نام یا شناسه</label><input id="editRelSearch" class="input" placeholder="نام یا P-000001" oninput="searchEditRelation()"><div id="editRelResults" class="searchresults"></div><input type="hidden" id="editRelTarget"></div><div id="editRelMotherWrap" style="display:none;margin-top:8px"><label>مادر این فرزند (به علت چندهمسری پدر)</label><select id="editRelMother" class="input"></select></div><div id="editRelFatherWrap" style="display:none;margin-top:8px"><label>پدر این فرزند (به علت چندهمسری مادر)</label><select id="editRelFather" class="input"></select></div><button class="btn primary" style="margin-top:10px" onclick="saveExistingRelation()">ذخیره رابطه انتخاب‌شده</button>`;showModal('روابط ثبت‌شده','<div>'+html+'</div>','relations');$('saveBtn').style.display='none';}
let editRelTimer=null;async function searchEditRelation(){if($('editRelTarget'))$('editRelTarget').value='';clearTimeout(editRelTimer);editRelTimer=setTimeout(async()=>{let q=$('editRelSearch').value,rel=$('editRelType').value;let base=DATA.people.find(p=>p.id===selectedId);let g=rel==='همسر'?(base.gender==='مرد'?'زن':'مرد'):(['پدر','پسر'].includes(rel)?'مرد':'زن');let resp=await api('/api/search?q='+encodeURIComponent(q));let arr=resp.items||[];$('editRelResults').innerHTML=arr.filter(p=>p.gender===g&&p.id!==selectedId).map(p=>`<div class="result" onclick="chooseEditRelation(${p.id},'${esc(p.first_name+' '+p.last_name)}')">${esc(p.first_name+' '+p.last_name)} · ${esc(p.tribe||'بدون طایفه')} (${p.gender})</div>`).join('')||'<div class="result">موردی یافت نشد.</div>'},160)}
function chooseEditRelation(id,label){$('editRelTarget').value=id;$('editRelSearch').value=label;$('editRelResults').innerHTML='<div class="result active">انتخاب شد: '+esc(label)+'</div>';let rel=$('editRelType').value,base=DATA.people.find(p=>p.id===selectedId),mw=$('editRelMotherWrap'),fw=$('editRelFatherWrap');mw.style.display='none';fw.style.display='none';let fatherId=null,motherId=null;if(rel==='پدر')fatherId=Number(id);else if(rel==='مادر')motherId=Number(id);else if(['پسر','دختر'].includes(rel)){if(base?.gender==='مرد')fatherId=base.id;else motherId=base.id}if(fatherId){let wives=DATA.marriages.filter(m=>m.husband_id===fatherId).map(m=>DATA.people.find(p=>p.id===m.wife_id)).filter(Boolean);if(wives.length>1){mw.style.display='block';$('editRelMother').innerHTML=wives.map(w=>`<option value="${w.id}">${esc(w.person_code+' - '+w.first_name+' '+w.last_name)}</option>`).join('')}}if(motherId){let husbands=DATA.marriages.filter(m=>m.wife_id===motherId).map(m=>DATA.people.find(p=>p.id===m.husband_id)).filter(Boolean);if(husbands.length>1){fw.style.display='block';$('editRelFather').innerHTML=husbands.map(h=>`<option value="${h.id}">${esc(h.person_code+' - '+h.first_name+' '+h.last_name)}</option>`).join('')}}}
async function saveExistingRelation(){let target=$('editRelTarget').value;if(!target){alert('ابتدا یک شخص را از نتایج جستجو انتخاب کنید.');return}let rel=$('editRelType').value,body={base_id:selectedId,target_id:Number(target),relation:rel};if($('editRelMotherWrap').style.display!=='none')body.mother_id=$('editRelMother').value;if($('editRelFatherWrap').style.display!=='none')body.father_id=$('editRelFather').value;try{await api('/api/relation',{method:'POST',body:JSON.stringify(body)});alert('رابطه با موفقیت ذخیره شد.');await loadTree();await editRelations()}catch(e){alert(e.message)}}
function resetEditRelationSearch(){$('editRelTarget').value='';$('editRelSearch').value='';$('editRelResults').innerHTML='';$('editRelMotherWrap').style.display='none';$('editRelFatherWrap').style.display='none'}
async function removeParent(id){if(!confirm('رابطه حذف شود؟'))return;await fetch('/api/parent/'+id,{method:'DELETE'});closeModal();loadTree()}
async function endMarriage(id){if(!confirm('برای این ازدواج طلاق ثبت شود؟'))return;await api('/api/divorce/'+id,{method:'POST',body:JSON.stringify({})});closeModal();loadTree()}
async function restoreDivorce(id){
 if(!confirm('آیا طلاق را حذف می‌کنید؟\nبا تأیید شما این ازدواج دوباره فعال و نشان آن به نقطه طلایی تبدیل می‌شود.'))return;
 try{await api('/api/marriage/restore-divorce/'+id,{method:'POST',body:JSON.stringify({})});await loadTree();}
 catch(e){alert(e.message)}
}
async function registerDeath(){let d=prompt('تاریخ فوت را وارد کنید (خالی = امروز):','');if(d===null)return;try{await api('/api/death/'+selectedId,{method:'POST',body:JSON.stringify({death_date:d})});await loadTree()}catch(e){alert(e.message)}}
async function registerDivorce(){let ms=await api('/api/person/'+selectedId+'/marriages');if(!ms.length){alert('این شخص ازدواج فعال ندارد.');return}let options=ms.map(m=>`${m.id} - ${m.husband_name} / ${m.wife_name}`).join('\n');let id=prompt('شناسه ازدواج موردنظر را انتخاب کنید:\n'+options,ms[0].id);if(!id)return;if(!ms.some(m=>m.id==Number(id))){alert('شناسه ازدواج معتبر نیست.');return}let d=prompt('تاریخ طلاق (خالی = امروز):','');if(d===null)return;try{await api('/api/divorce/'+id,{method:'POST',body:JSON.stringify({end_date:d})});await loadTree()}catch(e){alert(e.message)}}
async function deletePerson(){if(!selectedId){alert('ابتدا کارت شخص موردنظر را انتخاب کنید.');return}let p=DATA.people.find(x=>x.id===selectedId);if(!p){alert('شخص انتخاب‌شده پیدا نشد.');return}if(!confirm(`شخص «${p.first_name} ${p.last_name}» و روابط ثبت‌شده او حذف شود؟ این کار قابل بازگشت نیست.`))return;try{await api('/api/person/'+selectedId,{method:'DELETE'});selectedId=null;closeModal();await loadTree()}catch(e){alert(e.message)}}
async function viewPerson(){
 let f=await api('/api/person/'+selectedId+'/family'),p=f.person;
 const personLabel=x=>x?`${esc(x.person_code)} · ${esc((x.first_name||'')+' '+(x.last_name||''))} <span class="badge">${esc(x.gender||'')}</span>`:'ثبت نشده';
 const list=(arr,extra='')=>arr.length?'<ul class="family-list">'+arr.map(x=>`<li>${personLabel(x)} ${extra?extra(x):''}</li>`).join('')+'</ul>':'<div class="family-none">موردی ثبت نشده است.</div>';
 const spouseExtra=x=>`<small>${x.end_date?'پایان ازدواج: '+esc(x.end_date)+' ('+esc(x.end_reason||'')+')':'ازدواج فعال'}${x.start_date?' · شروع: '+esc(x.start_date):''}</small>`;
 const html=`<div class="person-detail-head"><div class="code">${esc(p.person_code)}</div><h2>${esc(p.first_name+' '+p.last_name)}</h2><span class="badge">${esc(p.gender)} · ${p.death_date?'درگذشته':'زنده'}</span></div>
 <div class="detail-grid">
 <div><b>تاریخ تولد</b><span>${esc(p.birth_date||'—')}</span></div><div><b>تاریخ فوت</b><span>${esc(p.death_date||'—')}</span></div>
 <div><b>قوم / طایفه</b><span>${esc(p.tribe||'—')}</span></div><div><b>شغل</b><span>${esc(p.job||'—')}</span></div>
 <div><b>تلفن</b><span>${esc(p.phone||'—')}</span></div><div><b>شهر محل سکونت</b><span>${esc(p.city||'—')}</span></div>
 <div class="wide"><b>توضیحات</b><span>${esc(p.notes||'—')}</span></div></div>
 <section class="family-section"><h4>پدر</h4>${personLabel(f.father)}</section>
 <section class="family-section"><h4>مادر</h4>${personLabel(f.mother)}</section>
 <section class="family-section"><h4>همسران</h4>${list(f.spouses,spouseExtra)}</section>
 <section class="family-section"><h4>فرزندان</h4>${list(f.children)}</section>
 <section class="family-section"><h4>خواهران و برادران</h4>${list(f.siblings)}</section>`;
 showModal('مشخصات کامل و خانواده شخص',html,'details');$('saveBtn').style.display='none';
}
async function saveModal(){const btn=$('saveBtn');try{if(modalMode==='editperson'||modalMode==='newperson'){const name=$('f_first_name')?.value?.trim();if(!name){alert('نام را وارد کنید.');return}}btn.disabled=true;btn.textContent='در حال ذخیره...';await photoCompressionPromise;const payload=readFields();if(modalMode==='newperson'){await api('/api/person',{method:'POST',body:JSON.stringify(payload)})}else if(modalMode==='editperson'){if(!selectedId)throw Error('شخصی برای ویرایش انتخاب نشده است.');await api('/api/person/'+selectedId,{method:'PUT',body:JSON.stringify(payload)})}else if(modalMode==='related'){let existing=$('existing_id').value;let body={base_id:selectedId,relation,start_date:$('start_date')?.value||'',mother_id:$('mother_id')?.value||''};if($('fatherPickWrap')?.style.display!=='none'&&$('father_id'))body.father_id=$('father_id').value;if(existing){body.target_id=Number(existing);await api('/api/relation',{method:'POST',body:JSON.stringify(body)})}else{Object.assign(body,payload);await api('/api/related',{method:'POST',body:JSON.stringify(body)})}}else{throw Error('فرم فعلی قابل ذخیره نیست.')}closeModal();await loadTree();}catch(e){alert('ذخیره اطلاعات انجام نشد: '+(e.message||e))}finally{btn.disabled=false;btn.textContent='ذخیره';btn.onclick=saveModal;}}
function zoom(f){const cv=$('treecanvas'),cx=cv.scrollLeft+cv.clientWidth/2,cy=cv.scrollTop+cv.clientHeight/2;scale=Math.max(.12,Math.min(3.2,scale*f));$('world').style.transform=`scale(${scale})`;updateWorldSpace();cv.scrollTo({left:Math.max(0,(cv.scrollLeft+cv.clientWidth/2)*f-cv.clientWidth/2),top:Math.max(0,(cv.scrollTop+cv.clientHeight/2)*f-cv.clientHeight/2),behavior:'smooth'})}
function fitTree(){const cv=$('treecanvas');const sx=Math.max(.12,(cv.clientWidth-28)/Math.max(1,treeBaseWidth));const sy=Math.max(.12,(cv.clientHeight-28)/Math.max(1,treeBaseHeight));scale=Math.min(1,sx,sy);$('world').style.transform=`scale(${scale})`;updateWorldSpace();requestAnimationFrame(()=>cv.scrollTo({left:0,top:0,behavior:'smooth'}));}
// جابه‌جایی درخت با یک انگشت یا ماوس؛ شروع حرکت از روی کارت‌ها نیز مجاز است.
let drag=null;const canvas=$('treecanvas');canvas.addEventListener('pointerdown',e=>{if(e.pointerType!=='mouse')return;if(e.target.closest('.zoomtools')||e.target.closest('button')||e.target.closest('input'))return;if(e.pointerType==='mouse'&&e.button!==0)return;drag={id:e.pointerId,x:e.clientX,y:e.clientY,l:canvas.scrollLeft,t:canvas.scrollTop,moved:false};try{canvas.setPointerCapture(e.pointerId)}catch(_){}});canvas.addEventListener('pointermove',e=>{if(drag&&drag.id===e.pointerId){const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(!drag.moved&&Math.hypot(dx,dy)>6){drag.moved=true;suppressCardClick=true;clearTimeout(touchTimer);touchStart=null;}if(drag.moved){canvas.scrollLeft=drag.l-dx;canvas.scrollTop=drag.t-dy;e.preventDefault();}}});function endCanvasDrag(e){if(drag&&(!e||drag.id===e.pointerId)){if(drag.moved){setTimeout(()=>{suppressCardClick=false},80)}drag=null}}canvas.addEventListener('pointerup',endCanvasDrag);canvas.addEventListener('pointercancel',endCanvasDrag);
// پیمایش لمسی قطعی: یک انگشت=حرکت افقی/عمودی، دو انگشت=بزرگ‌نمایی.
let pinchStartDist=0,pinchStartScale=1,pinchActive=false,touchPan=null;
canvas.addEventListener('touchstart',e=>{
 if(e.touches.length===2){pinchActive=true;touchPan=null;pinchStartDist=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);pinchStartScale=scale;drag=null;e.preventDefault();return;}
 if(e.touches.length===1){const t=e.touches[0];touchPan={x:t.clientX,y:t.clientY,left:canvas.scrollLeft,top:canvas.scrollTop,moved:false};clearTimeout(touchTimer);}
},{passive:false});
canvas.addEventListener('touchmove',e=>{
 if(pinchActive&&e.touches.length===2){let d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);scale=Math.max(.12,Math.min(3.2,pinchStartScale*d/Math.max(1,pinchStartDist)));$('world').style.transform=`scale(${scale})`;updateWorldSpace();e.preventDefault();return;}
 if(touchPan&&e.touches.length===1){const t=e.touches[0],dx=t.clientX-touchPan.x,dy=t.clientY-touchPan.y;if(!touchPan.moved&&Math.hypot(dx,dy)>5){touchPan.moved=true;suppressCardClick=true;touchStart=null;}if(touchPan.moved){canvas.scrollLeft=touchPan.left-dx;canvas.scrollTop=touchPan.top-dy;e.preventDefault();}}
},{passive:false});
canvas.addEventListener('touchend',e=>{if(e.touches.length<2)pinchActive=false;if(e.touches.length===0){if(touchPan?.moved)setTimeout(()=>suppressCardClick=false,100);touchPan=null;}},{passive:true});
canvas.addEventListener('touchcancel',()=>{touchPan=null;pinchActive=false;},{passive:true});
if(window.CURRENT_ROLE!=='admin')$('usersMenuBtn').style.display='none';loadTree();
</script></body></html>'''

# حذف رابطه والد از API
@app.delete('/api/parent/<int:link_id>')
def delete_parent_link(link_id):
    with db() as c: c.execute('DELETE FROM parent_links WHERE id=?',(link_id,))
    return jsonify(ok=True)

init_db()

if __name__ == '__main__':
    print('Shajareh running: http://127.0.0.1:5006')
    app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5006)),debug=False)
