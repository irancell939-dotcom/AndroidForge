# انبارداری — اپ اندروید (AndroidForge)

پروژهٔ Gradle استاندارد برای ساخت APK در **AndroidForge**.

## ساخت

```bash
gradle assembleDebug
```

خروجی:
```
app/build/outputs/apk/debug/app-debug.apk
```

## ویژگی‌ها

- رابط کاملاً فارسی و RTL
- تاریخ شمسی + تقویم ایرانی
- ورود / خروج کالا با ثبت شخص
- موجودی، گزارش روزانه/ماهانه/سالانه
- ذخیره‌سازی محلی (localStorage) — آفلاین
- طراحی موبایل‌فرست با دکمه‌های رنگی

## ساختار

```
AnbarAndroid/
├── settings.gradle
├── build.gradle
├── gradle.properties
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/anbar/app/MainActivity.kt
│       ├── assets/index.html      ← کل منطق UI و دیتابیس
│       └── res/
└── README.md
```

این پروژه یک **WebView** است که فایل HTML آفلاین داخل `assets` را لود می‌کند. نیازی به سرور Flask نیست.
