package com.anbar.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Environment
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.setSupportZoom(false)
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AnbarBridge(), "AnbarAndroid")

        webView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    inner class AnbarBridge {
        private fun anbarDir(): File {
            // Prefer public Documents/ANBAR, fallback to app external files
            val docs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            val dir = File(docs, "ANBAR")
            if (!dir.exists()) dir.mkdirs()
            if (dir.exists() && dir.canWrite()) return dir
            val alt = File(getExternalFilesDir(null), "ANBAR")
            if (!alt.exists()) alt.mkdirs()
            return alt
        }

        @JavascriptInterface
        fun saveBackup(json: String): String {
            return try {
                val dir = anbarDir()
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val file = File(dir, "anbar_backup_$stamp.json")
                file.writeText(json, Charsets.UTF_8)
                JSONObject()
                    .put("ok", true)
                    .put("path", file.absolutePath)
                    .put("name", file.name)
                    .toString()
            } catch (e: Exception) {
                JSONObject().put("ok", false).put("error", e.message ?: "error").toString()
            }
        }

        @JavascriptInterface
        fun listBackups(): String {
            return try {
                val dir = anbarDir()
                val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".json") }
                    ?.sortedByDescending { it.lastModified() }
                    ?.take(30)
                    ?: emptyList()
                val arr = org.json.JSONArray()
                files.forEach { f ->
                    arr.put(
                        JSONObject()
                            .put("name", f.name)
                            .put("path", f.absolutePath)
                            .put("size", f.length())
                    )
                }
                JSONObject().put("ok", true).put("files", arr).put("dir", dir.absolutePath).toString()
            } catch (e: Exception) {
                JSONObject().put("ok", false).put("error", e.message ?: "error").toString()
            }
        }

        @JavascriptInterface
        fun readBackup(path: String): String {
            return try {
                val file = File(path)
                val dir = anbarDir()
                // security: only files inside ANBAR dir
                if (!file.canonicalPath.startsWith(dir.canonicalPath)) {
                    return JSONObject().put("ok", false).put("error", "مسیر نامعتبر").toString()
                }
                val text = file.readText(Charsets.UTF_8)
                JSONObject().put("ok", true).put("data", text).toString()
            } catch (e: Exception) {
                JSONObject().put("ok", false).put("error", e.message ?: "error").toString()
            }
        }

        @JavascriptInterface
        fun getAnbarPath(): String {
            return try {
                anbarDir().absolutePath
            } catch (e: Exception) {
                ""
            }
        }
    }
}
