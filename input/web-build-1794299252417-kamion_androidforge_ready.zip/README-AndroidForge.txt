سامانه مدیریت کامیون - بسته AndroidForge
نام برنامه: سامانه مدیریت کامیون
شناسه بسته: ir.khavaran.kamion
نسخه: 1.0.0
نوع پروژه: Android Native WebView + HTML assets

نحوه ساخت:
1) کل فایل ZIP را در AndroidForge بارگذاری کنید.
2) Platform: Android و Build variant: auto یا debug را انتخاب کنید.
3) پروژه با Gradle و Android Gradle Plugin 8.7.3 ساخته می‌شود.

ورود پیش‌فرض برنامه:
نام کاربری: admin
رمز عبور: 1234

اطلاعات برنامه در فضای ذخیره‌سازی داخلی WebView (localStorage) نگهداری می‌شود.
برای حفظ اطلاعات، داده‌های برنامه را از تنظیمات اندروید پاک نکنید و برنامه را حذف نکنید.
