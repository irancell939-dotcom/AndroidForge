package com.example.phoneregistration

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class Contact(
    val id: String,
    var name: String,
    var phone: String,
    var note: String = ""
)

data class CallRecord(
    val id: String,
    val name: String,
    val phone: String,
    val timestamp: Long
)

class MainActivity : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var rvList: RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var tvCount: TextView
    private lateinit var fabAdd: FloatingActionButton
    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: ContactAdapter

    private val allContacts = mutableListOf<Contact>()
    private val filteredContacts = mutableListOf<Contact>()

    companion object {
        private const val REQUEST_CALL = 1001
    }

    private var pendingCallPhone: String? = null
    private var pendingCallName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.title = getString(R.string.app_name)

        etSearch = findViewById(R.id.etSearch)
        rvList = findViewById(R.id.rvList)
        tvEmpty = findViewById(R.id.tvEmpty)
        tvCount = findViewById(R.id.tvCount)
        fabAdd = findViewById(R.id.fabAdd)

        prefs = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)

        adapter = ContactAdapter(
            filteredContacts,
            onCall = { contact -> initiateCall(contact) },
            onEdit = { contact -> showContactDialog(contact) },
            onDelete = { contact -> confirmDelete(contact) }
        )
        rvList.layoutManager = LinearLayoutManager(this)
        rvList.adapter = adapter

        loadContacts()
        applyFilter("")

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                applyFilter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        fabAdd.setOnClickListener {
            showContactDialog(null)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_history) {
            startActivity(Intent(this, HistoryActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showContactDialog(existing: Contact?) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_contact, null)
        val etName = view.findViewById<TextInputEditText>(R.id.etName)
        val etPhone = view.findViewById<TextInputEditText>(R.id.etPhone)
        val etNote = view.findViewById<TextInputEditText>(R.id.etNote)
        val tvTitle = view.findViewById<TextView>(R.id.tvDialogTitle)

        if (existing != null) {
            tvTitle.text = getString(R.string.edit)
            etName.setText(existing.name)
            etPhone.setText(existing.phone)
            etNote.setText(existing.note)
        } else {
            tvTitle.text = getString(R.string.add_contact)
        }

        AlertDialog.Builder(this)
            .setView(view)
            .setPositiveButton(R.string.save) { _, _ ->
                val name = etName.text?.toString()?.trim().orEmpty()
                val phone = etPhone.text?.toString()?.trim().orEmpty()
                val note = etNote.text?.toString()?.trim().orEmpty()

                if (name.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(this, R.string.error_empty, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (existing != null) {
                    existing.name = name
                    existing.phone = phone
                    existing.note = note
                } else {
                    allContacts.add(0, Contact(UUID.randomUUID().toString(), name, phone, note))
                }
                saveContacts()
                applyFilter(etSearch.text.toString())
                Toast.makeText(this, R.string.success_save, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmDelete(contact: Contact) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete)
            .setMessage("«${contact.name}» حذف شود؟")
            .setPositiveButton(R.string.delete) { _, _ ->
                allContacts.removeAll { it.id == contact.id }
                saveContacts()
                applyFilter(etSearch.text.toString())
                Toast.makeText(this, R.string.success_delete, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun initiateCall(contact: Contact) {
        pendingCallPhone = contact.phone
        pendingCallName = contact.name

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            == PackageManager.PERMISSION_GRANTED
        ) {
            doCall(contact.phone, contact.name)
        } else {
            // Prefer ACTION_DIAL which needs no permission
            doDial(contact.phone, contact.name)
        }
    }

    private fun doDial(phone: String, name: String) {
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
            startActivity(intent)
            addCallHistory(name, phone)
        } catch (e: Exception) {
            Toast.makeText(this, "امکان تماس وجود ندارد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun doCall(phone: String, name: String) {
        try {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phone"))
            startActivity(intent)
            addCallHistory(name, phone)
        } catch (e: Exception) {
            doDial(phone, name)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CALL && grantResults.isNotEmpty()
            && grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            pendingCallPhone?.let { phone ->
                pendingCallName?.let { name -> doCall(phone, name) }
            }
        } else {
            pendingCallPhone?.let { phone ->
                pendingCallName?.let { name -> doDial(phone, name) }
            }
        }
    }

    private fun addCallHistory(name: String, phone: String) {
        val records = loadCallHistory().toMutableList()
        records.add(0, CallRecord(UUID.randomUUID().toString(), name, phone, System.currentTimeMillis()))
        // Keep only last 100
        val limited = records.take(100)
        val arr = JSONArray()
        limited.forEach { r ->
            val obj = JSONObject()
            obj.put("id", r.id)
            obj.put("name", r.name)
            obj.put("phone", r.phone)
            obj.put("timestamp", r.timestamp)
            arr.put(obj)
        }
        prefs.edit().putString("call_history", arr.toString()).apply()
    }

    private fun loadCallHistory(): List<CallRecord> {
        val json = prefs.getString("call_history", "[]") ?: "[]"
        val list = mutableListOf<CallRecord>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    CallRecord(
                        obj.getString("id"),
                        obj.getString("name"),
                        obj.getString("phone"),
                        obj.getLong("timestamp")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun applyFilter(query: String) {
        filteredContacts.clear()
        val q = query.trim().lowercase()
        if (q.isEmpty()) {
            filteredContacts.addAll(allContacts)
        } else {
            filteredContacts.addAll(allContacts.filter {
                it.name.lowercase().contains(q) || it.phone.contains(q) || it.note.lowercase().contains(q)
            })
        }
        adapter.notifyDataSetChanged()
        updateEmptyState(query)
        tvCount.text = "${filteredContacts.size} مخاطب"
    }

    private fun updateEmptyState(query: String) {
        if (filteredContacts.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            rvList.visibility = View.GONE
            tvEmpty.text = if (query.isBlank()) getString(R.string.empty_list)
            else getString(R.string.empty_search)
        } else {
            tvEmpty.visibility = View.GONE
            rvList.visibility = View.VISIBLE
        }
    }

    private fun saveContacts() {
        val arr = JSONArray()
        allContacts.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id)
            obj.put("name", c.name)
            obj.put("phone", c.phone)
            obj.put("note", c.note)
            arr.put(obj)
        }
        prefs.edit().putString("contacts", arr.toString()).apply()
    }

    private fun loadContacts() {
        allContacts.clear()
        val json = prefs.getString("contacts", "[]") ?: "[]"
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                allContacts.add(
                    Contact(
                        obj.getString("id"),
                        obj.getString("name"),
                        obj.getString("phone"),
                        obj.optString("note", "")
                    )
                )
            }
        } catch (_: Exception) {}
    }
}

class ContactAdapter(
    private val items: List<Contact>,
    private val onCall: (Contact) -> Unit,
    private val onEdit: (Contact) -> Unit,
    private val onDelete: (Contact) -> Unit
) : RecyclerView.Adapter<ContactAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvAvatar: TextView = view.findViewById(R.id.tvAvatar)
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvPhone: TextView = view.findViewById(R.id.tvPhone)
        val tvNote: TextView = view.findViewById(R.id.tvNote)
        val btnCall: MaterialButton = view.findViewById(R.id.btnCall)
        val btnEdit: MaterialButton = view.findViewById(R.id.btnEdit)
        val btnDelete: MaterialButton = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contact, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvName.text = item.name
        holder.tvPhone.text = item.phone
        holder.tvAvatar.text = item.name.take(1).uppercase()

        if (item.note.isNotBlank()) {
            holder.tvNote.visibility = View.VISIBLE
            holder.tvNote.text = item.note
        } else {
            holder.tvNote.visibility = View.GONE
        }

        holder.btnCall.setOnClickListener { onCall(item) }
        holder.btnEdit.setOnClickListener { onEdit(item) }
        holder.btnDelete.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount(): Int = items.size
}
