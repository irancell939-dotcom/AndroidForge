_server_started = False


def start_server(data_dir):

    global DB, _server_started

    if _server_started:
        return

    os.makedirs(data_dir, exist_ok=True)

    DB = os.path.join(data_dir, "game.db")

    init_db()

    _server_started = True

    def run_flask():

        app.run(
            host="127.0.0.1",
            port=5003,
            debug=False,
            use_reloader=False,
            threaded=True
        )

    thread = threading.Thread(
        target=run_flask,
        daemon=True
    )

    thread.start()