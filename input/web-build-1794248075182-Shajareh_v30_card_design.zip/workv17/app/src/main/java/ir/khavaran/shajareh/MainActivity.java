package ir.khavaran.shajareh;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import java.io.OutputStream;
import java.io.IOException;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.CookieManager;
import android.graphics.Color;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private ProgressBar progress;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int attempts = 0;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4107;
    private static final int BACKUP_CREATE_REQUEST = 4108;
    private byte[] pendingBackup;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16, 38, 62));
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(246, 247, 249));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void saveBackup(String encoded) {
                try {
                    pendingBackup = Base64.decode(encoded, Base64.DEFAULT);
                    runOnUiThread(() -> {
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/x-sqlite3");
                        intent.putExtra(Intent.EXTRA_TITLE, "shajareh-backup.db");
                        startActivityForResult(intent, BACKUP_CREATE_REQUEST);
                    });
                } catch (Exception ex) {
                    runOnUiThread(() -> android.widget.Toast.makeText(MainActivity.this, "آماده‌سازی پشتیبان ناموفق بود", android.widget.Toast.LENGTH_LONG).show());
                }
            }
        }, "AndroidBackup");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                status.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
            }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (failingUrl != null && failingUrl.startsWith("http://127.0.0.1")) retryLoad();
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        progress = new ProgressBar(this);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(100, 100, android.view.Gravity.CENTER);
        root.addView(progress, pp);
        status = new TextView(this);
        status.setText("در حال راه‌اندازی شجره‌نامه...");
        status.setTextColor(Color.rgb(25, 55, 78));
        status.setTextSize(16);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, android.view.Gravity.CENTER_HORIZONTAL | android.view.Gravity.CENTER_VERTICAL);
        sp.topMargin = 95;
        root.addView(status, sp);
        webView.setVisibility(View.INVISIBLE);
        setContentView(root);
        try {
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            Python.getInstance().getModule("android_entry").callAttr("start_server", getFilesDir().getAbsolutePath());
            // هر بار که برنامه از نو باز می‌شود، کوکی ورود قبلی پاک می‌شود.
            CookieManager cookies = CookieManager.getInstance();
            cookies.removeAllCookies(removed -> {
                cookies.flush();
                handler.postDelayed(() -> webView.loadUrl("http://127.0.0.1:5006"), 1800);
            });
        } catch (Exception e) {
            status.setText("راه‌اندازی برنامه ناموفق بود: " + e.getMessage());
            progress.setVisibility(View.GONE);
        }
    }

    private void retryLoad() {
        if (attempts++ < 12) handler.postDelayed(() -> webView.loadUrl("http://127.0.0.1:5006"), 700);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BACKUP_CREATE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackup != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IOException("خروجی فایل باز نشد");
                    out.write(pendingBackup);
                    out.flush();
                    android.widget.Toast.makeText(this, "فایل پشتیبان با موفقیت ذخیره شد.", android.widget.Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    android.widget.Toast.makeText(this, "ذخیره پشتیبان ناموفق بود: " + ex.getMessage(), android.widget.Toast.LENGTH_LONG).show();
                }
            }
            pendingBackup = null;
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
