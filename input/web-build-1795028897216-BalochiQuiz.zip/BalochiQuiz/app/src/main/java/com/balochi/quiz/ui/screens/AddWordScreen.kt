package com.balochi.quiz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.BalochiWord
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.theme.*

@Composable
fun AddWordScreen(
    viewModel: QuizViewModel,
    onBack: () -> Unit
) {
    var balochi by remember { mutableStateOf("") }
    var persian by remember { mutableStateOf("") }
    var english by remember { mutableStateOf("") }
    var arabic by remember { mutableStateOf("") }
    var urdu by remember { mutableStateOf("") }
    var example by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmNightParchment)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // نوار بالا
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "بازگشت",
                    tint = Cream
                )
            }
            Text(
                text = "افزودن کلمه جدید",
                color = Cream,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            WordTextField(
                value = balochi,
                onValueChange = { balochi = it; showError = false },
                label = "کلمه بلوچی *",
                isError = showError && balochi.isBlank()
            )

            Spacer(modifier = Modifier.height(16.dp))

            WordTextField(
                value = persian,
                onValueChange = { persian = it },
                label = "معنی فارسی"
            )

            Spacer(modifier = Modifier.height(12.dp))

            WordTextField(
                value = english,
                onValueChange = { english = it },
                label = "English meaning"
            )

            Spacer(modifier = Modifier.height(12.dp))

            WordTextField(
                value = arabic,
                onValueChange = { arabic = it },
                label = "المعنى بالعربية"
            )

            Spacer(modifier = Modifier.height(12.dp))

            WordTextField(
                value = urdu,
                onValueChange = { urdu = it },
                label = "معنی اردو"
            )

            Spacer(modifier = Modifier.height(12.dp))

            WordTextField(
                value = example,
                onValueChange = { example = it },
                label = "مثال (اختیاری)",
                singleLine = false
            )

            if (showError) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "حداقل کلمه بلوچی و یک معنی را وارد کنید",
                    color = WrongRed,
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = {
                    if (balochi.isBlank() ||
                        (persian.isBlank() && english.isBlank() &&
                                arabic.isBlank() && urdu.isBlank())
                    ) {
                        showError = true
                        return@Button
                    }
                    val word = BalochiWord(
                        balochi = balochi.trim(),
                        persian = persian.trim(),
                        english = english.trim(),
                        arabic = arabic.trim(),
                        urdu = urdu.trim(),
                        example = example.trim()
                    )
                    viewModel.addWord(word)
                    onBack()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = SaffronGold,
                    contentColor = WarmNightParchment
                )
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("ذخیره کلمه", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun WordTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    isError: Boolean = false,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = singleLine,
        isError = isError,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = SaffronGold,
            unfocusedBorderColor = TextSecondary.copy(alpha = 0.4f),
            focusedLabelColor = SaffronGold,
            unfocusedLabelColor = TextSecondary,
            cursorColor = SaffronGold,
            focusedTextColor = Cream,
            unfocusedTextColor = Cream,
            errorBorderColor = WrongRed,
            errorLabelColor = WrongRed
        )
    )
}
