package com.balochi.quiz.data

/**
 * مدل اصلی کلمه بلوچی
 * هر کلمه می‌تواند معنی فارسی، انگلیسی، عربی و اردو داشته باشد.
 */
data class BalochiWord(
    val id: String = java.util.UUID.randomUUID().toString(),
    val balochi: String,                    // کلمه به بلوچی
    val persian: String = "",               // معنی فارسی
    val english: String = "",               // معنی انگلیسی
    val arabic: String = "",                // معنی عربی
    val urdu: String = "",                  // معنی اردو
    val example: String = "",               // مثال (اختیاری)
    val createdAt: Long = System.currentTimeMillis()
) {
    /** آیا حداقل یک معنی دارد؟ */
    fun hasAnyMeaning(): Boolean =
        persian.isNotBlank() || english.isNotBlank() ||
                arabic.isNotBlank() || urdu.isNotBlank()

    /** گرفتن معنی بر اساس زبان */
    fun getMeaning(lang: QuizLanguage): String = when (lang) {
        QuizLanguage.PERSIAN -> persian
        QuizLanguage.ENGLISH -> english
        QuizLanguage.ARABIC -> arabic
        QuizLanguage.URDU -> urdu
    }
}

enum class QuizLanguage(val displayName: String, val code: String) {
    PERSIAN("فارسی", "fa"),
    ENGLISH("English", "en"),
    ARABIC("العربية", "ar"),
    URDU("اردو", "ur");

    companion object {
        fun fromCode(code: String): QuizLanguage =
            entries.find { it.code == code } ?: PERSIAN
    }
}
