package com.balochi.quiz.ui.screens

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.balochi.quiz.data.QuizViewModel

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Quiz : Screen("quiz")
    data object AddWord : Screen("add_word")
    data object WordList : Screen("word_list")
}

@Composable
fun AppNavigation(viewModel: QuizViewModel) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = viewModel,
                onStartQuiz = {
                    viewModel.startQuiz()
                    navController.navigate(Screen.Quiz.route)
                },
                onAddWord = { navController.navigate(Screen.AddWord.route) },
                onWordList = { navController.navigate(Screen.WordList.route) }
            )
        }
        composable(Screen.Quiz.route) {
            QuizScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onFinish = {
                    navController.popBackStack(Screen.Home.route, inclusive = false)
                }
            )
        }
        composable(Screen.AddWord.route) {
            AddWordScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Screen.WordList.route) {
            WordListScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
