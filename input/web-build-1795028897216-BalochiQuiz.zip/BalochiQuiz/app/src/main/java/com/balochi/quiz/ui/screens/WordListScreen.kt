package com.balochi.quiz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.BalochiWord
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.theme.*

@Composable
fun WordListScreen(
    viewModel: QuizViewModel,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmNightParchment)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "بازگشت",
                    tint = Cream
                )
            }
            Text(
                text = "لیست کلمات (${viewModel.words.size})",
                color = Cream,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        if (viewModel.words.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("هنوز کلمه‌ای اضافه نشده", color = TextSecondary)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(viewModel.words, key = { it.id }) { word ->
                    WordItem(
                        word = word,
                        onDelete = { viewModel.deleteWord(word.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun WordItem(
    word: BalochiWord,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = word.balochi,
                    color = SaffronGold,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                if (word.persian.isNotBlank()) {
                    MeaningLine("فارسی", word.persian)
                }
                if (word.english.isNotBlank()) {
                    MeaningLine("English", word.english)
                }
                if (word.arabic.isNotBlank()) {
                    MeaningLine("عربی", word.arabic)
                }
                if (word.urdu.isNotBlank()) {
                    MeaningLine("اردو", word.urdu)
                }
            }
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = "حذف",
                    tint = WrongRed.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
private fun MeaningLine(label: String, value: String) {
    Text(
        text = "$label: $value",
        color = TextSecondary,
        fontSize = 15.sp
    )
}
