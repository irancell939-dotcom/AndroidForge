package com.balochi.quiz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.QuizLanguage
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.theme.*

@Composable
fun HomeScreen(
    viewModel: QuizViewModel,
    onStartQuiz: () -> Unit,
    onAddWord: () -> Unit,
    onWordList: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmNightParchment)
            .padding(horizontal = 22.dp)
            .statusBarsPadding()
            .navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(40.dp))

        // عنوان بزرگ
        Text(
            text = "لغت بلوچی",
            fontSize = 42.sp,
            fontWeight = FontWeight.Bold,
            color = SaffronGold
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "آزمون چندگزینه‌ای زبان بلوچی",
            fontSize = 17.sp,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(36.dp))

        // کارت انتخاب زبان
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(CardBackground)
                .border(1.dp, BorderSubtle, RoundedCornerShape(20.dp))
                .padding(18.dp)
        ) {
            Text(
                text = "زبان معنی‌ها",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = Cream,
                modifier = Modifier.padding(bottom = 14.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuizLanguage.entries.forEach { lang ->
                    LanguageChip(
                        language = lang,
                        selected = viewModel.selectedLanguage == lang,
                        onClick = { viewModel.setLanguage(lang) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // دکمه اصلی شروع
        MainButton(
            text = "شروع آزمون",
            icon = Icons.Default.PlayArrow,
            onClick = onStartQuiz,
            enabled = viewModel.words.any {
                it.getMeaning(viewModel.selectedLanguage).isNotBlank()
            }
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedMainButton(
            text = "افزودن کلمه جدید",
            icon = Icons.Default.Add,
            onClick = onAddWord
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedMainButton(
            text = "لیست کلمات (${viewModel.words.size})",
            icon = Icons.Default.List,
            onClick = onWordList
        )

        Spacer(modifier = Modifier.weight(1f))

        Text(
            text = "کلمات نمونه از قبل موجود است.\nمی‌توانید کلمات خودتان را اضافه کنید.",
            fontSize = 14.sp,
            color = TextMuted,
            textAlign = TextAlign.Center,
            lineHeight = 22.sp
        )
        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun LanguageChip(
    language: QuizLanguage,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) SaffronGold else ChipBackground)
            .border(
                width = if (selected) 0.dp else 1.dp,
                color = if (selected) SaffronGold else BorderSubtle,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = language.displayName,
            color = if (selected) WarmNightParchment else Cream,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun MainButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = SaffronGold,
            contentColor = WarmNightParchment,
            disabledContainerColor = CardBackground,
            disabledContentColor = TextMuted
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(26.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Text(text = text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun OutlinedMainButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = Cream
        ),
        border = ButtonDefaults.outlinedButtonBorder.copy(
            width = 1.5.dp,
            brush = androidx.compose.ui.graphics.SolidColor(BorderSubtle)
        )
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Text(text = text, fontSize = 17.sp, fontWeight = FontWeight.Medium)
    }
}
