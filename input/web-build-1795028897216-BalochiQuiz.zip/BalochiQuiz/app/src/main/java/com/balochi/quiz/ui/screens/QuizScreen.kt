package com.balochi.quiz.ui.screens

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun QuizScreen(
    viewModel: QuizViewModel,
    onBack: () -> Unit,
    onFinish: () -> Unit
) {
    val currentWord = viewModel.currentWord
    val options = viewModel.options
    val selectedIndex = viewModel.selectedOptionIndex
    val isRevealed = viewModel.isAnswerRevealed
    val correctIndex = viewModel.correctOptionIndex

    LaunchedEffect(selectedIndex, isRevealed) {
        if (isRevealed && selectedIndex != null) {
            val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
            if (selectedIndex == correctIndex) {
                toneGen.startTone(ToneGenerator.TONE_PROP_ACK, 220)
            } else {
                toneGen.startTone(ToneGenerator.TONE_PROP_NACK, 450)
            }
            delay(500)
            toneGen.release()
        }
    }

    LaunchedEffect(isRevealed) {
        if (isRevealed) {
            delay(1700)
            if (!viewModel.quizFinished) {
                viewModel.onContinueAfterAnswer()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmNightParchment)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "بازگشت",
                    tint = Cream,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "سوال ${viewModel.totalAnswered + if (isRevealed) 0 else 1} از ۱۰",
                color = TextSecondary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "${viewModel.score}",
                color = SaffronGold,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        }

        if (viewModel.quizFinished) {
            ResultContent(
                score = viewModel.score,
                total = viewModel.totalAnswered,
                onFinish = onFinish
            )
        } else if (currentWord != null && options.size == 4) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 28.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "معنی این کلمه چیست؟",
                        color = TextSecondary,
                        fontSize = 17.sp
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    Text(
                        text = currentWord.balochi,
                        color = SaffronGold,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        lineHeight = 52.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    OptionCard(
                        text = options[0],
                        index = 0,
                        selectedIndex = selectedIndex,
                        correctIndex = correctIndex,
                        isRevealed = isRevealed,
                        onClick = { viewModel.selectOption(0) },
                        modifier = Modifier.weight(1f)
                    )
                    OptionCard(
                        text = options[1],
                        index = 1,
                        selectedIndex = selectedIndex,
                        correctIndex = correctIndex,
                        isRevealed = isRevealed,
                        onClick = { viewModel.selectOption(1) },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    OptionCard(
                        text = options[2],
                        index = 2,
                        selectedIndex = selectedIndex,
                        correctIndex = correctIndex,
                        isRevealed = isRevealed,
                        onClick = { viewModel.selectOption(2) },
                        modifier = Modifier.weight(1f)
                    )
                    OptionCard(
                        text = options[3],
                        index = 3,
                        selectedIndex = selectedIndex,
                        correctIndex = correctIndex,
                        isRevealed = isRevealed,
                        onClick = { viewModel.selectOption(3) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            if (isRevealed && selectedIndex != null) {
                Spacer(modifier = Modifier.height(24.dp))
                FeedbackBanner(
                    isCorrect = selectedIndex == correctIndex,
                    correctAnswer = options.getOrNull(correctIndex) ?: ""
                )
            }
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = SaffronGold, strokeWidth = 3.dp)
            }
        }
    }
}

@Composable
private fun OptionCard(
    text: String,
    index: Int,
    selectedIndex: Int?,
    correctIndex: Int,
    isRevealed: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSelected = selectedIndex == index
    val isCorrect = index == correctIndex

    val backgroundColor by animateColorAsState(
        targetValue = when {
            !isRevealed -> CardBackgroundLight
            isCorrect -> CorrectGreen.copy(alpha = 0.28f)
            isSelected && !isCorrect -> WrongRed.copy(alpha = 0.28f)
            else -> CardBackground
        },
        animationSpec = tween(280),
        label = "bg"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            !isRevealed && isSelected -> SaffronGold
            isRevealed && isCorrect -> CorrectGreen
            isRevealed && isSelected && !isCorrect -> WrongRed
            else -> BorderSubtle
        },
        animationSpec = tween(280),
        label = "border"
    )

    Box(
        modifier = modifier
            .aspectRatio(1.1f)
            .clip(RoundedCornerShape(20.dp))
            .background(backgroundColor)
            .border(2.5.dp, borderColor, RoundedCornerShape(20.dp))
            .clickable(enabled = !isRevealed, onClick = onClick)
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            maxLines = 4,
            lineHeight = 26.sp
        )
    }
}

@Composable
private fun FeedbackBanner(
    isCorrect: Boolean,
    correctAnswer: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (isCorrect) CorrectGreen.copy(alpha = 0.22f) else WrongRed.copy(alpha = 0.22f))
            .border(
                1.5.dp,
                if (isCorrect) CorrectGreen.copy(alpha = 0.5f) else WrongRed.copy(alpha = 0.5f),
                RoundedCornerShape(16.dp)
            )
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = if (isCorrect) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (isCorrect) CorrectGreen else WrongRed,
            modifier = Modifier.size(32.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column {
            Text(
                text = if (isCorrect) "آفرین! درست بود" else "اشتباه بود",
                color = if (isCorrect) CorrectGreen else WrongRed,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            if (!isCorrect) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "جواب درست: $correctAnswer",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun ResultContent(
    score: Int,
    total: Int,
    onFinish: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "پایان آزمون",
            color = SaffronGold,
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(28.dp))
        Text(
            text = "$score از $total",
            color = TextPrimary,
            fontSize = 56.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "پاسخ صحیح",
            color = TextSecondary,
            fontSize = 18.sp
        )
        Spacer(modifier = Modifier.height(48.dp))
        MainButton(
            text = "بازگشت به صفحه اصلی",
            icon = Icons.AutoMirrored.Filled.ArrowBack,
            onClick = onFinish
        )
    }
}
