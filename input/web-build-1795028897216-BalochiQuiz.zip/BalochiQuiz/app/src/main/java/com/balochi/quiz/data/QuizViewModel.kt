package com.balochi.quiz.data

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class QuizViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = WordRepository(application)

    var words by mutableStateOf<List<BalochiWord>>(emptyList())
        private set

    var selectedLanguage by mutableStateOf(QuizLanguage.PERSIAN)
        private set

    // --- Quiz state ---
    var currentWord by mutableStateOf<BalochiWord?>(null)
        private set

    var options by mutableStateOf<List<String>>(emptyList())
        private set

    var selectedOptionIndex by mutableStateOf<Int?>(null)
        private set

    var isAnswerRevealed by mutableStateOf(false)
        private set

    var correctOptionIndex by mutableStateOf(-1)
        private set

    var score by mutableStateOf(0)
        private set

    var totalAnswered by mutableStateOf(0)
        private set

    var quizFinished by mutableStateOf(false)
        private set

    private var usedWordIds = mutableSetOf<String>()

    init {
        loadWords()
    }

    fun loadWords() {
        words = repository.getAllWords()
    }

    fun setLanguage(lang: QuizLanguage) {
        selectedLanguage = lang
    }

    fun addWord(word: BalochiWord) {
        repository.addWord(word)
        loadWords()
    }

    fun deleteWord(id: String) {
        repository.deleteWord(id)
        loadWords()
    }

    // --- Quiz logic ---

    fun startQuiz() {
        score = 0
        totalAnswered = 0
        usedWordIds.clear()
        quizFinished = false
        nextQuestion()
    }

    fun nextQuestion() {
        selectedOptionIndex = null
        isAnswerRevealed = false

        val available = words.filter {
            it.id !in usedWordIds && it.getMeaning(selectedLanguage).isNotBlank()
        }

        if (available.isEmpty()) {
            // اگر همه کلمات استفاده شدند، دوباره شروع کن یا تمام کن
            if (words.any { it.getMeaning(selectedLanguage).isNotBlank() }) {
                usedWordIds.clear()
                nextQuestion()
            } else {
                quizFinished = true
            }
            return
        }

        val word = available.random()
        usedWordIds.add(word.id)
        currentWord = word

        val correctMeaning = word.getMeaning(selectedLanguage)

        // سه گزینه غلط از کلمات دیگر
        val wrongMeanings = words
            .filter { it.id != word.id && it.getMeaning(selectedLanguage).isNotBlank() }
            .map { it.getMeaning(selectedLanguage) }
            .distinct()
            .filter { it != correctMeaning }
            .shuffled()
            .take(3)

        val allOptions = (wrongMeanings + correctMeaning).shuffled()
        options = allOptions
        correctOptionIndex = allOptions.indexOf(correctMeaning)
    }

    fun selectOption(index: Int) {
        if (isAnswerRevealed) return
        selectedOptionIndex = index
        isAnswerRevealed = true
        totalAnswered++

        if (index == correctOptionIndex) {
            score++
        }

        // بعد از ۱.۵ ثانیه برو سوال بعدی (در UI کنترل می‌شود)
    }

    fun onContinueAfterAnswer() {
        if (totalAnswered >= 10) { // هر آزمون ۱۰ سوال
            quizFinished = true
        } else {
            nextQuestion()
        }
    }
}
