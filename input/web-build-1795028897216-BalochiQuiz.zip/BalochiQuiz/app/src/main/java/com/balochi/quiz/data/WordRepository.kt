package com.balochi.quiz.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class WordRepository(context: Context) {

    private val prefs = context.getSharedPreferences("balochi_words", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val key = "words_list"

    fun getAllWords(): List<BalochiWord> {
        val json = prefs.getString(key, null) ?: return sampleWords()
        return try {
            val type = object : TypeToken<List<BalochiWord>>() {}.type
            gson.fromJson<List<BalochiWord>>(json, type) ?: sampleWords()
        } catch (e: Exception) {
            sampleWords()
        }
    }

    fun saveWords(words: List<BalochiWord>) {
        val json = gson.toJson(words)
        prefs.edit().putString(key, json).apply()
    }

    fun addWord(word: BalochiWord) {
        val current = getAllWords().toMutableList()
        current.add(0, word)
        saveWords(current)
    }

    fun updateWord(word: BalochiWord) {
        val current = getAllWords().toMutableList()
        val index = current.indexOfFirst { it.id == word.id }
        if (index >= 0) {
            current[index] = word
            saveWords(current)
        }
    }

    fun deleteWord(id: String) {
        val current = getAllWords().toMutableList()
        current.removeAll { it.id == id }
        saveWords(current)
    }

    /** کلمات نمونه برای شروع */
    private fun sampleWords(): List<BalochiWord> = listOf(
        BalochiWord(
            balochi = "آب",
            persian = "آب",
            english = "Water",
            arabic = "ماء",
            urdu = "پانی"
        ),
        BalochiWord(
            balochi = "نان",
            persian = "نان",
            english = "Bread",
            arabic = "خبز",
            urdu = "روٹی"
        ),
        BalochiWord(
            balochi = "خانه",
            persian = "خانه",
            english = "House",
            arabic = "منزل",
            urdu = "گھر"
        ),
        BalochiWord(
            balochi = "دوست",
            persian = "دوست",
            english = "Friend",
            arabic = "صديق",
            urdu = "دوست"
        ),
        BalochiWord(
            balochi = "کتاب",
            persian = "کتاب",
            english = "Book",
            arabic = "كتاب",
            urdu = "کتاب"
        ),
        BalochiWord(
            balochi = "ماه",
            persian = "ماه",
            english = "Moon / Month",
            arabic = "قمر / شهر",
            urdu = "چاند / مہینہ"
        ),
        BalochiWord(
            balochi = "خورشید",
            persian = "خورشید",
            english = "Sun",
            arabic = "شمس",
            urdu = "سورج"
        ),
        BalochiWord(
            balochi = "دریا",
            persian = "دریا",
            english = "Sea",
            arabic = "بحر",
            urdu = "سمندر"
        )
    )
}
