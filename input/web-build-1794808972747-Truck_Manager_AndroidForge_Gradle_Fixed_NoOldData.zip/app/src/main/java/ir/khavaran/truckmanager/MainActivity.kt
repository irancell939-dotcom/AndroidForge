package ir.khavaran.truckmanager

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.view.View
import android.widget.ProgressBar
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.widget.Toast
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private var attempts = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        status = TextView(this).apply {
            text = "در حال آماده‌سازی برنامه..."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(24, 24, 24, 12)
        }
        progress = ProgressBar(this).apply { isIndeterminate = true }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }
        layout.addView(status)
        layout.addView(progress)
        layout.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)

        try {
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
            Python.getInstance().getModule("server").callAttr("start_server", filesDir.absolutePath)
            waitForServer()
        } catch (e: Exception) {
            status.text = "خطا در راه‌اندازی: ${e.message}"
            progress.visibility = View.GONE
        }
    }

    private fun waitForServer() {
        thread {
            var ready = false
            while (attempts < 60 && !ready) {
                try {
                    val conn = URL("http://127.0.0.1:5008/").openConnection() as HttpURLConnection
                    conn.connectTimeout = 700
                    conn.readTimeout = 700
                    conn.connect()
                    ready = conn.responseCode in 200..499
                    conn.disconnect()
                } catch (_: Exception) { }
                if (!ready) Thread.sleep(500)
                attempts++
            }
            handler.post {
                progress.visibility = View.GONE
                if (ready) {
                    status.visibility = View.GONE
                    webView.loadUrl("http://127.0.0.1:5008/")
                } else {
                    status.text = "تعذر تشغيل سرور داخلی برنامه. لطفاً برنامه را دوباره اجرا کنید."
                }
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
