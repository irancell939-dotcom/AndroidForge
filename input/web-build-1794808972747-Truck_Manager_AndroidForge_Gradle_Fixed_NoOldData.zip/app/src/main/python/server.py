import os
import sys
import threading

_started = False
_lock = threading.Lock()

def start_server(data_dir):
    global _started
    with _lock:
        if _started:
            return
        source_dir = os.path.dirname(os.path.abspath(__file__))
        if source_dir not in sys.path:
            sys.path.insert(0, source_dir)

        # Keep the app's templates/static files in the packaged source directory,
        # while storing the fresh SQLite database in Android's private app storage.
        os.chdir(source_dir)
        import app as truck_app
        truck_app.DATABASE = os.path.join(data_dir, "truck_manager.db")
        truck_app.app.template_folder = os.path.join(source_dir, "templates")
        truck_app.app.static_folder = os.path.join(source_dir, "static")

        def run():
            truck_app.init_db()
            truck_app.app.run(host="127.0.0.1", port=5008, debug=False, use_reloader=False, threaded=True)

        threading.Thread(target=run, daemon=True).start()
        _started = True
