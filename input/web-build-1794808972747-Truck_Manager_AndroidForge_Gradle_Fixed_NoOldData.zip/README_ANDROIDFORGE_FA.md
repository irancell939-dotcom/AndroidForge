پروژه AndroidForge – مدیریت کامیون

این ZIP یک پروژه واقعی Android/Gradle است و باید از ریشه‌ای بارگذاری شود که فایل settings.gradle و پوشه app در آن قرار دارند.

تنظیمات:
- Gradle 8.7
- Android Gradle Plugin 8.5.2
- Kotlin 1.9.24
- Chaquopy 16.0.0 / Python 3.10
- Flask 3.0.0 و jdatetime 4.1.0
- شناسه برنامه: ir.khavaran.truckmanager
- پورت داخلی Flask: 5008

داده‌ها:
- دیتابیس قدیمی همراه پروژه قرار داده نشده است.
- دیتابیس جدید در اولین اجرا در فضای خصوصی برنامه ساخته می‌شود.
- برای شروع کاملاً خالی، اطلاعات قبلی وجود ندارد.

مهم:
این بسته ساختار Gradle و اتصال Android به برنامه Flask را فراهم می‌کند. Build نهایی باید در AndroidForge با دسترسی به مخازن Google/Maven و Android SDK انجام شود.
