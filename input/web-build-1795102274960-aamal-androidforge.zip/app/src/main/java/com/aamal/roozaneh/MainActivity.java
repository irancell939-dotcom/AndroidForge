package com.aamal.roozaneh;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONObject;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private static final String CHANNEL_ID = "aamal_daily";
    private static final int NOTIF_REQ = 1001;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createNotificationChannel();
        requestNotifPermission();
        // Always (re)schedule from saved times + night reminder using device clock
        scheduleNightReminder();
        restorePrayerAlarms(this);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new WebAppInterface(this), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "یادآوری اعمال روزانه", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("اعلان نماز و تکمیل کارنامه");
            channel.enableVibration(true);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQ);
            }
        }
    }

    private void scheduleNightReminder() {
        scheduleAt(this, 21, 0, 9000, "night",
            "امروزت چگونه گذشت؟ کارنامه اعمالت را تکمیل کن");
    }

    /** Schedule using device local timezone Calendar */
    public static void scheduleAt(Context ctx, int hour, int minute, int reqCode, String type, String message) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            Intent intent = new Intent(ctx, NotificationReceiver.class);
            intent.putExtra("type", type);
            intent.putExtra("message", message);
            intent.putExtra("reqCode", reqCode);
            intent.putExtra("hour", hour);
            intent.putExtra("minute", minute);

            PendingIntent pi = PendingIntent.getBroadcast(ctx, reqCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            // Device local time
            Calendar cal = Calendar.getInstance(); // default = device timezone
            cal.set(Calendar.HOUR_OF_DAY, hour);
            cal.set(Calendar.MINUTE, minute);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1);
            }

            // Prefer setAlarmClock (shows in status bar, more reliable) when available
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                AlarmManager.AlarmClockInfo info =
                    new AlarmManager.AlarmClockInfo(cal.getTimeInMillis(), pi);
                am.setAlarmClock(info, pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void restorePrayerAlarms(Context ctx) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("aamal", Context.MODE_PRIVATE);
            String json = sp.getString("prayer_times", null);
            if (json == null || json.length() < 5) return;

            JSONObject obj = new JSONObject(json);
            String[] keys = {"fajr", "zuhr", "asr", "maghrib", "isha"};
            String[] names = {"صبح", "ظهر", "عصر", "مغرب", "عشاء"};

            for (int i = 0; i < keys.length; i++) {
                if (!obj.has(keys[i])) continue;
                String time = obj.optString(keys[i], "");
                if (time.length() < 3) continue;
                String[] parts = time.split(":");
                if (parts.length < 2) continue;
                int h = Integer.parseInt(parts[0].trim());
                int m = Integer.parseInt(parts[1].trim());
                if (h < 0 || h > 23 || m < 0 || m > 59) continue;

                // 15 minutes before
                int beforeM = m - 15;
                int beforeH = h;
                if (beforeM < 0) { beforeM += 60; beforeH -= 1; if (beforeH < 0) beforeH = 23; }
                scheduleAt(ctx, beforeH, beforeM, 1000 + i, "before",
                    "۱۵ دقیقه تا نماز " + names[i] + " — آماده شو و وضو بگیر");

                // 30 minutes after
                int afterM = m + 30;
                int afterH = h;
                if (afterM >= 60) { afterM -= 60; afterH += 1; if (afterH > 23) afterH = 0; }
                scheduleAt(ctx, afterH, afterM, 2000 + i, "after",
                    "نیم‌ساعت از وقت نماز " + names[i] + " گذشته — خواندی؟ در برنامه ثبت کن");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class WebAppInterface {
        Context ctx;
        WebAppInterface(Context c) { ctx = c; }

        @JavascriptInterface
        public void savePrayerTimes(String json) {
            try {
                SharedPreferences sp = ctx.getSharedPreferences("aamal", MODE_PRIVATE);
                sp.edit().putString("prayer_times", json).apply();
                restorePrayerAlarms(ctx);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @JavascriptInterface
        public String getDeviceTime() {
            Calendar c = Calendar.getInstance();
            return String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
