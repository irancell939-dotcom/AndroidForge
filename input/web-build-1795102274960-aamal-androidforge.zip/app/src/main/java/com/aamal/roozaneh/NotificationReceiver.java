package com.aamal.roozaneh;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;

public class NotificationReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "aamal_daily";

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            String type = intent.getStringExtra("type");
            String message = intent.getStringExtra("message");
            int reqCode = intent.getIntExtra("reqCode", 2100);
            int hour = intent.getIntExtra("hour", -1);
            int minute = intent.getIntExtra("minute", -1);
            if (message == null) message = "کارنامه اعمالت را تکمیل کن";

            String title = "اعمال روزانه";
            if ("before".equals(type)) title = "وقت نماز نزدیک است 🕌";
            else if ("after".equals(type)) title = "پیگیری نماز";
            else if ("night".equals(type)) title = "کارنامه امروز";

            Intent open = new Intent(context, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent contentPi = PendingIntent.getActivity(context, reqCode + 50, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setContentIntent(contentPi)
                .setAutoCancel(true);

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(reqCode, builder.build());

            // Reschedule same alarm for next day (device local time)
            if (hour >= 0 && minute >= 0) {
                MainActivity.scheduleAt(context, hour, minute, reqCode, type, message);
            } else if ("night".equals(type)) {
                MainActivity.scheduleAt(context, 21, 0, 9000, "night",
                    "امروزت چگونه گذشت؟ کارنامه اعمالت را تکمیل کن");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
