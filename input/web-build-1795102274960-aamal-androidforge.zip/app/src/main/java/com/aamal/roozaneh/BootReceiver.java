package com.aamal.roozaneh;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        try {
            MainActivity.scheduleAt(context, 21, 0, 9000, "night",
                "امروزت چگونه گذشت؟ کارنامه اعمالت را تکمیل کن");
            MainActivity.restorePrayerAlarms(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
