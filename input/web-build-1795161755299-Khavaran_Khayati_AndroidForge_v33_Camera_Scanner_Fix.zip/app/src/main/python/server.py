# -*- coding: utf-8 -*-
import os, threading
_server = None
_thread = None
def start_server(data_dir):
    global _server, _thread
    os.environ["KHAYATI_DATA_DIR"] = str(data_dir)
    os.environ["KHAVARAN_ANDROID"] = "1"
    os.environ["KHAVARAN_NO_BROWSER"] = "1"
    import app as khayati_app
    from werkzeug.serving import make_server
    if _server is None:
        _server = make_server("127.0.0.1", 5000, khayati_app.app, threaded=True)
        _thread = threading.Thread(target=_server.serve_forever, daemon=True)
        _thread.start()
    return True
