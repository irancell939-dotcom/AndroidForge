import os
import sqlite3
import threading
import random
import html

from flask import Flask, request, redirect, url_for, session

app = Flask(__name__)

app.secret_key = "Jasoos-Makhfi-Khavaran-2026"

DB = None

DEFAULT_WORDS = {
    "مکان‌ها": [
        "مدرسه", "بیمارستان", "فرودگاه",
        "رستوران", "مسجد", "پارک", "بانک"
    ],
    "حیوانات": [
        "شیر", "فیل", "گربه", "اسب",
        "دلفین", "گرگ"
    ],
    "غذاها": [
        "کباب", "پیتزا", "قورمه‌سبزی",
        "آش", "همبرگر"
    ],
    "وسایل": [
        "تلفن", "صندلی", "ساعت",
        "دوچرخه", "تلویزیون"
    ],
    "ورزش": [
        "فوتبال", "والیبال", "شنا",
        "بسکتبال"
    ],
    "شغل‌ها": [
        "پزشک", "معلم", "راننده",
        "آشپز", "نجار"
    ],
    "کشورها": [
        "ایران", "پاکستان", "ترکیه",
        "ژاپن", "آلمان"
    ],
    "فوتبالیست‌ها": [
        "امباپه", "رونالدو", "مسی", "هالند"
    ]
}

CSS = """
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 15px;
    direction: rtl;
    font-family: Tahoma;
    background: #f1eee7;
    color: #263238;
}

main {
    max-width: 650px;
    margin: auto;
}

.card {
    background: white;
    padding: 20px;
    border-radius: 18px;
    margin-top: 15px;
    box-shadow: 0 5px 20px #0001;
}

h1 {
    text-align: center;
    color: #263b68;
}

h2 {
    text-align: center;
    color: #344f82;
}

input, select, textarea, button {
    width: 100%;
    padding: 13px;
    margin: 7px 0;
    border-radius: 10px;
    border: 1px solid #ccd2dc;
    font-family: Tahoma;
    font-size: 15px;
}

button, .btn {
    display: block;
    background: #263b68;
    color: white;
    border: none;
    text-align: center;
    text-decoration: none;
    padding: 13px;
    border-radius: 10px;
    margin: 8px 0;
}

.danger {
    background: #b83232;
}

.green {
    background: #18845b;
}

.player {
    background: #eef2fa;
    padding: 12px;
    margin: 7px 0;
    border-radius: 10px;
}

.big {
    font-size: 25px;
    text-align: center;
    padding: 25px 5px;
}

.small {
    font-size: 12px;
    color: #777;
    text-align: center;
}

</style>
"""


def connect():

    db = sqlite3.connect(DB)

    db.row_factory = sqlite3.Row

    return db


def init_db():

    with connect() as db:

        db.execute("""
        CREATE TABLE IF NOT EXISTS words(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            word TEXT UNIQUE NOT NULL
        )
        """)

        db.execute("""
        CREATE TABLE IF NOT EXISTS scores(
            name TEXT PRIMARY KEY,
            score INTEGER DEFAULT 0
        )
        """)

        count = db.execute(
            "SELECT COUNT(*) FROM words"
        ).fetchone()[0]

        if count == 0:

            for category, words in DEFAULT_WORDS.items():

                for word in words:

                    db.execute(
                        """
                        INSERT OR IGNORE INTO words(category,word)
                        VALUES(?,?)
                        """,
                        (category, word)
                    )


def page(title, body):

    return f"""
    <!DOCTYPE html>
    <html lang="fa">

    <head>
        <meta charset="UTF-8">
        {CSS}
        <title>جاسوس مخفی</title>
    </head>

    <body>

        <main>

            <h1>🕵️ جاسوس مخفی</h1>

            <div class="card">

                <h2>{title}</h2>

                {body}

            </div>

            <p class="small">
                خاوران سافت
            </p>

        </main>

    </body>
    </html>
    """


def safe(value):

    return html.escape(str(value))


def award(names, points):

    with connect() as db:

        for name in names:

            if name:

                db.execute(
                    """
                    INSERT INTO scores(name,score)
                    VALUES(?,?)

                    ON CONFLICT(name)
                    DO UPDATE SET score=score+excluded.score
                    """,
                    (name, points)
                )


@app.route("/")
def home():

    players = session.get("players", [])

    with connect() as db:

        scores = db.execute(
            """
            SELECT name,score
            FROM scores
            ORDER BY score DESC
            """
        ).fetchall()

    body = """

    <form method="post" action="/start">

        <label>
            نام بازیکنان را وارد کنید.
            هر بازیکن در یک خط:
        </label>

        <textarea name="players" rows="7">
    """ + safe("\n".join(players)) + """
        </textarea>

        <button>شروع بازی</button>

    </form>

    <a class="btn" href="/players">
        مدیریت بازیکنان
    </a>

    <a class="btn" href="/words">
        مدیریت کلمات
    </a>

    <a class="btn" href="/scores">
        جدول امتیازات
    </a>

    """

    if scores:

        body += "<h3>جدول امتیازات</h3>"

        for row in scores:

            body += f"""
            <div class="player">
                {safe(row['name'])}
                :
                {row['score']}
            </div>
            """

    return page("صفحه اصلی", body)


@app.route("/start", methods=["POST"])
def start():

    players = [
        x.strip()
        for x in request.form.get("players", "").splitlines()
        if x.strip()
    ]

    players = list(dict.fromkeys(players))

    if not 3 <= len(players) <= 12:

        return page(
            "توجه",
            """
            <p>تعداد بازیکنان باید بین ۳ تا ۱۲ نفر باشد.</p>
            <a class="btn" href="/">بازگشت</a>
            """
        )

    with connect() as db:

        words = db.execute(
            "SELECT word FROM words"
        ).fetchall()

        for name in players:

            db.execute(
                """
                INSERT OR IGNORE INTO scores(name,score)
                VALUES(?,0)
                """,
                (name,)
            )

    if not words:

        return page(
            "خطا",
            "<p>کلمه‌ای برای بازی وجود ندارد.</p>"
        )

    session["players"] = players

    session["order"] = random.sample(
        players,
        len(players)
    )

    session["secret"] = random.choice(words)["word"]

    spy_count = 2 if len(players) >= 7 else 1

    session["spies"] = random.sample(
        players,
        spy_count
    )

    session["idx"] = 0

    return redirect("/reveal")


@app.route("/reveal")
def reveal():

    order = session.get("order", [])

    idx = session.get("idx", 0)

    if idx >= len(order):

        return redirect("/vote")

    name = order[idx]

    if name in session.get("spies", []):

        message = "🕵️ شما جاسوس هستید!"

    else:

        message = "کلمه: " + session.get("secret", "")

    body = f"""

    <h3 class="big">
        {safe(name)}
    </h3>

    <div class="big">
        {safe(message)}
    </div>

    <p>
        پس از مشاهده کارت، گوشی را به بازیکن بعدی بدهید.
    </p>

    <a class="btn green" href="/next">
        مشاهده کارت نفر بعد
    </a>

    """

    return page("کارت محرمانه", body)


@app.route("/next")
def next_player():

    session["idx"] = session.get("idx", 0) + 1

    return redirect("/reveal")


@app.route("/vote")
def vote():

    options = ""

    for name in session.get("players", []):

        options += f"""
        <option value="{safe(name)}">
            {safe(name)}
        </option>
        """

    body = f"""

    <p>
        بعد از گفت‌وگو، فرد مشکوک را انتخاب کنید.
    </p>

    <form method="post" action="/result">

        <select name="suspect">
            {options}
        </select>

        <button>ثبت نتیجه رأی‌گیری</button>

    </form>

    """

    return page("رأی‌گیری", body)


@app.route("/result", methods=["POST"])
def result():

    suspect = request.form.get("suspect", "")

    spies = session.get("spies", [])

    if suspect in spies:

        session["caught"] = suspect

        body = f"""

        <p>
            {safe(suspect)} جاسوس بود!
        </p>

        <p>
            حالا جاسوس فرصت دارد کلمه را حدس بزند.
        </p>

        <form method="post" action="/guess">

            <input
                name="guess"
                placeholder="حدس کلمه"
                required
            >

            <button>ثبت حدس</button>

        </form>

        """

    else:

        award(spies, 2)

        body = f"""

        <p>
            {safe(suspect)} جاسوس نبود.
        </p>

        <h3>
            جاسوس‌ها برنده شدند!
        </h3>

        <a class="btn green" href="/next-round">
            شروع دور بعدی
        </a>

        """

    return page("نتیجه بازی", body)


@app.route("/guess", methods=["POST"])
def guess():

    guess_word = request.form.get(
        "guess", ""
    ).strip()

    secret = session.get("secret", "")

    if guess_word == secret:

        award([session.get("caught")], 3)

        message = "جاسوس کلمه را درست حدس زد و برنده شد!"

    else:

        winners = [
            p for p in session.get("players", [])
            if p not in session.get("spies", [])
        ]

        award(winners, 2)

        message = "حدس جاسوس اشتباه بود؛ بازیکنان دیگر برنده شدند."

    body = f"""

    <h3>{message}</h3>

    <p>
        کلمه اصلی:
        <strong>{safe(secret)}</strong>
    </p>

    <a class="btn green" href="/next-round">
        دور بعدی
    </a>

    """

    return page("پایان دور", body)


@app.route("/next-round")
def next_round():

    for key in [
        "secret",
        "spies",
        "caught",
        "order",
        "idx"
    ]:

        session.pop(key, None)

    # نام بازیکنان حفظ می‌شود.
    return redirect("/")


@app.route("/players")
def players():

    ps = session.get("players", [])

    body = """

    <form method="post" action="/add-player">

        <input
            name="name"
            placeholder="نام بازیکن جدید"
            required
        >

        <button>افزودن بازیکن</button>

    </form>

    """

    for i, name in enumerate(ps):

        body += f"""

        <div class="player">

            {safe(name)}

            <a href="/remove-player/{i}">
                حذف بازیکن
            </a>

        </div>

        """

    body += '<a class="btn" href="/">بازگشت</a>'

    return page("مدیریت بازیکنان", body)


@app.route("/add-player", methods=["POST"])
def add_player():

    name = request.form.get(
        "name", ""
    ).strip()

    players = session.get("players", [])

    if (
        name
        and name not in players
        and len(players) < 12
    ):

        players.append(name)

        with connect() as db:

            db.execute(
                """
                INSERT OR IGNORE INTO scores(name,score)
                VALUES(?,0)
                """,
                (name,)
            )

    session["players"] = players

    return redirect("/players")


@app.route("/remove-player/<int:index>")
def remove_player(index):

    players = session.get("players", [])

    if 0 <= index < len(players):

        players.pop(index)

    session["players"] = players

    return redirect("/players")


@app.route("/words", methods=["GET", "POST"])
def words():

    if request.method == "POST":

        category = request.form.get(
            "category", ""
        ).strip()

        word = request.form.get(
            "word", ""
        ).strip()

        if category and word:

            with connect() as db:

                db.execute(
                    """
                    INSERT OR IGNORE INTO words(category,word)
                    VALUES(?,?)
                    """,
                    (category, word)
                )

    with connect() as db:

        rows = db.execute(
            """
            SELECT id,category,word
            FROM words
            ORDER BY category,word
            """
        ).fetchall()

    body = """

    <form method="post">

        <input
            name="category"
            placeholder="نام دسته‌بندی"
            required
        >

        <input
            name="word"
            placeholder="کلمه جدید"
            required
        >

        <button>افزودن کلمه</button>

    </form>

    """

    for row in rows:

        body += f"""

        <div class="player">

            {safe(row['category'])}
            —
            {safe(row['word'])}

            <a href="/delete-word/{row['id']}">
                حذف
            </a>

        </div>

        """

    body += '<a class="btn" href="/">بازگشت</a>'

    return page("مدیریت کلمات", body)


@app.route("/delete-word/<int:word_id>")
def delete_word(word_id):

    with connect() as db:

        db.execute(
            "DELETE FROM words WHERE id=?",
            (word_id,)
        )

    return redirect("/words")


@app.route("/scores", methods=["GET", "POST"])
def scores():

    if request.method == "POST":

        with connect() as db:

            db.execute(
                "UPDATE scores SET score=0"
            )

    with connect() as db:

        rows = db.execute(
            """
            SELECT name,score
            FROM scores
            ORDER BY score DESC
            """
        ).fetchall()

    body = ""

    for row in rows:

        body += f"""

        <div class="player">

            {safe(row['name'])}
            :
            {row['score']}

        </div>

        """

    body += """

    <form method="post"
          onsubmit="return confirm('تمام امتیازها پاک شود؟')">

        <button class="danger">
            پاک کردن تمام امتیازات
        </button>

    </form>

    <a class="btn" href="/">
        بازگشت
    </a>

    """

    return page("جدول امتیازات", body)


def start_server(data_dir):

    global DB

    DB = os.path.join(
        data_dir,
        "game.db"
    )

    init_db()

    thread = threading.Thread(
        target=lambda: app.run(
            host="127.0.0.1",
            port=5003,
            debug=False,
            use_reloader=False
        ),
        daemon=True
    )

    thread.start()