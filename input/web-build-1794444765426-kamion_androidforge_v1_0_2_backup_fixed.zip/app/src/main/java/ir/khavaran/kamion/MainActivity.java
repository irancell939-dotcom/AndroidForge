package ir.khavaran.kamion;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.view.Window;
import android.graphics.Color;
import android.content.pm.ActivityInfo;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Context;
import android.widget.Toast;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.print.PrintAttributes;
import android.webkit.JavascriptInterface;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4102;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(30,58,138));
        getWindow().setNavigationBarColor(Color.rgb(20,38,80));
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setSupportZoom(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(filePathCallback!=null) filePathCallback.onReceiveValue(null);
                filePathCallback=callback;
                Intent intent=params.createIntent(); intent.setType("application/json");
                try { startActivityForResult(intent,FILE_CHOOSER_REQUEST); }
                catch(Exception e){ filePathCallback=null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface public void saveBackup(String data,String name){ runOnUiThread(()->writeBackup(data,name)); }
        @JavascriptInterface public void printPage(){ runOnUiThread(()->doPrint()); }
    }
    private void writeBackup(String data,String name){
        Uri backupUri = null;
        try {
            if(data == null || data.trim().isEmpty()) throw new Exception("اطلاعات پشتیبان خالی است");
            String fileName = (name == null || name.trim().isEmpty()) ? "kamion-backup-" + System.currentTimeMillis() + ".json" : name;
            if(!fileName.toLowerCase().endsWith(".json")) fileName += ".json";
            byte[] bytes = data.getBytes("UTF-8");
            if(Build.VERSION.SDK_INT >= 29){
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Kamion");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                backupUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if(backupUri == null) throw new Exception("ساخت فایل در پوشه دانلودها ناموفق بود");
                OutputStream stream = getContentResolver().openOutputStream(backupUri, "w");
                if(stream == null) throw new Exception("امکان نوشتن فایل وجود ندارد");
                stream.write(bytes); stream.flush(); stream.close();
                ContentValues ready = new ContentValues();
                ready.put(MediaStore.Downloads.IS_PENDING, 0);
                if(getContentResolver().update(backupUri, ready, null, null) < 1) throw new Exception("ثبت نهایی فایل انجام نشد");
                android.database.Cursor cursor = getContentResolver().query(backupUri, new String[]{MediaStore.Downloads.SIZE}, null, null, null);
                long size = -1;
                if(cursor != null){ if(cursor.moveToFirst()) size = cursor.getLong(0); cursor.close(); }
                if(size != bytes.length) throw new Exception("بررسی فایل ذخیره‌شده ناموفق بود");
            } else {
                File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "Kamion");
                if(!dir.exists() && !dir.mkdirs()) throw new Exception("ساخت پوشه پشتیبان ناموفق بود");
                File file = new File(dir, fileName);
                FileOutputStream stream = new FileOutputStream(file);
                stream.write(bytes); stream.flush(); stream.close();
                if(!file.exists() || file.length() != bytes.length) throw new Exception("بررسی فایل ذخیره‌شده ناموفق بود");
            }
            final String message = "پشتیبان با موفقیت ذخیره و بررسی شد: " + fileName;
            webView.evaluateJavascript("if(window.onBackupResult)window.onBackupResult(true," + JSONObjectQuote(message) + ");", null);
            Toast.makeText(this, "پشتیبان در Downloads/Kamion ذخیره شد", Toast.LENGTH_LONG).show();
        } catch(Exception e){
            if(backupUri != null){ try { getContentResolver().delete(backupUri, null, null); } catch(Exception ignored) {} }
            final String message = "ذخیره پشتیبان ناموفق بود: " + (e.getMessage() == null ? "خطای ناشناخته" : e.getMessage());
            webView.evaluateJavascript("if(window.onBackupResult)window.onBackupResult(false," + JSONObjectQuote(message) + ");", null);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    private String JSONObjectQuote(String value){
        return "\"" + value.replace("\\\\","\\\\\\\\").replace("\"","\\\\\"").replace("\\n","\\\\n").replace("\\r","\\\\r") + "\"";
    }


    private void doPrint(){
        try {
            PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
            PrintDocumentAdapter adapter=webView.createPrintDocumentAdapter("گزارش سفر کامیون");
            pm.print("گزارش سفر کامیون",adapter,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build());
        } catch(Exception e){ Toast.makeText(this,"امکان چاپ فراهم نشد: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER_REQUEST && filePathCallback!=null){
            Uri[] results=null;
            if(resultCode==RESULT_OK && data!=null){
                Uri u=data.getData(); if(u!=null) results=new Uri[]{u};
                else if(data.getClipData()!=null && data.getClipData().getItemCount()>0) results=new Uri[]{data.getClipData().getItemAt(0).getUri()};
            }
            filePathCallback.onReceiveValue(results); filePathCallback=null;
        }
    }
    @Override public void onBackPressed(){
        if(webView!=null){ webView.evaluateJavascript("(function(){var p=document.getElementById('printPreviewLayer');if(p){p.remove();return 'closed';}return 'none';})()", value->{ if(!"\"closed\"".equals(value)){ if(webView.canGoBack())webView.goBack(); else superOnBackPressed(); }}); }
        else super.onBackPressed();
    }
    private void superOnBackPressed(){ super.onBackPressed(); }
    @Override protected void onDestroy(){ if(webView!=null){webView.destroy();webView=null;} super.onDestroy(); }
}
