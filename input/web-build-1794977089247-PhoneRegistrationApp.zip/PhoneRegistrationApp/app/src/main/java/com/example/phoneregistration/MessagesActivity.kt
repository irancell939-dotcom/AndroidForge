package com.example.phoneregistration

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class StoredSms(
    val id: String,
    val body: String,
    val date: Long,
    val type: Int // 1 inbox, 2 sent
)

class MessagesActivity : AppCompatActivity() {

    private lateinit var rv: RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var btnFetch: MaterialButton
    private lateinit var btnClear: MaterialButton
    private lateinit var prefs: android.content.SharedPreferences
    private val messages = mutableListOf<StoredSms>()
    private lateinit var adapter: MsgAdapter
    private var phone = ""
    private var contactName = ""

    companion object {
        const val EXTRA_PHONE = "phone"
        const val EXTRA_NAME = "name"
        private const val REQ_SMS = 3001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val p = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)
        when (p.getString("app_theme", "blue")) {
            "green" -> setTheme(R.style.Theme_PhoneRegistrationApp_Green)
            "purple" -> setTheme(R.style.Theme_PhoneRegistrationApp_Purple)
            "dark" -> setTheme(R.style.Theme_PhoneRegistrationApp_Dark)
            else -> setTheme(R.style.Theme_PhoneRegistrationApp)
        }
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_messages)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        phone = intent.getStringExtra(EXTRA_PHONE) ?: ""
        contactName = intent.getStringExtra(EXTRA_NAME) ?: phone
        supportActionBar?.title = "پیام‌های $contactName"

        prefs = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)
        rv = findViewById(R.id.rvMessages)
        tvEmpty = findViewById(R.id.tvEmptyMsg)
        btnFetch = findViewById(R.id.btnFetchSms)
        btnClear = findViewById(R.id.btnClearMsg)

        adapter = MsgAdapter(messages) { msg ->
            AlertDialog.Builder(this)
                .setTitle("حذف پیام")
                .setMessage("این پیام از دفترچه تلفن حذف شود؟")
                .setPositiveButton("حذف") { _, _ ->
                    messages.removeAll { it.id == msg.id }
                    saveMessages()
                    adapter.notifyDataSetChanged()
                    updateEmpty()
                }
                .setNegativeButton("انصراف", null)
                .show()
        }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        loadMessages()
        updateEmpty()

        btnFetch.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_SMS), REQ_SMS)
            } else {
                fetchFromDevice()
            }
        }

        btnClear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("پاک کردن همه")
                .setMessage("همه پیام‌های ذخیره‌شده این مخاطب پاک شود؟")
                .setPositiveButton("پاک کردن") { _, _ ->
                    messages.clear()
                    saveMessages()
                    adapter.notifyDataSetChanged()
                    updateEmpty()
                }
                .setNegativeButton("انصراف", null)
                .show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_SMS && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            fetchFromDevice()
        } else {
            Toast.makeText(this, "دسترسی به پیامک‌ها لازم است", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fetchFromDevice() {
        try {
            val uri = Uri.parse("content://sms")
            val cursor: Cursor? = contentResolver.query(
                uri, arrayOf("_id", "address", "body", "date", "type"),
                null, null, "date DESC"
            )
            var added = 0
            cursor?.use {
                val addrIdx = it.getColumnIndex("address")
                val bodyIdx = it.getColumnIndex("body")
                val dateIdx = it.getColumnIndex("date")
                val typeIdx = it.getColumnIndex("type")
                val digits = phone.filter { ch -> ch.isDigit() }
                while (it.moveToNext()) {
                    val addr = it.getString(addrIdx) ?: continue
                    val addrDigits = addr.filter { ch -> ch.isDigit() }
                    // match last 8-10 digits
                    if (addrDigits.takeLast(8) == digits.takeLast(8) ||
                        addrDigits.takeLast(10) == digits.takeLast(10)) {
                        val body = it.getString(bodyIdx) ?: ""
                        val date = it.getLong(dateIdx)
                        val type = it.getInt(typeIdx)
                        if (messages.none { m -> m.body == body && m.date == date }) {
                            messages.add(0, StoredSms(UUID.randomUUID().toString(), body, date, type))
                            added++
                        }
                    }
                }
            }
            // keep last 200
            while (messages.size > 200) messages.removeAt(messages.lastIndex)
            saveMessages()
            adapter.notifyDataSetChanged()
            updateEmpty()
            Toast.makeText(this, "$added پیام جدید اضافه شد", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در خواندن پیامک‌ها: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun key() = "sms_$phone"

    private fun saveMessages() {
        val arr = JSONArray()
        messages.forEach { m ->
            val o = JSONObject()
            o.put("id", m.id); o.put("body", m.body)
            o.put("date", m.date); o.put("type", m.type)
            arr.put(o)
        }
        prefs.edit().putString(key(), arr.toString()).apply()
    }

    private fun loadMessages() {
        messages.clear()
        val json = prefs.getString(key(), "[]") ?: "[]"
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                messages.add(StoredSms(o.getString("id"), o.getString("body"),
                    o.getLong("date"), o.optInt("type", 1)))
            }
        } catch (_: Exception) {}
    }

    private fun updateEmpty() {
        if (messages.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            rv.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            rv.visibility = View.VISIBLE
        }
    }
}

class MsgAdapter(
    private val items: List<StoredSms>,
    private val onDelete: (StoredSms) -> Unit
) : RecyclerView.Adapter<MsgAdapter.VH>() {

    private val fmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("fa"))

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val body: TextView = v.findViewById(R.id.tvMsgBody)
        val date: TextView = v.findViewById(R.id.tvMsgDate)
        val del: ImageButton = v.findViewById(R.id.btnDelMsg)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        holder.body.text = m.body
        holder.date.text = fmt.format(Date(m.date)) + if (m.type == 2) "  (ارسال‌شده)" else "  (دریافت‌شده)"
        holder.del.setOnClickListener { onDelete(m) }
    }

    override fun getItemCount() = items.size
}
