package com.example.phoneregistration

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class LockActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // Apply theme before super
        val prefs = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)
        when (prefs.getString("app_theme", "blue")) {
            "green" -> setTheme(R.style.Theme_PhoneRegistrationApp_Green)
            "purple" -> setTheme(R.style.Theme_PhoneRegistrationApp_Purple)
            "dark" -> setTheme(R.style.Theme_PhoneRegistrationApp_Dark)
            else -> setTheme(R.style.Theme_PhoneRegistrationApp)
        }
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lock)

        val pin = prefs.getString("app_pin", null)
        if (pin.isNullOrBlank()) {
            // No PIN set → go to main
            startMain()
            return
        }

        val etPin = findViewById<TextInputEditText>(R.id.etPin)
        val btnUnlock = findViewById<MaterialButton>(R.id.btnUnlock)
        val tvError = findViewById<TextView>(R.id.tvError)

        btnUnlock.setOnClickListener {
            val entered = etPin.text?.toString().orEmpty()
            if (entered == pin) {
                startMain()
            } else {
                tvError.visibility = View.VISIBLE
                tvError.text = "رمز اشتباه است"
                etPin.text?.clear()
            }
        }
    }

    private fun startMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
