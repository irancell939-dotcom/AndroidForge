مسابقه دینی - بسته استقرار نسخه وب Flask

نکته مهم درباره خطای Gradle:
این بسته یک پروژه وب Python/Flask است و پروژه Android/Gradle نیست. بنابراین اجرای دستور gradle assembleDebug در ریشه این بسته خطای «does not contain a Gradle build» می‌دهد؛ این خطا ناشی از نبود فایل‌های settings.gradle و build.gradle است و با تغییر کد بازی رفع نمی‌شود.

برای اجرای این بسته باید در AndroidForge نوع پروژه/محیط اجرای Python یا Flask (Web App) را انتخاب کنید، نه Android APK / Gradle. اگر هدف شما ساخت APK اندروید است، باید یک پروژه اندرویدی جداگانه با Gradle و WebView ساخته شود که این برنامه وب را نمایش دهد؛ این ZIP به‌تنهایی APK نیست.

ساختار:
- app.py: برنامه اصلی Flask
- questions.json: مجموعه ۱۹۵ پرسش و پاسخ
- templates/: صفحات بازی و مدیریت
- static/: فایل‌های CSS و JavaScript
- requirements.txt: وابستگی‌ها
- Procfile: فرمان اجرای وب با Gunicorn

ورود مدیریت: /admin
رمز اولیه: 1111

Start Command:
gunicorn --bind 0.0.0.0:$PORT app:app

نام برنامه‌نویس: محمدعمر خاوران
شماره تماس: 09159499928
