package com.balochi.quiz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.data.Sentence
import com.balochi.quiz.data.SentenceRepository
import com.balochi.quiz.ui.theme.*

@Composable
fun AddSentenceScreen(
    viewModel: QuizViewModel,
    existing: Sentence? = null,
    onBack: () -> Unit
) {
    val colors = getThemeColors(viewModel.currentTheme)
    val context = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { SentenceRepository(context) }

    var balochi by remember { mutableStateOf(existing?.balochi ?: "") }
    var persian by remember { mutableStateOf(existing?.persian ?: "") }
    var english by remember { mutableStateOf(existing?.english ?: "") }
    var arabic by remember { mutableStateOf(existing?.arabic ?: "") }
    var urdu by remember { mutableStateOf(existing?.urdu ?: "") }
    var genderNote by remember { mutableStateOf(existing?.genderNote ?: "") }
    var showError by remember { mutableStateOf(false) }
    val isEdit = existing != null

    Column(
        Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = colors.textPrimary)
            }
            Text(
                if (isEdit) "ویرایش جمله" else "افزودن جمله",
                color = colors.textPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Field(english, { english = it }, "English", colors)
            Spacer(Modifier.height(10.dp))
            Field(persian, { persian = it }, "فارسی", colors)
            Spacer(Modifier.height(10.dp))
            Field(balochi, { balochi = it }, "بلوچی (زاهدان/زابل)", colors)
            Spacer(Modifier.height(10.dp))
            Field(arabic, { arabic = it }, "العربية", colors)
            Spacer(Modifier.height(10.dp))
            Field(urdu, { urdu = it }, "اردو", colors)
            Spacer(Modifier.height(10.dp))
            Field(genderNote, { genderNote = it }, "یادداشت جنسیت فعل (اختیاری)", colors, false)

            if (showError) {
                Text("حداقل یک جمله وارد کنید", color = WrongRed, fontSize = 13.sp)
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    if (listOf(english, persian, balochi, arabic, urdu).all { it.isBlank() }) {
                        showError = true
                        return@Button
                    }
                    val s = Sentence(
                        id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                        english = english.trim(),
                        persian = persian.trim(),
                        balochi = balochi.trim(),
                        arabic = arabic.trim(),
                        urdu = urdu.trim(),
                        genderNote = genderNote.trim()
                    )
                    if (isEdit) repo.update(s) else repo.add(s)
                    onBack()
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.background)
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.width(8.dp))
                Text(if (isEdit) "ذخیره تغییرات" else "ذخیره جمله", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    colors: ThemeColors,
    single: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = single,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = colors.accent,
            unfocusedBorderColor = colors.border,
            focusedLabelColor = colors.accent,
            unfocusedLabelColor = colors.textSecondary,
            cursorColor = colors.accent,
            focusedTextColor = colors.textPrimary,
            unfocusedTextColor = colors.textPrimary
        )
    )
}
