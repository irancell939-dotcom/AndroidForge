package com.balochi.quiz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.data.Sentence
import com.balochi.quiz.data.SentenceRepository
import com.balochi.quiz.ui.theme.*

@Composable
fun SentencesScreen(
    viewModel: QuizViewModel,
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (Sentence) -> Unit
) {
    val colors = getThemeColors(viewModel.currentTheme)
    val context = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { SentenceRepository(context) }
    var list by remember { mutableStateOf(repo.getAll()) }
    var query by remember { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<Sentence?>(null) }

    fun reload() { list = repo.getAll() }

    val filtered = remember(query, list) {
        if (query.isBlank()) list
        else {
            val q = query.trim()
            list.filter {
                it.english.contains(q, true) || it.persian.contains(q, true) ||
                    it.arabic.contains(q, true) || it.urdu.contains(q, true) ||
                    it.balochi.contains(q, true) || it.genderNote.contains(q, true)
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = colors.textPrimary)
            }
            Text(
                "جملات (${filtered.size})",
                color = colors.textPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onAdd) {
                Icon(Icons.Default.Add, "افزودن", tint = colors.accent)
            }
        }

        Text(
            "توجه: فعل مذکر/مؤنث در عربی (و گاهی اردو) فرق دارد. بلوچی از لهجه‌های رایج (زاهدان، زابل، سراوان، چابهار، پاکستان و افغانستان) است و قابل ویرایش.",
            color = colors.textSecondary,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
        )

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
            placeholder = { Text("جستجو...", color = colors.textMuted) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = colors.textMuted) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Clear, null, tint = colors.textMuted)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.accent,
                unfocusedBorderColor = colors.border,
                focusedTextColor = colors.textPrimary,
                unfocusedTextColor = colors.textPrimary,
                cursorColor = colors.accent,
                focusedContainerColor = colors.card,
                unfocusedContainerColor = colors.card
            )
        )

        LazyColumn(
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered, key = { it.id }) { sentence ->
                SentenceCard(
                    sentence = sentence,
                    colors = colors,
                    onEdit = { onEdit(sentence) },
                    onDelete = { toDelete = sentence }
                )
            }
        }
    }

    toDelete?.let { s ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف جمله؟", fontWeight = FontWeight.Bold) },
            text = { Text(s.persian.ifBlank { s.english.ifBlank { s.balochi } }) },
            confirmButton = {
                TextButton(
                    onClick = {
                        repo.delete(s.id)
                        reload()
                        toDelete = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = WrongRed)
                ) { Text("حذف", fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("انصراف") }
            },
            containerColor = colors.card,
            titleContentColor = colors.textPrimary,
            textContentColor = colors.textSecondary
        )
    }
}

@Composable
private fun SentenceCard(
    sentence: Sentence,
    colors: ThemeColors,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.card)
            .border(1.dp, colors.border, RoundedCornerShape(14.dp))
            .clickable(onClick = onEdit)
            .padding(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                if (sentence.balochi.isNotBlank()) {
                    Text(sentence.balochi, color = colors.accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                } else if (sentence.english.isNotBlank()) {
                    Text(sentence.english, color = colors.accent, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                }
            }
            Box {
                IconButton(onClick = { menu = true }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.MoreVert, null, tint = colors.textMuted)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }, containerColor = colors.surface) {
                    DropdownMenuItem(
                        text = { Text("ویرایش", color = colors.textPrimary) },
                        onClick = { menu = false; onEdit() }
                    )
                    DropdownMenuItem(
                        text = { Text("حذف", color = WrongRed) },
                        onClick = { menu = false; onDelete() }
                    )
                }
            }
        }
        if (sentence.english.isNotBlank()) Text("EN: ${sentence.english}", color = colors.textPrimary, fontSize = 14.sp)
        if (sentence.persian.isNotBlank()) Text("FA: ${sentence.persian}", color = colors.textPrimary, fontSize = 14.sp)
        if (sentence.arabic.isNotBlank()) Text("AR: ${sentence.arabic}", color = colors.textPrimary, fontSize = 14.sp)
        if (sentence.urdu.isNotBlank()) Text("UR: ${sentence.urdu}", color = colors.textPrimary, fontSize = 14.sp)
        if (sentence.balochi.isNotBlank() && sentence.english.isNotBlank())
            Text("BL: ${sentence.balochi}", color = colors.textPrimary, fontSize = 14.sp)
        if (sentence.genderNote.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text("⚖ ${sentence.genderNote}", color = Sage, fontSize = 12.sp)
        }
    }
}
