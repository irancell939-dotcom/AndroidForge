package com.balochi.quiz.data

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

class QuizViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = WordRepository(application)
    private val settingsRepo = SettingsRepository(application)
    private val sentenceRepo = SentenceRepository(application)

    var words by mutableStateOf<List<BalochiWord>>(emptyList())
        private set

    var progress by mutableStateOf(repository.getProgress())
        private set

    var currentTheme by mutableStateOf(settingsRepo.getTheme())
        private set

    var soundMuted by mutableStateOf(settingsRepo.isSoundMuted())
        private set
    var soundType by mutableStateOf(settingsRepo.getSoundType())
        private set
    var langProgress by mutableStateOf(settingsRepo.getLangProgress())
        private set
    var reminder by mutableStateOf(settingsRepo.getReminder())
        private set

    /** words یا sentences */
    var quizMode by mutableStateOf("words")
        private set

    // دو زبان انتخابی برای آزمون
    var langA by mutableStateOf(settingsRepo.getLangA())
        private set
    var langB by mutableStateOf(settingsRepo.getLangB())
        private set

    // حالت آزمون
    var currentWord by mutableStateOf<BalochiWord?>(null)
        private set
    var questionText by mutableStateOf("")          // متن سوال (از زبان مبدأ)
    var options by mutableStateOf<List<String>>(emptyList())
        private set
    var selectedOptionIndex by mutableStateOf<Int?>(null)
        private set
    var isAnswerRevealed by mutableStateOf(false)
        private set
    var correctOptionIndex by mutableStateOf(-1)
        private set
    var score by mutableStateOf(0)
        private set
    var totalAnswered by mutableStateOf(0)
        private set
    var quizFinished by mutableStateOf(false)
        private set
    var fromLang by mutableStateOf(QuizLanguage.ENGLISH)
        private set
    var toLang by mutableStateOf(QuizLanguage.PERSIAN)
        private set

    private var usedWordIds = mutableSetOf<String>()
    private var wrongQueue = mutableListOf<String>() // برای تکرار اشتباهات

    init {
        loadWords()
    }

    fun loadWords() {
        words = repository.getAllWords()
        progress = repository.getProgress()
    }

    fun setLanguages(a: QuizLanguage, b: QuizLanguage) {
        if (a != b) {
            langA = a
            langB = b
            settingsRepo.setLanguages(a, b)
        }
    }

    fun addWord(word: BalochiWord) {
        repository.addWord(word)
        loadWords()
    }

    fun updateWord(word: BalochiWord) {
        repository.updateWord(word)
        loadWords()
    }

    fun deleteWord(id: String) {
        repository.deleteWord(id)
        loadWords()
    }

    fun exportBackup(): String? = repository.exportBackup()

    fun importBackup(): Boolean {
        val ok = repository.importBackup()
        if (ok) loadWords()
        return ok
    }

    fun importBackupFromJson(json: String): Boolean {
        val ok = repository.importBackupFromJson(json)
        if (ok) loadWords()
        return ok
    }

    fun resetProgress() {
        repository.resetProgress()
        settingsRepo.resetLangProgress()
        loadWords()
        progress = repository.getProgress()
        langProgress = settingsRepo.getLangProgress()
    }

    fun getBackupPath(): String = repository.getBackupPath()

    fun updateSoundMuted(muted: Boolean) {
        soundMuted = muted
        settingsRepo.setSoundMuted(muted)
    }

    fun updateSoundType(type: Int) {
        soundType = type
        settingsRepo.setSoundType(type)
    }

    fun updateReminder(r: SettingsRepository.ReminderSettings) {
        reminder = r
        settingsRepo.setReminder(r)
    }

    fun setTheme(theme: com.balochi.quiz.ui.theme.AppTheme) {
        currentTheme = theme
        settingsRepo.setTheme(theme)
    }

    fun updateQuizMode(mode: String) {
        quizMode = mode
    }

    
    private var sentencePool = listOf<com.balochi.quiz.data.Sentence>()
    private var currentSentenceId: String? = null
    private val quizTargetBase = 20

    private fun finishQuizIfReady(): Boolean {
        // حداقل ۲۰ سؤال + خالی شدن صف اشتباهات
        if (totalAnswered >= quizTargetBase && wrongQueue.isEmpty()) {
            quizFinished = true
            repository.updateProgress(score, totalAnswered)
            progress = repository.getProgress()
            return true
        }
        return false
    }

    private fun nextSentenceQuestion() {
        if (finishQuizIfReady()) return

        val all = sentenceRepo.getAll().filter {
            it.hasText(langA) && it.hasText(langB)
        }
        if (all.isEmpty()) {
            quizFinished = true
            repository.updateProgress(score, totalAnswered)
            progress = repository.getProgress()
            return
        }

        // اولویت با اشتباهات همین آزمون
        val candidateId = wrongQueue.firstOrNull()
        val s = if (candidateId != null && all.any { it.id == candidateId }) {
            wrongQueue.removeAt(0)
            all.first { it.id == candidateId }
        } else {
            if (sentencePool.isEmpty()) {
                // اول آن‌هایی که هنوز در این آزمون نیامده‌اند
                val unseen = all.filter { it.id !in usedWordIds }.shuffled()
                sentencePool = if (unseen.isNotEmpty()) unseen else all.shuffled()
            }
            val pick = sentencePool.first()
            sentencePool = sentencePool.drop(1)
            pick
        }

        currentSentenceId = s.id
        currentWord = null
        usedWordIds.add(s.id)

        val forward = (0..1).random() == 0
        fromLang = if (forward) langA else langB
        toLang = if (forward) langB else langA
        questionText = s.getText(fromLang)
        val correct = s.getText(toLang)
        val wrongs = all
            .filter { it.id != s.id && it.hasText(toLang) }
            .map { it.getText(toLang) }
            .distinct()
            .filter { it != correct }
            .shuffled()
            .take(3)
        var opts = (wrongs + correct).distinct().shuffled().toMutableList()
        var pad = 0
        while (opts.size < 4) {
            pad++
            opts.add("— $pad —")
        }
        opts = opts.take(4).shuffled().toMutableList()
        options = opts
        correctOptionIndex = opts.indexOf(correct)
    }

    fun startQuiz() {
        score = 0
        totalAnswered = 0
        usedWordIds.clear()
        wrongQueue.clear()
        sentencePool = emptyList()
        currentSentenceId = null
        quizFinished = false
        nextQuestion()
    }

    fun nextQuestion() {
        selectedOptionIndex = null
        isAnswerRevealed = false

        if (quizMode == "sentences") {
            nextSentenceQuestion()
            return
        }

        if (finishQuizIfReady()) return

        // اولویت اشتباهات + پوشش همه کلمات در طول آزمون‌های مختلف (priorityScore)
        val candidateId = wrongQueue.firstOrNull()
        val available = words.filter {
            it.hasMeaning(langA) && it.hasMeaning(langB) &&
                    (it.id !in usedWordIds || it.id == candidateId)
        }.sortedByDescending { it.priorityScore() }

        if (available.isEmpty()) {
            if (words.any { it.hasMeaning(langA) && it.hasMeaning(langB) }) {
                usedWordIds.clear()
                nextQuestion()
            } else {
                quizFinished = true
                repository.updateProgress(score, totalAnswered)
                progress = repository.getProgress()
            }
            return
        }

        val word = if (candidateId != null && available.any { it.id == candidateId }) {
            wrongQueue.removeAt(0)
            available.first { it.id == candidateId }
        } else {
            available.first()
        }

        usedWordIds.add(word.id)
        currentWord = word
        currentSentenceId = null

        val directionForward = (0..1).random() == 0
        fromLang = if (directionForward) langA else langB
        toLang = if (directionForward) langB else langA

        questionText = word.getMeaning(fromLang)
        val correctMeaning = word.getMeaning(toLang)

        val wrongMeanings = words
            .filter { it.id != word.id && it.hasMeaning(toLang) }
            .map { it.getMeaning(toLang) }
            .distinct()
            .filter { it != correctMeaning }
            .shuffled()
            .take(3)

        val allOptions = (wrongMeanings + correctMeaning).shuffled()
        options = allOptions
        correctOptionIndex = allOptions.indexOf(correctMeaning)
    }

    fun selectOption(index: Int) {
        if (isAnswerRevealed) return
        selectedOptionIndex = index
        isAnswerRevealed = true
        totalAnswered++

        val isCorrect = index == correctOptionIndex
        if (isCorrect) {
            score++
        } else {
            val id = currentWord?.id ?: currentSentenceId
            if (id != null && wrongQueue.count { it == id } < 3) {
                wrongQueue.add(id)
            }
        }
        currentWord?.let { repository.recordAnswer(it.id, isCorrect) }
        settingsRepo.recordLangAnswer(toLang.code, isCorrect)
        langProgress = settingsRepo.getLangProgress()
    }

    fun onContinueAfterAnswer() {
        if (finishQuizIfReady()) return
        nextQuestion()
    }

    fun sentenceCount(): Int = try {
        sentenceRepo.getAll().size
    } catch (_: Exception) {
        0
    }

}
