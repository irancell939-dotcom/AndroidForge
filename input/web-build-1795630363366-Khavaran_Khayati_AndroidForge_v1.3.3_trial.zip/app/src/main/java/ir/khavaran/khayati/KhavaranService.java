package ir.khavaran.khayati;

import android.app.*;
import android.content.*;
import android.os.*;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class KhavaranService extends Service {
    private static final String CHANNEL = "khavaran_server";
    private static final int NOTIF_ID = 41;
    private boolean serverStarted = false;

    @Override public void onCreate() {
        super.onCreate();
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        createChannel();
        startForeground(NOTIF_ID, buildNotification("در حال راه‌اندازی سرویس..."));
        new Thread(() -> {
            try {
                Python.getInstance().getModule("main").callAttr("start_server");
                serverStarted = true;
                // به‌روزرسانی نوتیفیکیشن پس از بالا آمدن سرور
                try {
                    Object portObj = Python.getInstance().getModule("main").callAttr("get_port");
                    String port = portObj == null ? "?" : String.valueOf(portObj);
                    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    if (nm != null) {
                        nm.notify(NOTIF_ID, buildNotification("فعال روی پورت " + port + " — اتصال Wi-Fi آماده است"));
                    }
                } catch (Exception ignored) {}
            } catch (Exception e) {
                android.util.Log.e("Khavaran", "Python server start failed", e);
            }
        }, "KhavaranServerThread").start();
    }

    private Notification buildNotification(String text) {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
            this, 0, open,
            Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0
        );
        return b.setContentTitle("خاوران سافت فعال است")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(pi)
            .setOngoing(true)
            .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                CHANNEL, "سرویس خاوران", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("نگه‌داشتن سرور برنامه برای اتصال کامپیوتر و چاپ");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    @Override public int onStartCommand(Intent i, int f, int id) {
        if (!serverStarted) {
            // اگر سرویس دوباره استارت شد و سرور قطع است، دوباره بالا بیاور
            new Thread(() -> {
                try {
                    Python.getInstance().getModule("main").callAttr("start_server");
                    serverStarted = true;
                } catch (Exception e) {
                    android.util.Log.e("Khavaran", "restart server failed", e);
                }
            }).start();
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        try { Python.getInstance().getModule("server_control").callAttr("stop_server"); } catch (Exception ignored) {}
        serverStarted = false;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
