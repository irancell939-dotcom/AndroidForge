def stop_server():
    try:
        import main
        main.stop_server()
    except Exception:
        pass


def stop():
    stop_server()
