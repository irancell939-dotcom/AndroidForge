package com.balochi.quiz.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.balochi.quiz.data.SettingsRepository
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        NotificationHelper.showReminder(context)
        // برنامه‌ریزی مجدد برای فردا در صورت نیاز
        ReminderScheduler.schedule(context)
    }
}

object ReminderScheduler {
    private const val REQ = 4401

    fun schedule(context: Context) {
        val settings = SettingsRepository(context).getReminder()
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(context)

        am.cancel(pi)
        if (!settings.enabled || settings.days.isEmpty()) return

        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, settings.hour)
            set(Calendar.MINUTE, settings.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // پیدا کردن نزدیک‌ترین روز فعال
        var found = false
        for (i in 0..7) {
            val day = target.get(Calendar.DAY_OF_WEEK) // 1=Sun ... 7=Sat
            // ما days را به صورت 1..7 ذخیره می‌کنیم مطابق Calendar
            if (settings.days.contains(day) && target.after(now)) {
                found = true
                break
            }
            target.add(Calendar.DAY_OF_YEAR, 1)
        }
        if (!found) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pi)
        } else {
            am.set(AlarmManager.RTC_WAKEUP, target.timeInMillis, pi)
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context))
    }

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, REQ, intent, flags)
    }
}
