خاوران سافت – بسته اندروید بر اساس سورس آخرین نسخه ویندوز ارسالی کاربر

این بسته از app.py و تمام قالب‌ها و فایل‌های static موجود در فایل khavaran_APP.zip ساخته شده است؛ نه از نسخه‌های قدیمی مکالمات.

محتویات:
- app.py: منطق کامل برنامه از سورس آخرین نسخه
- templates/ و static/: صفحات و ظاهر همان نسخه
- main.py: اجرای سرور محلی روی 127.0.0.1:5000 و ذخیره اطلاعات در پوشه خصوصی اندروید
- server_control.py: توقف سرور فقط در خروج کامل
- static/icons/khavaran-balochi-shirt-icon.png: آیکون پیراهن بلوچی مردانه
- requirements.txt: وابستگی‌های Flask و Werkzeug

تنظیمات لازم در AndroidForge:
1. پروژه را به‌صورت Python/Flask با Chaquopy و پوسته WebView محلی بسازید.
2. صفحه شروع WebView را روی http://127.0.0.1:5000 قرار دهید.
3. main.py را در شروع برنامه اجرا کنید. WebView نباید با بسته‌شدن صفحه یا رفتن به برنامه Binary Eye باعث توقف سرور شود.
4. برای روشن‌ماندن واقعی در پس‌زمینه، main.py باید در Android Foreground Service با اعلان دائمی اجرا شود و سرویس فقط با فرمان خروج کامل متوقف شود.
5. آیکون Launcher را از static/icons/khavaran-balochi-shirt-icon.png تنظیم کنید.
6. اینترنت برای WebView محلی، امکان بازکردن پیوند خارجی و ادامه/بازگشت WebView پس از بازگشت از اسکنر فعال باشد.

اسکن:
- صفحه «لباس‌های آماده تحویل» در همین سورس، دکمه اسکن را با پیوند binaryeye://scan و الگوی بازگشت #khavaran-scan={RESULT} اجرا می‌کند.
- Binary Eye باید روی گوشی نصب و مجوز دوربین آن فعال باشد.
- در WebView باید بازکردن scheme خارجی binaryeye:// به Intent اندروید سپرده شود و پس از برگشت، رویداد pageshow/hashchange اجرا شود. اگر AndroidForge همه لینک‌های غیر http را مسدود کند، اسکن باز نخواهد شد؛ این مورد باید در WebViewClient بخش Native تنظیم شود.

چاپ:
- صفحات چاپ این نسخه از window.print() استفاده می‌کنند.
- در پوسته Native باید فراخوانی چاپ WebView به Android PrintManager متصل باشد (createPrintDocumentAdapter و PrintManager.print). سپس چاپگرهای متصل به گوشی، از جمله Wi-Fi/Bluetooth/USB که سرویس چاپ اندرویدشان نصب است، انتخاب می‌شوند.

اطلاعات:
- دیتابیس ویندوز و session.secret ویندوز عمداً داخل بسته قرار نگرفته‌اند.
- نسخه موبایل بانک مستقل خود را در پوشه خصوصی برنامه ایجاد می‌کند.
- این ZIP سورس پروژه AndroidForge است، نه APK نهایی. فعال‌سازی Foreground Service و اتصال PrintManager و مدیریت Intent اسکن در پوسته Native فورگ لازم است.
