# Called by the Android wrapper only after the user chooses full exit.
def stop():
    import main
    main.stop_server()
