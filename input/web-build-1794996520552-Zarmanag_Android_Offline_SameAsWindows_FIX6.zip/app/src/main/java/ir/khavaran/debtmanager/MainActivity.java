package ir.khavaran.debtmanager;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import android.os.Bundle;
import android.net.Uri;
import android.os.Handler;
import android.os.Environment;
import android.app.DownloadManager;
import android.database.Cursor;
import android.webkit.DownloadListener;
import android.graphics.Color;
import android.view.View;
import android.webkit.*;
import android.widget.*;
import android.content.*;
import java.io.*;
import java.net.*;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private WebView web;
    private LinearLayout root;
    private TextView status;
    private boolean ready = false;
    private int localServerPort = 5000;
    private final Handler handler = new Handler();
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 77;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(6,21,47));
        getWindow().setNavigationBarColor(Color.rgb(6,21,47));
        buildScreen();
        createReminderChannel();
        requestNotificationPermission();
        resetOldDataOnce();
        preparePrivateFiles();
        startLocalServer();
    }

    private void buildScreen() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(244,246,251));
        status = new TextView(this); status.setText("زرمانگ\nدر حال آماده‌سازی برنامه...");
        status.setTextColor(Color.rgb(31,41,55)); status.setTextSize(17);
        status.setGravity(17); status.setPadding(20,30,20,30);
        root.addView(status, new LinearLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    // Clear the previous test database exactly once for this release.
    // Later app launches keep the user's new local records.
    private void resetOldDataOnce() {
        android.content.SharedPreferences prefs = getSharedPreferences("zarmanag_release", MODE_PRIVATE);
        if (!prefs.getBoolean("fresh_database_v4", false)) {
            File data = new File(getFilesDir(), "zarmanag_data");
            deleteTree(data);
            prefs.edit().putBoolean("fresh_database_v4", true).apply();
        }
    }

    private void deleteTree(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteTree(child);
        }
        file.delete();
    }

    private void preparePrivateFiles() {
        File data = new File(getFilesDir(), "zarmanag_data");
        File db = new File(data,"debts.db");
        File uploads = new File(data,"static/uploads");
        File backups = new File(data,"backups");
        File temp = new File(data,"tmp");
        if (!data.isDirectory() && !data.mkdirs()) {
            status.setText("خطا: پوشه خصوصی برنامه ساخته نشد: " + data.getAbsolutePath());
            return;
        }
        if ((!uploads.isDirectory() && !uploads.mkdirs()) ||
            (!backups.isDirectory() && !backups.mkdirs()) ||
            (!temp.isDirectory() && !temp.mkdirs())) {
            status.setText("خطا: پوشه‌های داخلی برنامه ساخته نشدند.");
            return;
        }
        // The new release intentionally starts with an empty database.
        // Flask init_db() creates debts.db in this private folder on first launch.
        // Flask reads this app-private path for database, uploads, backups and temp files.
        System.setProperty("ZARMANAG_DATA_DIR", data.getAbsolutePath());
    }

    private void startLocalServer() {
        new Thread(() -> {
            try {
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                String portText = Python.getInstance().getModule("server").callAttr("start_server", new File(getFilesDir(), "zarmanag_data").getAbsolutePath()).toString();
                localServerPort = Integer.parseInt(portText.trim());
                runOnUiThread(() -> showWebView());
            } catch (Throwable e) {
                final String message = android.util.Log.getStackTraceString(e);
                android.util.Log.e("ZarmanagStartup", message);
                runOnUiThread(() -> status.setText("اجرای برنامه با خطا مواجه شد:\n"+e.toString()+"\n\n"+message));
            }
        }).start();
    }

    private void showWebView() {
        if (ready) return; ready=true;
        web = new WebView(this);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true); s.setLoadWithOverviewMode(true); s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        web.setBackgroundColor(Color.rgb(244,246,251));
        web.addJavascriptInterface(new ReminderBridge(), "ZarmanagAndroid");
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && url.startsWith("http://127.0.0.1:" + localServerPort + "/")) {
                    String js = "(function(){fetch('/api/reminders',{credentials:'same-origin'}).then(function(r){if(!r.ok) return null; return r.json();}).then(function(d){if(d && window.ZarmanagAndroid){window.ZarmanagAndroid.scheduleReminders(JSON.stringify(d.items||[]));}}).catch(function(e){});})();";
                    view.evaluateJavascript(js, null);
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri uri = r.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                if ("sms".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme)) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                        startActivity(intent);
                    } catch (Exception ex) {
                        Toast.makeText(MainActivity.this, "برنامه پیامک یا تماس در دسترس نیست.", Toast.LENGTH_LONG).show();
                    }
                    return true;
                }
                return !"127.0.0.1".equals(uri.getHost());
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) status.setText("اتصال داخلی برقرار نشد. برنامه را دوباره باز کنید.\n"+e.getDescription());
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=cb;
                Intent i=p.createIntent();
                try { startActivityForResult(i,FILE_REQUEST); } catch(Exception ex){fileCallback=null;return false;}
                return true;
            }
        });
        web.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                                  String mimeType, long contentLength) {
                try {
                    String filename = URLUtil.guessFileName(url, contentDisposition, mimeType);
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    request.setTitle(filename);
                    request.setDescription("دریافت نسخه پشتیبان زرمانگ");
                    request.setMimeType(mimeType != null ? mimeType : "application/x-sqlite3");
                    String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
                    if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                    DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    manager.enqueue(request);
                    Toast.makeText(MainActivity.this, "دانلود پشتیبان در پوشه Downloads آغاز شد.", Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "خطا در دانلود: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
        root.removeAllViews(); root.addView(web,new LinearLayout.LayoutParams(-1,-1));
        web.loadUrl("http://127.0.0.1:" + localServerPort + "/");
    }

    private static final String REMINDER_CHANNEL = "zarmanag_due_reminders";
    private static final String REMINDER_ACTION = "ir.khavaran.debtmanager.DUE_REMINDER";
    private static final int NOTIFICATION_PERMISSION_REQUEST = 901;

    private void createReminderChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(REMINDER_CHANNEL, "یادآوری سررسیدها", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("یادآوری یک روز پیش از تاریخ سررسید طلب‌ها و بدهی‌ها");
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    public class ReminderBridge {
        @JavascriptInterface public void scheduleReminders(String json) {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return;
            try {
                JSONArray items = new JSONArray(json);
                AlarmManager alarms = (AlarmManager) getSystemService(ALARM_SERVICE);
                android.content.SharedPreferences prefs = getSharedPreferences("zarmanag_reminders", MODE_PRIVATE);
                Set<String> previous = new HashSet<>(prefs.getStringSet("scheduled_ids", new HashSet<String>()));
                Set<String> current = new HashSet<>();
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.getJSONObject(i);
                    int id = item.getInt("id");
                    String key = String.valueOf(id);
                    current.add(key);
                    String day = item.getString("reminder_date");
                    Date parsed = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(day);
                    Calendar when = Calendar.getInstance();
                    when.setTime(parsed); when.set(Calendar.HOUR_OF_DAY, 9); when.set(Calendar.MINUTE, 0); when.set(Calendar.SECOND, 0); when.set(Calendar.MILLISECOND, 0);
                    if (when.getTimeInMillis() <= System.currentTimeMillis()) when.setTimeInMillis(System.currentTimeMillis() + 60000L);
                    Intent intent = new Intent(MainActivity.this, ReminderReceiver.class);
                    intent.setAction(REMINDER_ACTION);
                    intent.putExtra("record_id", id);
                    intent.putExtra("person", item.optString("person", "مورد ثبت‌شده"));
                    intent.putExtra("kind", item.optString("kind", "سررسید"));
                    intent.putExtra("due_date", item.optString("due_date", ""));
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
                }
                for (String old : previous) {
                    if (!current.contains(old)) {
                        try {
                            int oldId = Integer.parseInt(old);
                            Intent intent = new Intent(MainActivity.this, ReminderReceiver.class); intent.setAction(REMINDER_ACTION);
                            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, oldId, intent, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                            if (pi != null) { alarms.cancel(pi); pi.cancel(); }
                        } catch (Exception ignored) {}
                    }
                }
                prefs.edit().putStringSet("scheduled_ids", current).apply();
            } catch (Exception e) { android.util.Log.e("ZarmanagReminder", "Could not schedule reminders", e); }
        }
    }

    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if(req==FILE_REQUEST && fileCallback!=null){
            Uri[] result=WebChromeClient.FileChooserParams.parseResult(res,data);
            fileCallback.onReceiveValue(result); fileCallback=null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (web != null) web.reload();
        }
    }

    @Override public void onBackPressed() {
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
