import os
import threading
import traceback
import tempfile
from werkzeug.serving import make_server

_server = None
_thread = None

def start_server(data_dir):
    global _server, _thread
    if _server is not None:
        return str(_server.server_port)
    # All writable application data is confined to Android's private files directory.
    os.makedirs(data_dir, exist_ok=True)
    for name in ('static/uploads', 'backups', 'tmp'):
        os.makedirs(os.path.join(data_dir, name), exist_ok=True)
    os.environ['ZARMANAG_DATA_DIR'] = data_dir
    os.environ['TMPDIR'] = os.path.join(data_dir, 'tmp')
    tempfile.tempdir = os.environ['TMPDIR']
    # Fail early with a useful message if Android did not provide writable storage.
    probe = os.path.join(data_dir, 'tmp', '.write_test')
    with open(probe, 'w', encoding='utf-8') as f:
        f.write('ok')
    os.remove(probe)
    from app import app
    # Android may keep an earlier local server process alive, or another local
    # service may already own port 5000. Try a small range instead of allowing
    # Werkzeug's bind failure to raise SystemExit and terminate Python.
    last_error = None
    for port in range(5000, 5011):
        try:
            _server = make_server('127.0.0.1', port, app, threaded=True)
            break
        except SystemExit as exc:
            last_error = exc
            _server = None
    if _server is None:
        raise RuntimeError('هیچ پورتی از 5000 تا 5010 برای سرور داخلی آزاد نیست. برنامه را کامل ببندید و دوباره اجرا کنید.') from last_error
    _thread = threading.Thread(target=_server.serve_forever, daemon=True)
    _thread.start()
    return str(_server.server_port)
