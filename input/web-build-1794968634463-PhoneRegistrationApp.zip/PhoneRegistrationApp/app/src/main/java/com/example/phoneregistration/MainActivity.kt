package com.example.phoneregistration

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONArray
import org.json.JSONObject

data class Contact(val id: String, val name: String, val phone: String)

class MainActivity : AppCompatActivity() {

    private lateinit var etName: TextInputEditText
    private lateinit var etPhone: TextInputEditText
    private lateinit var btnRegister: MaterialButton
    private lateinit var rvList: RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: ContactAdapter
    private val contacts = mutableListOf<Contact>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etName = findViewById(R.id.etName)
        etPhone = findViewById(R.id.etPhone)
        btnRegister = findViewById(R.id.btnRegister)
        rvList = findViewById(R.id.rvList)
        tvEmpty = findViewById(R.id.tvEmpty)

        prefs = getSharedPreferences("phone_reg", Context.MODE_PRIVATE)

        adapter = ContactAdapter(contacts) { contact ->
            deleteContact(contact)
        }
        rvList.layoutManager = LinearLayoutManager(this)
        rvList.adapter = adapter

        loadContacts()
        updateEmptyState()

        btnRegister.setOnClickListener {
            registerContact()
        }
    }

    private fun registerContact() {
        val name = etName.text?.toString()?.trim().orEmpty()
        val phone = etPhone.text?.toString()?.trim().orEmpty()

        if (name.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_empty), Toast.LENGTH_SHORT).show()
            return
        }

        val contact = Contact(
            id = System.currentTimeMillis().toString(),
            name = name,
            phone = phone
        )
        contacts.add(0, contact)
        saveContacts()
        adapter.notifyItemInserted(0)
        rvList.scrollToPosition(0)
        updateEmptyState()

        etName.text?.clear()
        etPhone.text?.clear()
        Toast.makeText(this, getString(R.string.success), Toast.LENGTH_SHORT).show()
    }

    private fun deleteContact(contact: Contact) {
        val index = contacts.indexOfFirst { it.id == contact.id }
        if (index >= 0) {
            contacts.removeAt(index)
            saveContacts()
            adapter.notifyItemRemoved(index)
            updateEmptyState()
        }
    }

    private fun saveContacts() {
        val arr = JSONArray()
        contacts.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id)
            obj.put("name", c.name)
            obj.put("phone", c.phone)
            arr.put(obj)
        }
        prefs.edit().putString("contacts", arr.toString()).apply()
    }

    private fun loadContacts() {
        contacts.clear()
        val json = prefs.getString("contacts", "[]") ?: "[]"
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                contacts.add(
                    Contact(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        phone = obj.getString("phone")
                    )
                )
            }
        } catch (e: Exception) {
            // ignore bad data
        }
        adapter.notifyDataSetChanged()
    }

    private fun updateEmptyState() {
        if (contacts.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            rvList.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            rvList.visibility = View.VISIBLE
        }
    }
}

class ContactAdapter(
    private val items: List<Contact>,
    private val onDelete: (Contact) -> Unit
) : RecyclerView.Adapter<ContactAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvPhone: TextView = view.findViewById(R.id.tvPhone)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contact, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvName.text = item.name
        holder.tvPhone.text = item.phone
        holder.btnDelete.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount(): Int = items.size
}
