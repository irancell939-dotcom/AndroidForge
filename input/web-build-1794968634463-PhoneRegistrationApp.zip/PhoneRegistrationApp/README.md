# اپ ثبت شماره تلفن (Phone Registration App)

یک اپ ساده اندروید برای ثبت نام و شماره تلفن.

## ویژگی‌ها
- فرم ثبت نام + شماره
- لیست شماره‌های ثبت‌شده
- ذخیره محلی (SharedPreferences)
- پشتیبانی از RTL (فارسی)
- بدون نیاز به اینترنت

## نحوه استفاده با AndroidForge

1. این پوشه را کامل ZIP کنید (کل محتوای پروژه داخل ZIP باشد)
2. به سایت AndroidForge بروید: https://professional-x.github.io/AndroidForge/
3. با GitHub Token خود لاگین کنید
4. فایل ZIP را آپلود کنید
5. Build را بزنید و APK را دانلود کنید

## ساخت دستی با Android Studio
پروژه را در Android Studio باز کنید و Run کنید.
