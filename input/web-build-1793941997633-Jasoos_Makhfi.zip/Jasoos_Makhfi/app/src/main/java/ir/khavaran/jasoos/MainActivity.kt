kotlin
package ir.khavaran.jasoos

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.widget.TextView
import android.widget.LinearLayout
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.Color
import android.widget.Toast

import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var statusText: TextView

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        showLoading()

        Thread {
            try {
                // راه‌اندازی پایتون
                if (!Python.isStarted()) {
                    Python.start(AndroidPlatform(applicationContext))
                }

                val appDir = File(filesDir, "jasoos")

                if (!appDir.exists()) {
                    appDir.mkdirs()
                }

                // اجرای سرور Flask
                val py = Python.getInstance()

                py.getModule("server")
                    .callAttr("start_server", appDir.absolutePath)

                // منتظر آماده شدن واقعی سرور می‌مانیم
                var ready = false

                for (i in 1..30) {

                    try {
                        val connection = URL(
                            "http://127.0.0.1:5003/"
                        ).openConnection() as HttpURLConnection

                        connection.connectTimeout = 1000
                        connection.readTimeout = 1000
                        connection.requestMethod = "GET"

                        val code = connection.responseCode

                        connection.disconnect()

                        if (code in 200..499) {
                            ready = true
                            break
                        }

                    } catch (_: Exception) {
                        Thread.sleep(500)
                    }
                }

                if (!ready) {
                    throw Exception("سرور بازی در زمان مقرر آماده نشد.")
                }

                // نمایش بازی در رابط کاربری
                handler.post {
                    openGame()
                }

            } catch (e: Throwable) {

                val error = e.message ?: e.toString()

                handler.post {
                    statusText.text =
                        "خطا در اجرای بازی:\n$error"

                    Toast.makeText(
                        this,
                        error,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

        }.start()
    }

    private fun showLoading() {

        val layout = LinearLayout(this)

        layout.orientation = LinearLayout.VERTICAL
        layout.gravity = Gravity.CENTER
        layout.setPadding(25, 25, 25, 25)
        layout.setBackgroundColor(Color.rgb(241, 238, 231))

        statusText = TextView(this)

        statusText.text = "در حال آماده‌سازی بازی جاسوس مخفی..."
        statusText.textSize = 18f
        statusText.gravity = Gravity.CENTER
        statusText.setTextColor(Color.rgb(38, 59, 104))

        layout.addView(
            statusText,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        setContentView(layout)
    }

    private fun openGame() {

        webView = WebView(this)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()

        setContentView(webView)

        webView.loadUrl("http://127.0.0.1:5003/")
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {

        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
