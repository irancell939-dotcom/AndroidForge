package ir.khavaran.shajareh;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.app.DownloadManager;
import android.content.Context;
import android.os.Environment;
import android.webkit.URLUtil;
import android.widget.Toast;
import android.graphics.Color;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private ProgressBar progress;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int attempts = 0;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 701;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16, 38, 62));
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(246, 247, 249));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/x-sqlite3", "application/octet-stream", "application/vnd.sqlite3"});
                startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                return true;
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setTitle("shajareh-backup.db");
                req.setDescription("نسخه پشتیبان شجره‌نامه");
                req.setMimeType("application/octet-stream");
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null) req.addRequestHeader("Cookie", cookies);
                req.addRequestHeader("User-Agent", webView.getSettings().getUserAgentString());
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "shajareh-backup.db");
                DownloadManager dm = (DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
                dm.enqueue(req);
                Toast.makeText(this, "ذخیره پشتیبان در پوشه Downloads آغاز شد.", Toast.LENGTH_LONG).show();
            } catch (Exception ex) { Toast.makeText(this, "ذخیره فایل ناموفق بود: " + ex.getMessage(), Toast.LENGTH_LONG).show(); }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                status.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
            }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (failingUrl != null && failingUrl.startsWith("http://127.0.0.1")) retryLoad();
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        progress = new ProgressBar(this);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(100, 100, android.view.Gravity.CENTER);
        root.addView(progress, pp);
        status = new TextView(this);
        status.setText("در حال راه‌اندازی شجره‌نامه...");
        status.setTextColor(Color.rgb(25, 55, 78));
        status.setTextSize(16);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, android.view.Gravity.CENTER_HORIZONTAL | android.view.Gravity.CENTER_VERTICAL);
        sp.topMargin = 95;
        root.addView(status, sp);
        webView.setVisibility(View.INVISIBLE);
        setContentView(root);
        try {
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            Python.getInstance().getModule("android_entry").callAttr("start_server", getFilesDir().getAbsolutePath());
            // هر بار که برنامه از نو باز می‌شود، کوکی ورود قبلی پاک می‌شود.
            CookieManager cookies = CookieManager.getInstance();
            cookies.removeAllCookies(removed -> {
                cookies.flush();
                handler.postDelayed(() -> webView.loadUrl("http://127.0.0.1:5006"), 1800);
            });
        } catch (Exception e) {
            status.setText("راه‌اندازی برنامه ناموفق بود: " + e.getMessage());
            progress.setVisibility(View.GONE);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    private void retryLoad() {
        if (attempts++ < 12) handler.postDelayed(() -> webView.loadUrl("http://127.0.0.1:5006"), 700);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
