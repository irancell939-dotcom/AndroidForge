import os
import threading
import time

_server_started = False

def start_server(data_dir):
    global _server_started
    if _server_started:
        return True
    os.makedirs(data_dir, exist_ok=True)
    os.environ['SHAJAREH_DATA_DIR'] = data_dir
    os.environ['SECRET_KEY'] = _load_secret(data_dir)
    import app as shajareh_app
    def run():
        shajareh_app.app.run(host='127.0.0.1', port=5006, debug=False, use_reloader=False, threaded=True)
    threading.Thread(target=run, daemon=True, name='ShajarehFlask').start()
    _server_started = True
    return True

def _load_secret(data_dir):
    path = os.path.join(data_dir, '.session_secret')
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return f.read().strip()
    import secrets
    value = secrets.token_hex(32)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(value)
    return value
