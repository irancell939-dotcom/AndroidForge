بسته سورس برنامه مدیریت کامیون

محتوا: app.py، requirements.txt، templates/، static/ و آیکون‌ها.
پایگاه داده قبلی عمداً حذف شده است. برنامه در اولین اجرا با init_db یک پایگاه داده خالی می‌سازد.

نکته مهم: این بسته سورس Flask است، نه پروژه Gradle اندروید. خطای «does not contain a Gradle build» با این بسته به‌تنهایی رفع نمی‌شود؛ برای ساخت APK باید قالب/پروژه Gradle مورد قبول AndroidForge در دسترس باشد.
نقطه ورود Flask: app.py | پورت: 5008
آیکون: icon.png (512x512)، icon-192.png
