import os
import shutil
import secrets
import sqlite3
import tempfile
from datetime import datetime
from functools import wraps

from flask import (Flask, render_template, request, redirect, url_for,
                   flash, g, session, send_file)
from werkzeug.security import generate_password_hash, check_password_hash
import jdatetime

app = Flask(__name__)
app.secret_key = 'change-this-to-a-random-secret-key'
DATABASE = 'truck_manager.db'

# ==================== دیتابیس ====================
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        db.executescript('''
            CREATE TABLE IF NOT EXISTS vehicles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_two_digit TEXT, plate_letter TEXT, plate_three_digit TEXT,
                plate_serial TEXT, model TEXT, created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS bank_cards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                card_number TEXT, bank_name TEXT, account_holder TEXT,
                sheba TEXT, created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS expense_types (
                id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE
            );
            CREATE TABLE IF NOT EXISTS trips (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vehicle_id INTEGER, origin TEXT, destination TEXT, cargo_type TEXT,
                driver_name TEXT, second_driver_name TEXT, apprentice_name TEXT,
                freight_amount INTEGER, departure_date TEXT, discharge_date TEXT,
                freight_status TEXT DEFAULT 'unpaid', freight_received_date TEXT,
                freight_card_id INTEGER, created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                expense_type_id INTEGER, amount INTEGER, description TEXT,
                expense_date TEXT, trip_id INTEGER, created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS payees (
                id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, role TEXT
            );
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trip_id INTEGER, payee_id INTEGER, amount INTEGER,
                payment_date TEXT, description TEXT,
                payee_card_id INTEGER, payee_card_number TEXT, created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY, value TEXT
            );
        ''')

        cols = [r[1] for r in db.execute("PRAGMA table_info(trips)").fetchall()]
        if 'freight_status' not in cols:
            db.execute("ALTER TABLE trips ADD COLUMN freight_status TEXT DEFAULT 'unpaid'")
        if 'freight_received_date' not in cols:
            db.execute("ALTER TABLE trips ADD COLUMN freight_received_date TEXT")
        if 'freight_card_id' not in cols:
            db.execute("ALTER TABLE trips ADD COLUMN freight_card_id INTEGER")

        pcols = [r[1] for r in db.execute("PRAGMA table_info(payments)").fetchall()]
        if 'payee_card_id' not in pcols:
            db.execute("ALTER TABLE payments ADD COLUMN payee_card_id INTEGER")
        if 'payee_card_number' not in pcols:
            db.execute("ALTER TABLE payments ADD COLUMN payee_card_number TEXT")
        db.commit()

        for t in ['سوخت', 'تعمیرات', 'عوارض جاده', 'بیمه', 'لاستیک', 'روغن', 'جریمه', 'سایر']:
            try:
                db.execute('INSERT INTO expense_types (name) VALUES (?)', (t,))
            except sqlite3.IntegrityError:
                pass
        for name, role in [('راننده پیش‌فرض', 'driver'), ('صاحب خودرو', 'owner'), ('شریک اول', 'partner')]:
            if not db.execute('SELECT id FROM payees WHERE name=?', (name,)).fetchone():
                db.execute('INSERT INTO payees (name, role) VALUES (?, ?)', (name, role))
        db.commit()

# ==================== توابع کمکی ====================
def number_to_persian_words(num):
    if num == 0:
        return "صفر"
    ones = ['', 'یک', 'دو', 'سه', 'چهار', 'پنج', 'شش', 'هفت', 'هشت', 'نه']
    teens = ['ده', 'یازده', 'دوازده', 'سیزده', 'چهارده', 'پانزده', 'شانزده', 'هفده', 'هجده', 'نوزده']
    tens = ['', '', 'بیست', 'سی', 'چهل', 'پنجاه', 'شصت', 'هفتاد', 'هشتاد', 'نود']
    hundreds = ['', 'صد', 'دویست', 'سیصد', 'چهارصد', 'پانصد', 'ششصد', 'هفتصد', 'هشتصد', 'نهصد']
    scales = ['', 'هزار', 'میلیون', 'میلیارد', 'بیلیون']

    def three_digit(n):
        parts = []
        h = n // 100
        r = n % 100
        if h > 0:
            parts.append(hundreds[h])
        if 10 <= r < 20:
            parts.append(teens[r - 10])
        else:
            t = r // 10
            o = r % 10
            if t > 0:
                parts.append(tens[t])
            if o > 0:
                parts.append(ones[o])
        return ' و '.join(parts)

    result = []
    scale_idx = 0
    while num > 0:
        chunk = num % 1000
        if chunk > 0:
            cw = three_digit(chunk)
            if scale_idx > 0:
                cw += ' ' + scales[scale_idx]
            result.insert(0, cw)
        num //= 1000
        scale_idx += 1
    return ' و '.join(result) + ' تومان'

def format_currency(amount):
    try:
        return f"{int(amount):,}"
    except (ValueError, TypeError):
        return "0"

def jalali_to_gregorian_str(jalali_str):
    if not jalali_str:
        return None
    try:
        parts = jalali_str.replace('-', '/').split('/')
        jy, jm, jd = int(parts[0]), int(parts[1]), int(parts[2])
        g = jdatetime.date(jy, jm, jd).togregorian()
        return g.strftime('%Y-%m-%d')
    except Exception:
        return jalali_str

def gregorian_to_jalali_str(gregorian_str):
    if not gregorian_str:
        return ''
    try:
        g = datetime.strptime(gregorian_str, '%Y-%m-%d').date()
        j = jdatetime.date.fromgregorian(date=g)
        return j.strftime('%Y/%m/%d')
    except Exception:
        return gregorian_str

def safe_int(v, default=0):
    try:
        return int(str(v).replace(',', '').strip() or default)
    except (ValueError, TypeError):
        return default

def jalali_now_str():
    return jdatetime.date.today().strftime('%Y/%m/%d')

def jalali_ymd_from_gregorian(gregorian_str):
    if not gregorian_str:
        return None, None
    try:
        g = datetime.strptime(gregorian_str, '%Y-%m-%d').date()
        j = jdatetime.date.fromgregorian(date=g)
        return j.year, j.month
    except Exception:
        return None, None

def jalali_month_name(month):
    names = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
             'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند']
    try:
        return names[int(month)]
    except Exception:
        return ''

app.jinja_env.filters['currency'] = format_currency
app.jinja_env.filters['persian_words'] = number_to_persian_words
app.jinja_env.filters['jalali'] = gregorian_to_jalali_str
app.jinja_env.filters['jalali_month'] = jalali_month_name
app.jinja_env.globals['jalali_today'] = jalali_now_str

# ==================== احراز هویت و نسخه آزمایشی ====================
TRIAL_MAX_TRIPS = 1

def compute_register2(reg1):
    s = str(reg1).strip()
    if len(s) != 15 or not s.isdigit():
        return None
    return f"{s[5:10]}DOA{s[-4:]}RE{s[:5]}{s[10]}"

def get_setting(db, key, default=None):
    row = db.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
    return row['value'] if row else default

def set_setting(db, key, value):
    db.execute('''INSERT INTO settings (key, value) VALUES (?, ?)
                  ON CONFLICT(key) DO UPDATE SET value=excluded.value''', (key, value))
    db.commit()

def is_setup_done(db):
    return get_setting(db, 'password_hash') is not None

def is_trial_mode():
    return bool(session.get('trial')) and not is_setup_done(get_db())

def trial_trips_count(db):
    return db.execute('SELECT COUNT(*) FROM trips').fetchone()[0]

def trial_limit_reached(db):
    if not is_trial_mode():
        return False
    return trial_trips_count(db) >= TRIAL_MAX_TRIPS

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        db = get_db()
        if is_setup_done(db):
            if not session.get('logged_in'):
                return redirect(url_for('login'))
        else:
            if not session.get('trial'):
                return redirect(url_for('welcome'))
        return f(*args, **kwargs)
    return wrapper

app.jinja_env.globals['is_trial_mode'] = is_trial_mode

# ==================== مسیرهای احراز هویت ====================
@app.route('/welcome')
def welcome():
    db = get_db()
    if is_setup_done(db):
        if session.get('logged_in'):
            return redirect(url_for('index'))
        return redirect(url_for('login'))
    if session.get('trial'):
        return redirect(url_for('index'))
    return render_template('welcome.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    db = get_db()
    setup_done = is_setup_done(db)

    if setup_done and session.get('logged_in'):
        return redirect(url_for('index'))

    if request.method == 'POST':
        action = request.form.get('action', '')

        if action == 'trial':
            if setup_done:
                flash('برنامه ثبت‌نام شده است و نسخه آزمایشی غیرفعال می‌باشد. لطفاً با رمز عبور وارد شوید.', 'warning')
                return redirect(url_for('login'))
            session['trial'] = True
            session.pop('logged_in', None)
            flash('به نسخه آزمایشی خوش آمدید. فقط ۱ سفر می‌توانید ثبت کنید.', 'info')
            return redirect(url_for('index'))

        if action == 'login':
            if not setup_done:
                flash('برنامه هنوز ثبت‌نام نشده است. ابتدا ثبت‌نام کنید.', 'warning')
                return redirect(url_for('setup'))
            password = request.form.get('password') or ''
            stored = get_setting(db, 'password_hash')
            if stored and check_password_hash(stored, password):
                session['logged_in'] = True
                session.pop('trial', None)
                flash('خوش آمدید', 'success')
                return redirect(url_for('index'))
            flash('رمز عبور اشتباه است', 'danger')
            return redirect(url_for('login'))

    return render_template('login.html',
                           setup_done=setup_done,
                           trial_mode=is_trial_mode())


@app.route('/setup', methods=['GET', 'POST'])
def setup():
    db = get_db()
    if is_setup_done(db):
        return redirect(url_for('login'))

    if 'gen_reg1' in request.args or (request.method == 'POST' and request.form.get('action') == 'gen'):
        rnd = secrets.randbelow(9000000) + 1000000
        session['reg1_full'] = f"{rnd}10246600"
        session['reg1_id'] = str(rnd)
        flash('شناسه تولید شد. پیامک را ارسال و کد ریجستر ۲ را وارد کنید.', 'info')
        return redirect(url_for('setup'))

    if request.method == 'POST' and request.form.get('action') == 'register':
        reg1_full = session.get('reg1_full')
        reg2_input = (request.form.get('reg2') or '').strip().upper()
        password = request.form.get('password') or ''
        password2 = request.form.get('password2') or ''

        if not reg1_full:
            flash('ابتدا شناسه را تولید کنید', 'danger')
            return redirect(url_for('setup'))
        if len(password) < 6:
            flash('رمز عبور باید حداقل ۶ کاراکتر باشد', 'danger')
            return redirect(url_for('setup'))
        if password != password2:
            flash('رمز عبور و تکرار آن یکسان نیستند', 'danger')
            return redirect(url_for('setup'))
        expected = compute_register2(reg1_full)
        if not expected or reg2_input != expected.upper():
            flash('کد ریجستر ۲ نامعتبر است', 'danger')
            return redirect(url_for('setup'))

        set_setting(db, 'password_hash', generate_password_hash(password))
        set_setting(db, 'reg1_id', session.get('reg1_id', ''))
        set_setting(db, 'registered_at', datetime.now().isoformat())
        session.pop('reg1_full', None)
        session.pop('trial', None)
        session['logged_in'] = True
        flash('ثبت‌نام با موفقیت انجام شد. نسخه آزمایشی به نسخه کامل ارتقا یافت.', 'success')
        return redirect(url_for('index'))

    trial_msg = session.get('trial_limit_msg')
    if trial_msg:
        session.pop('trial_limit_msg', None)
    return render_template('setup.html',
                           reg1_id=session.get('reg1_id', ''),
                           trial_msg=trial_msg)


@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    session.pop('trial', None)
    flash('از حساب خارج شدید', 'info')
    return redirect(url_for('welcome'))

# ==================== فراموشی رمز ====================
@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    db = get_db()
    if not is_setup_done(db):
        flash('برنامه هنوز ثبت‌نام نشده است.', 'warning')
        return redirect(url_for('setup'))

    if request.method == 'POST':
        code = (request.form.get('code') or '').strip()
        if len(code) != 15 or not code.isdigit() or not code.endswith('10246600'):
            flash('کد وارد شده نامعتبر است.', 'danger')
            return redirect(url_for('forgot_password'))
        session['reset_allowed'] = True
        flash('کد معتبر است. لطفاً رمز جدید را تعیین کنید.', 'success')
        return redirect(url_for('reset_password'))

    return render_template('forgot_password.html')


@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    db = get_db()
    if not is_setup_done(db):
        return redirect(url_for('setup'))
    if not session.get('reset_allowed'):
        flash('ابتدا کد بازیابی را وارد کنید.', 'warning')
        return redirect(url_for('forgot_password'))

    if request.method == 'POST':
        password = request.form.get('password') or ''
        password2 = request.form.get('password2') or ''
        if len(password) < 6:
            flash('رمز عبور باید حداقل ۶ کاراکتر باشد', 'danger')
            return redirect(url_for('reset_password'))
        if password != password2:
            flash('رمز عبور و تکرار آن یکسان نیستند', 'danger')
            return redirect(url_for('reset_password'))

        set_setting(db, 'password_hash', generate_password_hash(password))
        session.pop('reset_allowed', None)
        session['logged_in'] = True
        flash('رمز عبور با موفقیت تغییر کرد. خوش آمدید.', 'success')
        return redirect(url_for('index'))

    return render_template('reset_password.html')

# ==================== پشتیبان‌گیری و بازیابی ====================
@app.route('/backup')
@login_required
def backup_page():
    db = get_db()
    stats = {
        'vehicles': db.execute('SELECT COUNT(*) FROM vehicles').fetchone()[0],
        'trips': db.execute('SELECT COUNT(*) FROM trips').fetchone()[0],
        'expenses': db.execute('SELECT COUNT(*) FROM expenses').fetchone()[0],
        'payments': db.execute('SELECT COUNT(*) FROM payments').fetchone()[0],
        'cards': db.execute('SELECT COUNT(*) FROM bank_cards').fetchone()[0],
    }
    return render_template('backup.html', stats=stats)


@app.route('/backup/download')
@login_required
def backup_download():
    if not os.path.exists(DATABASE):
        flash('فایل دیتابیس یافت نشد', 'danger')
        return redirect(url_for('backup_page'))
    close_connection(None)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'truck_manager_backup_{timestamp}.db'
    return send_file(os.path.abspath(DATABASE), as_attachment=True, download_name=filename)


@app.route('/backup/restore', methods=['POST'])
@login_required
def backup_restore():
    f = request.files.get('db_file')
    if not f or f.filename == '':
        flash('هیچ فایلی انتخاب نشده است', 'danger')
        return redirect(url_for('backup_page'))

    if not f.filename.lower().endswith('.db'):
        flash('فقط فایل با پسوند .db مجاز است', 'danger')
        return redirect(url_for('backup_page'))

    tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
    try:
        f.save(tmp.name)
        tmp.close()

        try:
            check = sqlite3.connect(tmp.name)
            tables = [r[0] for r in check.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
            check.close()
            if 'settings' not in tables and 'trips' not in tables:
                flash('فایل انتخاب‌شده یک دیتابیس معتبر برنامه نیست', 'danger')
                os.unlink(tmp.name)
                return redirect(url_for('backup_page'))
        except sqlite3.DatabaseError:
            flash('فایل دیتابیس خراب یا نامعتبر است', 'danger')
            os.unlink(tmp.name)
            return redirect(url_for('backup_page'))

        close_connection(None)
        shutil.copy2(tmp.name, os.path.abspath(DATABASE))
        os.unlink(tmp.name)

        flash('دیتابیس با موفقیت بازیابی شد. لطفاً دوباره وارد شوید.', 'success')
        session.clear()
        return redirect(url_for('login'))
    except Exception as e:
        try:
            if os.path.exists(tmp.name):
                os.unlink(tmp.name)
        except Exception:
            pass
        flash(f'خطا در بازیابی: {e}', 'danger')
        return redirect(url_for('backup_page'))

# ==================== مسیرهای اصلی ====================
@app.route('/')
@login_required
def index():
    db = get_db()
    total_income = db.execute('SELECT COALESCE(SUM(freight_amount), 0) FROM trips').fetchone()[0]
    trip_expense = db.execute('SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE trip_id IS NOT NULL').fetchone()[0]
    general_expense = db.execute('SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE trip_id IS NULL').fetchone()[0]
    total_expense = trip_expense + general_expense
    balance = total_income - total_expense
    trips_count = db.execute('SELECT COUNT(*) FROM trips').fetchone()[0]
    return render_template('index.html',
                           total_income=total_income,
                           total_expense=total_expense,
                           trip_expense=trip_expense,
                           general_expense=general_expense,
                           balance=balance,
                           trips_count=trips_count,
                           trial_limit=TRIAL_MAX_TRIPS if is_trial_mode() else None)


@app.route('/vehicles', methods=['GET', 'POST'])
@login_required
def vehicles():
    db = get_db()
    if request.method == 'POST':
        db.execute('''INSERT INTO vehicles (plate_two_digit, plate_letter, plate_three_digit, plate_serial, model, created_at)
                     VALUES (?, ?, ?, ?, ?, ?)''',
                  (request.form.get('plate_two_digit', ''),
                   request.form.get('plate_letter', ''),
                   request.form.get('plate_three_digit', ''),
                   request.form.get('plate_serial', ''),
                   request.form.get('model', ''),
                   datetime.now().isoformat()))
        db.commit()
        flash('خودرو با موفقیت اضافه شد', 'success')
        return redirect(url_for('vehicles'))

    vehicles_list = db.execute('SELECT * FROM vehicles ORDER BY created_at DESC').fetchall()
    stats = {}
    for v in vehicles_list:
        vid = v['id']
        income = db.execute('SELECT COALESCE(SUM(freight_amount),0) FROM trips WHERE vehicle_id=?', (vid,)).fetchone()[0]
        trip_exp = db.execute('''SELECT COALESCE(SUM(e.amount),0) FROM expenses e
                                 JOIN trips t ON e.trip_id = t.id WHERE t.vehicle_id=?''', (vid,)).fetchone()[0]
        cnt = db.execute('SELECT COUNT(*) FROM trips WHERE vehicle_id=?', (vid,)).fetchone()[0]
        stats[vid] = {'income': income, 'expense': trip_exp, 'profit': income - trip_exp, 'trips_count': cnt}
    return render_template('vehicles.html', vehicles=vehicles_list, stats=stats)


@app.route('/vehicles/<int:vehicle_id>/report')
@login_required
def vehicle_report(vehicle_id):
    db = get_db()
    vehicle = db.execute('SELECT * FROM vehicles WHERE id=?', (vehicle_id,)).fetchone()
    if not vehicle:
        flash('خودرو یافت نشد', 'danger')
        return redirect(url_for('vehicles'))
    trips = db.execute('''SELECT t.*, c.card_number, c.bank_name FROM trips t
                          LEFT JOIN bank_cards c ON t.freight_card_id = c.id
                          WHERE t.vehicle_id = ? ORDER BY t.departure_date DESC''', (vehicle_id,)).fetchall()
    ids = [t['id'] for t in trips]
    trip_expenses = []
    total_expense = 0
    if ids:
        ph = ','.join('?' * len(ids))
        trip_expenses = db.execute(f'''SELECT e.*, et.name as type_name, t.origin, t.destination, t.departure_date
                                       FROM expenses e LEFT JOIN expense_types et ON e.expense_type_id=et.id
                                       JOIN trips t ON e.trip_id=t.id WHERE e.trip_id IN ({ph})
                                       ORDER BY e.created_at DESC''', ids).fetchall()
        total_expense = sum(e['amount'] for e in trip_expenses)
    total_income = sum(t['freight_amount'] or 0 for t in trips)
    paid = sum(t['freight_amount'] or 0 for t in trips if t['freight_status'] == 'paid')
    summary = {'income': total_income, 'paid_income': paid, 'unpaid_income': total_income - paid,
               'expense': total_expense, 'profit': total_income - total_expense, 'trips_count': len(trips)}
    return render_template('vehicle_report.html', vehicle=vehicle, trips=trips,
                           trip_expenses=trip_expenses, summary=summary)


@app.route('/cards', methods=['GET', 'POST'])
@login_required
def cards():
    db = get_db()
    if request.method == 'POST':
        db.execute('''INSERT INTO bank_cards (card_number, bank_name, account_holder, sheba, created_at)
                     VALUES (?, ?, ?, ?, ?)''',
                  (request.form.get('card_number', ''),
                   request.form.get('bank_name', ''),
                   request.form.get('account_holder', ''),
                   request.form.get('sheba', ''),
                   datetime.now().isoformat()))
        db.commit()
        flash('کارت بانکی اضافه شد', 'success')
        return redirect(url_for('cards'))
    cards_list = db.execute('SELECT * FROM bank_cards ORDER BY created_at DESC').fetchall()
    return render_template('cards.html', cards=cards_list)


@app.route('/expenses', methods=['GET', 'POST'])
@login_required
def expenses():
    db = get_db()
    if request.method == 'POST':
        action = request.form.get('action', '')
        if action == 'add_type':
            try:
                db.execute('INSERT INTO expense_types (name) VALUES (?)', (request.form.get('type_name', ''),))
                db.commit()
                flash('نوع هزینه اضافه شد', 'success')
            except sqlite3.IntegrityError:
                flash('این نوع هزینه قبلاً وجود دارد', 'danger')
            return redirect(url_for('expenses'))
        elif action == 'edit_type':
            tid = request.form.get('type_id')
            nn = request.form.get('type_name', '').strip()
            if tid and nn:
                try:
                    db.execute('UPDATE expense_types SET name=? WHERE id=?', (nn, tid))
                    db.commit()
                    flash('ویرایش شد', 'success')
                except sqlite3.IntegrityError:
                    flash('نام تکراری است', 'danger')
            return redirect(url_for('expenses'))
        elif action == 'delete_type':
            tid = request.form.get('type_id')
            used = db.execute('SELECT COUNT(*) FROM expenses WHERE expense_type_id=?', (tid,)).fetchone()[0]
            if used > 0:
                flash('این نوع هزینه در حال استفاده است', 'danger')
            else:
                db.execute('DELETE FROM expense_types WHERE id=?', (tid,))
                db.commit()
                flash('حذف شد', 'success')
            return redirect(url_for('expenses'))
        else:
            db.execute('''INSERT INTO expenses (expense_type_id, amount, description, expense_date, trip_id, created_at)
                         VALUES (?, ?, ?, ?, NULL, ?)''',
                      (request.form.get('expense_type_id'),
                       safe_int(request.form.get('amount')),
                       request.form.get('description', ''),
                       jalali_to_gregorian_str(request.form.get('expense_date', '')),
                       datetime.now().isoformat()))
            db.commit()
            flash('هزینه عمومی ثبت شد', 'success')
            return redirect(url_for('expenses'))

    types = db.execute('SELECT * FROM expense_types ORDER BY name').fetchall()
    general = db.execute('''SELECT e.*, t.name as type_name FROM expenses e
                            LEFT JOIN expense_types t ON e.expense_type_id=t.id
                            WHERE e.trip_id IS NULL ORDER BY e.created_at DESC LIMIT 100''').fetchall()
    trip_exps = db.execute('''SELECT e.*, t.name as type_name, tr.origin, tr.destination
                              FROM expenses e LEFT JOIN expense_types t ON e.expense_type_id=t.id
                              LEFT JOIN trips tr ON e.trip_id=tr.id
                              WHERE e.trip_id IS NOT NULL ORDER BY e.created_at DESC LIMIT 100''').fetchall()
    return render_template('expenses.html', expense_types=types, general_expenses=general,
                           trip_expenses=trip_exps,
                           total_general=sum(e['amount'] for e in general),
                           total_trip=sum(e['amount'] for e in trip_exps))


@app.route('/trips')
@login_required
def trips():
    db = get_db()
    q = request.args.get('q', '').strip().lower()
    all_trips = db.execute('''SELECT t.*, v.plate_two_digit, v.plate_letter, v.plate_three_digit, v.plate_serial,
                              c.card_number, c.bank_name FROM trips t
                              LEFT JOIN vehicles v ON t.vehicle_id=v.id
                              LEFT JOIN bank_cards c ON t.freight_card_id=c.id
                              ORDER BY t.created_at DESC''').fetchall()
    return render_template('trips.html', trips=all_trips, q=q, trial_limit_reached=trial_limit_reached(db))


@app.route('/trips/new', methods=['GET', 'POST'])
@login_required
def trip_new():
    db = get_db()
    if trial_limit_reached(db):
        session['trial_limit_msg'] = f'در نسخه آزمایشی فقط {TRIAL_MAX_TRIPS} سفر مجاز است. برای ثبت سفر بیشتر، لطفاً ثبت‌نام کنید.'
        return redirect(url_for('setup'))

    if request.method == 'POST':
        if trial_limit_reached(db):
            session['trial_limit_msg'] = 'در نسخه آزمایشی فقط یک سفر مجاز است.'
            return redirect(url_for('setup'))

        dep = jalali_to_gregorian_str(request.form.get('departure_date', ''))
        dis = jalali_to_gregorian_str(request.form.get('discharge_date', ''))
        rec = jalali_to_gregorian_str(request.form.get('freight_received_date', ''))
        st = request.form.get('freight_status', 'unpaid')
        cid = request.form.get('freight_card_id') or None
        db.execute('''INSERT INTO trips (vehicle_id, origin, destination, cargo_type, driver_name,
                     second_driver_name, apprentice_name, freight_amount, departure_date, discharge_date,
                     freight_status, freight_received_date, freight_card_id, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                  (request.form.get('vehicle_id') or None,
                   request.form.get('origin', ''),
                   request.form.get('destination', ''),
                   request.form.get('cargo_type', ''),
                   request.form.get('driver_name', ''),
                   request.form.get('second_driver_name', ''),
                   request.form.get('apprentice_name', ''),
                   safe_int(request.form.get('freight_amount')),
                   dep, dis, st,
                   rec if st == 'paid' else None,
                   cid if st == 'paid' else None,
                   datetime.now().isoformat()))
        db.commit()
        flash('سفر ثبت شد', 'success')
        if is_trial_mode() and trial_trips_count(db) >= TRIAL_MAX_TRIPS:
            flash('شما به سقف نسخه آزمایشی رسیدید. برای ادامه، لطفاً ثبت‌نام کنید.', 'warning')
            session['trial_limit_msg'] = 'شما به سقف نسخه آزمایشی رسیدید. برای ثبت سفرهای بیشتر، لطفاً ثبت‌نام کنید.'
        return redirect(url_for('trips'))

    vlist = db.execute('SELECT * FROM vehicles ORDER BY created_at DESC').fetchall()
    clist = db.execute('SELECT * FROM bank_cards ORDER BY created_at DESC').fetchall()
    return render_template('trip_new.html', vehicles=vlist, cards=clist,
                           trial_mode=is_trial_mode(),
                           trial_limit=TRIAL_MAX_TRIPS if is_trial_mode() else None)


@app.route('/trips/<int:trip_id>')
@login_required
def trip_detail(trip_id):
    db = get_db()
    trip = db.execute('''SELECT t.*, v.plate_two_digit, v.plate_letter, v.plate_three_digit, v.plate_serial,
                         c.card_number, c.bank_name, c.account_holder FROM trips t
                         LEFT JOIN vehicles v ON t.vehicle_id=v.id
                         LEFT JOIN bank_cards c ON t.freight_card_id=c.id
                         WHERE t.id = ?''', (trip_id,)).fetchone()
    if not trip:
        flash('سفر یافت نشد', 'danger')
        return redirect(url_for('trips'))
    et = db.execute('SELECT * FROM expense_types ORDER BY name').fetchall()
    te = db.execute('''SELECT e.*, et.name as type_name FROM expenses e
                       LEFT JOIN expense_types et ON e.expense_type_id=et.id
                       WHERE e.trip_id=? ORDER BY e.created_at DESC''', (trip_id,)).fetchall()
    clist = db.execute('SELECT * FROM bank_cards ORDER BY created_at DESC').fetchall()
    return render_template('trip_detail.html', trip=trip, expense_types=et,
                           trip_expenses=te, total_trip_expenses=sum(e['amount'] for e in te),
                           cards=clist)


@app.route('/trips/<int:trip_id>/edit', methods=['GET', 'POST'])
@login_required
def trip_edit(trip_id):
    db = get_db()
    trip = db.execute('SELECT * FROM trips WHERE id=?', (trip_id,)).fetchone()
    if not trip:
        flash('سفر یافت نشد', 'danger')
        return redirect(url_for('trips'))
    if request.method == 'POST':
        dep = jalali_to_gregorian_str(request.form.get('departure_date', ''))
        dis = jalali_to_gregorian_str(request.form.get('discharge_date', ''))
        rec = jalali_to_gregorian_str(request.form.get('freight_received_date', ''))
        st = request.form.get('freight_status', 'unpaid')
        cid = request.form.get('freight_card_id') or None
        db.execute('''UPDATE trips SET vehicle_id=?, origin=?, destination=?, cargo_type=?,
                     driver_name=?, second_driver_name=?, apprentice_name=?, freight_amount=?,
                     departure_date=?, discharge_date=?, freight_status=?, freight_received_date=?,
                     freight_card_id=? WHERE id=?''',
                  (request.form.get('vehicle_id') or None,
                   request.form.get('origin', ''),
                   request.form.get('destination', ''),
                   request.form.get('cargo_type', ''),
                   request.form.get('driver_name', ''),
                   request.form.get('second_driver_name', ''),
                   request.form.get('apprentice_name', ''),
                   safe_int(request.form.get('freight_amount')),
                   dep, dis, st,
                   rec if st == 'paid' else None,
                   cid if st == 'paid' else None,
                   trip_id))
        db.commit()
        flash('سفر ویرایش شد', 'success')
        return redirect(url_for('trip_detail', trip_id=trip_id))
    vlist = db.execute('SELECT * FROM vehicles ORDER BY created_at DESC').fetchall()
    clist = db.execute('SELECT * FROM bank_cards ORDER BY created_at DESC').fetchall()
    return render_template('trip_new.html', trip=trip, vehicles=vlist, cards=clist, edit_mode=True)


@app.route('/trips/<int:trip_id>/delete', methods=['POST'])
@login_required
def trip_delete(trip_id):
    db = get_db()
    db.execute('DELETE FROM expenses WHERE trip_id=?', (trip_id,))
    db.execute('DELETE FROM payments WHERE trip_id=?', (trip_id,))
    db.execute('DELETE FROM trips WHERE id=?', (trip_id,))
    db.commit()
    flash('سفر و داده‌های مرتبط حذف شد', 'success')
    return redirect(url_for('trips'))


@app.route('/trips/<int:trip_id>/update_freight', methods=['POST'])
@login_required
def trip_update_freight(trip_id):
    db = get_db()
    st = request.form.get('freight_status', 'unpaid')
    rec = jalali_to_gregorian_str(request.form.get('freight_received_date', ''))
    cid = request.form.get('freight_card_id') or None
    db.execute('UPDATE trips SET freight_status=?, freight_received_date=?, freight_card_id=? WHERE id=?',
               (st, rec if st == 'paid' else None, cid if st == 'paid' else None, trip_id))
    db.commit()
    flash('وضعیت کرایه به‌روزرسانی شد', 'success')
    return redirect(url_for('trip_detail', trip_id=trip_id))


@app.route('/trips/<int:trip_id>/add_expense', methods=['POST'])
@login_required
def add_trip_expense(trip_id):
    db = get_db()
    db.execute('''INSERT INTO expenses (trip_id, expense_type_id, amount, description, expense_date, created_at)
                 VALUES (?, ?, ?, ?, ?, ?)''',
              (trip_id,
               request.form.get('expense_type_id'),
               safe_int(request.form.get('amount')),
               request.form.get('description', ''),
               jalali_to_gregorian_str(request.form.get('expense_date', '')),
               datetime.now().isoformat()))
    db.commit()
    flash('هزینه به سفر اضافه شد', 'success')
    return redirect(url_for('trip_detail', trip_id=trip_id))


@app.route('/trips/<int:trip_id>/edit_expense/<int:expense_id>', methods=['POST'])
@login_required
def edit_trip_expense(trip_id, expense_id):
    db = get_db()
    db.execute('''UPDATE expenses SET expense_type_id=?, amount=?, description=?, expense_date=?
                 WHERE id=? AND trip_id=?''',
              (request.form.get('expense_type_id'),
               safe_int(request.form.get('amount')),
               request.form.get('description', ''),
               jalali_to_gregorian_str(request.form.get('expense_date', '')),
               expense_id, trip_id))
    db.commit()
    flash('هزینه ویرایش شد', 'success')
    return redirect(url_for('trip_detail', trip_id=trip_id))


@app.route('/trips/<int:trip_id>/delete_expense/<int:expense_id>', methods=['POST'])
@login_required
def delete_trip_expense(trip_id, expense_id):
    db = get_db()
    db.execute('DELETE FROM expenses WHERE id=? AND trip_id=?', (expense_id, trip_id))
    db.commit()
    flash('هزینه حذف شد', 'success')
    return redirect(url_for('trip_detail', trip_id=trip_id))


@app.route('/payments', methods=['GET', 'POST'])
@login_required
def payments():
    db = get_db()
    if request.method == 'POST':
        action = request.form.get('action', '')
        if action == 'add_payee':
            db.execute('INSERT INTO payees (name, role) VALUES (?, ?)',
                       (request.form.get('payee_name', ''), request.form.get('payee_role', '')))
            db.commit()
            flash('دریافت‌کننده اضافه شد', 'success')
            return redirect(url_for('payments'))
        else:
            cid = request.form.get('payee_card_id') or None
            cnum = request.form.get('payee_card_number', '').strip()
            if cid:
                row = db.execute('SELECT card_number FROM bank_cards WHERE id=?', (cid,)).fetchone()
                if row:
                    cnum = row['card_number']
            db.execute('''INSERT INTO payments (trip_id, payee_id, amount, payment_date, description,
                         payee_card_id, payee_card_number, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                      (request.form.get('trip_id') or None,
                       request.form.get('payee_id'),
                       safe_int(request.form.get('amount')),
                       jalali_to_gregorian_str(request.form.get('payment_date', '')),
                       request.form.get('description', ''),
                       cid, cnum, datetime.now().isoformat()))
            db.commit()
            flash('پرداخت ثبت شد', 'success')
            return redirect(url_for('payments'))

    q = request.args.get('q', '').strip().lower()
    payees = db.execute('SELECT * FROM payees').fetchall()
    trips_l = db.execute('SELECT id, origin, destination FROM trips ORDER BY created_at DESC').fetchall()
    clist = db.execute('SELECT * FROM bank_cards ORDER BY created_at DESC').fetchall()
    plist = db.execute('''SELECT p.*, py.name as payee_name, t.origin, t.destination FROM payments p
                          LEFT JOIN payees py ON p.payee_id=py.id
                          LEFT JOIN trips t ON p.trip_id=t.id
                          ORDER BY p.created_at DESC LIMIT 200''').fetchall()
    return render_template('payments.html', payees=payees, trips=trips_l, payments=plist,
                           q=q, total_amount=sum(p['amount'] for p in plist), cards=clist)


@app.route('/payments/<int:payment_id>/delete', methods=['POST'])
@login_required
def delete_payment(payment_id):
    db = get_db()
    db.execute('DELETE FROM payments WHERE id=?', (payment_id,))
    db.commit()
    flash('پرداخت حذف شد', 'success')
    return redirect(url_for('payments'))


@app.route('/reports')
@login_required
def reports():
    db = get_db()
    trips = db.execute('''SELECT t.*, v.plate_two_digit, v.plate_letter, v.plate_three_digit, v.plate_serial
                          FROM trips t LEFT JOIN vehicles v ON t.vehicle_id=v.id
                          ORDER BY t.departure_date DESC''').fetchall()
    monthly = {}
    yearly = {}
    for t in trips:
        y, m = jalali_ymd_from_gregorian(t['departure_date'])
        if y is None:
            continue
        monthly.setdefault((y, m), {'trips': [], 'income': 0, 'trip_expense': 0})
        monthly[(y, m)]['trips'].append(t)
        monthly[(y, m)]['income'] += (t['freight_amount'] or 0)
        yearly.setdefault(y, {'trips_count': 0, 'income': 0, 'trip_expense': 0, 'months': set()})
        yearly[y]['trips_count'] += 1
        yearly[y]['income'] += (t['freight_amount'] or 0)
        yearly[y]['months'].add(m)

    exp_rows = db.execute('''SELECT e.amount, t.departure_date FROM expenses e
                             JOIN trips t ON e.trip_id=t.id WHERE e.trip_id IS NOT NULL''').fetchall()
    for r in exp_rows:
        y, m = jalali_ymd_from_gregorian(r['departure_date'])
        if y is None:
            continue
        if (y, m) in monthly:
            monthly[(y, m)]['trip_expense'] += (r['amount'] or 0)
        if y in yearly:
            yearly[y]['trip_expense'] += (r['amount'] or 0)

    ml = [{'year': y, 'month': m, 'month_name': jalali_month_name(m),
           'trips_count': len(d['trips']), 'income': d['income'],
           'trip_expense': d['trip_expense'],
           'profit': d['income'] - d['trip_expense']}
          for (y, m), d in sorted(monthly.items(), key=lambda x: (x[0][0], x[0][1]), reverse=True)]

    yl = [{'year': y, 'trips_count': d['trips_count'], 'income': d['income'],
           'trip_expense': d['trip_expense'],
           'profit': d['income'] - d['trip_expense'],
           'months_count': len(d['months'])}
          for y, d in sorted(yearly.items(), key=lambda x: x[0], reverse=True)]

    return render_template('reports.html', monthly_list=ml, yearly_list=yl)


@app.route('/reports/month/<int:year>/<int:month>')
@login_required
def report_month(year, month):
    db = get_db()
    trips = db.execute('''SELECT t.*, v.plate_two_digit, v.plate_letter, v.plate_three_digit, v.plate_serial,
                          c.card_number, c.bank_name FROM trips t
                          LEFT JOIN vehicles v ON t.vehicle_id=v.id
                          LEFT JOIN bank_cards c ON t.freight_card_id=c.id
                          ORDER BY t.departure_date DESC''').fetchall()
    mt = [t for t in trips if jalali_ymd_from_gregorian(t['departure_date']) == (year, month)]
    income = sum(t['freight_amount'] or 0 for t in mt)
    ids = [t['id'] for t in mt]
    texp = 0
    if ids:
        ph = ','.join('?' * len(ids))
        texp = db.execute(f'SELECT COALESCE(SUM(amount),0) FROM expenses WHERE trip_id IN ({ph})', ids).fetchone()[0]
    gen = 0
    for g in db.execute('SELECT amount, expense_date FROM expenses WHERE trip_id IS NULL').fetchall():
        if jalali_ymd_from_gregorian(g['expense_date']) == (year, month):
            gen += g['amount'] or 0
    summary = {'income': income, 'trip_expense': texp, 'general_expense': gen,
               'profit': income - texp - gen, 'trips_count': len(mt)}
    return render_template('report_detail.html', period_type='month',
                           period_label=f"{jalali_month_name(month)} {year}",
                           year=year, month=month, trips=mt, summary=summary)


@app.route('/reports/year/<int:year>')
@login_required
def report_year(year):
    db = get_db()
    trips = db.execute('''SELECT t.*, v.plate_two_digit, v.plate_letter, v.plate_three_digit, v.plate_serial,
                          c.card_number, c.bank_name FROM trips t
                          LEFT JOIN vehicles v ON t.vehicle_id=v.id
                          LEFT JOIN bank_cards c ON t.freight_card_id=c.id
                          ORDER BY t.departure_date DESC''').fetchall()
    yt = [t for t in trips if jalali_ymd_from_gregorian(t['departure_date'])[0] == year]
    income = sum(t['freight_amount'] or 0 for t in yt)
    ids = [t['id'] for t in yt]
    texp = 0
    if ids:
        ph = ','.join('?' * len(ids))
        texp = db.execute(f'SELECT COALESCE(SUM(amount),0) FROM expenses WHERE trip_id IN ({ph})', ids).fetchone()[0]
    gen = 0
    for g in db.execute('SELECT amount, expense_date FROM expenses WHERE trip_id IS NULL').fetchall():
        if jalali_ymd_from_gregorian(g['expense_date'])[0] == year:
            gen += g['amount'] or 0
    summary = {'income': income, 'trip_expense': texp, 'general_expense': gen,
               'profit': income - texp - gen, 'trips_count': len(yt)}
    return render_template('report_detail.html', period_type='year',
                           period_label=f"سال {year}", year=year, month=None,
                           trips=yt, summary=summary)


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5008, debug=True)