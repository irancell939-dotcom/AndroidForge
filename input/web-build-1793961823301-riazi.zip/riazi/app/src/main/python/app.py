
# -*- coding: utf-8 -*-
import os
import sqlite3
import random
import html
from datetime import datetime, date

from flask import (
    Flask, request, redirect, url_for,
    render_template_string, session, abort
)

app = Flask(__name__)
app.secret_key = "RiyaziBaz-2026-change-this-key"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "riyazibaz.db")

OPERATIONS = {
    "jam": ("جمع", "+", "🍎"),
    "taf": ("تفریق", "−", "🎈"),
    "zar": ("ضرب", "×", "⭐"),
    "tag": ("تقسیم", "÷", "🧁"),
}

ORDER = ("jam", "taf", "zar", "tag")

# ==========================================
# اعداد فارسی
# ==========================================

def fa(value):
    return str(value).translate(
        str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
    )

def parse_number(value):
    value = str(value or "").translate(
        str.maketrans(
            "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩",
            "01234567890123456789"
        )
    )
    try:
        return int(value)
    except (TypeError, ValueError):
        return None

# ==========================================
# DATABASE
# ==========================================

def get_db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with get_db() as db:

        db.execute("""
            CREATE TABLE IF NOT EXISTS students(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                grade INTEGER NOT NULL,
                created_at TEXT
            )
        """)

        db.execute("""
            CREATE TABLE IF NOT EXISTS progress(
                student_id INTEGER,
                operation TEXT,
                level INTEGER DEFAULT 1,
                attempts INTEGER DEFAULT 0,
                correct INTEGER DEFAULT 0,
                PRIMARY KEY(student_id, operation)
            )
        """)

        db.execute("""
            CREATE TABLE IF NOT EXISTS answers(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER,
                operation TEXT,
                question TEXT,
                answer INTEGER,
                user_answer TEXT,
                correct INTEGER,
                created_at TEXT
            )
        """)

        db.execute("""
            CREATE TABLE IF NOT EXISTS daily_tests(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER,
                operation TEXT,
                test_date TEXT,
                total INTEGER,
                correct INTEGER
            )
        """)

init_db()

# ==========================================
# DATABASE FUNCTIONS
# ==========================================

def get_student(sid):
    with get_db() as db:
        return db.execute(
            "SELECT * FROM students WHERE id=?",
            (sid,)
        ).fetchone()

def get_progress(sid, operation):
    with get_db() as db:

        db.execute("""
            INSERT OR IGNORE INTO progress
            (student_id, operation)
            VALUES (?,?)
        """, (sid, operation))

        return db.execute("""
            SELECT * FROM progress
            WHERE student_id=? AND operation=?
        """, (sid, operation)).fetchone()

def has_certificate(sid, operation):
    p = get_progress(sid, operation)

    with get_db() as db:
        row = db.execute("""
            SELECT COUNT(*) AS total,
                   COALESCE(SUM(correct),0) AS correct
            FROM answers
            WHERE student_id=? AND operation=?
        """, (sid, operation)).fetchone()

    total = row["total"]
    correct = row["correct"]

    percent = correct / total if total else 0

    return (
        p["level"] >= 5
        and total >= 20
        and percent >= 0.80
    )

# ==========================================
# قفل و باز شدن عملیات
# ==========================================

def is_unlocked(sid, operation):

    if operation == "jam":
        return True

    if operation == "taf":
        return has_certificate(sid, "jam")

    if operation in ("zar", "tag"):
        return (
            has_certificate(sid, "jam")
            and has_certificate(sid, "taf")
        )

    return False

def require_operation(sid, operation):

    if operation not in OPERATIONS:
        abort(404)

    if not is_unlocked(sid, operation):
        return False

    return True

# ==========================================
# SAVE ANSWER
# ==========================================

def save_answer(sid, operation, question, answer, user_answer):

    given = parse_number(user_answer)
    correct = given is not None and given == answer

    with get_db() as db:

        db.execute("""
            INSERT INTO answers
            (
                student_id,
                operation,
                question,
                answer,
                user_answer,
                correct,
                created_at
            )
            VALUES (?,?,?,?,?,?,?)
        """, (
            sid,
            operation,
            question,
            answer,
            str(user_answer),
            int(correct),
            datetime.now().isoformat()
        ))

        db.execute("""
            INSERT OR IGNORE INTO progress
            (student_id,operation)
            VALUES (?,?)
        """, (sid, operation))

        db.execute("""
            UPDATE progress
            SET attempts=attempts+1,
                correct=correct+?
            WHERE student_id=? AND operation=?
        """, (int(correct), sid, operation))

        p = db.execute("""
            SELECT * FROM progress
            WHERE student_id=? AND operation=?
        """, (sid, operation)).fetchone()

        if p["attempts"] >= 8 and p["level"] < 5:

            if p["correct"] / p["attempts"] >= 0.80:

                db.execute("""
                    UPDATE progress
                    SET level=level+1,
                        attempts=0,
                        correct=0
                    WHERE student_id=? AND operation=?
                """, (sid, operation))

            else:

                db.execute("""
                    UPDATE progress
                    SET attempts=0,
                        correct=0
                    WHERE student_id=? AND operation=?
                """, (sid, operation))

    return correct

# ==========================================
# QUESTION GENERATOR
# ==========================================

def generate_question(grade, level, operation):

    if operation == "jam":

        # دو مرحله اول جمع با حاصل حداکثر ۱۰
        if level <= 2:
            maximum_total = 10
        else:
            maximum_total = min(
                10 + (level - 2) * 5,
                20 if grade == 1 else 50
            )

        a = random.randint(0, maximum_total)
        b = random.randint(0, maximum_total - a)

        return f"{a} + {b}", a + b, a, b

    if operation == "taf":

        maximum = 10 if level <= 2 else min(
            10 + (level - 2) * 5,
            20 if grade == 1 else 50
        )

        a = random.randint(0, maximum)
        b = random.randint(0, a)

        return f"{a} − {b}", a - b, a, b

    if operation == "zar":

        limit = min(level + 4, 10)

        a = random.randint(1, limit)
        b = random.randint(1, limit)

        return f"{a} × {b}", a * b, a, b

    if operation == "tag":

        divisor = random.randint(1, min(level + 4, 10))
        answer = random.randint(1, min(level + 4, 10))
        dividend = divisor * answer

        return f"{dividend} ÷ {divisor}", answer, dividend, divisor

    raise ValueError("عملیات نامعتبر است")

# ==========================================
# TALLY
# ==========================================

def tally(number):

    if number == 0:
        return "۰"

    groups = []

    for _ in range(number // 5):
        groups.append("||||╱")

    remainder = number % 5

    if remainder:
        groups.append("|" * remainder)

    return "　".join(groups)

# ==========================================
# APPLE PICTURES
# ==========================================

def apple_html(number):

    if number <= 0:
        return '<span class="zero">هیچ سیبی نداریم</span>'

    return (
        '<span class="apples">'
        + " ".join(["🍎"] * number)
        + "</span>"
    )

# ==========================================
# VISUAL LEARNING
# ==========================================

def visual_html(a, b, operation, level):

    symbol = OPERATIONS[operation][1]

    if operation == "jam":

        # مرحله اول: فقط سیب
        if level <= 1:

            return f"""
            <div class="visual-group">

                <div class="visual-label">
                    سیب‌های اول
                </div>

                {apple_html(a)}

            </div>

            <div class="visual-symbol">＋</div>

            <div class="visual-group">

                <div class="visual-label">
                    سیب‌هایی که اضافه می‌کنیم
                </div>

                {apple_html(b)}

            </div>
            """

        # مرحله دوم: سیب همراه چوب‌خط
        if level == 2:

            return f"""
            <div class="visual-group">

                {apple_html(a)}

                <div class="tally-small">
                    {tally(a)}
                </div>

            </div>

            <div class="visual-symbol">＋</div>

            <div class="visual-group">

                {apple_html(b)}

                <div class="tally-small">
                    {tally(b)}
                </div>

            </div>
            """

        # مرحله سوم: فقط چوب‌خط
        if level == 3:

            return f"""
            <div class="tally">
                {tally(a)} ＋ {tally(b)}
            </div>
            """

        # مرحله چهارم و پنجم: اعداد
        return f"""
        <div class="big">
            {fa(a)} ＋ {fa(b)} = ؟
        </div>
        """

    if level <= 2:

        return f"""
        <div class="tally">
            {tally(a)} {symbol} {tally(b)}
        </div>
        """

    return f"""
    <div class="big">
        {fa(a)} {symbol} {fa(b)} = ؟
    </div>
    """

# ==========================================
# FOUR ANSWER CARDS
# ==========================================

def make_options(answer):

    options = {answer}

    offsets = [-2, -1, 1, 2, 3, -3, 4, -4]
    random.shuffle(offsets)

    for offset in offsets:

        candidate = answer + offset

        if candidate >= 0:
            options.add(candidate)

        if len(options) == 4:
            break

    while len(options) < 4:
        options.add(
            random.randint(0, max(10, answer + 5))
        )

    result = list(options)
    random.shuffle(result)

    return result

# ==========================================
# HTML TEMPLATE
# ==========================================

HTML = """
<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1">

<title>{{ title }}</title>

<style>

@import url(
'https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;700;800&display=swap'
);

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #fff8e9;
    color: #34334c;
    font-family: Vazirmatn, Tahoma, sans-serif;
}

header {
    background: linear-gradient(120deg,#7055d8,#46a4e5);
    color: white;
    padding: 16px;
    text-align: center;
}

header a {
    color: white;
    text-decoration: none;
    margin: 8px;
}

.container {
    max-width: 900px;
    margin: auto;
    padding: 15px;
}

.card {
    background: white;
    padding: 22px;
    margin: 15px 0;
    border-radius: 22px;
    box-shadow: 0 5px 20px #00000010;
}

.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(145px,1fr));
    gap: 14px;
}

.btn {
    display: inline-block;
    background: #7055d8;
    color: white;
    padding: 12px 19px;
    border: 0;
    border-radius: 13px;
    text-decoration: none;
    cursor: pointer;
    font-family: inherit;
    margin: 4px;
    font-size: 16px;
}

.green { background: #20a879; }
.red { background: #dc5264; }
.orange { background: #ed9638; }

.light {
    background: #eeeaff;
    color: #5140a0;
}

.tile {
    background: #f0ecff;
    padding: 22px 12px;
    border-radius: 18px;
    text-align: center;
    text-decoration: none;
    color: #5140a0;
    font-size: 21px;
    font-weight: 800;
    display: block;
}

.tile small {
    display: block;
    font-size: 13px;
    margin-top: 8px;
}

.locked {
    background: #eeeeF2;
    color: #999;
    cursor: not-allowed;
}

.big {
    font-size: 36px;
    text-align: center;
    color: #7055d8;
    font-weight: 800;
    margin: 22px;
}

.tally {
    background: #fff2df;
    color: #df8134;
    padding: 18px;
    border-radius: 15px;
    text-align: center;
    font-size: 28px;
    line-height: 2;
    overflow-wrap: anywhere;
}

.tally-small {
    font-size: 20px;
    color: #d98236;
    margin-top: 7px;
}

.success {
    background: #eafff3;
    padding: 15px;
    border-radius: 12px;
    margin: 12px 0;
}

.error {
    background: #fff0f0;
    padding: 15px;
    border-radius: 12px;
    margin: 12px 0;
}

input, select {
    width: 100%;
    padding: 13px;
    border: 2px solid #e2dcf3;
    border-radius: 12px;
    margin: 10px 0 18px;
    font-family: inherit;
    font-size: 17px;
}

.visual-group {
    text-align: center;
    background: #fff9ed;
    border: 2px dashed #f0d49e;
    border-radius: 18px;
    padding: 15px;
    margin: 8px auto;
    max-width: 560px;
}

.visual-label {
    font-weight: 700;
    margin-bottom: 8px;
    color: #87602d;
}

.apples {
    font-size: clamp(28px,7vw,48px);
    line-height: 1.7;
    overflow-wrap: anywhere;
}

.visual-symbol {
    text-align: center;
    font-size: 34px;
    color: #7055d8;
    font-weight: bold;
}

.zero {
    font-size: 18px;
    color: #777;
}

.answer-grid {
    display: grid;
    grid-template-columns: repeat(2,minmax(0,1fr));
    gap: 13px;
    margin: 18px 0;
}

.answer-card {
    position: relative;
    display: block;
    cursor: pointer;
}

.answer-card input {
    position: absolute;
    opacity: 0;
    width: 1px;
}

.answer-card span {
    display: block;
    background: #f0ecff;
    border: 3px solid #e0d8ff;
    border-radius: 18px;
    text-align: center;
    padding: 18px 8px;
    font-size: 30px;
    font-weight: 800;
    color: #5140a0;
    min-height: 78px;
}

.answer-card input:checked + span {
    background: #dff9eb;
    border-color: #20a879;
    color: #14774f;
}

.answer-card span:active {
    transform: scale(.98);
}

.progress {
    background: #eee;
    height: 14px;
    border-radius: 20px;
    overflow: hidden;
}

.progress div {
    background: #20a879;
    height: 100%;
}

footer {
    text-align: center;
    padding: 20px;
    color: #888;
}

@media(max-width:600px) {

    .big {
        font-size: 29px;
    }

    .card {
        padding: 15px;
    }

    .answer-card span {
        font-size: 26px;
        padding: 15px 5px;
    }

}

@media print {

    header, footer, .no-print {
        display: none;
    }

}

</style>

</head>

<body>

<header>

<h2>🌈 ریاضی‌باز</h2>

<p>یاد می‌گیریم، بازی می‌کنیم!</p>

<a href="/">خانه</a>

<a href="/students">دانش‌آموزان</a>

</header>

<div class="container">

{{ content|safe }}

</div>

<footer>
ریاضی‌باز - آموزش شیرین ریاضی
</footer>

</body>
</html>
"""

def render_page(content, title="ریاضی‌باز"):

    return render_template_string(
        HTML,
        content=content,
        title=title
    )

# ==========================================
# HOME
# ==========================================

@app.route("/")
def home():

    content = """
    <div class="card">

        <h1>🎉 سلام قهرمان ریاضی!</h1>

        <p>به سرزمین عددها خوش آمدی.</p>

        <p>
        اول آموزش می‌بینیم، بعد تمرین می‌کنیم
        و در پایان آزمون می‌دهیم.
        </p>

        <a class="btn green" href="/students">
            شروع بازی
        </a>

    </div>

    <div class="grid">

        <div class="card">
            <h3>🍎 آموزش تصویری</h3>
            <p>یادگیری با سیب و چوب‌خط</p>
        </div>

        <div class="card">
            <h3>🎴 چهار کارت پاسخ</h3>
            <p>انتخاب جواب با لمس کارت‌ها</p>
        </div>

        <div class="card">
            <h3>🏆 گواهینامه</h3>
            <p>باز شدن مرحله بعد پس از یادگیری</p>
        </div>

    </div>
    """

    return render_page(content)

# ==========================================
# STUDENTS
# ==========================================

@app.route("/students")
def students():

    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM students ORDER BY name"
        ).fetchall()

    content = """
    <div class="card">

        <h1>👧🧒 دانش‌آموزان</h1>

        <a class="btn green" href="/new">
            ثبت دانش‌آموز جدید
        </a>

    </div>
    """

    for s in rows:

        content += f"""
        <div class="card">

            <h3>
                🌟 {html.escape(s['name'])}
                - کلاس {fa(s['grade'])}
            </h3>

            <a class="btn" href="/student/{s['id']}">
                ورود به بازی
            </a>

            <a class="btn light" href="/edit/{s['id']}">
                ویرایش
            </a>

            <form method="post"
            action="/delete/{s['id']}"
            style="display:inline"
            onsubmit="return confirm('حذف شود؟')">

                <button class="btn red">
                    حذف
                </button>

            </form>

        </div>
        """

    return render_page(content)

# ==========================================
# NEW STUDENT
# ==========================================

@app.route("/new", methods=["GET", "POST"])
def new_student():

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        grade = parse_number(request.form.get("grade"))

        if name and grade in (1, 2):

            with get_db() as db:

                db.execute("""
                    INSERT INTO students
                    (name,grade,created_at)
                    VALUES (?,?,?)
                """, (
                    name,
                    grade,
                    datetime.now().isoformat()
                ))

            return redirect("/students")

    content = """
    <div class="card">

        <h1>🌻 دانش‌آموز جدید</h1>

        <form method="post">

            <label>نام دانش‌آموز</label>

            <input name="name" required maxlength="80">

            <label>کلاس چندم هستی؟</label>

            <select name="grade">

                <option value="1">اول ابتدایی</option>

                <option value="2">دوم ابتدایی</option>

            </select>

            <button class="btn green">
                ذخیره
            </button>

        </form>

    </div>
    """

    return render_page(content)

# ==========================================
# EDIT STUDENT
# ==========================================

@app.route("/edit/<int:sid>", methods=["GET", "POST"])
def edit_student(sid):

    s = get_student(sid)

    if not s:
        abort(404)

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        grade = parse_number(request.form.get("grade"))

        if name and grade in (1, 2):

            with get_db() as db:

                db.execute("""
                    UPDATE students
                    SET name=?, grade=?
                    WHERE id=?
                """, (name, grade, sid))

            return redirect("/students")

    content = f"""
    <div class="card">

        <h1>ویرایش دانش‌آموز</h1>

        <form method="post">

            <label>نام</label>

            <input name="name"
            value="{html.escape(s['name'], quote=True)}"
            required>

            <label>کلاس</label>

            <select name="grade">

                <option value="1"
                {'selected' if s['grade']==1 else ''}>
                    اول
                </option>

                <option value="2"
                {'selected' if s['grade']==2 else ''}>
                    دوم
                </option>

            </select>

            <button class="btn green">
                ذخیره تغییرات
            </button>

        </form>

    </div>
    """

    return render_page(content)

# ==========================================
# DELETE STUDENT
# ==========================================

@app.route("/delete/<int:sid>", methods=["POST"])
def delete_student(sid):

    with get_db() as db:

        for table in ("answers", "progress", "daily_tests"):

            db.execute(
                f"DELETE FROM {table} WHERE student_id=?",
                (sid,)
            )

        db.execute(
            "DELETE FROM students WHERE id=?",
            (sid,)
        )

    return redirect("/students")

# ==========================================
# STUDENT HOME
# ==========================================

@app.route("/student/<int:sid>")
def student_home(sid):

    s = get_student(sid)

    if not s:
        abort(404)

    content = f"""
    <div class="card">

        <h1>
            سلام {html.escape(s['name'])} جان! 👋
        </h1>

        <p>کلاس {fa(s['grade'])} ابتدایی</p>

        <h3>کدام مرحله را ادامه می‌دهی؟</h3>

        <p>
        برای رفتن به مرحله بعد، اول گواهینامه
        مرحله قبلی را بگیر.
        </p>

    </div>

    <div class="grid">
    """

    for op in ORDER:

        title, symbol, emoji = OPERATIONS[op]

        p = get_progress(sid, op)
        unlocked = is_unlocked(sid, op)

        if unlocked:

            content += f"""
            <a class="tile" href="/learn/{sid}/{op}">

                {emoji}<br>

                {title}

                <small>
                    مرحله {fa(p['level'])} از ۵
                </small>

            </a>
            """

        else:

            needed = (
                "گواهینامه جمع"
                if op == "taf"
                else "گواهینامه جمع و تفریق"
            )

            content += f"""
            <div class="tile locked">

                🔒<br>

                {title}

                <small>
                    پس از دریافت {needed} باز می‌شود
                </small>

            </div>
            """

    content += f"""
    </div>

    <div class="card">

        <a class="btn green" href="/report/{sid}">
            📊 کارنامه و پیشرفت
        </a>

    </div>
    """

    return render_page(content)

# ==========================================
# LEARNING
# ==========================================

@app.route("/learn/<int:sid>/<op>")
def learn(sid, op):

    s = get_student(sid)

    if not s:
        abort(404)

    if not require_operation(sid, op):
        return redirect(url_for("student_home", sid=sid))

    p = get_progress(sid, op)

    if op == "jam":

        title = "جمع یعنی چیزها را کنار هم بگذاریم."

        a, b = 2, 3

        explanation = (
            "۲ سیب داریم و ۳ سیب دیگر به آن اضافه می‌کنیم. "
            "حالا همه سیب‌ها را با هم می‌شماریم."
        )

    elif op == "taf":

        title = "تفریق یعنی تعدادی را از یک مجموعه برداریم."

        a, b = 5, 2

        explanation = (
            "۵ بادکنک داریم و ۲ بادکنک را کنار می‌گذاریم. "
            "چند بادکنک می‌ماند؟"
        )

    elif op == "zar":

        title = "ضرب یعنی چند گروه مساوی داشته باشیم."

        a, b = 3, 2

        explanation = "۳ گروه داریم که در هر گروه ۲ مهره است."

    else:

        title = "تقسیم یعنی تعداد را به طور مساوی پخش کنیم."

        a, b = 6, 2

        explanation = "۶ شیرینی را بین ۲ کودک تقسیم می‌کنیم."

    symbol = OPERATIONS[op][1]

    result = {
        "jam": a+b,
        "taf": a-b,
        "zar": a*b,
        "tag": a//b
    }[op]

    visual = visual_html(a, b, op, p["level"])

    content = f"""
    <div class="card">

        <h1>📚 آموزش {OPERATIONS[op][0]}</h1>

        <h2>{title}</h2>

        <p>{explanation}</p>

        {visual}

        <div class="success"
        style="text-align:center;font-size:25px">

            {fa(a)} {symbol} {fa(b)} = {fa(result)}

        </div>

        <p>
            آفرین! حالا یک تمرین را با هم انجام می‌دهیم.
        </p>

        <a class="btn green"
        href="/guided/{sid}/{op}">

            تمرین با راهنما

        </a>

    </div>
    """

    return render_page(content)

# ==========================================
# GUIDED PRACTICE
# ==========================================

@app.route("/guided/<int:sid>/<op>")
def guided(sid, op):

    s = get_student(sid)

    if not s:
        abort(404)

    if not require_operation(sid, op):
        return redirect(url_for("student_home", sid=sid))

    p = get_progress(sid, op)

    q, answer, a, b = generate_question(
        s["grade"],
        p["level"],
        op
    )

    visual = visual_html(a, b, op, p["level"])

    hints = {
        "jam": (
            f"اول {fa(a)} تا را بشمار، "
            f"بعد {fa(b)} تا دیگر اضافه کن."
        ),

        "taf": (
            f"{fa(a)} تا را در نظر بگیر "
            f"و {fa(b)} تا از آن کم کن."
        ),

        "zar": (
            f"{fa(a)} گروه بساز و در هر گروه "
            f"{fa(b)} تا قرار بده."
        ),

        "tag": (
            f"{fa(a)} تا را بین {fa(b)} "
            f"گروه مساوی پخش کن."
        )
    }

    content = f"""
    <div class="card">

        <h1>🧩 تمرین با راهنما</h1>

        <div class="big">
            {fa(q)} = ؟
        </div>

        {visual}

        <p>{hints[op]}</p>

        <details>

            <summary>دیدن پاسخ</summary>

            <h2>{fa(answer)}</h2>

        </details>

        <a class="btn green"
        href="/quiz/{sid}/{op}">

            حالا خودم جواب می‌دهم

        </a>

    </div>
    """

    return render_page(content)

# ==========================================
# QUIZ
# ==========================================

@app.route("/quiz/<int:sid>/<op>", methods=["GET", "POST"])
def quiz(sid, op):

    s = get_student(sid)

    if not s:
        abort(404)

    if not require_operation(sid, op):
        return redirect(url_for("student_home", sid=sid))

    if request.method == "POST":

        expected = session.get("quiz_expected")
        question = session.get("quiz_question")

        given = request.form.get("answer", "")

        if expected is None or question is None:
            return redirect(request.path)

        correct = save_answer(
            sid,
            op,
            question,
            int(expected),
            given
        )

        session["quiz_feedback"] = {
            "correct": correct,
            "answer": int(expected)
        }

        session.pop("quiz_expected", None)
        session.pop("quiz_question", None)

        return redirect(request.path)

    feedback = session.pop("quiz_feedback", None)

    p = get_progress(sid, op)

    q, answer, a, b = generate_question(
        s["grade"],
        p["level"],
        op
    )

    options = make_options(answer)

    session["quiz_expected"] = answer
    session["quiz_question"] = q

    message = ""

    if feedback:

        if feedback["correct"]:

            message = """
            <div class="success">
                آفرین قهرمان! پاسخ درست بود ⭐
            </div>
            """

        else:

            message = f"""
            <div class="error">
                اشکالی ندارد! پاسخ درست
                {fa(feedback['answer'])} بود.
                با هم دوباره تمرین می‌کنیم.
            </div>
            """

    visual = visual_html(a, b, op, p["level"])

    cards = '<div class="answer-grid">'

    for option in options:

        cards += f"""
        <label class="answer-card">

            <input
                type="radio"
                name="answer"
                value="{option}"
                required
            >

            <span>{fa(option)}</span>

        </label>
        """

    cards += "</div>"

    content = f"""
    <div class="card">

        <h1>🎯 نوبت توست!</h1>

        {message}

        <div class="big">
            {fa(q)} = ؟
        </div>

        {visual}

        <p style="text-align:center;font-weight:bold">
            جواب درست را از بین چهار کارت انتخاب کن:
        </p>

        <form method="post">

            {cards}

            <button class="btn green" style="width:100%">
                ثبت جواب
            </button>

        </form>

        <a class="btn light" href="/learn/{sid}/{op}">
            آموزش دوباره
        </a>

    </div>
    """

    return render_page(content)

# ==========================================
# DAILY TEST
# ==========================================

@app.route("/daily/<int:sid>/<op>", methods=["GET", "POST"])
def daily(sid, op):

    s = get_student(sid)

    if not s:
        abort(404)

    if not require_operation(sid, op):
        return redirect(url_for("student_home", sid=sid))

    if request.method == "POST":

        questions = session.get("daily_questions", [])

        score = 0

        with get_db() as db:

            for i, item in enumerate(questions):

                question, answer, options = item

                given = request.form.get(f"a{i}", "")

                good = parse_number(given) == answer

                score += int(good)

                db.execute("""
                    INSERT INTO answers
                    (
                        student_id,
                        operation,
                        question,
                        answer,
                        user_answer,
                        correct,
                        created_at
                    )
                    VALUES (?,?,?,?,?,?,?)
                """, (
                    sid,
                    op,
                    question,
                    answer,
                    str(given),
                    int(good),
                    datetime.now().isoformat()
                ))

            db.execute("""
                INSERT INTO daily_tests
                (student_id,operation,test_date,total,correct)
                VALUES (?,?,?,?,?)
            """, (
                sid,
                op,
                date.today().isoformat(),
                len(questions),
                score
            ))

        session.pop("daily_questions", None)

        content = f"""
        <div class="card">

            <h1>🏆 نتیجه آزمون</h1>

            <div class="big">
                {fa(score)} از {fa(len(questions))}
            </div>

            <p>
                {
                    'آفرین! عالی بود.'
                    if score >= 8
                    else 'تلاش خوبی کردی. دوباره تمرین کن.'
                }
            </p>

            <a class="btn green" href="/report/{sid}">
                کارنامه
            </a>

        </div>
        """

        return render_page(content)

    p = get_progress(sid, op)

    questions = []

    for _ in range(10):

        q, answer, a, b = generate_question(
            s["grade"],
            p["level"],
            op
        )

        questions.append(
            (q, answer, make_options(answer))
        )

    session["daily_questions"] = questions

    content = """
    <div class="card">

        <h1>📝 آزمون روزانه</h1>

        <p>
            ۱۰ سؤال؛ برای هر سؤال یکی از چهار کارت را انتخاب کن.
        </p>

        <form method="post">
    """

    for i, (q, answer, options) in enumerate(questions):

        content += f"""
        <div class="card">

            <h3>
                {fa(i+1)}.
                {fa(q)} = ؟
            </h3>

            <div class="answer-grid">
        """

        for option in options:

            content += f"""
            <label class="answer-card">

                <input
                    type="radio"
                    name="a{i}"
                    value="{option}"
                    required
                >

                <span>{fa(option)}</span>

            </label>
            """

        content += """
            </div>
        </div>
        """

    content += """
            <button class="btn green" style="width:100%">
                پایان آزمون
            </button>

        </form>

    </div>
    """

    return render_page(content)

# ==========================================
# REPORT
# ==========================================

@app.route("/report/<int:sid>")
def report(sid):

    s = get_student(sid)

    if not s:
        abort(404)

    content = f"""
    <div class="card">

        <h1>
            📊 کارنامه {html.escape(s['name'])}
        </h1>

        کلاس {fa(s['grade'])} ابتدایی

    </div>
    """

    for op in ORDER:

        info = OPERATIONS[op]

        p = get_progress(sid, op)

        with get_db() as db:

            row = db.execute("""
                SELECT
                    COUNT(*) AS total,
                    COALESCE(SUM(correct),0) AS correct
                FROM answers
                WHERE student_id=? AND operation=?
            """, (sid, op)).fetchone()

        total = row["total"]
        correct = row["correct"]

        percent = (
            int(correct * 100 / total)
            if total else 0
        )

        mastered = has_certificate(sid, op)
        unlocked = is_unlocked(sid, op)

        if not unlocked:
            status = "🔒 هنوز قفل است"

        elif mastered:
            status = "🏆 آماده دریافت گواهینامه"

        else:
            status = "در حال یادگیری"

        content += f"""
        <div class="card">

            <h3>{info[2]} {info[0]}</h3>

            <p>وضعیت: {status}</p>

            <p>
                مرحله {fa(p['level'])} از ۵
            </p>

            <p>
                پاسخ درست: {fa(correct)} از {fa(total)}
                ({fa(percent)}٪)
            </p>

            <div class="progress">

                <div style="width:{percent}%"></div>

            </div>

            <br>
        """

        if unlocked:

            content += f"""
            <a class="btn" href="/learn/{sid}/{op}">
                ادامه آموزش
            </a>

            <a class="btn orange" href="/daily/{sid}/{op}">
                آزمون روزانه
            </a>
            """

            if mastered:

                content += f"""
                <a class="btn green"
                href="/certificate/{sid}/{op}">
                    دریافت گواهینامه
                </a>
                """

        content += "</div>"

    return render_page(content)

# ==========================================
# CERTIFICATE
# ==========================================

@app.route("/certificate/<int:sid>/<op>")
def certificate(sid, op):

    s = get_student(sid)

    if not s or op not in OPERATIONS:
        abort(404)

    if not is_unlocked(sid, op) or not has_certificate(sid, op):
        return redirect(url_for("report", sid=sid))

    content = f"""
    <div class="card"
    style="text-align:center;border:6px double #d7ad45;padding:40px">

        <div style="font-size:55px">
            🏆🎓🌟
        </div>

        <h1>گواهینامه ریاضی‌باز</h1>

        <h2>
            آفرین به {html.escape(s['name'])} عزیز!
        </h2>

        <p>
            برای یادگیری مهارت {OPERATIONS[op][0]}
        </p>

        <p>
            کلاس {fa(s['grade'])} ابتدایی
        </p>

        <p>
            {fa(date.today().strftime('%Y/%m/%d'))}
        </p>

        <button class="btn no-print"
        onclick="window.print()">

            چاپ گواهینامه

        </button>

        <br>

        <a class="btn green no-print"
        href="/student/{sid}">

            بازگشت به بازی

        </a>

    </div>
    """

    return render_page(content)

# ==========================================
# RUN
# ==========================================

if __name__ == "__main__":

    print("=" * 40)

    print("ریاضی‌باز اجرا شد")

    print("http://127.0.0.1:5003")

    print("=" * 40)

    app.run(
        host="0.0.0.0",
        port=5003,
        debug=True
    )