# Khayati Central Android

A Gradle Android application which embeds the existing Flask/Python tailoring app using Chaquopy. The designated Android phone runs the local web server and holds the SQLite database. Other authorized devices use a browser to connect to that phone over Wi-Fi or a private VPN.

See `README_ANDROID_FA.txt` for Persian setup instructions.

## Build

This is an Android source project, not a prebuilt APK. It is intended for AndroidForge / GitHub Actions. The Gradle project root is this directory (`settings.gradle`, `build.gradle`, `app/`).
