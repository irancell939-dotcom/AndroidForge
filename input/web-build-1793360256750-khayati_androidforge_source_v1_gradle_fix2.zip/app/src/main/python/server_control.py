# -*- coding: utf-8 -*-
"""Starts the shared Flask application as a local-network server on Android."""
import os
import threading
from pathlib import Path

_started = False
_lock = threading.Lock()


def start(data_dir: str, web_dir: str):
    global _started
    with _lock:
        if _started:
            return "already-started"
        data_path = Path(data_dir)
        web_path = Path(web_dir)
        data_path.mkdir(parents=True, exist_ok=True)
        os.environ["KHAYATI_DATA_DIR"] = str(data_path)
        os.environ["KHAYATI_WEB_DIR"] = str(web_path)
        os.environ["KHAYATI_ANDROID"] = "1"

        from werkzeug.serving import make_server
        from app import app

        def serve():
            status_file = data_path / "server_status.txt"
            try:
                server = make_server("0.0.0.0", 5000, app, threaded=True)
                status_file.write_text("ready", encoding="utf-8")
                server.serve_forever()
            except Exception as exc:
                status_file.write_text("error: " + repr(exc), encoding="utf-8")
                raise

        worker = threading.Thread(target=serve, name="KhayatiHTTPServer", daemon=True)
        worker.start()
        _started = True
        return "starting"
