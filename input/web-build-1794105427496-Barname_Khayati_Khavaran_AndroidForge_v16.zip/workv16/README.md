LATEST ANDROID REVISION: 1.8.0 (versionCode 18)
Print change: Notes 1, 2, and 3 replace the former extra fields in the print details list.

Khavaran Soft - AndroidForge project source

This ZIP contains the Android project source, not a prebuilt APK. Upload it to AndroidForge and choose Debug.

Features in this revision:
- Black left-side slide-out navigation drawer; Khavaran Soft branding.
- Code 128 barcode on the A5 measurement sheet.
- Ready-for-delivery page with camera scanning or manual customer selection.
- SMS draft opened in the phone's messaging app.
- Marking an item as delivered removes it from the ready list.
- Custom background color and per-combo-box option management.
- Android camera permission requested only when the scanner is started.
- Android ID is used as the device binding for the signed activation license.

Build: upload the ZIP to AndroidForge; root must include settings.gradle and build.gradle. Build Variant: Debug.

Run only on the central phone. Other phones and computers access the central phone through the same Wi-Fi browser address shown in the app.


نسخه تکمیلی: افزایش فونت اعداد اندازه اصلی و جابه‌جایی جای عدد و عنوان، فیلد بازو پس از زیر بغل، امکان نوشتن مقدار دلخواه در فیلدهای دارای گزینه، پیام عید تکی برای هر مشتری، حذف راهنمای نمونه کد رجیستر، عنوان لاتین KHAVARAN SOFT و اصلاح اندازه تصاویر و رسید چاپ.
