package com.aamal.roozaneh;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONObject;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    public static final String CHANNEL_BASE = "aamal_prayer_v4";
    public static String CHANNEL_ID = "aamal_prayer_v4_soft";
    private static final int NOTIF_REQ = 1001;
    private static final int RINGTONE_REQ = 2002;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createNotificationChannel();
        requestNotifPermission();
        requestIgnoreBatteryOptimizations();
        requestExactAlarmPermission();

        scheduleNightReminder();
        restorePrayerAlarms(this);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new WebAppInterface(this), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    public void recreateNotificationChannel() { createNotificationChannel(); }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm == null) return;

            // Delete old channels so sound settings apply
            try { nm.deleteNotificationChannel("aamal_daily"); } catch (Exception ignored) {}
            try { nm.deleteNotificationChannel("aamal_prayer"); } catch (Exception ignored) {}

            SharedPreferences spCh = getSharedPreferences("aamal", MODE_PRIVATE);
            String sid = spCh.getString("notif_sound_id", "soft");
            CHANNEL_ID = CHANNEL_BASE + "_" + sid;
            // remove previous variants lightly
            try {
                for (String x : new String[]{"soft","triple","rise","calm","system","custom"}) {
                    nm.deleteNotificationChannel(CHANNEL_BASE + "_" + x);
                }
            } catch (Exception ignored) {}
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "اعلان نماز (قفل صفحه)", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("حتی با صفحه خاموش و برنامه بسته");
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 400, 200, 400, 200, 400});
            channel.setShowBadge(true);
            channel.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
            channel.setBypassDnd(true);
            channel.enableLights(true);

            Uri sound = getSavedSoundUri();
            if (sound != null) {
                AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
                channel.setSound(sound, attrs);
            } else {
                Uri def = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (def == null) def = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
                channel.setSound(def, attrs);
            }
            nm.createNotificationChannel(channel);
        }
    }

    private Uri getSavedSoundUri() {
        return resolveSoundUri(this);
    }

    public static Uri resolveSoundUri(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("aamal", MODE_PRIVATE);
        String id = sp.getString("notif_sound_id", "soft");
        int resId = 0;
        if ("soft".equals(id)) resId = R.raw.tone_soft;
        else if ("triple".equals(id)) resId = R.raw.tone_triple;
        else if ("rise".equals(id)) resId = R.raw.tone_rise;
        else if ("calm".equals(id)) resId = R.raw.tone_calm;
        else if ("system".equals(id)) {
            return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        } else if ("custom".equals(id)) {
            String s = sp.getString("notif_sound", null);
            if (s != null && s.length() > 0) {
                try { return Uri.parse(s); } catch (Exception e) { return null; }
            }
        }
        if (resId != 0) {
            return Uri.parse("android.resource://" + ctx.getPackageName() + "/" + resId);
        }
        return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
    }

    public static String getSpeakPhrase(Context ctx, String type, String prayerKey) {
        SharedPreferences sp = ctx.getSharedPreferences("aamal", MODE_PRIVATE);
        String phrase = sp.getString("notif_phrase", "auto");
        String name = prayerKeyToName(prayerKey);
        if ("hayya".equals(phrase)) return "حي على الصلاة. حي على الفلاح. " + ("before".equals(type) ? "پانزده دقیقه تا نماز " + name : "نماز " + name + " را خواندید؟");
        if ("allahuakbar".equals(phrase)) return "الله اکبر. الله اکبر. " + ("before".equals(type) ? "وقت نماز " + name + " نزدیک است" : "آیا نماز " + name + " را خواندید؟");
        if ("waqt".equals(phrase)) return "before".equals(type) ? "وقت نماز " + name + " نزدیک شده است. آماده شوید." : "نیم ساعت از نماز " + name + " گذشته. آیا خواندید؟";
        // auto
        if ("before".equals(type)) return "پانزده دقیقه تا نماز " + name + " باقی مانده است. وضو بگیرید و آماده شوید.";
        if ("after".equals(type)) {
            if ("test".equals(prayerKey)) return "این یک اعلان آزمایشی است. اگر این صدا را می‌شنوید، اعلان‌ها درست کار می‌کنند.";
            return "نیم ساعت از وقت نماز " + name + " گذشته است. آیا نمازتان را خواندید؟";
        }
        return "امروزت چگونه گذشت؟ کارنامه اعمالت را تکمیل کن";
    }

    private static String prayerKeyToName(String key) {
        if (key == null) return "بعدی";
        switch (key) {
            case "fajr": return "صبح";
            case "zuhr": return "ظهر";
            case "asr": return "عصر";
            case "maghrib": return "مغرب";
            case "isha": return "عشاء";
            default: return "بعدی";
        }
    }

    private void requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQ);
            }
        }
    }

    private void requestIgnoreBatteryOptimizations() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void requestExactAlarmPermission() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
                if (am != null && !am.canScheduleExactAlarms()) {
                    Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void scheduleNightReminder() {
        scheduleAlarm(this, 21, 0, 9000, "night", "night",
            "امروزت چگونه گذشت؟ کارنامه اعمالت را تکمیل کن");
    }

    public static void scheduleAlarm(Context ctx, int hour, int minute, int reqCode,
                                     String type, String prayerKey, String message) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            Intent intent = new Intent(ctx, NotificationReceiver.class);
            intent.setAction("com.aamal.roozaneh.ALARM");
            intent.putExtra("type", type);
            intent.putExtra("prayerKey", prayerKey != null ? prayerKey : "");
            intent.putExtra("message", message);
            intent.putExtra("reqCode", reqCode);
            intent.putExtra("hour", hour);
            intent.putExtra("minute", minute);

            PendingIntent pi = PendingIntent.getBroadcast(ctx, reqCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, hour);
            cal.set(Calendar.MINUTE, minute);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            long trigger = cal.getTimeInMillis();
            if (trigger <= System.currentTimeMillis() + 3000) {
                cal.add(Calendar.DAY_OF_YEAR, 1);
                trigger = cal.getTimeInMillis();
            }

            // Primary: AlarmClock (survives Doze, shows in status bar)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                Intent show = new Intent(ctx, MainActivity.class);
                show.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                PendingIntent showPi = PendingIntent.getActivity(ctx, reqCode + 5000, show,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                AlarmManager.AlarmClockInfo info = new AlarmManager.AlarmClockInfo(trigger, showPi);
                am.setAlarmClock(info, pi);
            }

            // Backup: exact while idle with different request code (some OEMs kill one path)
            try {
                Intent intent2 = new Intent(ctx, NotificationReceiver.class);
                intent2.setAction("com.aamal.roozaneh.ALARM");
                intent2.putExtra("type", type);
                intent2.putExtra("prayerKey", prayerKey != null ? prayerKey : "");
                intent2.putExtra("message", message);
                intent2.putExtra("reqCode", reqCode);
                intent2.putExtra("hour", hour);
                intent2.putExtra("minute", minute);
                intent2.putExtra("backup", true);
                PendingIntent pi2 = PendingIntent.getBroadcast(ctx, reqCode + 7000, intent2,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi2);
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, trigger, pi2);
                }
            } catch (SecurityException se) {
                // Exact not permitted — AlarmClock path still active
            } catch (Exception ignored) {}
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void scheduleInMinutes(Context ctx, int minutes, int reqCode,
                                         String type, String prayerKey, String message) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            Intent intent = new Intent(ctx, NotificationReceiver.class);
            intent.setAction("com.aamal.roozaneh.ALARM");
            intent.putExtra("type", type);
            intent.putExtra("prayerKey", prayerKey != null ? prayerKey : "");
            intent.putExtra("message", message);
            intent.putExtra("reqCode", reqCode);
            intent.putExtra("hour", -1);
            intent.putExtra("minute", -1);

            PendingIntent pi = PendingIntent.getBroadcast(ctx, reqCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            long trigger = System.currentTimeMillis() + minutes * 60L * 1000L;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                Intent show = new Intent(ctx, MainActivity.class);
                PendingIntent showPi = PendingIntent.getActivity(ctx, reqCode + 5000, show,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(trigger, showPi), pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, trigger, pi);
            }
            try {
                PendingIntent pi2 = PendingIntent.getBroadcast(ctx, reqCode + 7000, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi2);
                }
            } catch (Exception ignored) {}
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void restorePrayerAlarms(Context ctx) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("aamal", Context.MODE_PRIVATE);
            String json = sp.getString("prayer_times", null);
            if (json == null || json.length() < 5) return;

            JSONObject obj = new JSONObject(json);
            String[] keys = {"fajr", "zuhr", "asr", "maghrib", "isha"};
            String[] names = {"صبح", "ظهر", "عصر", "مغرب", "عشاء"};

            for (int i = 0; i < keys.length; i++) {
                if (!obj.has(keys[i])) continue;
                String time = obj.optString(keys[i], "");
                if (time.length() < 3) continue;
                String[] parts = time.split(":");
                if (parts.length < 2) continue;
                int h, m;
                try {
                    h = Integer.parseInt(parts[0].trim());
                    m = Integer.parseInt(parts[1].trim());
                } catch (NumberFormatException e) { continue; }
                if (h < 0 || h > 23 || m < 0 || m > 59) continue;

                int bM = m - 15, bH = h;
                if (bM < 0) { bM += 60; bH -= 1; if (bH < 0) bH = 23; }
                scheduleAlarm(ctx, bH, bM, 1000 + i, "before", keys[i],
                    "۱۵ دقیقه تا نماز " + names[i] + " — وضو بگیر و آماده شو");

                int aM = m + 30, aH = h;
                if (aM >= 60) { aM -= 60; aH += 1; if (aH > 23) aH = 0; }
                scheduleAlarm(ctx, aH, aM, 2000 + i, "after", keys[i],
                    "نیم‌ساعت از وقت نماز " + names[i] + " گذشته — وضعیت را مشخص کنید");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RINGTONE_REQ && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            SharedPreferences sp = getSharedPreferences("aamal", MODE_PRIVATE);
            if (uri != null) {
                sp.edit().putString("notif_sound", uri.toString()).putString("notif_sound_id", "custom").apply();
            } else {
                sp.edit().remove("notif_sound").putString("notif_sound_id", "system").apply();
            }
            // Recreate channel with new sound
            createNotificationChannel();
            if (webView != null) {
                webView.post(() -> webView.evaluateJavascript(
                    "showToast('آهنگ اعلان ذخیره شد ✓')", null));
            }
        }
    }

    public class WebAppInterface {
        Context ctx;
        WebAppInterface(Context c) { ctx = c; }

        @JavascriptInterface
        public void savePrayerTimes(String json) {
            try {
                SharedPreferences sp = ctx.getSharedPreferences("aamal", MODE_PRIVATE);
                sp.edit().putString("prayer_times", json)
                    .putLong("times_saved_at", System.currentTimeMillis())
                    .apply();
                restorePrayerAlarms(ctx);
            } catch (Exception e) { e.printStackTrace(); }
        }

        @JavascriptInterface
        public void testNotification() {
            // 1 minute test with unique request code
            scheduleInMinutes(ctx, 1, 9999, "after", "test",
                "اعلان آزمایشی — اگر صدا و اعلان را دیدید سیستم درست کار می‌کند");
            // Also try immediate backup after 5s is not needed; user closes app
        }

        @JavascriptInterface
        public void pickNotificationSound() {
            runOnUiThread(() -> {
                Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL);
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "آهنگ اعلان نماز را انتخاب کنید");
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
                SharedPreferences sp = getSharedPreferences("aamal", MODE_PRIVATE);
                String cur = sp.getString("notif_sound", null);
                if (cur != null) {
                    intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(cur));
                }
                startActivityForResult(intent, RINGTONE_REQ);
            });
        }

        @JavascriptInterface
        public void setNotifSoundId(String id) {
            SharedPreferences sp = ctx.getSharedPreferences("aamal", MODE_PRIVATE);
            sp.edit().putString("notif_sound_id", id).apply();
            if (ctx instanceof MainActivity) {
                ((MainActivity) ctx).runOnUiThread(() -> {
                    ((MainActivity) ctx).recreateNotificationChannel();
                });
            }
        }

        @JavascriptInterface
        public void setNotifPhrase(String id) {
            ctx.getSharedPreferences("aamal", MODE_PRIVATE).edit().putString("notif_phrase", id).apply();
        }

        @JavascriptInterface
        public String getNotifSoundId() {
            return ctx.getSharedPreferences("aamal", MODE_PRIVATE).getString("notif_sound_id", "soft");
        }

        @JavascriptInterface
        public String getNotifPhrase() {
            return ctx.getSharedPreferences("aamal", MODE_PRIVATE).getString("notif_phrase", "auto");
        }

        @JavascriptInterface
        public String getDeviceTime() {
            Calendar c = Calendar.getInstance();
            return String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
        }

        @JavascriptInterface
        public String getPendingPrayers() {
            SharedPreferences sp = ctx.getSharedPreferences("aamal", MODE_PRIVATE);
            String[] keys = {"fajr", "zuhr", "asr", "maghrib", "isha"};
            StringBuilder sb = new StringBuilder("{");
            boolean first = true;
            for (String k : keys) {
                String v = sp.getString("pending_prayer_" + k, null);
                if (v != null) {
                    if (!first) sb.append(",");
                    sb.append("\"").append(k).append("\":\"").append(v).append("\"");
                    first = false;
                }
            }
            sb.append("}");
            return sb.toString();
        }

        @JavascriptInterface
        public void clearPendingPrayers() {
            SharedPreferences sp = ctx.getSharedPreferences("aamal", MODE_PRIVATE);
            SharedPreferences.Editor ed = sp.edit();
            for (String k : new String[]{"fajr", "zuhr", "asr", "maghrib", "isha"})
                ed.remove("pending_prayer_" + k);
            ed.remove("pending_prayer_ts");
            ed.apply();
        }

        @JavascriptInterface
        public long getTimesSavedAt() {
            return ctx.getSharedPreferences("aamal", MODE_PRIVATE).getLong("times_saved_at", 0);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
