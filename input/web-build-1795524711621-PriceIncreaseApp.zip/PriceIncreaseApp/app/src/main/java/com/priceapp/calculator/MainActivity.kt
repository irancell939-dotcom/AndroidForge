package com.priceapp.calculator

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import android.widget.EditText
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var etPrice: EditText
    private lateinit var etPercent: EditText
    private lateinit var btnCalculate: MaterialButton
    private lateinit var btnClear: MaterialButton
    private lateinit var cardResult: MaterialCardView
    private lateinit var tvNewPrice: TextView
    private lateinit var tvIncrease: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etPrice = findViewById(R.id.etPrice)
        etPercent = findViewById(R.id.etPercent)
        btnCalculate = findViewById(R.id.btnCalculate)
        btnClear = findViewById(R.id.btnClear)
        cardResult = findViewById(R.id.cardResult)
        tvNewPrice = findViewById(R.id.tvNewPrice)
        tvIncrease = findViewById(R.id.tvIncrease)

        btnCalculate.setOnClickListener { calculate() }
        btnClear.setOnClickListener { clearAll() }
    }

    private fun calculate() {
        val priceText = etPrice.text.toString().trim()
        val percentText = etPercent.text.toString().trim()

        if (priceText.isEmpty() || percentText.isEmpty()) {
            Toast.makeText(this, getString(R.string.empty_fields), Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val price = priceText.toDouble()
            val percent = percentText.toDouble()

            if (price < 0 || percent < 0) {
                Toast.makeText(this, getString(R.string.negative_not_allowed), Toast.LENGTH_SHORT).show()
                return
            }

            val increaseAmount = price * (percent / 100.0)
            val newPrice = price + increaseAmount

            val formatter = NumberFormat.getNumberInstance(Locale("fa", "IR"))
            formatter.maximumFractionDigits = 0

            tvNewPrice.text = formatter.format(newPrice)
            tvIncrease.text = "+ ${formatter.format(increaseAmount)}"

            cardResult.visibility = View.VISIBLE
            cardResult.alpha = 0f
            cardResult.animate().alpha(1f).setDuration(300).start()

        } catch (e: NumberFormatException) {
            Toast.makeText(this, getString(R.string.invalid_number), Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearAll() {
        etPrice.text.clear()
        etPercent.text.clear()
        cardResult.visibility = View.GONE
        etPrice.requestFocus()
    }
}
