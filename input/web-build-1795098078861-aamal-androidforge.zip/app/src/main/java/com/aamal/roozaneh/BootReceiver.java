package com.aamal.roozaneh;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONObject;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        try {
            // Night reminder
            MainActivity.scheduleAt(context, 21, 0, 9000, "night",
                "امروزت چگونه گذشت؟ کارنامه اعمالت را تکمیل کن");

            // Restore prayer time alarms
            SharedPreferences sp = context.getSharedPreferences("aamal", Context.MODE_PRIVATE);
            String json = sp.getString("prayer_times", null);
            if (json != null) {
                JSONObject obj = new JSONObject(json);
                String[] keys = {"fajr", "zuhr", "asr", "maghrib", "isha"};
                String[] names = {"صبح", "ظهر", "عصر", "مغرب", "عشاء"};
                for (int i = 0; i < keys.length; i++) {
                    if (!obj.has(keys[i])) continue;
                    String time = obj.getString(keys[i]);
                    if (time == null || time.length() < 4) continue;
                    String[] parts = time.split(":");
                    int h = Integer.parseInt(parts[0]);
                    int m = Integer.parseInt(parts[1]);
                    int beforeM = m - 10, beforeH = h;
                    if (beforeM < 0) { beforeM += 60; beforeH -= 1; if (beforeH < 0) beforeH = 23; }
                    MainActivity.scheduleAt(context, beforeH, beforeM, 1000 + i, "before",
                        "۱۰ دقیقه تا نماز " + names[i] + " — آماده شو و وضو بگیر");
                    int afterM = m + 30, afterH = h;
                    if (afterM >= 60) { afterM -= 60; afterH += 1; if (afterH > 23) afterH = 0; }
                    MainActivity.scheduleAt(context, afterH, afterM, 2000 + i, "after",
                        "نیم‌ساعت از وقت نماز " + names[i] + " گذشته — خواندی؟ در برنامه ثبت کن");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
