package ir.khavaran.khayati;

import android.Manifest;
import android.provider.Settings;
import android.webkit.PermissionRequest;
import android.print.PrintJob;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.app.DownloadManager;
import android.net.Uri;
import android.os.Environment;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 7201;
    private static final int REQ_NOTIFICATIONS = 7202;
    private WebView webView;
    private ValueCallback<android.net.Uri[]> fileCallback;
    private PermissionRequest pendingMediaRequest;
    private final Handler handler = new Handler();
    private int retryCount = 0;
    private final String homeUrl = "http://127.0.0.1:5000";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestNotificationPermissionIfNeeded();
        // هر بار که صفحه برنامه دوباره باز می‌شود، نشست قبلی WebView پاک شود تا رمز ورود مجدداً درخواست شود.
        CookieManager.getInstance().removeAllCookies(null);
        CookieManager.getInstance().flush();
        startLocalServer();
        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new AndroidBridge(), "KhayatiAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("sms:")) {
                    try { startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse(url))); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "برنامه پیامک در دسترس نیست.", Toast.LENGTH_LONG).show(); }
                    return true;
                }
                return false;
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri != null && "sms".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_SENDTO, uri)); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "برنامه پیامک در دسترس نیست.", Toast.LENGTH_LONG).show(); }
                    return true;
                }
                return false;
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                retryCount = 0;
            }
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) retryServerPage();
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                String cookie = CookieManager.getInstance().getCookie(url);
                DownloadManager.Request download = new DownloadManager.Request(Uri.parse(url));
                if (cookie != null) download.addRequestHeader("Cookie", cookie);
                download.addRequestHeader("User-Agent", userAgent);
                download.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
                download.setDescription("دریافت نسخه پشتیبان دفتر خیاطی");
                download.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                download.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        URLUtil.guessFileName(url, contentDisposition, mimeType));
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(download);
                Toast.makeText(MainActivity.this, "دریافت فایل پشتیبان آغاز شد.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "دریافت فایل انجام نشد: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    Uri origin = request.getOrigin();
                    if (origin == null || !"127.0.0.1".equals(origin.getHost())) {
                        request.deny();
                        return;
                    }
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        java.util.ArrayList<String> allowed = new java.util.ArrayList<>();
                        for (String resource : request.getResources()) {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) allowed.add(resource);
                        }
                        if (!allowed.isEmpty()) request.grant(allowed.toArray(new String[0]));
                        else request.deny();
                    } else {
                        pendingMediaRequest = request;
                        requestCameraPermissionIfNeeded();
                    }
                });
            }
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<android.net.Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*");
                try {
                    startActivityForResult(pick, REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "بازکردن انتخاب‌گر فایل ممکن نشد.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        setContentView(webView);
        handler.postDelayed(() -> webView.loadUrl(homeUrl), 1800);
    }

    private void startLocalServer() {
        Intent service = new Intent(this, ServerService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
        else startService(service);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private void requestCameraPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 7203);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 7203 && pendingMediaRequest != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pendingMediaRequest.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            } else {
                pendingMediaRequest.deny();
            }
            pendingMediaRequest = null;
        }
    }

    private void watchPrintJob(PrintJob job, int attempt) {
        if (job == null || webView == null) return;
        if (job.isCompleted() || job.isCancelled() || job.isFailed()) {
            handler.postDelayed(() -> { if (webView != null) webView.loadUrl(homeUrl); }, 450);
            return;
        }
        if (attempt < 1800) handler.postDelayed(() -> watchPrintJob(job, attempt + 1), 1000);
    }

    private void retryServerPage() {
        if (retryCount >= 30) return;
        retryCount++;
        handler.postDelayed(() -> {
            if (webView != null) webView.loadUrl(homeUrl);
        }, 1200);
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                    PrintJob job = printManager.print("برگه اندازه‌گیری خیاطی",
                            webView.createPrintDocumentAdapter("برگه اندازه‌گیری خیاطی"),
                            new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A5)
                                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                                    .build());
                    if (job != null) watchPrintJob(job, 0);
                    else handler.postDelayed(() -> { if (webView != null) webView.loadUrl(homeUrl); }, 1200);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "چاپ در این دستگاه در دسترس نیست.", Toast.LENGTH_LONG).show();
                    handler.postDelayed(() -> { if (webView != null) webView.loadUrl(homeUrl); }, 1200);
                }
            });
        }

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> {
                try {
                    stopService(new Intent(MainActivity.this, ServerService.class));
                } catch (Exception ignored) { }
                finishAndRemoveTask();
                new Handler().postDelayed(() -> android.os.Process.killProcess(android.os.Process.myPid()), 350);
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            android.net.Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new android.net.Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
