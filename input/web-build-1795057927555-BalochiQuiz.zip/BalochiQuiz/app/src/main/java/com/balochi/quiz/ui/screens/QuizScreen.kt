package com.balochi.quiz.ui.screens

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun QuizScreen(
    viewModel: QuizViewModel,
    onBack: () -> Unit,
    onFinish: () -> Unit
) {
    val colors = getThemeColors(viewModel.currentTheme)
    val options = viewModel.options
    val selectedIndex = viewModel.selectedOptionIndex
    val isRevealed = viewModel.isAnswerRevealed
    val correctIndex = viewModel.correctOptionIndex

    LaunchedEffect(selectedIndex, isRevealed) {
        if (isRevealed && selectedIndex != null) {
            val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
            if (selectedIndex == correctIndex) {
                toneGen.startTone(ToneGenerator.TONE_PROP_ACK, 220)
            } else {
                toneGen.startTone(ToneGenerator.TONE_PROP_NACK, 450)
            }
            delay(500)
            toneGen.release()
        }
    }

    LaunchedEffect(isRevealed) {
        if (isRevealed) {
            delay(1600)
            if (!viewModel.quizFinished) {
                viewModel.onContinueAfterAnswer()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت", tint = colors.textPrimary, modifier = Modifier.size(26.dp))
            }
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "${viewModel.totalAnswered + if (isRevealed) 0 else 1}",
                color = colors.textSecondary,
                fontSize = 15.sp
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "${viewModel.score}",
                color = colors.accent,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        }

        if (viewModel.quizFinished) {
            ResultContent(score = viewModel.score, total = viewModel.totalAnswered, colors = colors, onFinish = onFinish)
        } else if (viewModel.currentWord != null && options.size == 4) {
            Text(
                text = "${viewModel.fromLang.displayName}  →  ${viewModel.toLang.displayName}",
                color = Sage,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                textAlign = TextAlign.Center
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 22.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "معنی این کلمه چیست؟",
                        color = colors.textSecondary,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = viewModel.questionText,
                        color = colors.accent,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        lineHeight = 44.sp
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OptionCard(options[0], 0, selectedIndex, correctIndex, isRevealed, colors, { viewModel.selectOption(0) }, Modifier.weight(1f))
                    OptionCard(options[1], 1, selectedIndex, correctIndex, isRevealed, colors, { viewModel.selectOption(1) }, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OptionCard(options[2], 2, selectedIndex, correctIndex, isRevealed, colors, { viewModel.selectOption(2) }, Modifier.weight(1f))
                    OptionCard(options[3], 3, selectedIndex, correctIndex, isRevealed, colors, { viewModel.selectOption(3) }, Modifier.weight(1f))
                }
            }

            if (isRevealed && selectedIndex != null) {
                Spacer(modifier = Modifier.height(20.dp))
                FeedbackBanner(
                    isCorrect = selectedIndex == correctIndex,
                    correctAnswer = options.getOrNull(correctIndex) ?: "",
                    colors = colors
                )
            }
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = colors.accent)
            }
        }
    }
}

@Composable
private fun OptionCard(
    text: String,
    index: Int,
    selectedIndex: Int?,
    correctIndex: Int,
    isRevealed: Boolean,
    colors: ThemeColors,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSelected = selectedIndex == index
    val isCorrect = index == correctIndex

    val bg by animateColorAsState(
        when {
            !isRevealed -> colors.cardLight
            isCorrect -> CorrectGreen.copy(alpha = 0.28f)
            isSelected && !isCorrect -> WrongRed.copy(alpha = 0.28f)
            else -> colors.card
        }, tween(280), label = "bg"
    )
    val borderCol by animateColorAsState(
        when {
            !isRevealed && isSelected -> colors.accent
            isRevealed && isCorrect -> CorrectGreen
            isRevealed && isSelected && !isCorrect -> WrongRed
            else -> colors.border
        }, tween(280), label = "border"
    )

    Box(
        modifier = modifier
            .aspectRatio(1.12f)
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .border(2.5.dp, borderCol, RoundedCornerShape(18.dp))
            .clickable(enabled = !isRevealed, onClick = onClick)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = colors.textPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            maxLines = 4,
            lineHeight = 24.sp
        )
    }
}

@Composable
private fun FeedbackBanner(isCorrect: Boolean, correctAnswer: String, colors: ThemeColors) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (isCorrect) CorrectGreen.copy(alpha = 0.2f) else WrongRed.copy(alpha = 0.2f))
            .border(1.5.dp, if (isCorrect) CorrectGreen.copy(alpha = 0.5f) else WrongRed.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            if (isCorrect) Icons.Default.CheckCircle else Icons.Default.Warning,
            null,
            tint = if (isCorrect) CorrectGreen else WrongRed,
            modifier = Modifier.size(30.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column {
            Text(
                if (isCorrect) "آفرین! درست بود" else "اشتباه بود — دوباره می‌پرسیم",
                color = if (isCorrect) CorrectGreen else WrongRed,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            if (!isCorrect) {
                Text("جواب درست: $correctAnswer", color = colors.textPrimary, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun ResultContent(score: Int, total: Int, colors: ThemeColors, onFinish: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("پایان آزمون", color = colors.accent, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Text("$score از $total", color = colors.textPrimary, fontSize = 52.sp, fontWeight = FontWeight.Bold)
        Text("پاسخ صحیح", color = colors.textSecondary, fontSize = 17.sp)
        Spacer(Modifier.height(40.dp))
        MainButton("بازگشت به صفحه اصلی", Icons.AutoMirrored.Filled.ArrowBack, colors, onFinish)
    }
}
