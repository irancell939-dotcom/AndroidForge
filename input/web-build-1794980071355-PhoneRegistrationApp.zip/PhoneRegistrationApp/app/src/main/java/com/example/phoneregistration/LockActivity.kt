package com.example.phoneregistration

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.util.concurrent.Executor

class LockActivity : AppCompatActivity() {

    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)
        when (prefs.getString("app_theme", "blue")) {
            "green" -> setTheme(R.style.Theme_PhoneRegistrationApp_Green)
            "purple" -> setTheme(R.style.Theme_PhoneRegistrationApp_Purple)
            "dark" -> setTheme(R.style.Theme_PhoneRegistrationApp_Dark)
            else -> setTheme(R.style.Theme_PhoneRegistrationApp)
        }
        super.onCreate(savedInstanceState)

        val pin = prefs.getString("app_pin", null)
        if (pin.isNullOrBlank()) {
            startMain()
            return
        }

        setContentView(R.layout.activity_lock)

        val etPin = findViewById<TextInputEditText>(R.id.etPin)
        val btnUnlock = findViewById<MaterialButton>(R.id.btnUnlock)
        val btnBiometric = findViewById<MaterialButton>(R.id.btnBiometric)
        val tvError = findViewById<TextView>(R.id.tvError)
        val tvForgot = findViewById<TextView>(R.id.tvForgot)

        btnUnlock.setOnClickListener {
            val entered = etPin.text?.toString().orEmpty()
            if (entered == pin) {
                startMain()
            } else {
                tvError.visibility = View.VISIBLE
                tvError.text = "رمز اشتباه است"
                etPin.text?.clear()
            }
        }

        val biometricEnabled = prefs.getBoolean("biometric_unlock", true)
        val canAuth = BiometricManager.from(this).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        ) == BiometricManager.BIOMETRIC_SUCCESS

        if (biometricEnabled && canAuth) {
            btnBiometric.visibility = View.VISIBLE
            btnBiometric.text = "باز کردن با اثر انگشت / الگو"
            btnBiometric.setOnClickListener { authenticate(forRecovery = false) }
        } else {
            btnBiometric.visibility = View.GONE
        }

        tvForgot.setOnClickListener {
            if (canAuth) {
                AlertDialog.Builder(this)
                    .setTitle("فراموشی رمز")
                    .setMessage("با اثر انگشت یا رمز/الگوی گوشی تأیید کنید تا بتوانید رمز برنامه را عوض کنید.")
                    .setPositiveButton("ادامه") { _, _ -> authenticate(forRecovery = true) }
                    .setNegativeButton("انصراف", null)
                    .show()
            } else {
                Toast.makeText(this, "قفل صفحه گوشی فعال نیست", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun authenticate(forRecovery: Boolean) {
        val executor: Executor = ContextCompat.getMainExecutor(this)
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(if (forRecovery) "بازیابی رمز برنامه" else "ورود به دفترچه تلفن خاوران")
            .setSubtitle(
                if (forRecovery) "تأیید هویت برای تنظیم رمز جدید"
                else "با اثر انگشت یا الگو / رمز گوشی وارد شوید"
            )
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        val biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    if (forRecovery) {
                        askNewPinAfterRecovery()
                    } else {
                        // Direct unlock — no password change screen
                        startMain()
                    }
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                        Toast.makeText(this@LockActivity, errString, Toast.LENGTH_SHORT).show()
                    }
                }
            })

        biometricPrompt.authenticate(promptInfo)
    }

    private fun askNewPinAfterRecovery() {
        val input1 = TextInputEditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "رمز جدید (۴ تا ۸ رقم)"
            setPadding(40, 30, 40, 30)
            setTextColor(0xFF1A237E.toInt())
        }
        val input2 = TextInputEditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "تکرار رمز جدید"
            setPadding(40, 30, 40, 30)
            setTextColor(0xFF1A237E.toInt())
        }
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
            addView(input1)
            addView(input2)
        }

        AlertDialog.Builder(this)
            .setTitle("تنظیم رمز جدید")
            .setMessage("رمز جدید را دو بار وارد کنید.\nخالی = حذف رمز")
            .setView(container)
            .setPositiveButton("ذخیره و ورود") { _, _ ->
                val p1 = input1.text?.toString()?.trim().orEmpty()
                val p2 = input2.text?.toString()?.trim().orEmpty()
                when {
                    p1.isEmpty() && p2.isEmpty() -> {
                        prefs.edit().remove("app_pin").apply()
                        Toast.makeText(this, "رمز حذف شد", Toast.LENGTH_SHORT).show()
                        startMain()
                    }
                    p1.length !in 4..8 -> {
                        Toast.makeText(this, "رمز باید ۴ تا ۸ رقم باشد", Toast.LENGTH_SHORT).show()
                        askNewPinAfterRecovery()
                    }
                    p1 != p2 -> {
                        Toast.makeText(this, "دو رمز یکسان نیستند", Toast.LENGTH_SHORT).show()
                        askNewPinAfterRecovery()
                    }
                    else -> {
                        prefs.edit().putString("app_pin", p1).apply()
                        Toast.makeText(this, "رمز جدید ذخیره شد", Toast.LENGTH_SHORT).show()
                        startMain()
                    }
                }
            }
            .setNegativeButton("انصراف", null)
            .setCancelable(false)
            .show()
    }

    private fun startMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
