زرمانگ - بسته کامل AndroidForge

ساختار اصلی این ZIP یک پروژه واقعی Android/Gradle است؛ فایل settings.gradle در ریشه قرار دارد.
برای AndroidForge:
1) همین ZIP را بدون خارج کردن پوشه‌ها بارگذاری کنید.
2) Build Variant را روی Auto بگذارید.
3) Build APK را اجرا کنید.
4) پس از موفقیت، APK را از Artifact با نام AndroidForge-APKs دریافت کنید.

اپلیکیشن اندروید مستقل و آفلاین است و اطلاعات را در پایگاه داده SQLite خود گوشی نگهداری می‌کند.
ظاهر و منطق نسخه اندرویدی موجود حفظ شده است.

پوشه website_source شامل نسخه وب Flask، پایگاه داده، CSS و تمام قالب‌های HTML است؛ از جمله:
base, index, add, detail, archive, balance, backup, settings, login, register, set_password.
این پوشه منبع وب است و در ساخت APK اندروید به عنوان اپلیکیشن جداگانه اجرا نمی‌شود.

برای اجرای نسخه وب روی رایانه/سرور:
- وارد پوشه website_source شوید.
- وابستگی‌ها را با pip install -r requirements.txt نصب کنید.
- برنامه را با python app.py اجرا کنید.

نکته: ساخت APK باید در محیط AndroidForge انجام شود؛ در این محیط فایل APK نهایی ساخته نشده است.
