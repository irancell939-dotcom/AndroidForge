package com.example.phoneregistration

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class ChangePinActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        val prefs = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)
        when (prefs.getString("app_theme", "blue")) {
            "green" -> setTheme(R.style.Theme_PhoneRegistrationApp_Green)
            "purple" -> setTheme(R.style.Theme_PhoneRegistrationApp_Purple)
            "dark" -> setTheme(R.style.Theme_PhoneRegistrationApp_Dark)
            else -> setTheme(R.style.Theme_PhoneRegistrationApp)
        }
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_pin)

        val et1 = findViewById<TextInputEditText>(R.id.etPin1)
        val et2 = findViewById<TextInputEditText>(R.id.etPin2)
        val tvErr = findViewById<TextView>(R.id.tvPinError)
        val btnSave = findViewById<MaterialButton>(R.id.btnSavePin)
        val btnRemove = findViewById<MaterialButton>(R.id.btnRemovePin)

        btnSave.setOnClickListener {
            val p1 = et1.text?.toString()?.trim().orEmpty()
            val p2 = et2.text?.toString()?.trim().orEmpty()
            when {
                p1.length !in 4..8 -> {
                    tvErr.visibility = View.VISIBLE
                    tvErr.text = "رمز باید ۴ تا ۸ رقم باشد"
                }
                p1 != p2 -> {
                    tvErr.visibility = View.VISIBLE
                    tvErr.text = "دو رمز یکسان نیستند"
                }
                else -> {
                    prefs.edit().putString("app_pin", p1).apply()
                    Toast.makeText(this, "رمز ذخیره شد", Toast.LENGTH_SHORT).show()
                    goMain()
                }
            }
        }

        btnRemove.setOnClickListener {
            prefs.edit().remove("app_pin").apply()
            Toast.makeText(this, "رمز حذف شد", Toast.LENGTH_SHORT).show()
            goMain()
        }
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        finish()
    }
}
