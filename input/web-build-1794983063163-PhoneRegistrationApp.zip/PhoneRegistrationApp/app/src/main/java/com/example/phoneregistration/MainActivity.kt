package com.example.phoneregistration

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import com.google.android.material.navigation.NavigationView
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class Contact(
    val id: String,
    var name: String,
    var phone: String,
    var note: String = "",
    var category: String = ""
)

data class CallRecord(
    val id: String,
    val name: String,
    val phone: String,
    val timestamp: Long
)

class MainActivity : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var rvList: RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var tvCount: TextView
    private lateinit var fabAdd: FloatingActionButton
    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: ContactAdapter

    private val allContacts = mutableListOf<Contact>()
    private val filteredContacts = mutableListOf<Contact>()
    private val selectedIds = mutableSetOf<String>()
    private var currentCategoryFilter = ""
    private var selectMode = false

    private val defaultCategories = listOf("همکاران", "دوستان", "خانواده", "مشتریان", "سایر")

    companion object {
        private const val REQ_IMPORT_VCF = 2001
        private const val REQ_RESTORE = 2002
        private const val REQ_EXCEL_CSV = 2003
        private const val PREF_THEME = "app_theme"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        applyThemeStyle()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()

        etSearch = findViewById(R.id.etSearch)
        rvList = findViewById(R.id.rvList)
        tvEmpty = findViewById(R.id.tvEmpty)
        tvCount = findViewById(R.id.tvCount)
        fabAdd = findViewById(R.id.fabAdd)

        prefs = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)

        val drawerLayout = findViewById<DrawerLayout>(R.id.drawerLayout)
        val navView = findViewById<NavigationView>(R.id.navView)
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }
        findViewById<ImageButton>(R.id.btnHistoryToolbar).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        navView.setNavigationItemSelectedListener { item ->
            drawerLayout.closeDrawer(GravityCompat.START)
            when (item.itemId) {
                R.id.nav_history -> startActivity(Intent(this, HistoryActivity::class.java))
                R.id.nav_select -> {
                    selectMode = !selectMode
                    if (!selectMode) selectedIds.clear()
                    adapter.notifyDataSetChanged()
                    updateCountLabel()
                    Toast.makeText(this, if (selectMode) "حالت انتخاب فعال شد" else "حالت انتخاب خاموش شد", Toast.LENGTH_SHORT).show()
                }
                R.id.nav_export_selected -> exportSelectedVcf()
                R.id.nav_export_vcf -> exportVcf(allContacts)
                R.id.nav_import_vcf -> pickFile(REQ_IMPORT_VCF)
                R.id.nav_backup -> exportBackup()
                R.id.nav_restore -> pickFile(REQ_RESTORE)
                R.id.nav_excel -> {
                    AlertDialog.Builder(this)
                        .setTitle(R.string.excel_to_vcf)
                        .setMessage("فایل اکسل را به صورت CSV ذخیره کنید (Save As → CSV)، سپس انتخاب کنید.\nستون‌ها: نام، شماره، دسته، یادداشت")
                        .setPositiveButton("انتخاب فایل") { _, _ -> pickFile(REQ_EXCEL_CSV) }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                }
                R.id.nav_theme -> showThemeDialog()
                R.id.nav_pin -> showPinDialog()
                R.id.nav_biometric -> {
                    val enabled = prefs.getBoolean("biometric_unlock", true)
                    val next = !enabled
                    prefs.edit().putBoolean("biometric_unlock", next).apply()
                    Toast.makeText(this, if (next) "اثر انگشت/الگو فعال شد" else "اثر انگشت/الگو غیرفعال شد", Toast.LENGTH_LONG).show()
                }
            }
            true
        }

        adapter = ContactAdapter(
            filteredContacts,
            selectedIds,
            { selectMode },
            onCall = { initiateCall(it) },
            onSms = { sendSms(it) },
            onMessages = { contact ->
                val i = Intent(this, MessagesActivity::class.java)
                i.putExtra(MessagesActivity.EXTRA_PHONE, contact.phone)
                i.putExtra(MessagesActivity.EXTRA_NAME, contact.name)
                startActivity(i)
            },
            onEdit = { showContactDialog(it) },
            onDelete = { confirmDelete(it) },
            onToggleSelect = { contact, checked ->
                if (checked) selectedIds.add(contact.id) else selectedIds.remove(contact.id)
                updateCountLabel()
            }
        )
        rvList.layoutManager = LinearLayoutManager(this)
        rvList.adapter = adapter

        loadContacts()
        applyFilter("")

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                applyFilter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        fabAdd.setOnClickListener { showContactDialog(null) }
        tvCount.setOnClickListener { showCategoryFilterDialog() }
    }

    private fun applyThemeStyle() {
        val theme = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)
            .getString(PREF_THEME, "blue") ?: "blue"
        when (theme) {
            "green" -> setTheme(R.style.Theme_PhoneRegistrationApp_Green)
            "purple" -> setTheme(R.style.Theme_PhoneRegistrationApp_Purple)
            "dark" -> setTheme(R.style.Theme_PhoneRegistrationApp_Dark)
            else -> setTheme(R.style.Theme_PhoneRegistrationApp)
        }
    }

    private fun showThemeDialog() {
        val themes = arrayOf(
            getString(R.string.theme_blue),
            getString(R.string.theme_green),
            getString(R.string.theme_purple),
            getString(R.string.theme_dark)
        )
        val keys = arrayOf("blue", "green", "purple", "dark")
        AlertDialog.Builder(this)
            .setTitle(R.string.theme)
            .setItems(themes) { _, which ->
                prefs.edit().putString(PREF_THEME, keys[which]).apply()
                Toast.makeText(this, "تم ذخیره شد. برنامه را ببندید و دوباره باز کنید.", Toast.LENGTH_LONG).show()
                // Restart app to fully apply
                val i = Intent(this, LockActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                finish()
            }
            .show()
    }

    private fun showPinDialog() {
        startActivity(Intent(this, ChangePinActivity::class.java))
    }


    private fun pickFile(requestCode: Int) {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "انتخاب فایل"), requestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            REQ_IMPORT_VCF -> importVcf(uri)
            REQ_RESTORE -> restoreBackup(uri)
            REQ_EXCEL_CSV -> convertCsvToVcf(uri)
        }
    }

    private fun showContactDialog(existing: Contact?) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_contact, null)
        val etName = view.findViewById<TextInputEditText>(R.id.etName)
        val etPhone = view.findViewById<TextInputEditText>(R.id.etPhone)
        val etNote = view.findViewById<TextInputEditText>(R.id.etNote)
        val etCategory = view.findViewById<AutoCompleteTextView>(R.id.etCategory)
        val tvTitle = view.findViewById<TextView>(R.id.tvDialogTitle)
        val btnSave = view.findViewById<MaterialButton>(R.id.btnSave)
        val btnCancel = view.findViewById<MaterialButton>(R.id.btnCancel)

        val cats = (defaultCategories + allContacts.map { it.category }.filter { it.isNotBlank() }).distinct()
        etCategory.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, cats))

        if (existing != null) {
            tvTitle.text = getString(R.string.edit)
            etName.setText(existing.name)
            etPhone.setText(existing.phone)
            etNote.setText(existing.note)
            etCategory.setText(existing.category)
        } else {
            tvTitle.text = getString(R.string.add_contact)
        }

        val dialog = AlertDialog.Builder(this).setView(view).setCancelable(true).create()
        btnCancel.setOnClickListener { dialog.dismiss() }
        btnSave.setOnClickListener {
            val name = etName.text?.toString()?.trim().orEmpty()
            val phone = etPhone.text?.toString()?.trim().orEmpty()
            val note = etNote.text?.toString()?.trim().orEmpty()
            val category = etCategory.text?.toString()?.trim().orEmpty()
            if (name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, R.string.error_empty, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (existing != null) {
                existing.name = name
                existing.phone = phone
                existing.note = note
                existing.category = category
            } else {
                allContacts.add(0, Contact(UUID.randomUUID().toString(), name, phone, note, category))
            }
            saveContacts()
            applyFilter(etSearch.text.toString())
            Toast.makeText(this, R.string.success_save, Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun showCategoryFilterDialog() {
        val cats = listOf(getString(R.string.all_categories)) +
                (defaultCategories + allContacts.map { it.category }.filter { it.isNotBlank() }).distinct().sorted()
        AlertDialog.Builder(this)
            .setTitle("فیلتر دسته‌بندی")
            .setItems(cats.toTypedArray()) { _, which ->
                currentCategoryFilter = if (which == 0) "" else cats[which]
                applyFilter(etSearch.text.toString())
            }
            .show()
    }

    private fun confirmDelete(contact: Contact) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete)
            .setMessage("«${contact.name}» حذف شود؟")
            .setPositiveButton(R.string.delete) { _, _ ->
                allContacts.removeAll { it.id == contact.id }
                selectedIds.remove(contact.id)
                saveContacts()
                applyFilter(etSearch.text.toString())
                Toast.makeText(this, R.string.success_delete, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun initiateCall(contact: Contact) {
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contact.phone}")))
            addCallHistory(contact.name, contact.phone)
        } catch (e: Exception) {
            Toast.makeText(this, "امکان تماس وجود ندارد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendSms(contact: Contact) {
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${contact.phone}")))
        } catch (e: Exception) {
            Toast.makeText(this, "امکان ارسال پیامک وجود ندارد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun contactsToVcf(list: List<Contact>): String {
        val sb = StringBuilder()
        list.forEach { c ->
            sb.append("BEGIN:VCARD\nVERSION:3.0\n")
            sb.append("FN:${c.name}\n")
            sb.append("TEL;TYPE=CELL:${c.phone}\n")
            if (c.note.isNotBlank()) sb.append("NOTE:${c.note}\n")
            if (c.category.isNotBlank()) sb.append("CATEGORIES:${c.category}\n")
            sb.append("END:VCARD\n")
        }
        return sb.toString()
    }

    private fun exportVcf(list: List<Contact>) {
        if (list.isEmpty()) {
            Toast.makeText(this, "مخاطبی انتخاب نشده", Toast.LENGTH_SHORT).show()
            return
        }
        val content = contactsToVcf(list)
        val name = "khavaran_contacts_${System.currentTimeMillis()}.vcf"
        saveToDownloads(name, content, "text/vcard")
        shareTextFile(name, content, "text/vcard")
        Toast.makeText(this, R.string.export_success, Toast.LENGTH_SHORT).show()
    }

    private fun exportSelectedVcf() {
        val selected = allContacts.filter { selectedIds.contains(it.id) }
        exportVcf(selected)
    }

    private fun importVcf(uri: Uri) {
        try {
            val reader = BufferedReader(InputStreamReader(contentResolver.openInputStream(uri)))
            val content = reader.readText()
            reader.close()
            val cards = content.split("BEGIN:VCARD")
            var count = 0
            cards.forEach { card ->
                if (card.isBlank()) return@forEach
                var name = ""; var phone = ""; var note = ""; var category = ""
                card.lines().forEach { line ->
                    when {
                        line.startsWith("FN:") -> name = line.removePrefix("FN:").trim()
                        line.startsWith("TEL") -> {
                            val p = line.substringAfter(":").trim()
                            if (p.isNotBlank()) phone = p
                        }
                        line.startsWith("NOTE:") -> note = line.removePrefix("NOTE:").trim()
                        line.startsWith("CATEGORIES:") -> category = line.removePrefix("CATEGORIES:").trim()
                    }
                }
                if (name.isNotBlank() && phone.isNotBlank() &&
                    allContacts.none { it.phone == phone && it.name == name }) {
                    allContacts.add(Contact(UUID.randomUUID().toString(), name, phone, note, category))
                    count++
                }
            }
            saveContacts()
            applyFilter(etSearch.text.toString())
            Toast.makeText(this, "$count مخاطب وارد شد", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در خواندن VCF", Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportBackup() {
        val arr = JSONArray()
        allContacts.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id); obj.put("name", c.name); obj.put("phone", c.phone)
            obj.put("note", c.note); obj.put("category", c.category)
            arr.put(obj)
        }
        val content = arr.toString(2)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val name = "khavaran_backup_$stamp.json"
        saveToDownloads(name, content, "application/json")
        shareTextFile(name, content, "application/json")
        Toast.makeText(this, R.string.backup_success, Toast.LENGTH_LONG).show()
    }

    private fun restoreBackup(uri: Uri) {
        try {
            val reader = BufferedReader(InputStreamReader(contentResolver.openInputStream(uri)))
            val json = reader.readText()
            reader.close()
            val arr = JSONArray(json)
            var count = 0
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val name = obj.optString("name")
                val phone = obj.optString("phone")
                if (name.isNotBlank() && phone.isNotBlank() &&
                    allContacts.none { it.phone == phone && it.name == name }) {
                    allContacts.add(
                        Contact(
                            obj.optString("id", UUID.randomUUID().toString()),
                            name, phone, obj.optString("note", ""), obj.optString("category", "")
                        )
                    )
                    count++
                }
            }
            saveContacts()
            applyFilter(etSearch.text.toString())
            Toast.makeText(this, "$count مخاطب بازیابی شد", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در بازیابی", Toast.LENGTH_SHORT).show()
        }
    }

    private fun convertCsvToVcf(uri: Uri) {
        try {
            val reader = BufferedReader(InputStreamReader(contentResolver.openInputStream(uri)))
            val lines = reader.readLines()
            reader.close()
            if (lines.isEmpty()) {
                Toast.makeText(this, "فایل خالی است", Toast.LENGTH_SHORT).show()
                return
            }
            val sb = StringBuilder()
            var count = 0
            val start = if (lines[0].contains("نام") || lines[0].lowercase().contains("name") ||
                lines[0].lowercase().contains("phone")) 1 else 0
            for (i in start until lines.size) {
                val parts = lines[i].split(",", ";", "\t").map { it.trim().removeSurrounding("\"") }
                if (parts.size < 2) continue
                val name = parts[0]; val phone = parts[1]
                val category = if (parts.size > 2) parts[2] else ""
                val note = if (parts.size > 3) parts[3] else ""
                if (name.isBlank() || phone.isBlank()) continue
                sb.append("BEGIN:VCARD\nVERSION:3.0\nFN:$name\nTEL;TYPE=CELL:$phone\n")
                if (note.isNotBlank()) sb.append("NOTE:$note\n")
                if (category.isNotBlank()) sb.append("CATEGORIES:$category\n")
                sb.append("END:VCARD\n")
                count++
            }
            if (count == 0) {
                Toast.makeText(this, "هیچ مخاطب معتبری پیدا نشد", Toast.LENGTH_SHORT).show()
                return
            }
            val name = "converted_${System.currentTimeMillis()}.vcf"
            saveToDownloads(name, sb.toString(), "text/vcard")
            shareTextFile(name, sb.toString(), "text/vcard")
            Toast.makeText(this, "$count مخاطب به VCF تبدیل و ذخیره شد", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در تبدیل", Toast.LENGTH_SHORT).show()
        }
    }

    /** Save file permanently to Downloads folder */
    private fun saveToDownloads(filename: String, content: String, mime: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                uri?.let {
                    contentResolver.openOutputStream(it)?.use { os ->
                        OutputStreamWriter(os).use { it.write(content) }
                    }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    contentResolver.update(it, values, null, null)
                }
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!dir.exists()) dir.mkdirs()
                File(dir, filename).writeText(content)
            }
        } catch (e: Exception) {
            // still try share
        }
    }

    private fun shareTextFile(filename: String, content: String, mime: String) {
        try {
            val dir = File(cacheDir, "shares")
            dir.mkdirs()
            val file = File(dir, filename)
            file.writeText(content)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "اشتراک‌گذاری"))
        } catch (_: Exception) {}
    }

    private fun addCallHistory(name: String, phone: String) {
        val records = loadCallHistory().toMutableList()
        records.add(0, CallRecord(UUID.randomUUID().toString(), name, phone, System.currentTimeMillis()))
        val limited = records.take(100)
        val arr = JSONArray()
        limited.forEach { r ->
            val obj = JSONObject()
            obj.put("id", r.id); obj.put("name", r.name)
            obj.put("phone", r.phone); obj.put("timestamp", r.timestamp)
            arr.put(obj)
        }
        prefs.edit().putString("call_history", arr.toString()).apply()
    }

    private fun loadCallHistory(): List<CallRecord> {
        val json = prefs.getString("call_history", "[]") ?: "[]"
        val list = mutableListOf<CallRecord>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(CallRecord(obj.getString("id"), obj.getString("name"),
                    obj.getString("phone"), obj.getLong("timestamp")))
            }
        } catch (_: Exception) {}
        return list
    }

    private fun applyFilter(query: String) {
        filteredContacts.clear()
        val q = query.trim().lowercase()
        val base = if (currentCategoryFilter.isBlank()) allContacts
        else allContacts.filter { it.category == currentCategoryFilter }
        if (q.isEmpty()) filteredContacts.addAll(base)
        else filteredContacts.addAll(base.filter {
            it.name.lowercase().contains(q) || it.phone.contains(q) ||
            it.note.lowercase().contains(q) || it.category.lowercase().contains(q)
        })
        adapter.notifyDataSetChanged()
        updateEmptyState(query)
        updateCountLabel()
    }

    private fun updateCountLabel() {
        val catLabel = if (currentCategoryFilter.isBlank()) "" else " ($currentCategoryFilter)"
        val sel = if (selectMode && selectedIds.isNotEmpty()) " | ${selectedIds.size} انتخاب" else ""
        tvCount.text = "${filteredContacts.size} مخاطب$catLabel$sel"
    }

    private fun updateEmptyState(query: String) {
        if (filteredContacts.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            rvList.visibility = View.GONE
            tvEmpty.text = if (query.isBlank() && currentCategoryFilter.isBlank())
                getString(R.string.empty_list) else getString(R.string.empty_search)
        } else {
            tvEmpty.visibility = View.GONE
            rvList.visibility = View.VISIBLE
        }
    }

    private fun saveContacts() {
        val arr = JSONArray()
        allContacts.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id); obj.put("name", c.name); obj.put("phone", c.phone)
            obj.put("note", c.note); obj.put("category", c.category)
            arr.put(obj)
        }
        prefs.edit().putString("contacts", arr.toString()).apply()
    }

    private fun loadContacts() {
        allContacts.clear()
        val json = prefs.getString("contacts", "[]") ?: "[]"
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                allContacts.add(
                    Contact(
                        obj.getString("id"), obj.getString("name"), obj.getString("phone"),
                        obj.optString("note", ""), obj.optString("category", "")
                    )
                )
            }
        } catch (_: Exception) {}
    }
}

class ContactAdapter(
    private val items: List<Contact>,
    private val selectedIds: Set<String>,
    private val isSelectMode: () -> Boolean,
    private val onCall: (Contact) -> Unit,
    private val onSms: (Contact) -> Unit,
    private val onMessages: (Contact) -> Unit,
    private val onEdit: (Contact) -> Unit,
    private val onDelete: (Contact) -> Unit,
    private val onToggleSelect: (Contact, Boolean) -> Unit
) : RecyclerView.Adapter<ContactAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cbSelect: CheckBox = view.findViewById(R.id.cbSelect)
        val tvAvatar: TextView = view.findViewById(R.id.tvAvatar)
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvPhone: TextView = view.findViewById(R.id.tvPhone)
        val tvNote: TextView = view.findViewById(R.id.tvNote)
        val btnCall: MaterialButton = view.findViewById(R.id.btnCall)
        val btnSms: MaterialButton = view.findViewById(R.id.btnSms)
        val btnMessages: MaterialButton = view.findViewById(R.id.btnMessages)
        val btnMore: ImageButton = view.findViewById(R.id.btnMore)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_contact, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvName.text = if (item.category.isNotBlank()) "${item.name}  •  ${item.category}" else item.name
        holder.tvPhone.text = item.phone
        holder.tvAvatar.text = item.name.take(1).uppercase()

        if (item.note.isNotBlank()) {
            holder.tvNote.visibility = View.VISIBLE
            holder.tvNote.text = item.note
        } else holder.tvNote.visibility = View.GONE

        val select = isSelectMode()
        holder.cbSelect.visibility = if (select) View.VISIBLE else View.GONE
        holder.cbSelect.setOnCheckedChangeListener(null)
        holder.cbSelect.isChecked = selectedIds.contains(item.id)
        holder.cbSelect.setOnCheckedChangeListener { _, checked ->
            onToggleSelect(item, checked)
        }

        holder.btnCall.setOnClickListener { onCall(item) }
        holder.btnSms.setOnClickListener { onSms(item) }
        holder.btnMessages.setOnClickListener { onMessages(item) }
        holder.btnMore.setOnClickListener { view ->
            val popup = PopupMenu(view.context, view)
            popup.menu.add(0, 1, 0, view.context.getString(R.string.edit))
            popup.menu.add(0, 2, 1, view.context.getString(R.string.delete))
            popup.setOnMenuItemClickListener { mi ->
                when (mi.itemId) {
                    1 -> { onEdit(item); true }
                    2 -> { onDelete(item); true }
                    else -> false
                }
            }
            popup.show()
        }
    }

    override fun getItemCount(): Int = items.size
}
