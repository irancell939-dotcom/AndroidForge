package ir.khavaran.khayati;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.print.*;
import android.webkit.*;
import android.webkit.ValueCallback;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.app.DownloadManager;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.webkit.URLUtil;
import android.webkit.CookieManager;
import java.io.*;
import androidx.core.content.FileProvider;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int MAX_WAIT_MS = 45000;
    private static final int POLL_MS = 350;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9);

        Intent s = new Intent(this, KhavaranService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(Color.parseColor("#F4EDDC"));
            getWindow().setNavigationBarColor(Color.parseColor("#F4EDDC"));
        }
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(true);
        }

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        }
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= 21) {
            web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        applySystemInsetsPadding(web);

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void printPage() {
                runOnUiThread(() -> printWebView());
            }

            @JavascriptInterface
            public void shareBackupViaWhatsApp() {
                runOnUiThread(() -> MainActivity.this.shareDbBackupViaWhatsApp());
            }
        }, "KhavaranNative");

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void printPage() {
                runOnUiThread(() -> printWebView());
            }
        }, "KhayatiAndroid");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                if (url != null && url.startsWith("khavaran://share-backup")) {
                    shareDbBackupViaWhatsApp();
                    return true;
                }
                return false;
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
                String host = u.getHost() == null ? "" : u.getHost().toLowerCase();

                // اشتراک پشتیبان واتس‌اپ
                if ("khavaran".equals(scheme) && "share-backup".equals(host)) {
                    shareDbBackupViaWhatsApp();
                    return true;
                }

                // اسکنر بارکد
                if ("binaryeye".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "ابتدا Binary Eye را نصب کنید", Toast.LENGTH_LONG).show();
                    }
                    return true;
                }

                // پیامک / تماس / واتس‌اپ
                if ("sms".equals(scheme) || "smsto".equals(scheme) || "mms".equals(scheme)
                        || "mmsto".equals(scheme) || "tel".equals(scheme)
                        || "whatsapp".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "برنامه مناسب برای باز کردن این لینک پیدا نشد", Toast.LENGTH_LONG).show();
                    }
                    return true;
                }

                // لینک وب واتس‌اپ باید در اپ واتس‌اپ باز شود
                if (("http".equals(scheme) || "https".equals(scheme))
                        && ("wa.me".equals(host) || "api.whatsapp.com".equals(host) || "whatsapp.com".equals(host))) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "واتس‌اپ نصب نیست یا باز نشد", Toast.LENGTH_LONG).show();
                    }
                    return true;
                }

                if ("http".equals(scheme) || "https".equals(scheme)) {
                    if ("127.0.0.1".equals(host) || "localhost".equals(host)) return false;
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(
                    "window.print=function(){if(window.KhavaranNative){window.KhavaranNative.printPage();}else if(window.KhayatiAndroid){window.KhayatiAndroid.printPage();}};",
                    null
                );
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    // اجازه انتخاب هر فایل (db/sqlite و ...)
                    if (intent.getType() == null || "*/*".equals(intent.getType()) == false) {
                        // keep as is
                    }
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    Toast.makeText(MainActivity.this, "امکان باز کردن انتخاب فایل نیست", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });

        // دانلود فایل پشتیبان و سایر پیوست‌ها روی حافظه گوشی
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                if (fileName == null || fileName.isEmpty()) fileName = "khayati_backup.db";
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType != null ? mimeType : "application/octet-stream");
                req.addRequestHeader("User-Agent", userAgent);
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null && !cookies.isEmpty()) {
                    req.addRequestHeader("Cookie", cookies);
                }
                req.setDescription("دانلود فایل خاوران");
                req.setTitle(fileName);
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                // ذخیره در Downloads/KHAVARAN
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "KHAVARAN/" + fileName);
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                dm.enqueue(req);
                Toast.makeText(MainActivity.this, "ذخیره در Downloads/KHAVARAN: " + fileName, Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "خطا در دانلود فایل", Toast.LENGTH_LONG).show();
            }
        });
        setContentView(web);

        web.loadDataWithBaseURL(
            null,
            "<!DOCTYPE html><html dir='rtl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{margin:0;background:#f4eddc;color:#493b2e;font-family:Tahoma,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center}"
                + ".box{padding:28px}.spinner{width:42px;height:42px;border:4px solid #e9dbc0;border-top-color:#8153b8;border-radius:50%;animation:s 0.8s linear infinite;margin:0 auto 16px}"
                + "@keyframes s{to{transform:rotate(360deg)}}p{font-size:15px;line-height:1.8;margin:0}</style></head>"
                + "<body><div class='box'><div class='spinner'></div><p>در حال راه‌اندازی سرور خاوران…</p></div></body></html>",
            "text/html",
            "utf-8",
            null
        );

        new Thread(() -> {
            String url = waitForServerReady();
            runOnUiThread(() -> {
                if (url != null) {
                    web.loadUrl(url);
                } else {
                    web.loadDataWithBaseURL(
                        null,
                        "<!DOCTYPE html><html dir='rtl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                            + "<style>body{margin:0;background:#f4eddc;color:#493b2e;font-family:Tahoma,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center;padding:24px}"
                            + "p{font-size:15px;line-height:1.9}</style></head>"
                            + "<body><p>سرور برنامه راه‌اندازی نشد.<br>برنامه را ببندید و دوباره باز کنید.</p></body></html>",
                        "text/html",
                        "utf-8",
                        null
                    );
                    Toast.makeText(MainActivity.this, "خطا در راه‌اندازی سرور", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    private void applySystemInsetsPadding(final View target) {
        // سیستم با decorFitsSystemWindows(true) خودش WebView را
        // دقیقاً زیر StatusBar و بالای NavigationBar جا می‌دهد.
        // هیچ padding اضافه روی WebView نمی‌گذاریم تا دوباره‌کاری نشود.
        target.setPadding(0, 0, 0, 0);
        if (Build.VERSION.SDK_INT >= 20) {
            target.setOnApplyWindowInsetsListener((v, insets) -> insets);
            target.requestApplyInsets();
        }
    }


    private String waitForServerReady() {
        File portFile = new File(getFilesDir(), "khavaran_data/server_port.txt");
        long deadline = System.currentTimeMillis() + MAX_WAIT_MS;
        Integer port = null;

        while (System.currentTimeMillis() < deadline) {
            if (port == null && portFile.exists()) {
                try {
                    String text = readFile(portFile).trim();
                    if (!text.isEmpty()) {
                        port = Integer.parseInt(text);
                    }
                } catch (Exception ignored) {}
            }
            if (port != null) {
                String candidate = "http://127.0.0.1:" + port + "/";
                if (isServerResponding(candidate)) {
                    return candidate;
                }
            }
            try {
                Thread.sleep(POLL_MS);
            } catch (InterruptedException e) {
                break;
            }
        }
        if (port == null) {
            for (int p = 5000; p <= 5020; p++) {
                String candidate = "http://127.0.0.1:" + p + "/";
                if (isServerResponding(candidate)) return candidate;
            }
        }
        return null;
    }

    private static String readFile(File f) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private static boolean isServerResponding(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(800);
            conn.setReadTimeout(800);
            conn.setRequestMethod("GET");
            conn.setInstanceFollowRedirects(false);
            int code = conn.getResponseCode();
            return code > 0 && code < 500;
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) try { conn.disconnect(); } catch (Exception ignored) {}
        }
    }


    
    private void shareDbBackupViaWhatsApp() {
        try {
            File dbFile = findDatabaseFile();
            if (dbFile == null || !dbFile.exists() || dbFile.length() < 64) {
                Toast.makeText(this, "فایل پایگاه داده پیدا نشد. یک‌بار برنامه را باز و بسته کنید.", Toast.LENGTH_LONG).show();
                return;
            }

            String stamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US)
                    .format(new java.util.Date());
            String fileName = "khayati_backup_" + stamp + ".db";

            File shareDir = new File(getCacheDir(), "share");
            if (!shareDir.exists() && !shareDir.mkdirs()) {
                throw new IOException("cache share dir");
            }
            File shareFile = new File(shareDir, fileName);
            copyFile(dbFile, shareFile);

            // ذخیره عمومی در Downloads/KHAVARAN (بهترین تلاش)
            try {
                savePublicBackupCopy(shareFile, fileName);
            } catch (Exception ignored) {}

            Uri contentUri = FileProvider.getUriForFile(
                    this,
                    "ir.khavaran.khayati.fileprovider",
                    shareFile
            );

            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/octet-stream");
            send.putExtra(Intent.EXTRA_STREAM, contentUri);
            send.putExtra(Intent.EXTRA_SUBJECT, "پشتیبان خاوران سافت");
            send.putExtra(Intent.EXTRA_TEXT, "فایل پشتیبان خاوران سافت");
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            send.setClipData(android.content.ClipData.newUri(getContentResolver(), "backup", contentUri));

            // اعطای مجوز خواندن به همه گیرنده‌های ممکن
            java.util.List<ResolveInfo> resInfoList = getPackageManager()
                    .queryIntentActivities(send, PackageManager.MATCH_DEFAULT_ONLY);
            for (ResolveInfo ri : resInfoList) {
                grantUriPermission(ri.activityInfo.packageName, contentUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }

            Intent wa = new Intent(send);
            wa.setPackage("com.whatsapp");
            if (wa.resolveActivity(getPackageManager()) != null) {
                startActivity(wa);
            } else {
                Intent w4b = new Intent(send);
                w4b.setPackage("com.whatsapp.w4b");
                if (w4b.resolveActivity(getPackageManager()) != null) {
                    startActivity(w4b);
                } else {
                    startActivity(Intent.createChooser(send, "ارسال فایل پشتیبان"));
                }
            }
        } catch (Exception e) {
            android.util.Log.e("Khavaran", "share backup failed", e);
            Toast.makeText(this, "خطای ارسال واتس‌اپ: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void savePublicBackupCopy(File shareFile, String fileName) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/KHAVARAN");
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return;
            try (InputStream in = new FileInputStream(shareFile);
                 OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) return;
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            values.clear();
            values.put(MediaStore.Downloads.IS_PENDING, 0);
            getContentResolver().update(uri, values, null, null);
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "KHAVARAN");
            if (!dir.exists()) dir.mkdirs();
            copyFile(shareFile, new File(dir, fileName));
        }
    }

    private void copyFile(File src, File dst) throws IOException {
        try (InputStream in = new FileInputStream(src);
             OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.flush();
        }
    }

    private File findDatabaseFile() {
        try {
            File marker = new File(getFilesDir(), "khavaran_data/db_path.txt");
            if (marker.exists()) {
                String path = readFile(marker).trim();
                if (!path.isEmpty()) {
                    File f = new File(path);
                    if (f.exists() && f.length() > 64) return f;
                }
            }
        } catch (Exception ignored) {}

        File[] candidates = new File[] {
                new File(getFilesDir(), "khavaran_data/khayati.db"),
                new File(getFilesDir(), "khayati.db"),
        };
        for (File f : candidates) {
            if (f.exists() && f.length() > 64) return f;
        }
        return searchFile(getFilesDir(), "khayati.db", 0);
    }

    private File searchFile(File dir, String name, int depth) {
        if (dir == null || !dir.isDirectory() || depth > 5) return null;
        File[] kids = dir.listFiles();
        if (kids == null) return null;
        for (File k : kids) {
            if (k.isFile() && name.equals(k.getName()) && k.length() > 64) return k;
            if (k.isDirectory()) {
                File r = searchFile(k, name, depth + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    private void printWebView
() {
        if (Build.VERSION.SDK_INT >= 19) {
            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
            PrintDocumentAdapter adapter = web.createPrintDocumentAdapter("Khavaran");
            pm.print("چاپ خاوران", adapter, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A5).build());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    String dataString = data.getDataString();
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    } else if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    }
                }
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        // حفظ سرویس پس‌زمینه در صورت بسته شدن موقت
        try {
            Intent s = new Intent(this, KhavaranService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        } catch (Exception ignored) {}
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
