FactorSaz AndroidForge Gradle project. Read README-فارسی.md for build instructions.
