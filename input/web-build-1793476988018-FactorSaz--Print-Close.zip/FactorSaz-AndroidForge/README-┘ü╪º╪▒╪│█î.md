# فاکتورساز اندروید – بسته آماده AndroidForge

این پروژه به‌صورت Android Gradle ساخته شده تا AndroidForge آن را به‌عنوان پروژه Gradle شناسایی کند. هسته اصلی همان Flask فاکتورساز است و با Chaquopy درون APK اجرا می‌شود؛ رابط کاربری در WebView داخلی باز می‌شود.

## ویژگی‌های بسته
- اجرای Flask داخل خود APK و بدون نیاز به سرور اینترنتی
- نمایش صفحات در WebView داخلی، نه مرورگر خارجی
- ذخیره دیتابیس SQLite در فضای خصوصی برنامه اندروید: `files/factorsaz_data/invoices.db`
- کپی کد فعلی فاکتورساز شامل طرح‌های چاپی به مسیر `app/src/main/python/app.py`
- پشتیبانی از ARM64 و ARMv7

## بارگذاری در AndroidForge
1. کل ZIP را در بخش Upload ZIP سایت AndroidForge انتخاب کنید.
2. نوع ساخت را Android / Auto (یا Debug) بگذارید.
3. Build را اجرا کنید.
4. پس از پایان موفق، از صفحه اجرای GitHub Actions فایل Artifact با نام AndroidForge-APKs را دریافت کنید.

## نکته فنی مهم
AndroidForge طبق تشخیص پروژه، پروژه‌های Gradle و Flutter را می‌سازد؛ Buildozer به‌تنهایی جزو قالب‌های تشخیص‌داده‌شده نیست. به همین دلیل این نسخه به پروژه Gradle تبدیل شده و از Chaquopy برای اجرای Python/Flask داخل APK استفاده می‌کند.

## وابستگی‌ها
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Chaquopy 17.2.0
- Python 3.10
- Flask 3.1.2، jdatetime 5.2.0، ReportLab 4.4.4

## اصلاح خطای Python 3.11

خطای `Couldn't find Python 3.11` به این دلیل بود که محیط ساخت AndroidForge بر پایه Ubuntu 22.04 است و Python سیستم آن 3.10 می‌باشد. نسخه Chaquopy و Python برنامه اکنون روی 3.10 تنظیم شده‌اند و `buildPython` به `/usr/bin/python3` اشاره می‌کند تا نسخه میزبان و نسخه داخل APK یکسان باشند.

## وضعیت آزمایش
ساختار Gradle و فایل‌های پروژه آماده شده‌اند، اما این ZIP در این محیط روی AndroidForge اجرا/کامپایل نشده است. بنابراین APK کامپایل‌شده محسوب نمی‌شود. اگر ساخت در AndroidForge با خطای نصب یکی از بسته‌های Python (به‌ویژه ReportLab) متوقف شد، گزارش کامل Build را بفرستید تا وابستگی مربوطه را اصلاح کنم.

## پشتیبان‌گیری
برای پشتیبان‌گیری از دیتابیس، از داخل برنامه یا با خروجی پشتیبان استفاده کنید. حذف و نصب مجدد برنامه ممکن است فضای خصوصی آن را پاک کند.
