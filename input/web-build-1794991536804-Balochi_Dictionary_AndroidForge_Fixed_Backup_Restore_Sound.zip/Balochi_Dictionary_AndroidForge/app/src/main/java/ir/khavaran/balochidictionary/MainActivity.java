package ir.khavaran.balochidictionary;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_SAVE_BACKUP = 4101;
    private static final int REQUEST_OPEN_BACKUP = 4102;
    private WebView webView;
    private String pendingBackupJson = null;
    private String pendingBackupName = "balochi-backup.json";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void saveBackup(String json, String filename) {
            runOnUiThread(() -> {
                pendingBackupJson = json;
                if (filename != null && !filename.trim().isEmpty()) {
                    pendingBackupName = filename;
                }
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, pendingBackupName);
                startActivityForResult(intent, REQUEST_SAVE_BACKUP);
            });
        }

        @JavascriptInterface
        public void openBackupPicker() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json"});
                startActivityForResult(intent, REQUEST_OPEN_BACKUP);
            });
        }

        @JavascriptInterface
        public void playFeedback(boolean correct) {
            runOnUiThread(() -> {
                ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 85);
                tone.startTone(correct ? ToneGenerator.TONE_PROP_ACK : ToneGenerator.TONE_PROP_NACK, 220);
                webView.postDelayed(tone::release, 350);
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingBackupJson = null;
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQUEST_SAVE_BACKUP) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null || pendingBackupJson == null) throw new Exception("Cannot open output");
                out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                out.flush();
                Toast.makeText(this, "فایل پشتیبان ذخیره شد", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "ذخیره فایل پشتیبان ناموفق بود", Toast.LENGTH_LONG).show();
            } finally {
                pendingBackupJson = null;
            }
        } else if (requestCode == REQUEST_OPEN_BACKUP) {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                if (in == null) throw new Exception("Cannot open input");
                byte[] bytes = new byte[8192];
                int count;
                while ((count = in.read(bytes)) != -1) buffer.write(bytes, 0, count);
                String content = android.util.Base64.encodeToString(buffer.toByteArray(), android.util.Base64.NO_WRAP);
                String js = "window.handleNativeImport && window.handleNativeImport('" + content + "')";
                webView.evaluateJavascript(js, null);
            } catch (Exception e) {
                Toast.makeText(this, "خواندن فایل پشتیبان ناموفق بود", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
