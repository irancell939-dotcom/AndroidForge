import os, sqlite3, shutil
from datetime import date, datetime
from collections import deque
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file, abort
from werkzeug.utils import secure_filename

try:
    import jdatetime
except ImportError:
    jdatetime = None

APP_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(APP_DIR, "family_tree.db")
UPLOAD_DIR = os.path.join(APP_DIR, "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "zarezei-family-tree-local-secret")
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
ALLOWED = {"png", "jpg", "jpeg", "webp"}

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS people(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT DEFAULT '',
            tribe TEXT DEFAULT '',
            gender TEXT NOT NULL DEFAULT 'مرد',
            birth_date TEXT DEFAULT '',
            death_date TEXT DEFAULT '',
            is_deceased INTEGER DEFAULT 0,
            occupation TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            city TEXT DEFAULT '',
            photo TEXT DEFAULT '',
            father_id INTEGER REFERENCES people(id) ON DELETE SET NULL,
            mother_id INTEGER REFERENCES people(id) ON DELETE SET NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS marriages(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            person1_id INTEGER NOT NULL REFERENCES people(id) ON DELETE CASCADE,
            person2_id INTEGER NOT NULL REFERENCES people(id) ON DELETE CASCADE,
            marriage_date TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            UNIQUE(person1_id, person2_id),
            CHECK(person1_id <> person2_id)
        );
        CREATE INDEX IF NOT EXISTS idx_people_name ON people(first_name,last_name,tribe);
        """)

init_db()

def jalali_today():
    if jdatetime:
        return jdatetime.date.today().strftime("%Y/%m/%d")
    return date.today().strftime("%Y/%m/%d")

def parse_jalali(s):
    if not s: return None
    try:
        y, m, d = [int(x) for x in s.replace("-", "/").split("/")]
        if jdatetime:
            return jdatetime.date(y, m, d).togregorian()
        return date(y, m, d)
    except Exception:
        return None

def age_between(birth, end=None):
    b = parse_jalali(birth)
    e = parse_jalali(end) if end else date.today()
    if not b or not e: return ""
    return max(0, e.year-b.year-((e.month,e.day)<(b.month,b.day)))

def person_label(p):
    if not p: return ""
    prefix = "مرحوم " if p["is_deceased"] or p["death_date"] else ""
    return prefix + (p["first_name"] or "") + " " + (p["last_name"] or "")

def get_person(pid):
    with db() as con:
        return con.execute("SELECT * FROM people WHERE id=?", (pid,)).fetchone()

def get_people():
    with db() as con:
        return con.execute("SELECT * FROM people ORDER BY first_name COLLATE NOCASE, last_name COLLATE NOCASE").fetchall()

def marriage_rows(pid):
    with db() as con:
        return con.execute("""SELECT p.*, m.id AS marriage_id, m.marriage_date AS marriage_date
          FROM marriages m JOIN people p
          ON p.id=CASE WHEN m.person1_id=? THEN m.person2_id ELSE m.person1_id END
          WHERE m.person1_id=? OR m.person2_id=? ORDER BY p.first_name""", (pid,pid,pid)).fetchall()

def relatives(pid):
    p = get_person(pid)
    if not p: return {}
    with db() as con:
        father = con.execute("SELECT * FROM people WHERE id=?", (p["father_id"],)).fetchone() if p["father_id"] else None
        mother = con.execute("SELECT * FROM people WHERE id=?", (p["mother_id"],)).fetchone() if p["mother_id"] else None
        children = con.execute("SELECT * FROM people WHERE father_id=? OR mother_id=? ORDER BY first_name", (pid,pid)).fetchall()
        siblings = []
        if p["father_id"] or p["mother_id"]:
            siblings = con.execute("""SELECT * FROM people WHERE id<>? AND
              ((father_id IS NOT NULL AND father_id=?) OR (mother_id IS NOT NULL AND mother_id=?))
              ORDER BY first_name""", (pid,p["father_id"],p["mother_id"])).fetchall()
        pg = con.execute("SELECT * FROM people WHERE id IN (?,?)", (father["father_id"] if father else -1, father["mother_id"] if father else -1)).fetchall()
        mg = con.execute("SELECT * FROM people WHERE id IN (?,?)", (mother["father_id"] if mother else -1, mother["mother_id"] if mother else -1)).fetchall()
    return {"father":father,"mother":mother,"children":children,"siblings":siblings,
            "paternal_grandparents":pg,"maternal_grandparents":mg,"spouses":marriage_rows(pid)}

def family_count():
    people = get_people()
    graph = {p["id"]: set() for p in people}
    with db() as con:
        for m in con.execute("SELECT person1_id,person2_id FROM marriages"):
            graph[m[0]].add(m[1]); graph[m[1]].add(m[0])
        for p in people:
            for parent in (p["father_id"],p["mother_id"]):
                if parent and parent in graph:
                    graph[p["id"]].add(parent); graph[parent].add(p["id"])
    seen=set(); count=0
    for node in graph:
        if node not in seen:
            count += 1; q=[node]; seen.add(node)
            while q:
                n=q.pop()
                for nxt in graph[n]:
                    if nxt not in seen: seen.add(nxt); q.append(nxt)
    return count

def stats():
    people=get_people()
    alive=sum(not (p["is_deceased"] or p["death_date"]) for p in people)
    dead=len(people)-alive
    male=sum(p["gender"]=="مرد" for p in people)
    female=len(people)-male
    tribe_count=sum(1 for p in people if p["tribe"])
    single_m=single_f=0
    married=set()
    with db() as con:
        for r in con.execute("SELECT person1_id,person2_id FROM marriages"):
            married.update([r[0],r[1]])
    for p in people:
        age=age_between(p["birth_date"])
        if age != "" and age >= 18 and p["id"] not in married and not (p["father_id"] or p["mother_id"]):
            # Unmarried is based on recorded spouse links; parenthood does not determine marital status.
            pass
        if age != "" and age >= 18 and p["id"] not in married and not (p["is_deceased"] or p["death_date"]):
            if p["gender"]=="مرد": single_m+=1
            else: single_f+=1
    tribes=len(set(p["tribe"].strip() for p in people if p["tribe"].strip()))
    return {"total":len(people),"alive":alive,"dead":dead,"male":male,"female":female,
            "families":family_count(),"tribe_total":tribe_count,"tribes":tribes,
            "single_m":single_m,"single_f":single_f}

@app.context_processor
def inject_globals():
    return {"today_jalali":jalali_today, "person_label":person_label}

@app.route("/")
def index():
    q=request.args.get("q","").strip()
    people=get_people()
    if q:
        people=[p for p in people if q.casefold() in " ".join([p["first_name"],p["last_name"],p["tribe"],p["city"],p["phone"]]).casefold()]
    return render_template("index.html", people=people, stats=stats(), q=q)

@app.route("/person/new", methods=["GET","POST"])
def person_new():
    if request.method=="POST":
        first=request.form.get("first_name","").strip()
        if not first:
            flash("وارد کردن نام الزامی است.","error"); return redirect(url_for("person_new"))
        father_id=request.form.get("father_id") or None
        mother_id=request.form.get("mother_id") or None
        father=get_person(father_id) if father_id else None
        last=request.form.get("last_name","").strip()
        tribe=request.form.get("tribe","").strip()
        if father:
            if not last: last=father["last_name"]
            if not tribe: tribe=father["tribe"]
        photo=""
        f=request.files.get("photo")
        if f and f.filename:
            ext=f.filename.rsplit(".",1)[-1].lower()
            if ext in ALLOWED:
                name=f"{datetime.now().strftime('%Y%m%d%H%M%S%f')}.{ext}"
                f.save(os.path.join(UPLOAD_DIR,name)); photo=name
            else:
                flash("فرمت عکس باید JPG، PNG یا WEBP باشد.","error")
        deceased=1 if request.form.get("is_deceased") else 0
        death=request.form.get("death_date","").strip()
        deceased=1 if deceased or death else 0
        with db() as con:
            con.execute("""INSERT INTO people(first_name,last_name,tribe,gender,birth_date,death_date,is_deceased,
                occupation,phone,city,photo,father_id,mother_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (first,last,tribe,request.form.get("gender","مرد"),request.form.get("birth_date",""),
                 death,deceased,request.form.get("occupation","").strip(),request.form.get("phone","").strip(),
                 request.form.get("city","").strip(),photo,father_id,mother_id))
            pid=con.execute("SELECT last_insert_rowid()").fetchone()[0]
        flash("فرد با موفقیت ثبت شد.","success")
        return redirect(url_for("person_detail",pid=pid))
    people=get_people()
    surnames=sorted(set(p["last_name"] for p in people if p["last_name"]))
    tribes=sorted(set(p["tribe"] for p in people if p["tribe"]))
    return render_template("person_form.html", person=None, people=people, surnames=surnames, tribes=tribes)

@app.route("/person/<int:pid>/edit", methods=["GET","POST"])
def person_edit(pid):
    person=get_person(pid)
    if not person: abort(404)
    if request.method=="POST":
        father_id=request.form.get("father_id") or None
        father=get_person(father_id) if father_id else None
        last=request.form.get("last_name","").strip() or (father["last_name"] if father else "")
        tribe=request.form.get("tribe","").strip() or (father["tribe"] if father else "")
        death=request.form.get("death_date","").strip()
        deceased=1 if request.form.get("is_deceased") or death else 0
        photo=person["photo"]
        f=request.files.get("photo")
        if f and f.filename:
            ext=f.filename.rsplit(".",1)[-1].lower()
            if ext in ALLOWED:
                name=f"{datetime.now().strftime('%Y%m%d%H%M%S%f')}.{ext}"
                f.save(os.path.join(UPLOAD_DIR,name)); photo=name
        with db() as con:
            con.execute("""UPDATE people SET first_name=?,last_name=?,tribe=?,gender=?,birth_date=?,death_date=?,
              is_deceased=?,occupation=?,phone=?,city=?,photo=?,father_id=?,mother_id=? WHERE id=?""",
              (request.form.get("first_name","").strip(),last,tribe,request.form.get("gender","مرد"),
               request.form.get("birth_date","").strip(),death,deceased,request.form.get("occupation","").strip(),
               request.form.get("phone","").strip(),request.form.get("city","").strip(),photo,father_id,
               request.form.get("mother_id") or None,pid))
        flash("اطلاعات ویرایش شد.","success")
        return redirect(url_for("person_detail",pid=pid))
    people=[p for p in get_people() if p["id"]!=pid]
    surnames=sorted(set(p["last_name"] for p in get_people() if p["last_name"]))
    tribes=sorted(set(p["tribe"] for p in get_people() if p["tribe"]))
    return render_template("person_form.html",person=person,people=people,surnames=surnames,tribes=tribes)

@app.route("/person/<int:pid>")
def person_detail(pid):
    p=get_person(pid)
    if not p: abort(404)
    rel=relatives(pid)
    return render_template("person_detail.html",p=p,rel=rel,age=age_between(p["birth_date"],p["death_date"] if p["death_date"] else None))

@app.route("/person/<int:pid>/delete",methods=["POST"])
def person_delete(pid):
    with db() as con:
        con.execute("DELETE FROM people WHERE id=?",(pid,))
    flash("فرد حذف شد.","success")
    return redirect(url_for("index"))

@app.route("/relationships",methods=["GET","POST"])
def relationships():
    people=get_people()
    selected=request.args.get("person_id",type=int)
    if request.method=="POST":
        action=request.form.get("action")
        pid=request.form.get("person_id",type=int)
        if not get_person(pid): flash("فرد انتخاب‌شده معتبر نیست.","error"); return redirect(url_for("relationships"))
        if action=="spouse":
            sid=request.form.get("related_id",type=int)
            if sid==pid or not get_person(sid): flash("همسر انتخاب‌شده معتبر نیست.","error")
            else:
                a,b=sorted([pid,sid])
                try:
                    with db() as con: con.execute("INSERT INTO marriages(person1_id,person2_id,marriage_date,notes) VALUES(?,?,?,?)",
                        (a,b,request.form.get("marriage_date",""),request.form.get("notes","")))
                    flash("رابطه همسری ثبت شد.","success")
                except sqlite3.IntegrityError: flash("این رابطه قبلاً ثبت شده است.","error")
        elif action=="parent":
            role=request.form.get("role")
            rid=request.form.get("related_id",type=int)
            rp=get_person(rid) if rid else None
            if rid==pid or not rp: flash("فرد انتخاب‌شده معتبر نیست.","error")
            elif role=="father" and rp["gender"]!="مرد": flash("برای پدر باید فردی با جنسیت مرد انتخاب شود.","error")
            elif role=="mother" and rp["gender"]!="زن": flash("برای مادر باید فردی با جنسیت زن انتخاب شود.","error")
            else:
                child=get_person(pid)
                # Prevent direct circular ancestry.
                with db() as con:
                    col="father_id" if role=="father" else "mother_id"
                    con.execute(f"UPDATE people SET {col}=? WHERE id=?",(rid,pid))
                flash("رابطه والدین ثبت شد.","success")
        elif action=="child":
            cid=request.form.get("related_id",type=int)
            child=get_person(cid) if cid else None
            if cid==pid or not child: flash("فرزند انتخاب‌شده معتبر نیست.","error")
            else:
                role=request.form.get("role","father")
                if role=="father" and get_person(pid)["gender"]!="مرد": flash("این فرد مرد نیست و نمی‌تواند به‌عنوان پدر ثبت شود.","error")
                elif role=="mother" and get_person(pid)["gender"]!="زن": flash("این فرد زن نیست و نمی‌تواند به‌عنوان مادر ثبت شود.","error")
                else:
                    col="father_id" if role=="father" else "mother_id"
                    with db() as con: con.execute(f"UPDATE people SET {col}=? WHERE id=?",(pid,cid))
                    flash("رابطه فرزندی ثبت شد.","success")
        elif action=="remove_spouse":
            mid=request.form.get("marriage_id",type=int)
            with db() as con: con.execute("DELETE FROM marriages WHERE id=? AND (person1_id=? OR person2_id=?)",(mid,pid,pid))
            flash("رابطه همسری حذف شد.","success")
        return redirect(url_for("relationships",person_id=pid))
    selected_person=get_person(selected) if selected else None
    spouses=marriage_rows(selected) if selected_person else []
    return render_template("relationships.html",people=people,selected=selected_person,spouses=spouses)

@app.route("/relationship-path",methods=["GET","POST"])
def relationship_path():
    people=get_people(); result=None
    if request.method=="POST":
        a=request.form.get("person_a",type=int); b=request.form.get("person_b",type=int)
        if a==b: result={"text":"هر دو انتخاب مربوط به یک نفر هستند."}
        elif get_person(a) and get_person(b):
            result=find_relation(a,b)
        else: result={"text":"لطفاً هر دو نفر را انتخاب کنید."}
    return render_template("relationship_path.html",people=people,result=result)

def find_relation(a,b):
    # Build a family graph. Edges carry readable labels in both directions.
    graph={}
    def edge(x,y,label_xy,label_yx):
        graph.setdefault(x,[]).append((y,label_xy)); graph.setdefault(y,[]).append((x,label_yx))
    people={p["id"]:p for p in get_people()}
    for p in people.values():
        if p["father_id"] in people:
            edge(p["father_id"],p["id"],"پدرِ","فرزندِ")
        if p["mother_id"] in people:
            edge(p["mother_id"],p["id"],"مادرِ","فرزندِ")
    with db() as con:
        for m in con.execute("SELECT person1_id,person2_id FROM marriages"):
            edge(m[0],m[1],"همسرِ","همسرِ")
    q=deque([(a,[])]); seen={a}
    while q:
        node,path=q.popleft()
        if node==b:
            labels=[x[1] for x in path]
            # Direct paths and common patterns rendered more naturally.
            if len(path)==2 and labels==["پدرِ","فرزندِ"]: phrase="خواهر یا برادر"
            elif len(path)==2 and labels==["مادرِ","فرزندِ"]: phrase="خواهر یا برادر"
            elif len(path)==2 and labels==["فرزندِ","پدرِ"]: phrase="خواهر یا برادر"
            elif len(path)==2 and labels==["فرزندِ","مادرِ"]: phrase="خواهر یا برادر"
            elif len(path)==2 and labels[0]=="همسرِ" and labels[1]=="فرزندِ": phrase="فرزندِ همسر"
            else: phrase=" سپس ".join(labels)
            return {"text":phrase,"path":[people[a]["first_name"]+" "+people[a]["last_name"]]+[people[x[0]]["first_name"]+" "+people[x[0]]["last_name"] for x in path],"steps":labels}
        for nxt,label in graph.get(node,[]):
            if nxt not in seen:
                seen.add(nxt); q.append((nxt,path+[(nxt,label)]))
    return {"text":"با اطلاعات ثبت‌شده مسیر خویشاوندی پیدا نشد.","path":[]}

@app.route("/api/search")
def api_search():
    q=request.args.get("q","").strip().casefold()
    if len(q)<1: return jsonify([])
    out=[]
    for p in get_people():
        name=(p["first_name"]+" "+p["last_name"]+" "+p["tribe"]).casefold()
        if q in name:
            out.append({"id":p["id"],"name":person_label(p),"tribe":p["tribe"]})
        if len(out)>=12: break
    return jsonify(out)

@app.route("/backup")
def backup():
    if not os.path.exists(DB_PATH): abort(404)
    return send_file(DB_PATH,as_attachment=True,download_name="shajareh_zarezei_backup.db")

@app.route("/restore",methods=["POST"])
def restore():
    f=request.files.get("database")
    if not f or not f.filename:
        flash("فایل پشتیبان انتخاب نشده است.","error"); return redirect(url_for("index"))
    temp=os.path.join(APP_DIR,"restore_temp.db")
    f.save(temp)
    try:
        con=sqlite3.connect(temp)
        tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        con.close()
        if "people" not in tables or "marriages" not in tables: raise ValueError()
        shutil.copy2(temp,DB_PATH)
        flash("پشتیبان با موفقیت بازیابی شد.","success")
    except Exception:
        flash("فایل انتخاب‌شده پایگاه داده معتبر این برنامه نیست.","error")
    finally:
        if os.path.exists(temp): os.remove(temp)
    return redirect(url_for("index"))

@app.route("/print")
def print_all():
    people=get_people()
    return render_template("print_all.html",people=people,stats=stats())

@app.route("/manifest.json")
def manifest():
    return jsonify({"name":"شجره نامه طایفه زاره زئی","short_name":"شجره زاره زئی",
      "start_url":"/","display":"standalone","background_color":"#f5f0e6","theme_color":"#164e63",
      "icons":[{"src":"/static/icon.svg","sizes":"any","type":"image/svg+xml"}]})

@app.route("/health")
def health(): return "OK"

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)),debug=False)
