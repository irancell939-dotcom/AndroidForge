function toggleMenu(){document.getElementById('drawer').classList.toggle('open');document.getElementById('shade').classList.toggle('show')}
document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.alert').forEach(a=>setTimeout(()=>a.classList.add('hide'),4500));});
