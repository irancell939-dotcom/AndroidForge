مدیریت طلب و بدهی — بسته آماده استقرار در AndroidForge

ساختار فایل‌ها در ریشه ZIP: app.py، requirements.txt، Procfile، wsgi.py، templates/ و static/

نقطه ورود Flask: app:app (یا wsgi:application)
فرمان اجرا: gunicorn app:app --bind 0.0.0.0:$PORT

پایگاه داده SQLite با نام debts.db کنار app.py نگهداری می‌شود. پوشه‌های static/uploads و backups برای تصاویر و نسخه‌های پشتیبان هستند.

نکته مهم: فایل debts.db موجود در بسته حفظ شده و شامل داده‌های قبلی است. پیش از انتشار عمومی، مقدار SECRET_KEY و MASTER_PASSWORD را در متغیرهای محیطی AndroidForge به مقادیر محرمانه و قوی تغییر دهید. برای حفظ داده‌ها پس از استقرار، مطمئن شوید فضای ذخیره‌سازی پلتفرم پایدار (persistent) باشد؛ در غیر این صورت SQLite با استقرار مجدد ممکن است از بین برود.
