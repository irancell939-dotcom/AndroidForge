package ir.khavaran.khayati;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.print.*;
import android.webkit.*;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    WebView web;
    private static final int MAX_WAIT_MS = 45000;
    private static final int POLL_MS = 350;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9);

        Intent s = new Intent(this, KhavaranService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(Color.parseColor("#F4EDDC"));
            getWindow().setNavigationBarColor(Color.parseColor("#F4EDDC"));
        }
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(true);
        }

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= 21) {
            web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        applySystemInsetsPadding(web);

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void printPage() {
                runOnUiThread(() -> printWebView());
            }
        }, "KhavaranNative");

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void printPage() {
                runOnUiThread(() -> printWebView());
            }
        }, "KhayatiAndroid");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("binaryeye".equals(u.getScheme())) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "ابتدا Binary Eye را نصب کنید", Toast.LENGTH_LONG).show();
                    }
                    return true;
                }
                if ("http".equals(u.getScheme()) || "https".equals(u.getScheme())) {
                    if ("127.0.0.1".equals(u.getHost()) || "localhost".equals(u.getHost())) return false;
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(
                    "window.print=function(){if(window.KhavaranNative){window.KhavaranNative.printPage();}else if(window.KhayatiAndroid){window.KhayatiAndroid.printPage();}};",
                    null
                );
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);

        web.loadDataWithBaseURL(
            null,
            "<!DOCTYPE html><html dir='rtl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{margin:0;background:#f4eddc;color:#493b2e;font-family:Tahoma,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center}"
                + ".box{padding:28px}.spinner{width:42px;height:42px;border:4px solid #e9dbc0;border-top-color:#8153b8;border-radius:50%;animation:s 0.8s linear infinite;margin:0 auto 16px}"
                + "@keyframes s{to{transform:rotate(360deg)}}p{font-size:15px;line-height:1.8;margin:0}</style></head>"
                + "<body><div class='box'><div class='spinner'></div><p>در حال راه‌اندازی سرور خاوران…</p></div></body></html>",
            "text/html",
            "utf-8",
            null
        );

        new Thread(() -> {
            String url = waitForServerReady();
            runOnUiThread(() -> {
                if (url != null) {
                    web.loadUrl(url);
                } else {
                    web.loadDataWithBaseURL(
                        null,
                        "<!DOCTYPE html><html dir='rtl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                            + "<style>body{margin:0;background:#f4eddc;color:#493b2e;font-family:Tahoma,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center;padding:24px}"
                            + "p{font-size:15px;line-height:1.9}</style></head>"
                            + "<body><p>سرور برنامه راه‌اندازی نشد.<br>برنامه را ببندید و دوباره باز کنید.</p></body></html>",
                        "text/html",
                        "utf-8",
                        null
                    );
                    Toast.makeText(MainActivity.this, "خطا در راه‌اندازی سرور", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    private void applySystemInsetsPadding(final View target) {
        float density = getResources().getDisplayMetrics().density;
        final int minTop = Math.round(36 * density);
        final int minBottom = Math.round(12 * density);
        target.setPadding(0, minTop, 0, minBottom);

        if (Build.VERSION.SDK_INT >= 20) {
            target.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override
                public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                    int top = insets.getSystemWindowInsetTop();
                    int bottom = insets.getSystemWindowInsetBottom();
                    if (top < minTop) top = minTop;
                    if (bottom < minBottom) bottom = minBottom;
                    v.setPadding(0, top, 0, bottom);
                    return insets.consumeSystemWindowInsets();
                }
            });
            target.requestApplyInsets();
        }
    }

    private String waitForServerReady() {
        File portFile = new File(getFilesDir(), "khavaran_data/server_port.txt");
        long deadline = System.currentTimeMillis() + MAX_WAIT_MS;
        Integer port = null;

        while (System.currentTimeMillis() < deadline) {
            if (port == null && portFile.exists()) {
                try {
                    String text = readFile(portFile).trim();
                    if (!text.isEmpty()) {
                        port = Integer.parseInt(text);
                    }
                } catch (Exception ignored) {}
            }
            if (port != null) {
                String candidate = "http://127.0.0.1:" + port + "/";
                if (isServerResponding(candidate)) {
                    return candidate;
                }
            }
            try {
                Thread.sleep(POLL_MS);
            } catch (InterruptedException e) {
                break;
            }
        }
        if (port == null) {
            for (int p = 5000; p <= 5020; p++) {
                String candidate = "http://127.0.0.1:" + p + "/";
                if (isServerResponding(candidate)) return candidate;
            }
        }
        return null;
    }

    private static String readFile(File f) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private static boolean isServerResponding(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(800);
            conn.setReadTimeout(800);
            conn.setRequestMethod("GET");
            conn.setInstanceFollowRedirects(false);
            int code = conn.getResponseCode();
            return code > 0 && code < 500;
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) try { conn.disconnect(); } catch (Exception ignored) {}
        }
    }

    private void printWebView() {
        if (Build.VERSION.SDK_INT >= 19) {
            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
            PrintDocumentAdapter adapter = web.createPrintDocumentAdapter("Khavaran");
            pm.print("چاپ خاوران", adapter, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A5).build());
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
