package ir.khavaran.quiz;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.FrameLayout;
import android.graphics.Color;
import android.content.res.AssetManager;
import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private WebView webView;
    private ProgressBar progress;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean pageLoaded = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(20, 83, 65));
        getWindow().setNavigationBarColor(Color.rgb(15, 55, 45));

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        progress = new ProgressBar(this);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(100, 100, android.view.Gravity.CENTER);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(progress, pp);
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setLoadsImagesAutomatically(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                progress.setVisibility(View.GONE);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        startLocalGameServer();
    }

    private void startLocalGameServer() {
        progress.setVisibility(View.VISIBLE);
        new Thread(() -> {
            try {
                File gameDir = new File(getFilesDir(), "game");
                copyAssetFolder(getAssets(), "game", gameDir);
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                Python.getInstance().getModule("android_server").callAttr("start_server", gameDir.getAbsolutePath());
            } catch (Exception e) {
                final String msg = e.toString();
                handler.post(() -> showError(msg));
            }
        }).start();
        waitForServer(0);
    }

    private void waitForServer(int attempt) {
        new Thread(() -> {
            boolean ready = false;
            for (int i = 0; i < 40; i++) {
                try {
                    java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL("http://127.0.0.1:5000/").openConnection();
                    c.setConnectTimeout(500);
                    c.setReadTimeout(500);
                    c.setRequestMethod("GET");
                    ready = c.getResponseCode() == 200;
                    c.disconnect();
                    if (ready) break;
                } catch (Exception ignored) { }
                try { Thread.sleep(500); } catch (InterruptedException ignored) { }
            }
            final boolean ok = ready;
            handler.post(() -> {
                if (ok) webView.loadUrl("http://127.0.0.1:5000/");
                else showError("سرور بازی اجرا نشد. لطفاً برنامه را ببندید و دوباره باز کنید.");
            });
        }).start();
    }

    private void showError(String message) {
        progress.setVisibility(View.GONE);
        webView.loadDataWithBaseURL(null, "<html dir='rtl'><meta charset='utf-8'><body style='font-family:sans-serif;text-align:center;padding:32px'><h3>خطا در اجرای مسابقه دینی</h3><p>" + message + "</p></body></html>", "text/html", "UTF-8", null);
    }

    private void copyAssetFolder(AssetManager assetManager, String assetPath, File destination) throws IOException {
        String[] files = assetManager.list(assetPath);
        if (files == null) return;
        if (files.length == 0) {
            copyAssetFile(assetManager, assetPath, destination);
            return;
        }
        if (!destination.exists() && !destination.mkdirs()) throw new IOException("Cannot create " + destination);
        for (String name : files) {
            String childAsset = assetPath + "/" + name;
            File childDest = new File(destination, name);
            String[] children = assetManager.list(childAsset);
            if (children != null && children.length > 0) copyAssetFolder(assetManager, childAsset, childDest);
            else copyAssetFile(assetManager, childAsset, childDest);
        }
    }

    private void copyAssetFile(AssetManager assetManager, String assetPath, File destination) throws IOException {
        if (destination.exists() && destination.length() > 0) return;
        File parent = destination.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (InputStream in = assetManager.open(assetPath); FileOutputStream out = new FileOutputStream(destination)) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
