پروژه اندرویدی مسابقه دینی - نسخه اصلاح‌شده

اصلاح خطای Chaquopy:
- minSdk روی 24 تنظیم شده است؛ Chaquopy 16 به Android API 24 یا بالاتر نیاز دارد.
- فایل MainActivity.java اضافه شده است.
- سرور Flask درون گوشی اجرا می‌شود و بازی در WebView نمایش داده می‌شود.
- فایل‌های app.py، سوالات، قالب‌ها و فایل‌های CSS/JS داخل assets قرار دارند.
- آیکون اختصاصی مسابقه دینی (کتاب و هلال) اضافه شده است.

ویژگی‌ها:
- اجرای بازی داخل اپ اندروید
- اجرای Flask به صورت محلی روی گوشی
- ۱۹۵ سؤال موجود در فایل سوالات
- پنل مدیریت با رمز اولیه 1111
- نام برنامه‌نویس: محمدعمر خاوران
- شماره تماس: 09159499928

ساخت:
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Chaquopy: 16.0.0
- Python: 3.11
- compileSdk: 35
- minSdk: 24

در AndroidForge فایل ZIP را طوری استخراج کنید که settings.gradle و build.gradle مستقیماً در ریشه workspace باشند.
دستور ساخت: gradle assembleDebug

شناسه برنامه: ir.khavaran.quiz
نام نمایشی: مسابقه دینی


اصلاح تکمیلی خطای ABI در Chaquopy:
- در app/build.gradle بخش android.defaultConfig مقدار ndk.abiFilters تنظیم شده است.
- معماری‌های فعال: arm64-v8a، armeabi-v7a و x86_64.
