# -*- coding: utf-8 -*-
"""برنامه دفتر مشتریان و اندازه‌های خیاطی؛ ذخیره‌سازی محلی با SQLite."""
import os
import sys
import subprocess as _bootstrap_subprocess
from pathlib import Path as _BootstrapPath

_BOOT_DIR = _BootstrapPath(__file__).resolve().parent
if os.name == "nt":
    _venv_dir = _BOOT_DIR / ".venv"
    _venv_python = _venv_dir / "Scripts" / "python.exe"
    if not _venv_python.exists():
        try:
            _bootstrap_subprocess.run([sys.executable, "-m", "venv", str(_venv_dir)], check=True)
        except Exception:
            pass
    if _venv_python.exists() and _BootstrapPath(sys.executable).resolve() != _venv_python.resolve():
        os.execv(str(_venv_python), [str(_venv_python), str(_BootstrapPath(__file__).resolve()), *sys.argv[1:]])

try:
    import flask as _flask_check  # noqa: F401
except ImportError:
    print("در حال نصب وابستگی‌های برنامه (Flask)...")
    _install_command = [sys.executable, "-m", "pip", "install", "-r", str(_BOOT_DIR / "requirements.txt")]
    _install_result = _bootstrap_subprocess.run(_install_command)
    if _install_result.returncode:
        print("مخزن اصلی در دسترس نبود؛ مخزن جایگزین امتحان می‌شود...")
        _bootstrap_subprocess.run(
            _install_command + ["-i", "https://repo.huaweicloud.com/repository/pypi/simple"],
            check=True,
        )

from flask import Flask, render_template, request, redirect, url_for, flash, send_file, session, abort, make_response
import sqlite3
from pathlib import Path
from datetime import date, timedelta
import json
import re
import shutil
import secrets
import socket
from datetime import datetime
from decimal import Decimal, InvalidOperation
import threading
import webbrowser
from collections import OrderedDict
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.serving import make_server
import hashlib
import base64
import hmac
import platform
import smtplib
import ssl
from email.message import EmailMessage
from urllib.parse import quote, urlencode
from urllib.request import Request as URLRequest, urlopen
from urllib.error import URLError, HTTPError

CODE_DIR = Path(__file__).resolve().parent
APP_DIR = Path(os.environ.get("KHAYATI_DATA_DIR", str(CODE_DIR))).expanduser().resolve()
WEB_DIR = Path(os.environ.get("KHAYATI_WEB_DIR", str(CODE_DIR))).expanduser().resolve()
APP_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = APP_DIR / "khayati.db"
UPLOAD_DIR = APP_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)
MDB_CONFIG = APP_DIR / "mdb_mapping.json"
SMTP_PASSWORD_PATH = APP_DIR / ".smtp_password"  # رمز SMTP خارج از دیتابیس پشتیبان نگهداری می‌شود.
AMOOT_TOKEN_PATH = APP_DIR / ".amoot_token"  # توکن آموت خارج از دیتابیس پشتیبان نگهداری می‌شود.

app = Flask(__name__, template_folder=str(WEB_DIR / "templates"), static_folder=str(WEB_DIR / "static"))
_secret_path = APP_DIR / "session.secret"
if _secret_path.exists():
    app.secret_key = _secret_path.read_text(encoding="utf-8").strip()
else:
    app.secret_key = secrets.token_hex(32)
    _secret_path.write_text(app.secret_key, encoding="utf-8")
app.config["MAX_CONTENT_LENGTH"] = 250 * 1024 * 1024
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

# فیلدهایی که به پرونده دائمی مشتری و اندازه‌های او تعلق دارند.
ALL_PROFILE_FIELDS = [
    ("remarks", "ملاحظات"),
    ("fabric_meter", "متراژ پارچه"),
    ("order_quantity", "تعداد سفارش"),
    ("order_date", "تاریخ آخرین اندازه‌گیری"),
    ("height", "قد"),
    ("sleeve", "آستین"),
    ("shoulder", "شانه"),
    ("collar", "یقه"),
    ("waist", "کمر"),
    ("skirt", "دامن"),
    ("trousers", "شلوار"),
    ("hem", "دمپا"),
    ("underarm", "زیر بغل"),
    ("extra_3", "بازو"),
    ("middle", "وسط"),
    ("hem_circumference", "دور کف"),
    ("hem_model", "مدل کف"),
    ("trousers_model", "مدل شلوار"),
    ("trousers_width", "عرض شلوار"),
    ("crotch", "خشتک"),
    ("trousers_hem_model", "مدل دمپا"),
    ("pocket_model", "مدل جیب"),
    ("pocket_distance", "فاصله جیب"),
    ("pocket_height", "ارتفاع جیب"),
    ("pocket_width", "عرض جیب"),
    ("pen_holder", "جاخودکاری"),
    ("brand_type", "نوع مارک"),
    ("waist_quarter_1", "چارک کمر ۱"),
    ("waist_quarter_2", "چارک کمر ۲"),
    ("waist_quarter_3", "چارک کمر ۳"),
    ("collar_model", "مدل یقه"),
    ("pati_size", "اندازه پتی"),
    ("pati_type", "نوع پتی"),
    ("pati_button", "دکمه پتی"),
    ("extra_4", "زیر پتی"),
    ("stitch_type", "نوع دوخت"),
    ("skirt_model", "مدل دامن"),
    ("button_type", "نوع دکمه"),
    ("fabric_color", "رنگ پارچه"),
    ("description", "توضیحات"),
    ("tailor_name", "نام خیاط"),
    ("extra_1", "جیب مخفی"),
    ("extra_2", "جیب شلوار"),
    ("extra_5", "فیلد اضافی ۵"),
    ("extra_6", "فیلد اضافی ۶"),
    ("extra_7", "فیلد اضافی ۷"),
]
# فیلدهای حسابداری/تعداد و جدول سفارش از فرم جدید حذف شده‌اند.
PROFILE_FIELDS = ALL_PROFILE_FIELDS
PROFILE_META_FIELDS = [
    ("remarks", "ملاحظات"),
    ("fabric_meter", "متراژ پارچه"),
    ("order_quantity", "تعداد سفارش"),
    ("order_date", "تاریخ آخرین اندازه‌گیری"),
    ("tailor_name", "نام خیاط"),
]
MAIN_MEASUREMENTS = [
    ("height", "قد"), ("sleeve", "آستین"), ("shoulder", "شانه"),
    ("collar", "یقه"), ("waist", "کمر"), ("skirt", "دامن"),
    ("trousers", "شلوار"), ("hem", "دمپا"),
]
DETAIL_FIELDS = [
    (key, label) for key, label in PROFILE_FIELDS
    if key not in {"remarks", "fabric_meter", "order_quantity", "order_date", "tailor_name"}
    and key not in {k for k, _ in MAIN_MEASUREMENTS}
    and not key.startswith("extra_")
]
POCKET_FIELDS = [("extra_1", "جیب مخفی"), ("extra_2", "جیب شلوار")]
RESERVED_FIELDS = [(f"extra_{n}", f"فیلد اضافی {n}") for n in range(3, 8)]
ALL_EDITABLE_FIELDS = [("name", "نام مشتری"), ("mobile", "موبایل")] + PROFILE_FIELDS
ALL_EDITABLE_FIELD_KEYS = {key for key, _ in ALL_EDITABLE_FIELDS}
CUSTOMER_IMPORT_FIELDS = [("customer_code", "کد مشتری (ID از MDB)"), ("name", "نام مشتری"), ("mobile", "موبایل")]
MDB_FIELDS = CUSTOMER_IMPORT_FIELDS + PROFILE_FIELDS
PRINT_DETAIL_FIELDS = [
    (key, label) for key, label in DETAIL_FIELDS + POCKET_FIELDS + RESERVED_FIELDS
    if key not in {"pati_size", "pati_type", "pati_button", "extra_4", "pocket_distance", "pocket_height", "pocket_width", "brand_type"}
]
OPTION_FIELDS = [(key, label) for key, label in PROFILE_FIELDS if label.startswith(("مدل", "نوع"))]
OPTION_FIELD_KEYS = {key for key, _ in OPTION_FIELDS}
REQUIRED_PROFILE_KEYS = {"fabric_meter", "order_quantity", *(key for key, _ in MAIN_MEASUREMENTS)}
# کلید عمومی RSA؛ کلید خصوصی صدور مجوز خارج از برنامه و نزد صادرکننده نگهداری می‌شود.
LICENSE_PUBLIC_N = int("b72251b2071275f1eb3f386c7c1309ef669d5ca011ba1ce0d656c9a2c2abaa708101f5b7e717d51aba85c122dd817a7d3dd5f79f8a9479a86d5f8927e0bf7b5d5fc05d50a09339f07dc0533adca8934a2d7f58131b43e0a61239b2bf45071333ba1e47e88689e62d579c440837bc5f8ed6db44a8eeede96fd31d47a7e3b5adfc4cbae280d8a52f77fe7582131011bbfc9c94aa772340353ae868d2c5bd0059ebb74b56b27209dd32cd0f16b81cb2d57c2f5f0fec4e1570b06da5c70a40abd35752ebbbc9c609a712ed959fdf64d8ecb1f126c9e8d9f2f47cd84bb435f83892268d26e6b3a431c5f3ecb66b236c74ae45eb62a3dc14e3436e7344e3d9ef1b510b", 16)
LICENSE_PUBLIC_E = 65537
# کد عمومی فعال‌سازی که مالک برنامه تعیین کرده است. برای امنیت بالاتر، کد امضاشده اختصاصی توصیه می‌شود.
MASTER_REGISTRATION_CODE = "omar992810246600"
DEVELOPER_SMS_NUMBER = "09159499928"

def _device_identity_seed():
    supplied = os.environ.get("KHAYATI_DEVICE_ID", "").strip()
    if supplied:
        return "android:" + supplied
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
                return "windows:" + str(winreg.QueryValueEx(key, "MachineGuid")[0])
        except Exception:
            pass
    for candidate in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
        try:
            value = candidate.read_text(encoding="utf-8").strip()
            if value:
                return "linux:" + value
        except Exception:
            pass
    return "fallback:" + platform.node() + ":" + str(getattr(os, "getuid", lambda: 0)())


def get_installation_id():
    seed = _device_identity_seed()
    if seed and not seed.startswith("fallback:"):
        return hashlib.sha256(("KHAVARAN-SOFT|" + seed).encode("utf-8")).hexdigest()[:24].upper()
    id_path = APP_DIR / "license.installation"
    if id_path.exists():
        value = id_path.read_text(encoding="utf-8").strip().upper()
        if re.fullmatch(r"[A-F0-9]{24}", value):
            return value
    value = secrets.token_hex(12).upper()
    id_path.write_text(value, encoding="utf-8")
    return value

INSTALLATION_ID = get_installation_id()
DEFAULT_DEVICE_CODE = str(int(hashlib.sha256(("KHAVARAN-DEVICE|" + INSTALLATION_ID).encode("utf-8")).hexdigest(), 16) % (10**15)).zfill(15)
SERVER_INSTANCE = secrets.token_urlsafe(18)
_HTTP_SERVER = None


def gregorian_to_jalali(gy, gm, gd):
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
    gy2 = gy + 1 if gm > 2 else gy
    days = (355666 + 365 * gy + (gy2 + 3) // 4 - (gy2 + 99) // 100
            + (gy2 + 399) // 400 + gd + g_d_m[gm - 1])
    jy = -1595 + 33 * (days // 12053)
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    if days < 186:
        jm = 1 + days // 31
        jd = 1 + days % 31
    else:
        jm = 7 + (days - 186) // 30
        jd = 1 + (days - 186) % 30
    return jy, jm, jd


def today_jalali():
    now = date.today()
    y, m, d = gregorian_to_jalali(now.year, now.month, now.day)
    return f"{y:04d}/{m:02d}/{d:02d}"


def normalize_digits(value):
    text = str(value or "")
    return text.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))


def normalize_mobile(value):
    digits = re.sub(r"\D", "", normalize_digits(value))
    if digits.startswith("0098") and len(digits) >= 12:
        digits = "0" + digits[4:]
    elif digits.startswith("98") and len(digits) == 12:
        digits = "0" + digits[2:]
    return digits


def display_customer_code(value):
    code = str(value or "").strip()
    upper = code.upper()
    if upper.startswith("OLD-"):
        return code[4:]
    if upper.startswith("LOCAL-"):
        return code[6:]
    return code


def customer_sort_key(customer):
    code = normalize_digits(display_customer_code(customer["customer_code"] or "")).strip()
    if code.isdigit():
        return (0, int(code), int(customer["id"]))
    return (1, code.casefold(), int(customer["id"]))


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    profile_sql = ",\n".join(f'"{key}" TEXT' for key, _ in PROFILE_FIELDS)
    with get_db() as db:
        db.execute(f"""
            CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_code TEXT DEFAULT '',
                name TEXT NOT NULL,
                mobile TEXT DEFAULT '',
                {profile_sql}
            )
        """)
        customer_columns = {row[1] for row in db.execute("PRAGMA table_info(customers)").fetchall()}
        added_profile_columns = []
        for key, _ in PROFILE_FIELDS:
            if key not in customer_columns:
                db.execute(f'ALTER TABLE customers ADD COLUMN "{key}" TEXT')
                added_profile_columns.append(key)
        if "customer_code" not in customer_columns:
            db.execute("ALTER TABLE customers ADD COLUMN customer_code TEXT DEFAULT ''")
        for column in ("last_sms_text", "last_sms_at", "last_sms_type"):
            if column not in customer_columns:
                db.execute(f"ALTER TABLE customers ADD COLUMN {column} TEXT DEFAULT ''")

        # مهاجرت امن: آخرین اندازه‌های موجود هر مشتری از آخرین ردیف جدول قدیمی orders
        # به پرونده دائمی مشتری منتقل می‌شود. جدول قبلی حذف نمی‌شود تا داده‌های قدیمی محفوظ بماند.
        legacy_tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        if "orders" in legacy_tables and added_profile_columns:
            order_columns = {r[1] for r in db.execute("PRAGMA table_info(orders)").fetchall()}
            transferable = [k for k in added_profile_columns if k in order_columns]
            customer_ids = db.execute("SELECT id FROM customers ORDER BY id").fetchall()
            for c in customer_ids:
                last = db.execute("SELECT * FROM orders WHERE customer_id=? ORDER BY id DESC LIMIT 1", (c["id"],)).fetchone()
                if not last:
                    continue
                for key in transferable:
                    db.execute(f'UPDATE customers SET "{key}"=? WHERE id=?', (last[key], c["id"]))

        old_rows = db.execute("SELECT id FROM customers WHERE customer_code IS NULL OR customer_code='' ").fetchall()
        for row in old_rows:
            db.execute("UPDATE customers SET customer_code=? WHERE id=?", (f"LOCAL-{row['id']}", row["id"]))
        db.execute("""
            CREATE TABLE IF NOT EXISTS dropdown_options (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                field_key TEXT NOT NULL,
                option_value TEXT NOT NULL,
                UNIQUE(field_key, option_value)
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS daily_jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                order_day TEXT NOT NULL,
                created_at TEXT NOT NULL,
                fabric_meter TEXT DEFAULT '',
                order_quantity TEXT DEFAULT '',
                barcode TEXT DEFAULT '',
                status TEXT DEFAULT 'in_progress',
                delivered_at TEXT DEFAULT '',
                FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE
            )
        """)
        job_columns = {row[1] for row in db.execute("PRAGMA table_info(daily_jobs)").fetchall()}
        for column, definition in {
            "fabric_meter": "TEXT DEFAULT ''",
            "order_quantity": "TEXT DEFAULT ''",
            "barcode": "TEXT DEFAULT ''",
            "status": "TEXT DEFAULT 'in_progress'",
            "delivered_at": "TEXT DEFAULT ''",
            "ready_at": "TEXT DEFAULT ''",
            "sent_to_sewing_at": "TEXT DEFAULT ''",
        }.items():
            if column not in job_columns:
                db.execute(f"ALTER TABLE daily_jobs ADD COLUMN {column} {definition}")
        db.execute("CREATE INDEX IF NOT EXISTS idx_daily_jobs_day ON daily_jobs(order_day, id)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_daily_jobs_barcode ON daily_jobs(barcode)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_daily_jobs_status ON daily_jobs(status, order_day)")
        db.execute("UPDATE daily_jobs SET ready_at=? WHERE status='ready' AND (ready_at IS NULL OR ready_at='')", (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))
        db.execute("""
            CREATE TABLE IF NOT EXISTS app_settings (
                setting_key TEXT PRIMARY KEY,
                setting_value TEXT NOT NULL
            )
        """)
        db.execute("CREATE INDEX IF NOT EXISTS idx_customers_name ON customers(name)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_customers_mobile ON customers(mobile)")
        db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_customers_code_unique ON customers(customer_code) WHERE customer_code<>''")
        old_registration = db.execute("SELECT setting_value FROM app_settings WHERE setting_key='registration_completed'").fetchone()
        registration_version = db.execute("SELECT setting_value FROM app_settings WHERE setting_key='registration_version'").fetchone()
        if old_registration and old_registration[0] == "1" and (not registration_version or registration_version[0] not in {"rsa1", "owner-code-or-rsa1"}):
            db.execute("UPDATE app_settings SET setting_value='0' WHERE setting_key='registration_completed'")
        db.commit()


def form_value(key):
    return request.form.get(key, "").strip()


def get_all_field_options():
    with get_db() as db:
        rows = db.execute("SELECT field_key, option_value FROM dropdown_options ORDER BY option_value COLLATE NOCASE").fetchall()
    result = {key: [] for key, _ in OPTION_FIELDS}
    for row in rows:
        if row["field_key"] in result:
            result[row["field_key"]].append(row["option_value"])
    return result


def create_daily_job(db, customer_id, fabric_meter="", order_quantity=""):
    now = datetime.now()
    cur = db.execute(
        "INSERT INTO daily_jobs(customer_id, order_day, created_at, fabric_meter, order_quantity) VALUES(?,?,?,?,?)",
        (customer_id, today_jalali(), now.strftime("%H:%M"), fabric_meter or "", order_quantity or ""),
    )
    return cur.lastrowid


# Code 128 B symbol patterns. این بارکد بدون نیاز به سرویس اینترنتی یا کتابخانه اضافی تولید می‌شود.
_CODE128_PATTERNS = """BaBbBb|BbBaBb|BbBbBa|AbAbBc|AbAcBb|AcAbBb|AbBbAc|AbBcAb|AcBbAb|BbAbAc|BbAcAb|BcAbAb|AaBbCb|AbBaCb|AbBbCa|AaCbBb|AbCaBb|AbCbBa|BbCbAa|BbAaCb|BbAbCa|BaCbAb|BbCaAb|CaBaCa|CaAbBb|CbAaBb|CbAbBa|CaBbAb|CbBaAb|CbBbAa|BaBaBc|BaBcBa|BcBaBa|AaAcBc|AcAaBc|AcAcBa|AaBcAc|AcBaAc|AcBcAa|BaAcAc|BcAaAc|BcAcAa|AaBaCc|AaBcCa|AcBaCa|AaCaBc|AaCcBa|AcCaBa|CaCaBa|BaAcCa|BcAaCa|BaCaAc|BaCcAa|BaCaCa|CaAaBc|CaAcBa|CcAaBa|CaBaAc|CaBcAa|CcBaAa|CaDaAa|BbAdAa|DcAaAa|AaAbBd|AaAdBb|AbAaBd|AbAdBa|AdAaBb|AdAbBa|AaBbAd|AaBdAb|AbBaAd|AbBdAa|AdBaAb|AdBbAa|BdAbAa|BbAaAd|DaCaAa|BdAaAb|AcDaAa|AaAbDb|AbAaDb|AbAbDa|AaDbAb|AbDaAb|AbDbAa|DaAbAb|DbAaAb|DbAbAa|BaBaDa|BaDaBa|DaBaBa|AaAaDc|AaAcDa|AcAaDa|AaDaAc|AaDcAa|DaAaAc|DaAcAa|AaCaDa|AaDaCa|CaAaDa|DaAaCa|BaAdAb|BaAbAd|BaAbCb|BcCaAaB""".split("|")

def code128_svg(value):
    text_value = re.sub(r"[^0-9]", "", str(value or ""))
    if not text_value:
        return ""
    codes = [104] + [ord(ch) - 32 for ch in text_value]
    checksum = (104 + sum((idx + 1) * code for idx, code in enumerate(codes[1:]))) % 103
    codes.extend([checksum, 106])
    x = 10
    bars = []
    for code in codes:
        pattern = _CODE128_PATTERNS[code]
        for position, letter in enumerate(pattern):
            width = ord(letter.lower()) - ord('a') + 1
            if position % 2 == 0:
                bars.append(f'<rect x="{x}" y="0" width="{width}" height="42" fill="#000"/>')
            x += width
    total_width = x + 10
    return (f'<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="بارکد {text_value}" '
            f'viewBox="0 0 {total_width} 46" width="{total_width}mm" height="15mm" preserveAspectRatio="none">'
            + ''.join(bars) + '</svg>')


def job_barcode(db, job_id, customer):
    row = db.execute("SELECT barcode FROM daily_jobs WHERE id=?", (job_id,)).fetchone()
    if row and row["barcode"]:
        return row["barcode"]
    now = datetime.now()
    jy, jm, jd = gregorian_to_jalali(now.year, now.month, now.day)
    code = re.sub(r"\D", "", normalize_digits(display_customer_code(customer["customer_code"] or "")))
    if not code:
        code = str(customer["id"])
    value = f"{jy:04d}{jm:02d}{jd:02d}{now:%H%M}{code}"
    db.execute("UPDATE daily_jobs SET barcode=? WHERE id=?", (value, job_id))
    return value


def local_ipv4_addresses():
    found = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127."):
                found.add(ip)
    except OSError:
        pass
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(("192.0.2.1", 80))
        ip = probe.getsockname()[0]
        probe.close()
        if ip and not ip.startswith("127."):
            found.add(ip)
    except OSError:
        pass
    return sorted(found)


def build_customer_groups(customers):
    grouped = OrderedDict()
    for customer in customers:
        mobile_key = normalize_mobile(customer["mobile"])
        key = mobile_key if mobile_key else f"no-mobile-{customer['id']}"
        grouped.setdefault(key, []).append(customer)
    groups = []
    for key, members in grouped.items():
        groups.append({
            "mobile": members[0]["mobile"] or "شماره ثبت نشده",
            "normalized_mobile": "" if key.startswith("no-mobile-") else key,
            "shared": bool(key and not key.startswith("no-mobile-") and len(members) > 1),
            "customers": members,
        })
    return groups


def _ordered_main_measurements(db=None):
    close = db is None
    if db is None:
        db = get_db()
    try:
        raw = _setting(db, "main_measurement_order")
        order = json.loads(raw) if raw else []
        lookup = dict(MAIN_MEASUREMENTS)
        keys = [k for k in order if k in lookup]
        keys += [k for k, _ in MAIN_MEASUREMENTS if k not in keys]
        return [(k, lookup[k]) for k in keys]
    finally:
        if close: db.close()

def _ordered_all_fields(db=None):
    close = db is None
    if db is None: db = get_db()
    try:
        raw = _setting(db, "all_form_field_order")
        try: order = json.loads(raw) if raw else []
        except Exception: order = []
        lookup = dict(ALL_EDITABLE_FIELDS)
        keys = [k for k in order if k in lookup]
        keys += [k for k, _ in ALL_EDITABLE_FIELDS if k not in keys]
        return [(k, lookup[k]) for k in keys]
    finally:
        if close: db.close()

def _customer_form_context(customer=None, print_after_save=False, validation_error=False, job_id=""):
    with get_db() as db:
        ordered_main = _ordered_main_measurements(db)
        ordered_all = _ordered_all_fields(db)
        measurement_layout = _setting(db, "measurement_layout") or "tiles"
    return render_template(
        "form.html", customer=customer,
        profile_meta_fields=PROFILE_META_FIELDS,
        main_fields=ordered_main,
        all_fields=ordered_all,
        measurement_layout=measurement_layout,
        detail_fields=DETAIL_FIELDS,
        pocket_fields=POCKET_FIELDS,
        reserved_fields=RESERVED_FIELDS,
        print_after_save=print_after_save,
        validation_error=validation_error,
        job_id=job_id,
        today_date=today_jalali(),
        required_keys={"name", "mobile"} | REQUIRED_PROFILE_KEYS,
        main_keys={key for key, _ in MAIN_MEASUREMENTS},
        option_fields=OPTION_FIELD_KEYS,
        field_options=get_all_field_options(),
    )


def _setting(db, key):
    row = db.execute("SELECT setting_value FROM app_settings WHERE setting_key=?", (key,)).fetchone()
    return row["setting_value"] if row else ""


def _save_setting(db, key, value):
    db.execute("INSERT OR REPLACE INTO app_settings(setting_key,setting_value) VALUES(?,?)", (key, str(value)))


def make_activation_code(device_code):
    """ساخت کد درخواستی ۲۰ نویسه‌ای طبق الگوی توافق‌شده."""
    digits = re.sub(r"\D", "", normalize_digits(str(device_code or "")))
    if len(digits) != 15:
        return ""
    return digits[5:10] + "DOA" + digits[11:15] + "RE" + digits[:5] + digits[10]


def valid_device_code(device_code):
    return bool(re.fullmatch(r"\d{15}", re.sub(r"\D", "", normalize_digits(str(device_code or "")))))


def registration_code_valid(code, device_code="", now=None):
    expected = make_activation_code(device_code)
    if expected and hmac.compare_digest(str(code or "").strip().upper(), expected):
        return True
    if str(code or "").strip() == MASTER_REGISTRATION_CODE:
        return True
    """کد امضاشده و مختص شناسه نصب؛ کلید خصوصی فقط در ابزار صدور مجوزِ جداگانه نگهداری می‌شود."""
    parts = str(code or "").strip().split(".")
    if len(parts) != 3 or parts[0] != "KH1" or parts[1].upper() != INSTALLATION_ID:
        return False
    try:
        signature = base64.urlsafe_b64decode(parts[2] + "=" * (-len(parts[2]) % 4))
        key_size = (LICENSE_PUBLIC_N.bit_length() + 7) // 8
        if len(signature) != key_size:
            return False
        encoded = pow(int.from_bytes(signature, "big"), LICENSE_PUBLIC_E, LICENSE_PUBLIC_N).to_bytes(key_size, "big")
        payload = f"KHAVARAN-SOFT|LICENSE|V1|{INSTALLATION_ID}".encode("utf-8")
        digest_info = bytes.fromhex("3031300d060960864801650304020105000420") + hashlib.sha256(payload).digest()
        padding = b"\xff" * (key_size - len(digest_info) - 3)
        expected = b"\x00\x01" + padding + b"\x00" + digest_info
        return hmac.compare_digest(encoded, expected)
    except Exception:
        return False


def customer_count(db):
    return db.execute("SELECT COUNT(*) FROM customers").fetchone()[0]


def _local_request():
    host_ips = {"127.0.0.1", "::1", *local_ipv4_addresses()}
    return request.remote_addr in host_ips


@app.before_request
def require_login():
    public_endpoints = {"static", "setup_admin", "login", "health"}
    if request.endpoint in public_endpoints or request.endpoint is None:
        return None
    with get_db() as db:
        pin_hash = _setting(db, "admin_pin_hash")
    if not pin_hash:
        return redirect(url_for("setup_admin"))
    if (not session.get("khayati_authenticated") or
            session.get("server_instance") != SERVER_INSTANCE):
        session.clear()
        return redirect(url_for("login", next=request.path))

    # صفحه ثبت مجموعه همیشه قابل دسترسی است؛ پس از سقف پنج مشتری، همه مسیرهای دیگر قفل می‌شوند.
    if request.endpoint == "register_page":
        return None
    with get_db() as db:
        business_name = _setting(db, "business_name")
        registered = _setting(db, "registration_completed") == "1"
        count = customer_count(db)
    if not business_name or (count >= 5 and not registered):
        return redirect(url_for("register_page"))
    return None


@app.route("/health")
def health():
    return {"ok": True, "app": "khayati"}


@app.route("/setup", methods=["GET", "POST"])
def setup_admin():
    with get_db() as db:
        pin_hash = _setting(db, "admin_pin_hash")
    if pin_hash:
        return redirect(url_for("login"))
    if request.method == "POST":
        pin = normalize_digits(request.form.get("pin", "")).strip()
        confirm = normalize_digits(request.form.get("confirm_pin", "")).strip()
        if len(pin) < 6 or not pin.isdigit():
            flash("رمز ورود باید حداقل ۶ رقم باشد.", "error")
        elif pin != confirm:
            flash("تکرار رمز با رمز اصلی یکسان نیست.", "error")
        else:
            with get_db() as db:
                db.execute("INSERT OR REPLACE INTO app_settings(setting_key,setting_value) VALUES('admin_pin_hash',?)",
                           (generate_password_hash(pin),))
                db.commit()
            session.clear()
            session["khayati_authenticated"] = True
            session["server_instance"] = SERVER_INSTANCE
            flash("رمز مدیر با موفقیت تنظیم شد.", "success")
            return redirect(url_for("register_page"))
    return render_template("setup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    with get_db() as db:
        pin_hash = _setting(db, "admin_pin_hash")
    if not pin_hash:
        return redirect(url_for("setup_admin"))
    if request.method == "POST":
        pin = normalize_digits(request.form.get("pin", "")).strip()
        if check_password_hash(pin_hash, pin):
            session.clear()
            session["khayati_authenticated"] = True
            session["server_instance"] = SERVER_INSTANCE
            session.permanent = False
            with get_db() as db:
                has_business = bool(_setting(db, "business_name"))
                registered = _setting(db, "registration_completed") == "1"
                count = customer_count(db)
            target = request.args.get("next", "")
            if not has_business or (count >= 5 and not registered):
                target = url_for("register_page")
            elif not target.startswith("/") or target.startswith("//"):
                target = url_for("customers_page")
            return redirect(target)
        flash("رمز ورود نادرست است.", "error")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register_page():
    with get_db() as db:
        shop = {
            "business_name": _setting(db, "business_name"),
            "business_address": _setting(db, "business_address"),
            "business_phone1": _setting(db, "business_phone1"),
            "business_phone2": _setting(db, "business_phone2"),
        }
        registered = _setting(db, "registration_completed") == "1"
        count = customer_count(db)

    if request.method == "POST":
        # لوگوی اختیاری خیاطی؛ فایل در پوشه پایدار داده‌ها نگهداری می‌شود.
        logo_file = request.files.get("business_logo")
        if logo_file and logo_file.filename:
            ext = Path(logo_file.filename).suffix.lower()
            if ext not in {".png", ".jpg", ".jpeg", ".webp"}:
                flash("لوگو باید تصویر PNG، JPG یا WEBP باشد.", "error")
                return redirect(url_for("register_page"))
            logo_name = "business_logo" + ext
            logo_file.save(UPLOAD_DIR / logo_name)
            with get_db() as db:
                _save_setting(db, "business_logo", logo_name)
                db.commit()
        code = normalize_digits(request.form.get("registration_code", "")).strip().upper()
        device_code = re.sub(r"\D", "", normalize_digits(request.form.get("device_code", "")))
        if request.form.get("action") == "request_activation":
            if not shop["business_name"]:
                details = {
                    "business_name": request.form.get("business_name", "").strip(),
                    "business_address": request.form.get("business_address", "").strip(),
                    "business_phone1": normalize_digits(request.form.get("business_phone1", "")).strip(),
                    "business_phone2": normalize_digits(request.form.get("business_phone2", "")).strip(),
                }
                if not details["business_name"] or not details["business_address"] or not details["business_phone1"]:
                    flash("ابتدا نام خیاطی، آدرس و تلفن اول را تکمیل کنید.", "error")
                    return render_template("register.html", shop=details, registered=False, locked=(count >= 5), installation_id=INSTALLATION_ID, developer_phone=DEVELOPER_SMS_NUMBER, default_device_code="")
                with get_db() as db:
                    for key, value in details.items(): _save_setting(db, key, value)
                    db.commit()
                shop = details
            if not valid_device_code(device_code):
                flash("لطفاً کد IMEI سیم‌کارت ۱ را دقیقاً با ۱۵ رقم وارد کنید.", "error")
                return redirect(url_for("register_page"))
            request_message = (f"درخواست فعال‌سازی خاوران سافت\nشناسه دستگاه: {device_code}\nنام خیاطی: {shop['business_name']}\nآدرس: {shop['business_address']}\nتلفن: {shop['business_phone1']}")
            return redirect("sms:" + DEVELOPER_SMS_NUMBER + "?body=" + quote(request_message))
        if not shop["business_name"]:
            details = {
                "business_name": request.form.get("business_name", "").strip(),
                "business_address": request.form.get("business_address", "").strip(),
                "business_phone1": normalize_digits(request.form.get("business_phone1", "")).strip(),
                "business_phone2": normalize_digits(request.form.get("business_phone2", "")).strip(),
            }
            missing = [label for key, label in [
                ("business_name", "نام خیاطی"), ("business_address", "آدرس"),
                ("business_phone1", "شماره تلفن اول")
            ] if not details[key]]
            if missing:
                flash("لطفاً این موارد را تکمیل کنید: " + "، ".join(missing), "error")
                return render_template("register.html", shop=details, registered=False, locked=(count >= 5), installation_id=INSTALLATION_ID, developer_phone=DEVELOPER_SMS_NUMBER, default_device_code="")
            with get_db() as db:
                for key, value in details.items():
                    _save_setting(db, key, value)
                if code and registration_code_valid(code, device_code):
                    _save_setting(db, "registration_completed", "1")
                    _save_setting(db, "registration_version", "owner-code-or-rsa1")
                    _save_setting(db, "registration_code_hash", hashlib.sha256(code.encode("utf-8")).hexdigest())
                elif code:
                    flash("کد رجیستر معتبر نیست.", "error")
                db.commit()
            flash("اطلاعات خیاطی ثبت شد.", "success")
            with get_db() as db:
                completed_now = _setting(db, "registration_completed") == "1"
            return redirect(url_for("customers_page") if completed_now or count < 5 else url_for("register_page"))
        else:
            if registered:
                flash("ثبت برنامه قبلاً انجام شده است.", "success")
            elif registration_code_valid(code, device_code):
                with get_db() as db:
                    _save_setting(db, "registration_completed", "1")
                    _save_setting(db, "registration_version", "owner-code-or-rsa1")
                    _save_setting(db, "registration_code_hash", hashlib.sha256(code.encode("utf-8")).hexdigest())
                    db.commit()
                flash("ثبت برنامه با موفقیت انجام شد.", "success")
                return redirect(url_for("customers_page"))
            else:
                flash("کد رجیستر معتبر نیست.", "error")

    with get_db() as db:
        shop = {
            "business_name": _setting(db, "business_name"),
            "business_address": _setting(db, "business_address"),
            "business_phone1": _setting(db, "business_phone1"),
            "business_phone2": _setting(db, "business_phone2"),
        }
        registered = _setting(db, "registration_completed") == "1"
        count = customer_count(db)
    return render_template("register.html", shop=shop, registered=registered, locked=(count >= 5 and not registered), customer_total=count, installation_id=INSTALLATION_ID, developer_phone=DEVELOPER_SMS_NUMBER, default_device_code="")


@app.route("/logout", methods=["POST", "GET"])
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
def index():
    return redirect(url_for("customers_page"))


@app.route("/customers")
def customers_page():
    today = today_jalali()
    with get_db() as db:
        customers = db.execute("SELECT * FROM customers").fetchall()
        latest_status = {r["customer_id"]: dict(r) for r in db.execute("""
            SELECT j.customer_id, j.status, j.order_day, j.sent_to_sewing_at, j.ready_at, j.delivered_at FROM daily_jobs j
            JOIN (SELECT customer_id, MAX(id) AS max_id FROM daily_jobs GROUP BY customer_id) x ON x.max_id=j.id
        """).fetchall()}
        today_jobs = db.execute("""
            SELECT j.id AS job_id, j.created_at, j.fabric_meter, j.order_quantity,
                   c.id AS customer_id, c.customer_code, c.name, c.mobile
            FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
            WHERE j.order_day=? ORDER BY j.id DESC
        """, (today,)).fetchall()
        yesterday_g = date.today() - timedelta(days=1)
        jy, jm, jd = gregorian_to_jalali(yesterday_g.year, yesterday_g.month, yesterday_g.day)
        yesterday = f"{jy:04d}/{jm:02d}/{jd:02d}"
        yesterday_jobs = db.execute("""
            SELECT j.id AS job_id, j.created_at, j.fabric_meter, j.order_quantity,
                   c.id AS customer_id, c.customer_code, c.name, c.mobile
            FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
            WHERE j.order_day=? ORDER BY j.id DESC
        """, (yesterday,)).fetchall()
    customers = sorted(customers, key=customer_sort_key)
    status_labels = {"in_progress": "ارسال جهت دوخت", "ready": "آماده تحویل", "delivered": "تحویل شد"}
    def _status_date(item, customer):
        item = item or {}
        stamp = item.get("delivered_at") if item.get("status") == "delivered" else item.get("ready_at") if item.get("status") == "ready" else item.get("sent_to_sewing_at")
        try:
            d = datetime.strptime(stamp[:10], "%Y-%m-%d").date() if stamp else date.fromisoformat(item.get("order_day", ""))
            jy, jm, jd = gregorian_to_jalali(d.year, d.month, d.day)
            return f"{jy:04d}/{jm:02d}/{jd:02d}"
        except Exception:
            return customer.get("order_date") or "—"
    customers = [dict(c) | {"latest_status_label": status_labels.get(latest_status.get(c["id"], {}).get("status"), "ثبت سفارش"),
                            "latest_status_date": _status_date(latest_status.get(c["id"]), dict(c))} for c in customers]
    groups = build_customer_groups(customers)
    return render_template("customers.html", groups=groups,
                           total_customers=len(customers), main_fields=MAIN_MEASUREMENTS,
                           today=today, today_jobs=today_jobs, yesterday=yesterday, yesterday_jobs=yesterday_jobs,
                           business_name=business_name_for_sms())


@app.route("/customer/new", methods=["GET", "POST"])
def new_customer():
    if request.method == "POST":
        name = form_value("name")
        mobile = form_value("mobile")
        values = {key: form_value(key) for key, _ in PROFILE_FIELDS}
        required_missing = []
        if not name: required_missing.append("نام مشتری")
        if not mobile: required_missing.append("موبایل")
        required_missing.extend(label for key, label in MAIN_MEASUREMENTS if not values.get(key))
        required_missing.extend(label for key, label in [("fabric_meter", "متراژ پارچه"), ("order_quantity", "تعداد سفارش")] if not values.get(key))
        if required_missing:
            flash("لطفاً این قسمت‌ها را تکمیل کنید: " + "، ".join(required_missing), "error")
            form_data = {"name": name, "mobile": mobile, **values}
            return _customer_form_context(form_data, validation_error=True)
        if not values.get("order_date"):
            values["order_date"] = today_jalali()
        keys = ",".join(f'"{key}"' for key, _ in PROFILE_FIELDS)
        marks = ",".join("?" for _ in PROFILE_FIELDS)
        with get_db() as db:
            db.execute(f"INSERT INTO customers(name,mobile,{keys}) VALUES (?,?,{marks})",
                       [name, mobile] + [values[k] for k, _ in PROFILE_FIELDS])
            new_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
            db.execute("UPDATE customers SET customer_code=? WHERE id=?", (f"LOCAL-{new_id}", new_id))
            create_daily_job(db, new_id, values.get("fabric_meter", ""), values.get("order_quantity", ""))
            db.commit()
        flash("پرونده مشتری و اندازه‌های او ذخیره شد.", "success")
        return redirect(url_for("new_customer_saved", customer_id=new_id))
    return _customer_form_context(None)


@app.route("/customer/<int:customer_id>/new-saved")
def new_customer_saved(customer_id):
    with get_db() as db:
        customer = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
    if not customer:
        flash("مشتری پیدا نشد.", "error")
        return redirect(url_for("customers_page"))
    return render_template("new_customer_saved.html", customer=customer,
                           code=display_customer_code(customer["customer_code"]),
                           welcome_sms_url=url_for("prepare_customer_welcome", customer_id=customer_id))


@app.route("/sms/welcome/<int:customer_id>")
def prepare_customer_welcome(customer_id):
    with get_db() as db: row = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
    if not row or not row["mobile"]:
        flash("شماره موبایل مشتری ثبت نشده است.", "warning")
        return redirect(url_for("customers_page"))
    return render_template("sms_confirm.html", mobile=normalize_mobile(row["mobile"]),
                           message=make_customer_message(row, "welcome"), customer_name=row["name"],
                           kind="welcome", job_id="", customer_id=row["id"], whatsapp_enabled=whatsapp_is_enabled())


@app.route("/customer/<int:customer_id>/edit", methods=["GET", "POST"])
def edit_customer(customer_id):
    print_after_save = request.args.get("print_after", "") == "1" or request.form.get("print_after_save") == "1"
    active_job_id = request.form.get("job_id", "") or request.args.get("job_id", "")
    with get_db() as db:
        customer = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
        if not customer:
            flash("مشتری پیدا نشد.", "error")
            return redirect(url_for("customers_page"))
        if request.method == "POST":
            name = form_value("name")
            mobile = form_value("mobile")
            values = {key: form_value(key) for key, _ in PROFILE_FIELDS}
            required_missing = []
            if not name: required_missing.append("نام مشتری")
            if not mobile: required_missing.append("موبایل")
            required_missing.extend(label for key, label in MAIN_MEASUREMENTS if not values.get(key))
            required_missing.extend(label for key, label in [("fabric_meter", "متراژ پارچه"), ("order_quantity", "تعداد سفارش")] if not values.get(key))
            if required_missing:
                flash("لطفاً این قسمت‌ها را تکمیل کنید: " + "، ".join(required_missing), "error")
                form_data = {"name": name, "mobile": mobile, **values, "customer_code": customer["customer_code"]}
                return _customer_form_context(form_data, print_after_save, validation_error=True, job_id=request.form.get("job_id", ""))
            if not values.get("order_date"):
                values["order_date"] = today_jalali()
            assignments = ",".join(["name=?", "mobile=?"] + [f'"{key}"=?' for key, _ in PROFILE_FIELDS])
            params = [name, mobile] + [values[k] for k, _ in PROFILE_FIELDS] + [customer_id]
            db.execute(f"UPDATE customers SET {assignments} WHERE id=?", params)
            job_id = request.form.get("job_id", "").strip()
            if job_id.isdigit():
                db.execute("UPDATE daily_jobs SET fabric_meter=?, order_quantity=? WHERE id=? AND customer_id=?",
                           (values.get("fabric_meter", ""), values.get("order_quantity", ""), int(job_id), customer_id))
            db.commit()
            flash("اطلاعات و اندازه‌های مشتری به‌روز شد.", "success")
            if print_after_save:
                return redirect(url_for("print_customer", customer_id=customer_id, job_id=job_id if job_id.isdigit() else ""))
            return redirect(url_for("customers_page"))
    if request.args.get("new_visit") == "1" and request.method == "GET":
        form_data = {key: customer[key] for key in customer.keys()}
        form_data["fabric_meter"] = ""
        form_data["order_quantity"] = ""
        return _customer_form_context(form_data, print_after_save, job_id=active_job_id)
    return _customer_form_context(customer, print_after_save, job_id=active_job_id)


@app.route("/customer/<int:customer_id>/start-order", methods=["POST"])
def start_customer_order(customer_id):
    with get_db() as db:
        customer = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
        if not customer:
            flash("مشتری پیدا نشد.", "error")
            return redirect(url_for("customers_page"))
        db.execute("UPDATE customers SET order_date=? WHERE id=?", (today_jalali(), customer_id))
        job_id = create_daily_job(db, customer_id, customer["fabric_meter"], customer["order_quantity"])
        db.commit()
        customer = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
    return render_template("prepare_print.html", customer=customer,
                           code=display_customer_code(customer["customer_code"]), job_id=job_id)


@app.route("/customer/<int:customer_id>/print")
def print_customer(customer_id):
    requested_job_id = request.args.get("job_id", "")
    with get_db() as db:
        record = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
        if not record:
            flash("مشتری پیدا نشد.", "error")
            return redirect(url_for("customers_page"))
        job = None
        if requested_job_id.isdigit():
            job = db.execute("SELECT * FROM daily_jobs WHERE id=? AND customer_id=?", (int(requested_job_id), customer_id)).fetchone()
        if job is None:
            job = db.execute("SELECT * FROM daily_jobs WHERE customer_id=? AND order_day=? ORDER BY id DESC LIMIT 1",
                             (customer_id, today_jalali())).fetchone()
        if job is None:
            new_job_id = create_daily_job(db, customer_id, record["fabric_meter"], record["order_quantity"])
            job = db.execute("SELECT * FROM daily_jobs WHERE id=?", (new_job_id,)).fetchone()
        barcode_value = job_barcode(db, job["id"], record)
        db.commit()
    with get_db() as db:
        logo_name = _setting(db, "business_logo")
    with get_db() as db:
        diagram_names = {k: _setting(db, "print_diagram_" + k) for k in ("sleeve", "pocket", "pati", "trousers", "waist_slit")}
    diagram_images = {k: (url_for("uploaded_file", filename=v) if v else "") for k,v in diagram_names.items()}
    return render_template("print_order.html", record=record,
                           business_logo_url=(url_for("uploaded_file", filename=logo_name) if logo_name else ""),
                           main_fields=MAIN_MEASUREMENTS,
                           detail_fields=PRINT_DETAIL_FIELDS,
                           code=display_customer_code(record["customer_code"]),
                           barcode_value=barcode_value, barcode_svg=code128_svg(barcode_value),
                           diagram_images=diagram_images,
                           home_url=url_for("customers_page"))


@app.route("/options", methods=["GET", "POST"])
def manage_options():
    if not session.get("settings_unlocked"):
        return redirect(url_for("appearance_settings"))
    if request.method == "POST":
        action = request.form.get("action", "")
        if action == "add":
            field_key = request.form.get("field_key", "")
            value = request.form.get("option_value", "").strip()
            if field_key not in OPTION_FIELD_KEYS:
                flash("فیلد انتخاب‌شده معتبر نیست.", "error")
            elif not value:
                flash("متن گزینه را وارد کنید.", "error")
            else:
                with get_db() as db:
                    try:
                        db.execute("INSERT INTO dropdown_options(field_key, option_value) VALUES(?,?)", (field_key, value))
                        db.commit()
                        flash("گزینه جدید اضافه شد.", "success")
                    except sqlite3.IntegrityError:
                        flash("این گزینه قبلاً برای همین فیلد ثبت شده است.", "error")
        elif action == "delete":
            option_id = request.form.get("option_id", "")
            with get_db() as db:
                db.execute("DELETE FROM dropdown_options WHERE id=?", (option_id,))
                db.commit()
            flash("گزینه حذف شد. اطلاعات قبلی مشتریان تغییر نمی‌کند.", "success")
        return redirect(url_for("appearance_settings"))
    return redirect(url_for("appearance_settings"))


@app.route("/ready", methods=["GET", "POST"])
def ready_to_deliver():
    if request.method == "POST":
        action = request.form.get("action", "manual")
        if action in {"sewing_scan", "ready_scan", "deliver_scan"}:
            barcode_value = re.sub(r"\D", "", normalize_digits(request.form.get("barcode", "")))
            if not barcode_value:
                flash("بارکد خوانده نشد؛ دوباره تلاش کنید.", "error")
                return redirect(url_for("ready_to_deliver"))
            with get_db() as db:
                job = db.execute("SELECT id,status FROM daily_jobs WHERE barcode=?", (barcode_value,)).fetchone()
                if not job:
                    flash("سفارشی با این بارکد پیدا نشد.", "error")
                    return redirect(url_for("ready_to_deliver"))
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                if action == "sewing_scan":
                    if job["status"] == "delivered":
                        flash("این لباس قبلاً تحویل شده است.", "warning")
                    else:
                        db.execute("UPDATE daily_jobs SET status='in_progress', sent_to_sewing_at=? WHERE id=?", (now, job["id"]))
                        db.commit(); flash("ارسال لباس جهت دوخت ثبت شد.", "success")
                    return redirect(url_for("ready_to_deliver"))
                if action == "ready_scan":
                    if job["status"] == "delivered":
                        flash("این لباس قبلاً تحویل شده است.", "warning")
                        return redirect(url_for("ready_to_deliver"))
                    db.execute("UPDATE daily_jobs SET status='ready', ready_at=? WHERE id=?", (now, job["id"]))
                    db.commit(); flash("لباس در مغازه آماده تحویل ثبت شد.", "success")
                    return redirect(url_for("ready_to_deliver", focus=job["id"]))
                if job["status"] != "ready":
                    flash("ابتدا باید لباس در وضعیت آماده تحویل باشد.", "error")
                    return redirect(url_for("ready_to_deliver"))
                db.execute("UPDATE daily_jobs SET status='delivered', delivered_at=? WHERE id=?", (now, job["id"]))
                db.commit()
            return redirect(url_for("prepare_customer_sms", job_id=job["id"], kind="delivered"))
        if action == "deliver_scan_legacy":
            barcode_value = re.sub(r"\D", "", normalize_digits(request.form.get("barcode", "")))
            with get_db() as db:
                job = db.execute("SELECT id, status FROM daily_jobs WHERE barcode=?", (barcode_value,)).fetchone() if barcode_value else None
                if not job or job["status"] != "ready":
                    flash("بارکد متعلق به لباس آماده تحویل نیست.", "error")
                    return redirect(url_for("ready_to_deliver"))
                db.execute("UPDATE daily_jobs SET status='delivered', delivered_at=? WHERE id=?", (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), job["id"]))
                db.commit()
            return redirect(url_for("prepare_customer_sms", job_id=job["id"], kind="delivered"))
        if action == "deliver_lookup":
            lookup = normalize_digits(request.form.get("customer_lookup", "")).strip()
            with get_db() as db:
                job = db.execute("SELECT j.id,j.status FROM daily_jobs j JOIN customers c ON c.id=j.customer_id WHERE (CAST(c.id AS TEXT)=? OR c.customer_code=?) AND j.status='ready' ORDER BY j.id DESC LIMIT 1", (lookup, lookup)).fetchone()
                if not job:
                    flash("لباس آماده‌ای با این کد مشتری پیدا نشد.", "error")
                    return redirect(url_for("ready_to_deliver"))
                db.execute("UPDATE daily_jobs SET status='delivered', delivered_at=? WHERE id=?", (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), job["id"]))
                db.commit()
            return redirect(url_for("prepare_customer_sms", job_id=job["id"], kind="delivered"))
        if action == "deliver_select":
            selected = request.form.get("ready_job_id", "")
            if not selected.isdigit():
                flash("یک سفارش آماده تحویل را انتخاب کنید.", "error")
                return redirect(url_for("ready_to_deliver"))
            with get_db() as db:
                job = db.execute("SELECT id FROM daily_jobs WHERE id=? AND status='ready'", (int(selected),)).fetchone()
                if not job:
                    flash("سفارش انتخاب‌شده در فهرست آماده تحویل نیست.", "error")
                    return redirect(url_for("ready_to_deliver"))
                db.execute("UPDATE daily_jobs SET status='delivered', delivered_at=? WHERE id=?", (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), job["id"]))
                db.commit()
            return redirect(url_for("prepare_customer_sms", job_id=job["id"], kind="delivered"))
        if action == "lookup":
            lookup = normalize_digits(request.form.get("customer_lookup", "")).strip()
            with get_db() as db:
                customer = db.execute("SELECT * FROM customers WHERE CAST(id AS TEXT)=? OR customer_code=? ORDER BY id DESC LIMIT 1", (lookup, lookup)).fetchone()
                if not customer:
                    flash("کد مشتری پیدا نشد.", "error")
                    return redirect(url_for("ready_to_deliver"))
                job = db.execute("SELECT * FROM daily_jobs WHERE customer_id=? AND status='in_progress' ORDER BY id DESC LIMIT 1", (customer["id"],)).fetchone()
                job_id = job["id"] if job else create_daily_job(db, customer["id"], customer["fabric_meter"], customer["order_quantity"])
                barcode_value = job_barcode(db, job_id, customer)
                db.execute("UPDATE daily_jobs SET status='ready', ready_at=? WHERE id=?", (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), job_id))
                db.commit()
            flash(f"لباس {customer['name']} به فهرست آماده تحویل اضافه شد.", "success")
            return redirect(url_for("ready_to_deliver", focus=job_id))
        if action == "scan":
            barcode_value = re.sub(r"\D", "", normalize_digits(request.form.get("barcode", "")))
            if not barcode_value:
                flash("بارکد خوانده نشد؛ دوباره تلاش کنید.", "error")
                return redirect(url_for("ready_to_deliver"))
            with get_db() as db:
                job = db.execute("SELECT id, customer_id, status FROM daily_jobs WHERE barcode=?", (barcode_value,)).fetchone()
                if not job:
                    flash("برای این بارکد پرونده‌ای پیدا نشد. ابتدا برگه مشتری را چاپ کنید.", "error")
                elif job["status"] == "delivered":
                    flash("این لباس قبلاً تحویل مشتری شده است.", "warning")
                else:
                    db.execute("UPDATE daily_jobs SET status='ready', ready_at=? WHERE id=?", (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), job["id"]))
                    db.commit()
                    flash("اطلاعات مشتری پیدا شد و به فهرست آماده تحویل اضافه شد.", "success")
                    return redirect(url_for("ready_to_deliver", focus=job["id"]))
        else:
            customer_id = request.form.get("customer_id", "")
            if not customer_id.isdigit():
                flash("ابتدا مشتری را انتخاب کنید.", "error")
                return redirect(url_for("ready_to_deliver"))
            with get_db() as db:
                customer = db.execute("SELECT * FROM customers WHERE id=?", (int(customer_id),)).fetchone()
                if not customer:
                    flash("مشتری پیدا نشد.", "error")
                    return redirect(url_for("ready_to_deliver"))
                job = db.execute("SELECT * FROM daily_jobs WHERE customer_id=? AND status='in_progress' ORDER BY id DESC LIMIT 1", (int(customer_id),)).fetchone()
                if job is None:
                    job_id = create_daily_job(db, int(customer_id), customer["fabric_meter"], customer["order_quantity"])
                else:
                    job_id = job["id"]
                barcode_value = job_barcode(db, job_id, customer)
                db.execute("UPDATE daily_jobs SET status='ready', ready_at=? WHERE id=?", (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), job_id))
                db.commit()
            flash(f"{customer['name']} به فهرست آماده تحویل اضافه شد.", "success")
        return redirect(url_for("ready_to_deliver"))

    with get_db() as db:
        ready_jobs = db.execute("""
            SELECT j.id AS job_id, j.created_at, j.order_day, j.barcode, j.ready_at,
                   c.id AS customer_id, c.customer_code, c.name, c.mobile, c.last_sms_text, c.last_sms_at, c.last_sms_type,
                   c.fabric_meter, c.order_quantity
            FROM daily_jobs j JOIN customers c ON c.id=j.customer_id
            WHERE j.status='ready' ORDER BY j.id DESC
        """).fetchall()
        customers = db.execute("SELECT id, customer_code, name, mobile FROM customers ORDER BY name COLLATE NOCASE").fetchall()
    sms_rows = []
    for row in ready_jobs:
        ready_message = (f"آقای {row['name']} لباس شما آماده است؛ جهت تحویل به {business_name_for_sms()} مراجعه کنید.\n"
                         f"شماره تماس: {business_phones_for_sms()}\nآدرس: {business_address_for_sms()}")
        ready_stamp = row["ready_at"] or ""
        try:
            is_overdue = bool(ready_stamp) and (datetime.now() - datetime.strptime(ready_stamp, "%Y-%m-%d %H:%M:%S")).days >= 15
        except Exception:
            is_overdue = False
        reminder_message = (f"آقای {row['name']}، با سلام. لباس شما بیش از ۱۵ روز است آماده تحویل می‌باشد. لطفاً حداکثر ظرف ۱۵ روز آینده برای دریافت آن مراجعه و تسویه نمایید. با توجه به نوسانات بازار، در صورت عدم مراجعه تا پایان مهلت، لباس طبق شرایط اعلام‌شده به فروش خواهد رسید؛ یا برای نگهداری آن، مبلغ را بر اساس قیمت روز به‌روزرسانی و پرداخت کنید.\n"
                            f"خیاطی: {business_name_for_sms()}\nشماره تماس: {business_phones_for_sms()}\nآدرس: {business_address_for_sms()}")
        sms_rows.append({"job": row, "ready_sms_url": url_for("prepare_customer_sms", job_id=row["job_id"], kind="ready"),
                         "reminder_sms_url": url_for("prepare_customer_sms", job_id=row["job_id"], kind="reminder"),
                         "is_overdue": is_overdue})
    return render_template("ready.html", ready_rows=sms_rows, customers=customers,
                           focus_id=request.args.get("focus", ""))



@app.route("/customer/<int:customer_id>/message", methods=["GET", "POST"])
def customer_message(customer_id):
    with get_db() as db:
        customer = db.execute("SELECT id,name,mobile FROM customers WHERE id=?", (customer_id,)).fetchone()
        job = db.execute("SELECT id FROM daily_jobs WHERE customer_id=? ORDER BY id DESC LIMIT 1", (customer_id,)).fetchone()
    if not customer:
        flash("مشتری پیدا نشد.", "error")
        return redirect(url_for("customers_page"))
    if not customer["mobile"]:
        flash("برای این مشتری شماره موبایل ثبت نشده است.", "warning")
        return redirect(url_for("customers_page"))
    if not job:
        flash("برای این مشتری هنوز سفارشی ثبت نشده است.", "warning")
        return redirect(url_for("customers_page"))
    if request.method == "POST":
        kind = request.form.get("kind", "welcome")
        if kind not in {"eid", "welcome", "ready", "reminder", "delivered"}:
            abort(400)
        return redirect(url_for("prepare_customer_sms", job_id=job["id"], kind=kind))
    return render_template("customer_message.html", customer=customer)


@app.route("/sms/prepare/<int:job_id>/<kind>")
def prepare_customer_sms(job_id, kind):
    if kind not in {"ready", "reminder", "delivered"}: abort(404)
    with get_db() as db:
        row = db.execute("""SELECT j.*, c.id AS customer_id, c.name, c.mobile FROM daily_jobs j
                            JOIN customers c ON c.id=j.customer_id WHERE j.id=?""", (job_id,)).fetchone()
        if not row or not row["mobile"]:
            flash("برای این مشتری شماره موبایل ثبت نشده است.", "warning")
            return redirect(url_for("ready_to_deliver"))
        message = make_customer_message(row, kind)
    return render_template("sms_confirm.html", mobile=normalize_mobile(row["mobile"]), message=message,
                           customer_name=row["name"], kind=kind, job_id=job_id, customer_id=row["customer_id"], whatsapp_enabled=whatsapp_is_enabled())


def make_customer_message(row, kind):
    shop, address, phones = business_name_for_sms(), business_address_for_sms(), business_phones_for_sms()
    with get_db() as db:
        custom = _setting(db, "message_" + kind)
    if custom:
        return custom.replace("{نام}", str(row["name"] if hasattr(row, "keys") and "name" in row.keys() else "مشتری گرامی")).replace("{نام_خیاطی}", shop).replace("{آدرس}", address).replace("{تلفن}", phones)
    if kind == "eid":
        return ("مشتری گرامی، چنانچه قصد سفارش لباس برای عید را دارید، از هم‌اکنون مراجعه نمایید. "
                "در ایام نزدیک به عید به دلیل سفارشات زیاد، از پذیرفتن سفارشات معذوریم.\n"
                f"{shop}\nتلفن تماس: {phones}\nآدرس: {address}")
    if kind == "welcome":
        return f"{row['name']} عزیز، به {shop} خوش آمدید. از اعتماد شما سپاسگزاریم.\n{address}\n{phones}"
    if kind == "delivered":
        return f"{row['name']} عزیز، لباس شما در تاریخ {today_jalali()} تحویل گردید. به امید دیدار مجدد.\n{shop}\n{address}\n{phones}"
    if kind == "ready":
        return f"{row['name']} عزیز، لباس شما آماده تحویل است. لطفاً برای دریافت مراجعه فرمایید.\n{shop}\n{phones}\n{address}"
    return f"{row['name']} عزیز، لباس شما بیش از ۱۵ روز است آماده تحویل می‌باشد. لطفاً برای دریافت و تسویه مراجعه کنید. با توجه به نوسانات بازار، در صورت تأخیر بیشتر، مبلغ نگهداری بر اساس قیمت روز محاسبه خواهد شد.\n{shop}\n{phones}\n{address}"



def whatsapp_is_enabled():
    with get_db() as db:
        return _setting(db, "whatsapp_enabled") == "1"


@app.route("/sms/eid", methods=["GET", "POST"])
def eid_campaign():
    with get_db() as db:
        rows = db.execute("SELECT name,mobile FROM customers WHERE mobile IS NOT NULL AND mobile<>'' ORDER BY name").fetchall()
    phones = [normalize_mobile(r["mobile"]) for r in rows if normalize_mobile(r["mobile"])]
    message = make_customer_message({"name":"مشتری گرامی"}, "eid")
    if request.method == "POST":
        selected = request.form.getlist("mobiles")
        selected = [normalize_mobile(x) for x in selected if normalize_mobile(x)]
        if not selected:
            flash("حداقل یک مشتری را انتخاب کنید.", "warning")
            return redirect(url_for("eid_campaign"))
        text_message = request.form.get("message", message).strip()
        if request.form.get("method") == "amoot":
            token = AMOOT_TOKEN_PATH.read_text(encoding="utf-8").strip() if AMOOT_TOKEN_PATH.exists() else ""
            with get_db() as db: line = _setting(db, "amoot_line_number")
            if not token or not line:
                flash("ابتدا توکن و شماره خط آموت را در تنظیمات ثبت کنید.", "error")
                return redirect(url_for("appearance_settings"))
            sent = 0
            for phone in selected:
                payload = urlencode({"SendDateTime": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "SMSMessageText": text_message, "LineNumber": line, "Mobiles": phone}).encode("utf-8")
                req = URLRequest("https://portal.amootsms.com/rest/SendSimple", data=payload, headers={"Authorization": token, "Content-Type": "application/x-www-form-urlencoded"})
                try:
                    with urlopen(req, timeout=20) as response: result = json.loads(response.read().decode("utf-8", "replace"))
                    if str(result.get("Status", "")).lower() in {"success", "true", "1", "200"} or result.get("Data"): sent += 1
                except Exception: pass
            flash(f"درخواست ارسال آموت برای {sent} از {len(selected)} شماره ثبت شد؛ وضعیت نهایی را در پنل آموت بررسی کنید.", "success" if sent else "error")
            return redirect(url_for("customers_page"))
        return redirect("sms:" + ",".join(selected) + "?body=" + quote(text_message))
    return render_template("eid_campaign.html", rows=rows, message=message, whatsapp_enabled=whatsapp_is_enabled())

@app.route("/sms/send", methods=["POST"])
def send_customer_sms():
    mobile = re.sub(r"[^0-9+]", "", normalize_mobile(request.form.get("mobile", "")))
    message = request.form.get("message", "").strip()
    kind = request.form.get("kind", "")
    job_id = request.form.get("job_id", "")
    customer_id = request.form.get("customer_id", "")
    method = request.form.get("method", "phone")
    if not mobile or not message:
        flash("شماره یا متن پیامک خالی است.", "error")
        return redirect(url_for("ready_to_deliver"))
    if method == "amoot":
        token = AMOOT_TOKEN_PATH.read_text(encoding="utf-8").strip() if AMOOT_TOKEN_PATH.exists() else ""
        with get_db() as db: line = _setting(db, "amoot_line_number")
        if not token or not line:
            flash("توکن و شماره فرستنده آموت را در تنظیمات وارد کنید.", "error")
            return redirect(url_for("ready_to_deliver"))
        payload = urlencode({"SendDateTime": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "SMSMessageText": message, "LineNumber": line, "Mobiles": mobile}).encode("utf-8")
        req = URLRequest("https://portal.amootsms.com/rest/SendSimple", data=payload, headers={"Authorization": token, "Content-Type": "application/x-www-form-urlencoded"})
        try:
            with urlopen(req, timeout=20) as response: result = json.loads(response.read().decode("utf-8", "replace"))
            if str(result.get("Status", "")).lower() not in {"success", "true", "1", "200"} and not result.get("Data"):
                flash("پاسخ آموت: " + str(result.get("Message") or result.get("explanation") or result)[:300], "error")
                return redirect(url_for("ready_to_deliver"))
        except Exception as exc:
            flash("ارسال از آموت انجام نشد: " + str(exc)[:220], "error")
            return redirect(url_for("ready_to_deliver"))
        flash("درخواست ارسال به سامانه آموت ارسال شد. وضعیت نهایی را از پنل آموت بررسی کنید.", "success")
    else:
        # فقط پس از تأیید کاربر، برنامه پیامک گوشی را باز می‌کند؛ ارسال نهایی با خود کاربر است.
        with get_db() as db:
            customer = db.execute("SELECT id FROM customers WHERE id=?", (int(customer_id),)).fetchone() if customer_id.isdigit() else None
            if customer:
                db.execute("UPDATE customers SET last_sms_text=?, last_sms_at=?, last_sms_type=? WHERE id=?", (message, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), kind + "_prepared", customer["id"]))
                db.commit()
        return redirect("sms:" + mobile + "?body=" + quote(message))
    with get_db() as db:
        customer = db.execute("SELECT id FROM customers WHERE id=?", (int(customer_id),)).fetchone() if customer_id.isdigit() else None
        if customer:
            db.execute("UPDATE customers SET last_sms_text=?, last_sms_at=?, last_sms_type=? WHERE id=?", (message, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), kind, customer["id"]))
        db.commit()
    return redirect(url_for("ready_to_deliver"))


def business_name_for_sms():
    with get_db() as db: return _setting(db, "business_name") or "خیاطی"
def business_address_for_sms():
    with get_db() as db: return _setting(db, "business_address") or ""
def business_phones_for_sms():
    with get_db() as db:
        p1, p2 = _setting(db, "business_phone1"), _setting(db, "business_phone2")
    return " - ".join(x for x in (p1, p2) if x)


@app.route("/ready/<int:job_id>/delivered", methods=["POST"])
def mark_delivered(job_id):
    with get_db() as db:
        changed = db.execute("UPDATE daily_jobs SET status='delivered', delivered_at=? WHERE id=? AND status='ready'",
                             (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), job_id)).rowcount
        db.commit()
    if changed:
        return redirect(url_for("prepare_customer_sms", job_id=job_id, kind="delivered"))
    flash("این مورد در فهرست آماده تحویل نبود.", "warning")
    return redirect(url_for("ready_to_deliver"))



@app.route("/settings/measurement-order", methods=["POST"])
def save_measurement_order():
    if not session.get("settings_unlocked"):
        abort(403)
    data = request.get_json(silent=True) or {}
    allowed = ALL_EDITABLE_FIELD_KEYS
    order = [k for k in data.get("order", []) if k in allowed]
    order += [k for k, _ in ALL_EDITABLE_FIELDS if k not in order]
    with get_db() as db:
        _save_setting(db, "all_form_field_order", json.dumps(order, ensure_ascii=False))
        db.commit()
    return {"ok": True}

@app.route("/settings", methods=["GET", "POST"])
def appearance_settings():
    if request.method == "POST" and request.form.get("action") == "unlock_settings":
        if normalize_digits(request.form.get("settings_password", "")).strip() == "10446600":
            session["settings_unlocked"] = True
            return redirect(url_for("appearance_settings"))
        flash("رمز ورود تنظیمات نادرست است.", "error")
        return redirect(url_for("appearance_settings"))
    if not session.get("settings_unlocked"):
        return render_template("settings.html", settings_locked=True)
    if request.method == "POST":
        color = request.form.get("theme_color", "").strip()
        backup_email = request.form.get("backup_email", "").strip()
        smtp_host = request.form.get("smtp_host", "smtp.gmail.com").strip()
        smtp_port_text = normalize_digits(request.form.get("smtp_port", "587")).strip()
        smtp_username = request.form.get("smtp_username", "").strip()
        smtp_security = request.form.get("smtp_security", "starttls").strip().lower()
        smtp_password = re.sub(r"\s+", "", request.form.get("smtp_password", ""))
        clear_smtp_password = request.form.get("clear_smtp_password") == "1"
        # تصاویر راهنمای چاپ؛ فایل قبلی در صورت انتخاب‌نشدن حفظ می‌شود.
        diagram_uploads = {}
        for diagram_key, _diagram_label in (("sleeve", "آستین"), ("pocket", "جیب"), ("pati", "پتی"), ("trousers", "شلوار"), ("waist_slit", "چاک کمر")):
            uploaded_diagram = request.files.get("diagram_" + diagram_key)
            if uploaded_diagram and uploaded_diagram.filename:
                ext = Path(uploaded_diagram.filename).suffix.lower()
                if ext not in {".png", ".jpg", ".jpeg", ".webp"}:
                    flash("تصاویر نمونه باید PNG، JPG یا WEBP باشند.", "error")
                else:
                    safe_name = "print_" + diagram_key + "_" + secrets.token_hex(6) + ext
                    uploaded_diagram.save(UPLOAD_DIR / safe_name)
                    diagram_uploads[diagram_key] = safe_name
        amoot_token = request.form.get("amoot_token", "").strip()
        amoot_line_number = request.form.get("amoot_line_number", "").strip()
        clear_amoot_token = request.form.get("clear_amoot_token") == "1"
        try:
            requested_order = json.loads(request.form.get("main_measurement_order", "[]"))
        except Exception:
            requested_order = []
        allowed_order = {k for k, _ in MAIN_MEASUREMENTS}
        requested_order = [k for k in requested_order if k in allowed_order]
        requested_order += [k for k, _ in MAIN_MEASUREMENTS if k not in requested_order]
        try: all_field_order = json.loads(request.form.get("all_form_field_order", "[]"))
        except Exception: all_field_order = []
        all_field_order = [k for k in all_field_order if k in ALL_EDITABLE_FIELD_KEYS]
        all_field_order += [k for k, _ in ALL_EDITABLE_FIELDS if k not in all_field_order]
        whatsapp_code = request.form.get("whatsapp_activation_code", "")
        whatsapp_enabled = request.form.get("enable_whatsapp") == "1"
        measurement_layout = request.form.get("measurement_layout", "tiles")
        if measurement_layout not in {"tiles", "list"}: measurement_layout = "tiles"
        message_lock_code = request.form.get("message_lock_code", "")
        message_lock_ok = message_lock_code == "10346600"
        custom_messages = {k: request.form.get("msg_"+k, "").strip() for k in ("welcome","ready","delivered","reminder","eid")}
        if any(custom_messages.values()) and not message_lock_ok:
            flash("برای تغییر متن پیام‌ها، کد قفل ۱۰۳۴۶۶۰۰ را وارد کنید.", "error")
            custom_messages = {}
        errors = []
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
            errors.append("رنگ زمینه معتبر نیست.")
        if backup_email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", backup_email):
            errors.append("نشانی ایمیل مقصد معتبر نیست.")
        try:
            smtp_port = int(smtp_port_text)
            if not 1 <= smtp_port <= 65535:
                raise ValueError
        except Exception:
            smtp_port = 587
            errors.append("شماره درگاه SMTP باید بین ۱ تا ۶۵۵۳۵ باشد.")
        if smtp_security not in {"starttls", "ssl"}:
            smtp_security = "starttls"
            errors.append("نوع اتصال ایمیل معتبر نیست.")
        if backup_email and (not smtp_host or not smtp_username):
            errors.append("برای ارسال ایمیل، سرور SMTP و ایمیل فرستنده را نیز وارد کنید.")
        if errors:
            for error in errors:
                flash(error, "error")
        else:
            with get_db() as db:
                _save_setting(db, "theme_color", color.lower())
                _save_setting(db, "backup_email", backup_email)
                _save_setting(db, "smtp_host", smtp_host)
                _save_setting(db, "smtp_port", smtp_port)
                _save_setting(db, "smtp_username", smtp_username)
                _save_setting(db, "smtp_security", smtp_security)
                _save_setting(db, "amoot_line_number", amoot_line_number)
                _save_setting(db, "main_measurement_order", json.dumps(requested_order, ensure_ascii=False))
                _save_setting(db, "all_form_field_order", json.dumps(all_field_order, ensure_ascii=False))
                _save_setting(db, "measurement_layout", measurement_layout)
                for diagram_key, diagram_filename in diagram_uploads.items():
                    _save_setting(db, "print_diagram_" + diagram_key, diagram_filename)
                if whatsapp_code == "10246600":
                    _save_setting(db, "whatsapp_enabled", "1")
                elif request.form.get("disable_whatsapp") == "1":
                    _save_setting(db, "whatsapp_enabled", "0")
                elif whatsapp_enabled and _setting(db, "whatsapp_enabled") != "1":
                    flash("کد فعال‌سازی واتس‌اپ صحیح نیست؛ این قابلیت غیرفعال ماند.", "error")
                if message_lock_ok:
                    for k,v in custom_messages.items():
                        if v: _save_setting(db, "message_"+k, v)
                db.commit()
            if smtp_password:
                temp_password_path = SMTP_PASSWORD_PATH.with_name(SMTP_PASSWORD_PATH.name + ".tmp")
                temp_password_path.write_text(smtp_password, encoding="utf-8")
                try:
                    os.chmod(temp_password_path, 0o600)
                except Exception:
                    pass
                os.replace(temp_password_path, SMTP_PASSWORD_PATH)
            elif clear_smtp_password:
                SMTP_PASSWORD_PATH.unlink(missing_ok=True)
            if amoot_token:
                temp_token = AMOOT_TOKEN_PATH.with_name(AMOOT_TOKEN_PATH.name + ".tmp")
                temp_token.write_text(amoot_token, encoding="utf-8")
                try: os.chmod(temp_token, 0o600)
                except Exception: pass
                os.replace(temp_token, AMOOT_TOKEN_PATH)
            elif clear_amoot_token:
                AMOOT_TOKEN_PATH.unlink(missing_ok=True)
            flash("تنظیمات ذخیره شد.", "success")
        return redirect(url_for("appearance_settings"))
    with get_db() as db:
        settings = {
            "theme_color": _setting(db, "theme_color") or "#f4eddc",
            "backup_email": _setting(db, "backup_email"),
            "smtp_host": _setting(db, "smtp_host") or "smtp.gmail.com",
            "smtp_port": _setting(db, "smtp_port") or "587",
            "smtp_username": _setting(db, "smtp_username"),
            "smtp_security": _setting(db, "smtp_security") or "starttls",
            "amoot_line_number": _setting(db, "amoot_line_number"),
            "main_measurement_order": json.dumps([k for k,_ in _ordered_main_measurements(db)]),
            "measurement_layout": _setting(db, "measurement_layout") or "tiles",
            "main_measurement_labels": MAIN_MEASUREMENTS,
            "all_form_field_labels": _ordered_all_fields(db),
            "all_form_field_order": json.dumps([k for k, _ in _ordered_all_fields(db)]),
            "whatsapp_enabled": _setting(db, "whatsapp_enabled") == "1",
            "print_diagrams": {k: _setting(db, "print_diagram_" + k) for k in ("sleeve", "pocket", "pati", "trousers", "waist_slit")},
            "custom_messages": {k: _setting(db, "message_"+k) for k in ("welcome","ready","delivered","reminder","eid")},
        }
        option_rows = db.execute("SELECT * FROM dropdown_options ORDER BY field_key, option_value COLLATE NOCASE").fetchall()
        grouped_options = {key: [] for key, _ in OPTION_FIELDS}
        for option_row in option_rows: grouped_options[option_row["field_key"]].append(option_row)
        settings["option_fields"] = OPTION_FIELDS
        settings["grouped_options"] = grouped_options
    default_messages = {"welcome": "{نام} عزیز، به {نام_خیاطی} خوش آمدید.", "ready": "{نام} عزیز، لباس شما آماده تحویل است.", "delivered": "{نام} عزیز، لباس شما تحویل گردید. به امید دیدار مجدد. {نام_خیاطی} ـ {آدرس}", "reminder": "{نام} عزیز، لطفاً برای تحویل لباس مراجعه کنید.", "eid": "چنانچه قصد سفارش لباس برای عید را دارید از هم‌اکنون مراجعه نمایید. در روزهای نزدیک عید به دلیل سفارشات زیاد از پذیرش سفارش معذوریم. {نام_خیاطی} ـ {تلفن}"}
    return render_template("settings.html", **settings, default_messages=default_messages, smtp_password_set=SMTP_PASSWORD_PATH.exists(), amoot_token_set=AMOOT_TOKEN_PATH.exists())


@app.route("/settings/business-identity", methods=["GET", "POST"])
def business_identity_settings():
    if request.method == "POST" and not session.get("identity_settings_unlocked"):
        if normalize_digits(request.form.get("identity_code", "")).strip() == "8910000912":
            session["identity_settings_unlocked"] = True
            return redirect(url_for("business_identity_settings"))
        flash("رمز نادرست است.", "error")
        return redirect(url_for("appearance_settings"))
    if not session.get("identity_settings_unlocked"):
        abort(404)
    if request.method == "POST":
        values = {
            "business_name": request.form.get("business_name", "").strip(),
            "business_address": request.form.get("business_address", "").strip(),
            "business_phone1": normalize_digits(request.form.get("business_phone1", "")).strip(),
            "business_phone2": normalize_digits(request.form.get("business_phone2", "")).strip(),
        }
        if not values["business_name"] or not values["business_address"] or not values["business_phone1"]:
            flash("نام خیاطی، آدرس و تلفن اول الزامی است.", "error")
        else:
            with get_db() as db:
                for key, value in values.items(): _save_setting(db, key, value)
                db.commit()
            flash("مشخصات خیاطی به‌روزرسانی شد.", "success")
            return redirect(url_for("business_identity_settings"))
    with get_db() as db:
        values = {k: _setting(db, k) for k in ("business_name", "business_address", "business_phone1", "business_phone2")}
    return render_template("business_identity.html", **values)

@app.route("/exit", methods=["POST"])
def exit_app():
    global _HTTP_SERVER
    if not _local_request():
        abort(403)
    response = make_response(render_template("goodbye.html"))
    def stop_server():
        if _HTTP_SERVER is not None:
            _HTTP_SERVER.shutdown()
            return
        # در نسخه اندروید، سرور داخل ServerService اجرا می‌شود.
        controller = sys.modules.get("server_control")
        if controller is not None and hasattr(controller, "stop"):
            controller.stop()
    threading.Timer(0.7, stop_server).start()
    return response


@app.route("/connection")
def connection_info():
    ips = local_ipv4_addresses()
    return render_template("connection.html", ips=ips, port=5000)


def load_mdb_config():
    if MDB_CONFIG.exists():
        try:
            return json.loads(MDB_CONFIG.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def save_mdb_config(config):
    MDB_CONFIG.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")


def access_parser_for_file(path):
    from access_parser import AccessParser
    return AccessParser(str(path))


def access_table_rows(parser, table_name):
    """نام ستون‌ها را حتی برای جدول خالی استخراج می‌کند و شکل‌های مختلف داده را می‌پذیرد."""
    table_object = None
    raw_data = None
    # get_table علاوه بر داده، اطلاعات ستون‌های تعریف‌شده را هم دارد؛ برای جدول خالی مفید است.
    try:
        table_object = parser.get_table(table_name)
        if table_object is not None:
            raw_data = table_object.parse()
    except Exception:
        table_object = None
    if raw_data is None:
        raw_data = parser.parse_table(table_name)

    columns = []
    if isinstance(raw_data, dict):
        columns = [str(k) for k in raw_data.keys()]
    if not columns and table_object is not None:
        try:
            columns = [str(col.col_name_str) for col in table_object.columns.values()]
        except Exception:
            columns = []

    rows = []
    if isinstance(raw_data, dict) and columns:
        series = []
        for col in columns:
            value = raw_data.get(col, [])
            if isinstance(value, (list, tuple)):
                series.append(list(value))
            elif value in (None, ""):
                series.append([])
            else:
                series.append([value])
        row_count = max((len(values) for values in series), default=0)
        for row_index in range(row_count):
            row = {}
            for col, values in zip(columns, series):
                value = values[row_index] if row_index < len(values) else ""
                if value is None:
                    value = ""
                elif isinstance(value, bytes):
                    try:
                        value = value.decode("utf-8").strip("\x00")
                    except UnicodeDecodeError:
                        value = value.hex()
                else:
                    value = str(value)
                row[col] = value.strip() if isinstance(value, str) else value
            rows.append(row)
    elif isinstance(raw_data, (list, tuple)):
        for item in raw_data:
            if isinstance(item, dict):
                if not columns:
                    columns = [str(k) for k in item.keys()]
                rows.append({str(k): str(v if v is not None else "") for k, v in item.items()})
    return columns, rows


def _plain_value(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8").strip("\x00").strip()
        except UnicodeDecodeError:
            return value.hex()
    text = str(value).strip()
    # برای ID عددی، مقدارهایی مثل 27.0 به 27 تبدیل شوند.
    if re.fullmatch(r"\d+\.0+", text):
        text = text.split(".", 1)[0]
    return text


def _read_mdb_state(config, selected_table=""):
    mdb_path = UPLOAD_DIR / config.get("filename", "") if config.get("filename") else None
    if not mdb_path or not mdb_path.exists():
        return [], [], [], None
    parser = access_parser_for_file(mdb_path)
    catalog = getattr(parser, "catalog", {})
    if isinstance(catalog, dict):
        tables = [str(name) for name in catalog.keys()]
    elif isinstance(catalog, (list, tuple, set)):
        tables = [str(name) for name in catalog]
    else:
        tables = []
    tables = sorted([name for name in tables if not name.lower().startswith("msys")], key=str.casefold)
    columns, preview = [], []
    if selected_table and selected_table in tables:
        columns, rows = access_table_rows(parser, selected_table)
        preview = rows[:3]
    return tables, columns, preview, parser


@app.route("/mdb", methods=["GET", "POST"])
def mdb_mapping():
    config = load_mdb_config()
    selected_table = config.get("table", "")
    try:
        if request.method == "POST":
            action = request.form.get("action", "")
            if action == "upload":
                uploaded = request.files.get("mdb_file")
                if not uploaded or not uploaded.filename.lower().endswith((".mdb", ".accdb")):
                    flash("لطفاً یک فایل MDB یا ACCDB انتخاب کنید.", "error")
                else:
                    filename = secure_filename(uploaded.filename)
                    if not filename:
                        flash("نام فایل معتبر نیست.", "error")
                    else:
                        uploaded.save(UPLOAD_DIR / filename)
                        config = {"filename": filename, "table": "", "mapping": {}}
                        save_mdb_config(config)
                        flash("فایل بارگذاری شد. حالا جدول را انتخاب کنید.", "success")
                return redirect(url_for("mdb_mapping"))

            if action == "select_table":
                selected_table = request.form.get("table", "").strip()
                config["table"] = selected_table
                save_mdb_config(config)
                return redirect(url_for("mdb_mapping"))

        tables, columns, preview, parser = _read_mdb_state(config, selected_table)

        if request.method == "POST" and request.form.get("action") == "save_mapping":
            selected_table = request.form.get("table", selected_table).strip()
            # ستون‌ها مجدداً از خود جدول خوانده می‌شوند تا انتخاب نامعتبر ذخیره نشود.
            tables, columns, preview, parser = _read_mdb_state(config, selected_table)
            if not columns:
                flash("از جدول انتخاب‌شده ستونی استخراج نشد. لطفاً جدول دیگری را امتحان کنید.", "error")
            else:
                config["table"] = selected_table
                config["mapping"] = {key: request.form.get("map_" + key, "") for key, _ in MDB_FIELDS}
                save_mdb_config(config)
                flash("اتصال ستون‌ها ذخیره شد.", "success")
                return redirect(url_for("mdb_mapping"))

        if request.method == "POST" and request.form.get("action") == "import":
            selected_table = request.form.get("table", selected_table).strip()
            tables, columns, preview, parser = _read_mdb_state(config, selected_table)
            mapping = config.get("mapping", {})
            if not mapping.get("customer_code") or not mapping.get("name"):
                flash("ابتدا اتصال ID و نام مشتری را ذخیره کنید.", "error")
            elif not columns:
                flash("ستون‌های جدول شناسایی نشدند؛ انتقال انجام نشد.", "error")
            else:
                _, all_rows = access_table_rows(parser, selected_table)
                imported = skipped = 0
                limit_reached = False
                with get_db() as db:
                    registered_for_import = _setting(db, "registration_completed") == "1"
                    for source in all_rows:
                        code = _plain_value(source.get(mapping.get("customer_code", ""), ""))
                        name = _plain_value(source.get(mapping.get("name", ""), ""))
                        if not code or not name:
                            skipped += 1
                            continue
                        mobile = _plain_value(source.get(mapping.get("mobile", ""), "")) if mapping.get("mobile") else ""
                        field_values = {}
                        for key, _ in PROFILE_FIELDS:
                            col = mapping.get(key, "")
                            if col:
                                field_values[key] = _plain_value(source.get(col, ""))
                        if not field_values.get("order_date"):
                            field_values["order_date"] = today_jalali()
                        existing = db.execute("SELECT id FROM customers WHERE customer_code=?", (code,)).fetchone()
                        if not existing and not registered_for_import and customer_count(db) >= 5:
                            skipped += 1
                            limit_reached = True
                            continue
                        if existing:
                            cid = existing["id"]
                            updates = {"name": name, "mobile": mobile, **field_values}
                            assignment = ",".join(f'"{key}"=?' for key in updates)
                            db.execute(f"UPDATE customers SET {assignment} WHERE id=?",
                                       list(updates.values()) + [cid])
                        else:
                            insert_values = {"customer_code": code, "name": name, "mobile": mobile, **field_values}
                            # تمام ستون‌های پروفایل را وارد می‌کنیم؛ ستون‌های بدون اتصال خالی می‌مانند.
                            for key, _ in PROFILE_FIELDS:
                                insert_values.setdefault(key, "")
                            insert_keys = list(insert_values.keys())
                            quoted = ",".join(f'"{k}"' for k in insert_keys)
                            marks = ",".join("?" for _ in insert_keys)
                            db.execute(f"INSERT INTO customers({quoted}) VALUES ({marks})",
                                       [insert_values[k] for k in insert_keys])
                        imported += 1
                    db.commit()
                if limit_reached:
                    flash(f"حد مجاز ثبت مشتری در این مرحله تکمیل شد. {imported} مشتری ثبت/به‌روزرسانی شد؛ برای ادامه، کد رجیستر لازم است.", "warning")
                else:
                    flash(f"ورود اطلاعات تمام شد: {imported} مشتری ثبت/به‌روزرسانی شد؛ {skipped} ردیف بدون ID یا نام نادیده گرفته شد.", "success")
                return redirect(url_for("customers_page"))

    except ModuleNotFoundError:
        flash("کتابخانه access-parser نصب نشده است. run_app.bat را اجرا کنید تا وابستگی‌ها نصب شوند.", "error")
        tables, columns, preview = [], [], []
    except sqlite3.IntegrityError:
        flash("کد مشتری تکراری است یا با یک شناسه موجود تعارض دارد. مقدار ID در MDB را بررسی کنید.", "error")
        try:
            tables, columns, preview, _ = _read_mdb_state(config, selected_table)
        except Exception:
            tables, columns, preview = [], [], []
    except Exception as exc:
        flash(f"خواندن جدول MDB با خطا روبه‌رو شد: {exc}", "error")
        tables, columns, preview = [], [], []

    return render_template("mdb.html", config=config, tables=tables,
                           selected_table=selected_table, columns=columns,
                           preview=preview, mapping=config.get("mapping", {}),
                           fields=MDB_FIELDS)


@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_file(UPLOAD_DIR / secure_filename(filename))


@app.route("/backup")
def backup_info():
    with get_db() as db:
        backup_email = _setting(db, "backup_email")
    return render_template("backup.html", db_exists=DB_PATH.exists(), db_name=DB_PATH.name,
                           backup_email=backup_email)


@app.route("/email-backup", methods=["POST"])
def email_backup():
    """ساخت snapshot سازگار SQLite و ارسال آن به ایمیل پشتیبان از طریق SMTP."""
    with get_db() as db:
        cfg = {
            "recipient": _setting(db, "backup_email"),
            "host": _setting(db, "smtp_host") or "smtp.gmail.com",
            "port": _setting(db, "smtp_port") or "587",
            "username": _setting(db, "smtp_username"),
            "security": _setting(db, "smtp_security") or "starttls",
        }
    if not DB_PATH.exists():
        flash("فایل دیتابیس برای پشتیبان‌گیری وجود ندارد.", "error")
        return redirect(url_for("backup_info"))
    if not cfg["recipient"] or not cfg["username"] or not SMTP_PASSWORD_PATH.exists():
        flash("ابتدا ایمیل مقصد، ایمیل فرستنده و رمز اختصاصی SMTP را در صفحه تنظیمات ثبت کنید.", "error")
        return redirect(url_for("backup_info"))
    temp_backup = APP_DIR / ("email_backup_" + secrets.token_hex(8) + ".db")
    try:
        # از SQLite backup API استفاده می‌کنیم تا هنگام بازبودن برنامه نیز snapshot سالم ساخته شود.
        source_db = sqlite3.connect(str(DB_PATH), timeout=20)
        target_db = sqlite3.connect(str(temp_backup))
        try:
            source_db.backup(target_db)
        finally:
            target_db.close()
            source_db.close()
        password = SMTP_PASSWORD_PATH.read_text(encoding="utf-8")
        message = EmailMessage()
        message["Subject"] = f"نسخه پشتیبان خاوران سافت - {today_jalali()}"
        message["From"] = cfg["username"]
        message["To"] = cfg["recipient"]
        message.set_content(
            "سلام،\n\nفایل نسخه پشتیبان پایگاه داده خاوران سافت به این ایمیل پیوست شده است.\n"
            f"زمان تهیه: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            "لطفاً این فایل را در محل امن نگهداری کنید."
        )
        message.add_attachment(temp_backup.read_bytes(), maintype="application", subtype="octet-stream",
                               filename=f"khavaran_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db")
        port = int(cfg["port"])
        context = ssl.create_default_context()
        if cfg["security"] == "ssl":
            mail_server = smtplib.SMTP_SSL(cfg["host"], port, timeout=30, context=context)
        else:
            mail_server = smtplib.SMTP(cfg["host"], port, timeout=30)
        with mail_server as server:
            if cfg["security"] != "ssl":
                server.ehlo()
                server.starttls(context=context)
                server.ehlo()
            server.login(cfg["username"], password)
            server.send_message(message)
        flash("نسخه پشتیبان با موفقیت به ایمیل ثبت‌شده ارسال شد.", "success")
    except Exception as exc:
        # جزئیات فنی مفید است، اما هیچ‌گاه رمز SMTP در پیام خطا نمایش داده نمی‌شود.
        flash("ارسال ایمیل انجام نشد. تنظیمات SMTP، رمز اختصاصی و اتصال اینترنت را بررسی کنید. "
              f"جزئیات: {type(exc).__name__}: {exc}", "error")
    finally:
        temp_backup.unlink(missing_ok=True)
    return redirect(url_for("backup_info"))


@app.route("/download-backup")
def download_backup():
    if not DB_PATH.exists():
        flash("هنوز پایگاه داده‌ای ایجاد نشده است.", "error")
        return redirect(url_for("backup_info"))
    return send_file(DB_PATH, as_attachment=True, download_name="khayati_backup.db")


@app.route("/upload-database", methods=["POST"])
def upload_database():
    uploaded = request.files.get("database_file")
    if not uploaded or not uploaded.filename:
        flash("فایل پایگاه داده را انتخاب کنید.", "error")
        return redirect(url_for("backup_info"))
    filename = secure_filename(uploaded.filename)
    suffix = Path(filename).suffix.lower()
    if suffix not in {".db", ".sqlite", ".sqlite3"}:
        flash("فقط فایل پشتیبان SQLite با پسوند DB یا SQLITE پذیرفته می‌شود. برای MDB از صفحه ورود MDB استفاده کنید.", "error")
        return redirect(url_for("backup_info"))
    temp_path = APP_DIR / ("upload_" + secrets.token_hex(8) + suffix)
    try:
        uploaded.save(temp_path)
        check_db = sqlite3.connect(f"file:{temp_path.as_posix()}?mode=ro", uri=True)
        integrity = check_db.execute("PRAGMA integrity_check").fetchone()[0]
        tables = {r[0] for r in check_db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        check_db.close()
        if integrity != "ok" or "customers" not in tables:
            raise ValueError("فایل انتخاب‌شده یک پایگاه داده معتبر برنامه خیاطی نیست.")
        if DB_PATH.exists():
            backup_path = APP_DIR / f"khayati_before_upload_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
            shutil.copy2(DB_PATH, backup_path)
        os.replace(temp_path, DB_PATH)
        init_db()
        # پس از جایگزینی بانک، دوباره با رمز ثبت‌شده در همان بانک وارد شوید.
        session.clear()
        flash("پایگاه داده با موفقیت جایگزین شد. از دیتابیس قبلی نیز نسخه پشتیبان خودکار نگهداری شد؛ اکنون دوباره وارد شوید.", "success")
    except Exception as exc:
        try:
            temp_path.unlink(missing_ok=True)
        except Exception:
            pass
        flash(f"بارگذاری پایگاه داده انجام نشد: {exc}", "error")
    return redirect(url_for("customers_page"))


@app.context_processor
def inject_helpers():
    with get_db() as db:
        brand = _setting(db, "business_name") or "خیاطی"
        registered = _setting(db, "registration_completed") == "1"
        count = customer_count(db)
        has_business = bool(_setting(db, "business_name"))
        address = _setting(db, "business_address")
        phone1 = _setting(db, "business_phone1")
        phone2 = _setting(db, "business_phone2")
        theme_bg_color = _setting(db, "theme_color") or "#f4eddc"
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", theme_bg_color):
            theme_bg_color = "#f4eddc"
    return {
        "display_customer_code": display_customer_code,
        "installation_id": INSTALLATION_ID,
        "theme_bg_color": theme_bg_color,
        "business_name": brand,
        "business_address": address,
        "business_phone1": phone1,
        "business_phone2": phone2,
        "registration_locked": (not has_business or (count >= 5 and not registered)),
        "registration_pending": has_business and not registered,
        "is_local_host": _local_request(),
    }


init_db()


def _open_browser_when_ready():
    webbrowser.open("http://127.0.0.1:5000", new=2)


if __name__ == "__main__":
    print("\nخاوران سافت در حال اجراست.")
    print("نشانی برنامه: http://127.0.0.1:5000")
    print("برای خروج کامل، از منوی برنامه گزینه «خروج کامل از برنامه» را بزنید.\n")
    threading.Timer(1.2, _open_browser_when_ready).start()
    _HTTP_SERVER = make_server("0.0.0.0", 5000, app, threaded=True)
    try:
        _HTTP_SERVER.serve_forever()
    finally:
        _HTTP_SERVER.server_close()
