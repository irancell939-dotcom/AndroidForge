package com.carpetcleaning.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val address: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "orders",
    foreignKeys = [
        ForeignKey(
            entity = Customer::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("customerId")]
)
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val itemsJson: String,
    val transportCost: Long,
    val washingCost: Long = 0,
    val totalCost: Long = 0,
    val receiveDateJalali: String = "",
    val deliveryDateJalali: String,
    val status: String = "در انتظار",
    val createdAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)

data class CarpetItem(
    val type: String,
    val size: String,
    val quantity: Int,
    val areaM2: Double = 0.0,
    val unitPrice: Long = 0,
    val lineTotal: Long = 0
)

@Entity(tableName = "rates")
data class Rates(
    @PrimaryKey val id: Int = 1,
    val carpetPerM2: Long = 15000,
    val runnerPerM2: Long = 12000,
    val blanketPerPiece: Long = 80000,
    val moquettePerM2: Long = 10000,
    val gilimPerM2: Long = 14000,
    val otherPerPiece: Long = 50000
)
