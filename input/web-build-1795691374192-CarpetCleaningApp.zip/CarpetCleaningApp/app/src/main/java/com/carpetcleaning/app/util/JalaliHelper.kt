package com.carpetcleaning.app.util

import saman.zamani.persiandate.PersianDate
import saman.zamani.persiandate.PersianDateFormat
import java.util.Calendar

object JalaliHelper {

    fun todayJalali(): String {
        val pd = PersianDate()
        return format(pd)
    }

    fun format(pd: PersianDate): String {
        return String.format("%04d/%02d/%02d", pd.shYear, pd.shMonth, pd.shDay)
    }

    fun fromMillis(millis: Long): String {
        val cal = Calendar.getInstance()
        cal.timeInMillis = millis
        val pd = PersianDate(cal.time)
        return format(pd)
    }

    /** لیست روزهای یک ماه برای انتخاب ساده */
    fun daysInMonth(year: Int, month: Int): Int {
        val pd = PersianDate().initJalaliDate(year, month, 1)
        return pd.monthDays
    }

    fun getCurrentYearMonthDay(): Triple<Int, Int, Int> {
        val pd = PersianDate()
        return Triple(pd.shYear, pd.shMonth, pd.shDay)
    }
}
