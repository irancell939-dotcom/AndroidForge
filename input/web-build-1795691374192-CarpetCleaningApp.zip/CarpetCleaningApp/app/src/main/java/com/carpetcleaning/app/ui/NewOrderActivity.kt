package com.carpetcleaning.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.carpetcleaning.app.data.AppDatabase
import com.carpetcleaning.app.data.CarpetItem
import com.carpetcleaning.app.data.Order
import com.carpetcleaning.app.data.Rates
import com.carpetcleaning.app.databinding.ActivityNewOrderBinding
import com.carpetcleaning.app.databinding.ItemCarpetInputBinding
import com.carpetcleaning.app.util.JalaliHelper
import com.carpetcleaning.app.util.PersianNumberToWords
import com.carpetcleaning.app.util.PriceCalculator
import com.carpetcleaning.app.util.SmsHelper
import com.carpetcleaning.app.util.toPersianDigits
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class NewOrderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNewOrderBinding
    private lateinit var db: AppDatabase
    private var customerId: Long = -1
    private var customerName: String = ""
    private var customerPhone: String = ""
    private var rates: Rates = Rates()
    private val itemViews = mutableListOf<ItemCarpetInputBinding>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewOrderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        db = AppDatabase.getInstance(this)
        customerId = intent.getLongExtra("customerId", -1)
        if (customerId == -1L) { finish(); return }

        lifecycleScope.launch {
            val c = db.customerDao().getById(customerId)
            if (c != null) {
                customerName = c.name
                customerPhone = c.phone
                binding.tvCustomerInfo.text = "مشتری: ${c.name}  |  ${c.phone.toPersianDigits()}"
            }
            rates = db.ratesDao().get() ?: Rates()
        }

        val (y, m, d) = JalaliHelper.getCurrentYearMonthDay()
        binding.etRecvYear.setText(y.toString())
        binding.etRecvMonth.setText(m.toString())
        binding.etRecvDay.setText(d.toString())
        binding.etDelYear.setText(y.toString())
        binding.etDelMonth.setText(m.toString())
        binding.etDelDay.setText((d + 2).coerceAtMost(30).toString())

        binding.etTransport.addTextChangedListener(simpleWatcher { recalculate() })

        // نمونه پیش‌فرض مطابق درخواست کاربر
        addItemRow("فرش", "۱۲ متری", 3, 12.0)
        addItemRow("فرش", "۹ متری", 2, 9.0)
        addItemRow("کناره", "۱/۵×۵ متری", 2, 7.5)

        binding.btnAddItem.setOnClickListener { addItemRow() }
        binding.btnSave.setOnClickListener { saveOrder() }

        recalculate()
    }

    private fun addItemRow(type: String = "فرش", size: String = "", qty: Int = 1, area: Double = 0.0) {
        val itemBinding = ItemCarpetInputBinding.inflate(LayoutInflater.from(this))
        itemBinding.etType.setText(type)
        itemBinding.etSize.setText(size)
        itemBinding.etQty.setText(qty.toString())
        itemBinding.etArea.setText(if (area > 0) area.toString() else "0")
        itemBinding.btnRemove.setOnClickListener {
            binding.containerItems.removeView(itemBinding.root)
            itemViews.remove(itemBinding)
            recalculate()
        }
        val watcher = simpleWatcher { recalculate() }
        itemBinding.etType.addTextChangedListener(watcher)
        itemBinding.etQty.addTextChangedListener(watcher)
        itemBinding.etArea.addTextChangedListener(watcher)
        binding.containerItems.addView(itemBinding.root)
        itemViews.add(itemBinding)
        recalculate()
    }

    private fun collectItems(): List<CarpetItem> {
        return itemViews.mapNotNull { v ->
            val type = v.etType.text?.toString()?.trim().orEmpty()
            val size = v.etSize.text?.toString()?.trim().orEmpty()
            val qty = v.etQty.text?.toString()?.toIntOrNull() ?: 0
            val area = v.etArea.text?.toString()?.toDoubleOrNull() ?: 0.0
            if (type.isEmpty() || qty <= 0) return@mapNotNull null
            val raw = CarpetItem(type, size, qty, area)
            PriceCalculator.calculateLine(raw, rates)
        }
    }

    private fun recalculate() {
        val items = collectItems()
        val washing = PriceCalculator.totalWashing(items)
        val transport = binding.etTransport.text?.toString()?.toLongOrNull() ?: 0L
        val total = washing + transport

        binding.tvWashingCost.text = "هزینه شستشو: ${washing.toPersianDigits()} تومان"
        binding.tvTransportDisplay.text = "هزینه حمل: ${transport.toPersianDigits()} تومان"
        binding.tvTotalCost.text = "مبلغ کل: ${total.toPersianDigits()} تومان"
        binding.tvTotalWords.text = PersianNumberToWords.tomanToWords(total)

        // به‌روزرسانی هزینه هر خط
        itemViews.forEachIndexed { index, v ->
            if (index < items.size) {
                val line = items[index].lineTotal
                v.tvLineTotal.text = "هزینه این خط: ${line.toPersianDigits()} تومان"
            }
        }
    }

    private fun readDate(yearEt: android.widget.EditText, monthEt: android.widget.EditText, dayEt: android.widget.EditText): String? {
        val y = yearEt.text?.toString()?.toIntOrNull() ?: return null
        val m = monthEt.text?.toString()?.toIntOrNull() ?: return null
        val d = dayEt.text?.toString()?.toIntOrNull() ?: return null
        return String.format("%04d/%02d/%02d", y, m, d)
    }

    private fun saveOrder() {
        val items = collectItems()
        if (items.isEmpty()) {
            Toast.makeText(this, "حداقل یک آیتم وارد کنید", Toast.LENGTH_SHORT).show()
            return
        }
        val transport = binding.etTransport.text?.toString()?.toLongOrNull() ?: 0L
        val washing = PriceCalculator.totalWashing(items)
        val total = washing + transport
        val receiveDate = readDate(binding.etRecvYear, binding.etRecvMonth, binding.etRecvDay) ?: ""
        val deliveryDate = readDate(binding.etDelYear, binding.etDelMonth, binding.etDelDay)
        if (deliveryDate == null) {
            Toast.makeText(this, "تاریخ تحویل را کامل وارد کنید", Toast.LENGTH_SHORT).show()
            return
        }
        val notes = binding.etNotes.text?.toString()?.trim().orEmpty()

        val jsonArr = JSONArray()
        items.forEach { item ->
            jsonArr.put(JSONObject().apply {
                put("type", item.type)
                put("size", item.size)
                put("quantity", item.quantity)
                put("areaM2", item.areaM2)
                put("unitPrice", item.unitPrice)
                put("lineTotal", item.lineTotal)
            })
        }

        lifecycleScope.launch {
            val order = Order(
                customerId = customerId,
                itemsJson = jsonArr.toString(),
                transportCost = transport,
                washingCost = washing,
                totalCost = total,
                receiveDateJalali = receiveDate,
                deliveryDateJalali = deliveryDate,
                notes = notes
            )
            db.orderDao().insert(order)

            val itemsText = items.joinToString("\n") {
                "• ${it.quantity.toPersianDigits()} ${it.type} ${it.size}" +
                        if (it.areaM2 > 0) " (${it.areaM2} م²)" else ""
            }
            val msg = SmsHelper.orderRegisteredMessage(
                customerName, itemsText, transport, washing, total, receiveDate, deliveryDate
            )

            // انتخاب روش ارسال
            runOnUiThread {
                AlertDialog.Builder(this@NewOrderActivity)
                    .setTitle("ارسال پیام")
                    .setMessage("سفارش ذخیره شد. پیام را چگونه ارسال کنیم؟")
                    .setPositiveButton("پیامک") { _, _ ->
                        SmsHelper.sendSms(this@NewOrderActivity, customerPhone, msg)
                        finish()
                    }
                    .setNeutralButton("واتساپ") { _, _ ->
                        SmsHelper.sendWhatsApp(this@NewOrderActivity, customerPhone, msg)
                        finish()
                    }
                    .setNegativeButton("بدون ارسال") { _, _ -> finish() }
                    .show()
            }
        }
    }

    private fun simpleWatcher(after: () -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) { after() }
    }
}
