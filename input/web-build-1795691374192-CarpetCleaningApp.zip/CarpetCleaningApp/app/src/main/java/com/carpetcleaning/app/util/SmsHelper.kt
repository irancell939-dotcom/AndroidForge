package com.carpetcleaning.app.util

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.telephony.SmsManager
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

object SmsHelper {

    private const val REQUEST_SMS = 1001

    fun hasPermission(activity: Activity): Boolean {
        return ContextCompat.checkSelfPermission(
            activity, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun requestPermission(activity: Activity) {
        ActivityCompat.requestPermissions(
            activity,
            arrayOf(Manifest.permission.SEND_SMS),
            REQUEST_SMS
        )
    }

    fun sendSms(activity: Activity, phone: String, message: String): Boolean {
        if (!hasPermission(activity)) {
            requestPermission(activity)
            Toast.makeText(activity, "لطفاً مجوز ارسال پیامک را بدهید", Toast.LENGTH_LONG).show()
            return false
        }
        return try {
            val smsManager = activity.getSystemService(SmsManager::class.java)
            val parts = smsManager.divideMessage(message)
            smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
            Toast.makeText(activity, "پیامک ارسال شد", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Toast.makeText(activity, "خطا در ارسال پیامک: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    fun sendWhatsApp(activity: Activity, phone: String, message: String) {
        try {
            var normalized = phone.filter { it.isDigit() }
            if (normalized.startsWith("0")) {
                normalized = "98" + normalized.substring(1)
            } else if (!normalized.startsWith("98")) {
                normalized = "98$normalized"
            }
            val url = "https://api.whatsapp.com/send?phone=$normalized&text=${Uri.encode(message)}"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(url)
                setPackage("com.whatsapp")
            }
            if (intent.resolveActivity(activity.packageManager) != null) {
                activity.startActivity(intent)
            } else {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                activity.startActivity(browserIntent)
            }
        } catch (e: Exception) {
            Toast.makeText(activity, "خطا در باز کردن واتساپ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun deliveryMessage(customerName: String): String {
        return "سلام $customerName عزیز،\nتا ساعاتی دیگر فرش‌های شما تحویل خواهد شد.\nقالیشویی ما"
    }

    fun orderRegisteredMessage(
        customerName: String,
        itemsText: String,
        transport: Long,
        washing: Long,
        total: Long,
        receiveDate: String,
        deliveryDate: String
    ): String {
        val transportWords = PersianNumberToWords.tomanToWords(transport)
        val totalWords = PersianNumberToWords.tomanToWords(total)
        return buildString {
            append("سلام $customerName عزیز،\n")
            append("سفارش شما ثبت شد:\n")
            append(itemsText)
            append("\nهزینه شستشو: ${washing.toPersianDigits()} تومان")
            append("\nهزینه حمل: ${transport.toPersianDigits()} تومان ($transportWords)")
            append("\nمبلغ کل: ${total.toPersianDigits()} تومان ($totalWords)")
            if (receiveDate.isNotEmpty()) append("\nتاریخ دریافت: $receiveDate")
            append("\nتاریخ تحویل: $deliveryDate")
            append("\nبا تشکر - قالیشویی ما")
        }
    }
}

fun String.toPersianDigits(): String {
    val persian = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')
    val builder = StringBuilder()
    for (c in this) {
        if (c in '0'..'9') builder.append(persian[c - '0'])
        else builder.append(c)
    }
    return builder.toString()
}

fun Long.toPersianDigits(): String = this.toString().toPersianDigits()
fun Int.toPersianDigits(): String = this.toString().toPersianDigits()
