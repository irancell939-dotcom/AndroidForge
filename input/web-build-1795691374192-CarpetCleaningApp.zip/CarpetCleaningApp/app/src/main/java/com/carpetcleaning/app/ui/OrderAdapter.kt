package com.carpetcleaning.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.carpetcleaning.app.data.Order
import com.carpetcleaning.app.databinding.ItemOrderBinding
import com.carpetcleaning.app.util.PersianNumberToWords
import com.carpetcleaning.app.util.toPersianDigits
import org.json.JSONArray

class OrderAdapter(
    private val onDeliverySms: (Order) -> Unit,
    private val onDeliveryWhatsApp: (Order) -> Unit,
    private val onOrderSms: (Order) -> Unit,
    private val onOrderWhatsApp: (Order) -> Unit
) : ListAdapter<Order, OrderAdapter.VH>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Order>() {
            override fun areItemsTheSame(a: Order, b: Order) = a.id == b.id
            override fun areContentsTheSame(a: Order, b: Order) = a == b
        }
    }

    class VH(val binding: ItemOrderBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemOrderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val order = getItem(position)
        holder.binding.tvItems.text = formatItems(order.itemsJson)

        val totalWords = PersianNumberToWords.tomanToWords(order.totalCost)
        holder.binding.tvTransport.text = buildString {
            append("شستشو: ${order.washingCost.toPersianDigits()}  |  ")
            append("حمل: ${order.transportCost.toPersianDigits()}\n")
            append("کل: ${order.totalCost.toPersianDigits()} تومان ($totalWords)")
        }

        val dates = buildString {
            if (order.receiveDateJalali.isNotEmpty()) append("دریافت: ${order.receiveDateJalali}  |  ")
            append("تحویل: ${order.deliveryDateJalali}")
        }
        holder.binding.tvDate.text = dates
        holder.binding.tvStatus.text = order.status

        holder.binding.btnSmsDelivery.setOnClickListener { onDeliverySms(order) }
        holder.binding.btnSmsOrder.setOnClickListener { onOrderSms(order) }
        holder.binding.btnWaDelivery.setOnClickListener { onDeliveryWhatsApp(order) }
        holder.binding.btnWaOrder.setOnClickListener { onOrderWhatsApp(order) }
    }

    private fun formatItems(json: String): String {
        return try {
            val arr = JSONArray(json)
            val lines = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val qty = o.getInt("quantity")
                val type = o.getString("type")
                val size = o.optString("size", "")
                val area = o.optDouble("areaM2", 0.0)
                val line = o.optLong("lineTotal", 0)
                var text = "${qty.toPersianDigits()} $type $size"
                if (area > 0) text += " (${area} م²)"
                if (line > 0) text += " → ${line.toPersianDigits()} ت"
                lines.add(text)
            }
            lines.joinToString("\n")
        } catch (e: Exception) {
            json
        }
    }
}
