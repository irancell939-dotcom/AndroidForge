package com.carpetcleaning.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.carpetcleaning.app.data.AppDatabase
import com.carpetcleaning.app.data.Customer
import com.carpetcleaning.app.data.Order
import com.carpetcleaning.app.databinding.ActivityCustomerDetailBinding
import com.carpetcleaning.app.util.SmsHelper
import com.carpetcleaning.app.util.toPersianDigits
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import org.json.JSONArray

class CustomerDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCustomerDetailBinding
    private lateinit var db: AppDatabase
    private var customer: Customer? = null
    private lateinit var orderAdapter: OrderAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomerDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        db = AppDatabase.getInstance(this)
        val customerId = intent.getLongExtra("customerId", -1)
        if (customerId == -1L) { finish(); return }

        orderAdapter = OrderAdapter(
            onDeliverySms = { order -> sendDelivery(order, false) },
            onDeliveryWhatsApp = { order -> sendDelivery(order, true) },
            onOrderSms = { order -> sendOrder(order, false) },
            onOrderWhatsApp = { order -> sendOrder(order, true) }
        )
        binding.rvOrders.layoutManager = LinearLayoutManager(this)
        binding.rvOrders.adapter = orderAdapter

        binding.fabNewOrder.setOnClickListener {
            val intent = Intent(this, NewOrderActivity::class.java)
            intent.putExtra("customerId", customerId)
            startActivity(intent)
        }

        lifecycleScope.launch {
            customer = db.customerDao().getById(customerId)
            customer?.let {
                binding.tvName.text = it.name
                binding.tvPhone.text = it.phone.toPersianDigits()
                binding.tvAddress.text = it.address.ifEmpty { "آدرس ثبت نشده" }
                supportActionBar?.title = it.name
            }
        }

        lifecycleScope.launch {
            db.orderDao().getByCustomer(customerId).collectLatest { list ->
                orderAdapter.submitList(list)
            }
        }
    }

    private fun sendDelivery(order: Order, whatsapp: Boolean) {
        val c = customer ?: return
        val msg = SmsHelper.deliveryMessage(c.name)
        if (whatsapp) SmsHelper.sendWhatsApp(this, c.phone, msg)
        else SmsHelper.sendSms(this, c.phone, msg)
    }

    private fun sendOrder(order: Order, whatsapp: Boolean) {
        val c = customer ?: return
        val itemsText = parseItemsText(order.itemsJson)
        val msg = SmsHelper.orderRegisteredMessage(
            c.name, itemsText, order.transportCost, order.washingCost,
            order.totalCost, order.receiveDateJalali, order.deliveryDateJalali
        )
        if (whatsapp) SmsHelper.sendWhatsApp(this, c.phone, msg)
        else SmsHelper.sendSms(this, c.phone, msg)
    }

    private fun parseItemsText(json: String): String {
        return try {
            val arr = JSONArray(json)
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                sb.append("• ${o.getInt("quantity")} ${o.getString("type")} ${o.optString("size")}\n")
            }
            sb.toString().trim()
        } catch (e: Exception) {
            json
        }
    }
}
