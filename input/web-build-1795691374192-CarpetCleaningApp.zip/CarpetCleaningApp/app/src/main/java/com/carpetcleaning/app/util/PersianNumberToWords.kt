package com.carpetcleaning.app.util

object PersianNumberToWords {

    private val ones = arrayOf(
        "", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه",
        "ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده",
        "هفده", "هجده", "نوزده"
    )
    private val tens = arrayOf(
        "", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود"
    )
    private val hundreds = arrayOf(
        "", "صد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد"
    )
    private val scales = arrayOf("", "هزار", "میلیون", "میلیارد", "تریلیون")

    fun convert(number: Long): String {
        if (number == 0L) return "صفر"
        if (number < 0) return "منفی " + convert(-number)

        val parts = mutableListOf<String>()
        var n = number
        var scaleIndex = 0

        while (n > 0) {
            val chunk = (n % 1000).toInt()
            if (chunk != 0) {
                val chunkWords = convertChunk(chunk)
                val scale = if (scaleIndex > 0) " " + scales[scaleIndex] else ""
                parts.add(0, chunkWords + scale)
            }
            n /= 1000
            scaleIndex++
        }
        return parts.joinToString(" و ")
    }

    private fun convertChunk(n: Int): String {
        val result = mutableListOf<String>()
        val h = n / 100
        val t = n % 100

        if (h > 0) result.add(hundreds[h])

        when {
            t == 0 -> {}
            t < 20 -> result.add(ones[t])
            else -> {
                val ten = t / 10
                val one = t % 10
                result.add(tens[ten])
                if (one > 0) result.add(ones[one])
            }
        }
        return result.joinToString(" و ")
    }

    /** تبدیل عدد تومان به حروف + واحد */
    fun tomanToWords(amount: Long): String {
        return convert(amount) + " تومان"
    }
}
