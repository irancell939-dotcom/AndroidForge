package com.carpetcleaning.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.carpetcleaning.app.data.AppDatabase
import com.carpetcleaning.app.data.Rates
import com.carpetcleaning.app.databinding.ActivityRatesBinding
import kotlinx.coroutines.launch

class RatesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRatesBinding
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRatesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        db = AppDatabase.getInstance(this)

        lifecycleScope.launch {
            val rates = db.ratesDao().get() ?: Rates()
            binding.etCarpet.setText(rates.carpetPerM2.toString())
            binding.etRunner.setText(rates.runnerPerM2.toString())
            binding.etMoquette.setText(rates.moquettePerM2.toString())
            binding.etGilim.setText(rates.gilimPerM2.toString())
            binding.etBlanket.setText(rates.blanketPerPiece.toString())
            binding.etOther.setText(rates.otherPerPiece.toString())
        }

        binding.btnSave.setOnClickListener {
            val rates = Rates(
                carpetPerM2 = binding.etCarpet.text?.toString()?.toLongOrNull() ?: 15000,
                runnerPerM2 = binding.etRunner.text?.toString()?.toLongOrNull() ?: 12000,
                moquettePerM2 = binding.etMoquette.text?.toString()?.toLongOrNull() ?: 10000,
                gilimPerM2 = binding.etGilim.text?.toString()?.toLongOrNull() ?: 14000,
                blanketPerPiece = binding.etBlanket.text?.toString()?.toLongOrNull() ?: 80000,
                otherPerPiece = binding.etOther.text?.toString()?.toLongOrNull() ?: 50000
            )
            lifecycleScope.launch {
                db.ratesDao().save(rates)
                Toast.makeText(this@RatesActivity, "نرخ‌ها ذخیره شد", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
