package com.carpetcleaning.app.util

import com.carpetcleaning.app.data.CarpetItem
import com.carpetcleaning.app.data.Rates

object PriceCalculator {

    /**
     * محاسبه قیمت یک خط بر اساس نوع و نرخ‌ها
     * - فرش، کناره، موکت، گلیم → بر اساس متر مربع
     * - پتو و سایر → بر اساس تعداد
     */
    fun calculateLine(item: CarpetItem, rates: Rates): CarpetItem {
        val (unitPrice, lineTotal) = when (item.type.trim()) {
            "فرش" -> {
                val price = rates.carpetPerM2
                price to (item.quantity * item.areaM2 * price).toLong()
            }
            "کناره" -> {
                val price = rates.runnerPerM2
                price to (item.quantity * item.areaM2 * price).toLong()
            }
            "موکت" -> {
                val price = rates.moquettePerM2
                price to (item.quantity * item.areaM2 * price).toLong()
            }
            "گلیم" -> {
                val price = rates.gilimPerM2
                price to (item.quantity * item.areaM2 * price).toLong()
            }
            "پتو" -> {
                val price = rates.blanketPerPiece
                price to (item.quantity * price)
            }
            else -> {
                val price = rates.otherPerPiece
                price to (item.quantity * price)
            }
        }
        return item.copy(unitPrice = unitPrice, lineTotal = lineTotal)
    }

    fun totalWashing(items: List<CarpetItem>): Long =
        items.sumOf { it.lineTotal }
}
