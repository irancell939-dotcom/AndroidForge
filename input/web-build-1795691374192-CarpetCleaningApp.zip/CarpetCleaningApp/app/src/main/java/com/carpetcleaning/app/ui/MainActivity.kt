package com.carpetcleaning.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.carpetcleaning.app.R
import com.carpetcleaning.app.data.AppDatabase
import com.carpetcleaning.app.data.Customer
import com.carpetcleaning.app.databinding.ActivityMainBinding
import com.carpetcleaning.app.databinding.DialogNewCustomerBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var db: AppDatabase
    private lateinit var adapter: CustomerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        db = AppDatabase.getInstance(this)

        adapter = CustomerAdapter { customer ->
            val intent = Intent(this, CustomerDetailActivity::class.java)
            intent.putExtra("customerId", customer.id)
            startActivity(intent)
        }
        binding.rvCustomers.layoutManager = LinearLayoutManager(this)
        binding.rvCustomers.adapter = adapter

        binding.fabAdd.setOnClickListener { showNewCustomerDialog() }

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                loadCustomers(s?.toString()?.trim().orEmpty())
            }
        })

        loadCustomers("")
    }

    private fun loadCustomers(query: String) {
        lifecycleScope.launch {
            val flow = if (query.isEmpty()) db.customerDao().getAll()
            else db.customerDao().search(query)
            flow.collectLatest { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                binding.rvCustomers.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
            }
        }
    }

    private fun showNewCustomerDialog() {
        val dialogBinding = DialogNewCustomerBinding.inflate(LayoutInflater.from(this))
        val dialog = AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setPositiveButton("ذخیره") { _, _ ->
                val name = dialogBinding.etName.text?.toString()?.trim().orEmpty()
                val phone = dialogBinding.etPhone.text?.toString()?.trim().orEmpty()
                if (name.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(this, "نام و شماره موبایل الزامی است", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                lifecycleScope.launch {
                    db.customerDao().insert(
                        Customer(
                            name = name,
                            phone = phone,
                            address = dialogBinding.etAddress.text?.toString()?.trim().orEmpty(),
                            notes = dialogBinding.etNotes.text?.toString()?.trim().orEmpty()
                        )
                    )
                    Toast.makeText(this@MainActivity, "مشتری ذخیره شد", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("انصراف", null)
            .create()
        dialog.show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_rates -> {
                startActivity(Intent(this, RatesActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}
