import os
import socket
import threading
from pathlib import Path

_private = os.environ.get("ANDROID_PRIVATE") or os.environ.get("HOME") or str(Path.cwd())
_data = Path(_private) / "khavaran_data"
_data.mkdir(parents=True, exist_ok=True)
os.environ["KHAYATI_DATA_DIR"] = str(_data)
# 0.0.0.0 = گوشی روی شبکه Wi-Fi برای کامپیوتر قابل دسترسی می‌شود
os.environ["HOST"] = "0.0.0.0"
os.environ["KHAVARAN_ANDROID"] = "1"

from werkzeug.serving import make_server
from app import app

_server = None
_thread = None
_port = None
_lock = threading.RLock()
_PORT_FILE = _data / "server_port.txt"
_IP_FILE = _data / "server_ip.txt"


def find_free_port(start=5000, end=5200):
    """اولین پورت آزاد را پیدا می‌کند (روی همه اینترفیس‌ها)."""
    for port in range(start, end + 1):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("0.0.0.0", port))
                return port
        except OSError:
            continue
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("0.0.0.0", 0))
        return sock.getsockname()[1]


def detect_lan_ips():
    """IPهای واقعی شبکه محلی (Wi-Fi/LAN) را برمی‌گرداند؛ localhost حذف می‌شود."""
    found = []
    seen = set()

    def add(ip):
        if not ip or ip.startswith("127.") or ip.startswith("169.254.") or ip in seen:
            return
        # ترجیح IPv4 خصوصی
        if ip.startswith(("10.", "192.168.", "172.")):
            seen.add(ip)
            found.append(ip)
        elif ":" not in ip:
            seen.add(ip)
            found.append(ip)

    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.settimeout(0.5)
        probe.connect(("192.0.2.1", 80))
        add(probe.getsockname()[0])
        probe.close()
    except OSError:
        pass

    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            add(info[4][0])
    except OSError:
        pass

    try:
        hostname = socket.gethostname()
        add(socket.gethostbyname(hostname))
    except OSError:
        pass

    # مسیر /proc روی اندروید گاهی اینترفیس‌ها را نشان می‌دهد
    try:
        with open("/proc/net/fib_trie", "r", encoding="utf-8", errors="ignore") as fh:
            for line in fh:
                line = line.strip()
                if line.startswith("-- ") and "/" not in line:
                    candidate = line.replace("--", "").strip()
                    if candidate.count(".") == 3:
                        add(candidate)
    except Exception:
        pass

    return found


def get_port():
    with _lock:
        if _port:
            return _port
    try:
        if _PORT_FILE.exists():
            return int(_PORT_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        pass
    try:
        return int(os.environ.get("PORT", "5000"))
    except Exception:
        return 5000


def start_server():
    global _server, _thread, _port
    with _lock:
        if _server is not None:
            return
        _port = find_free_port()
        os.environ["PORT"] = str(_port)
        os.environ["HOST"] = "0.0.0.0"
        try:
            _PORT_FILE.write_text(str(_port), encoding="utf-8")
        except Exception:
            pass
        try:
            ips = detect_lan_ips()
            if ips:
                _IP_FILE.write_text("\n".join(ips), encoding="utf-8")
        except Exception:
            pass
        # شنود روی همه آدرس‌ها تا کامپیوتر هم‌شبکه بتواند وصل شود
        _server = make_server("0.0.0.0", _port, app, threaded=True)
        _thread = threading.Thread(target=_server.serve_forever, name="KhavaranFlask", daemon=True)
        _thread.start()


def stop_server():
    global _server, _thread, _port
    with _lock:
        server = _server
        _server = None
        _thread = None
        _port = None
    if server:
        try:
            server.shutdown()
            server.server_close()
        except Exception:
            pass
    for path in (_PORT_FILE, _IP_FILE):
        try:
            if path.exists():
                path.unlink()
        except Exception:
            pass
