plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.khavaran.dozdkiist"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.khavaran.dozdkiist"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    // هماهنگ‌سازی هدف JVM برای جلوگیری از خطای Java 1.8 و Kotlin 17
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
