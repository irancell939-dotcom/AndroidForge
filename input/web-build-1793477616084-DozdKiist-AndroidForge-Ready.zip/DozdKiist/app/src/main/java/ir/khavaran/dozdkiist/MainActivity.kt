package ir.khavaran.dozdkiist

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues
import org.json.JSONArray
import org.json.JSONObject

class JobsDb(context: Activity) : SQLiteOpenHelper(context, "dozdkiist.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE jobs (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun initialize(json: String) {
        val db=writableDatabase
        if(db.rawQuery("SELECT COUNT(*) FROM jobs", null).use { it.moveToFirst(); it.getInt(0) } == 0) {
            val arr=JSONArray(json); db.beginTransaction()
            try { for(i in 0 until arr.length()) { val v=ContentValues().apply{put("name",arr.getString(i))}; db.insertWithOnConflict("jobs",null,v,SQLiteDatabase.CONFLICT_IGNORE) }; db.setTransactionSuccessful() } finally { db.endTransaction() }
        }
    }
    fun all(): String { val a=JSONArray(); readableDatabase.rawQuery("SELECT name FROM jobs ORDER BY name COLLATE NOCASE",null).use { c->while(c.moveToNext()) a.put(JSONObject().put("name",c.getString(0))) }; return a.toString() }
    fun add(name:String)=writableDatabase.insertWithOnConflict("jobs",null,ContentValues().apply{put("name",name)},SQLiteDatabase.CONFLICT_IGNORE)>=0
    fun update(old:String, fresh:String)=writableDatabase.update("jobs",ContentValues().apply{put("name",fresh)},"name=?",arrayOf(old))>0
    fun delete(name:String)=writableDatabase.delete("jobs","name=?",arrayOf(name))>0
}

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var db: JobsDb
    inner class AndroidDB {
        @JavascriptInterface fun initializeJobs(json:String) { db.initialize(json) }
        @JavascriptInterface fun getJobs():String = db.all()
        @JavascriptInterface fun addJob(name:String):Boolean = db.add(name.trim())
        @JavascriptInterface fun updateJob(old:String, fresh:String):Boolean = db.update(old.trim(),fresh.trim())
        @JavascriptInterface fun deleteJob(name:String):Boolean = db.delete(name.trim())
    }
    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db=JobsDb(this)
        webView=WebView(this)
        webView.settings.javaScriptEnabled=true
        webView.settings.domStorageEnabled=true
        webView.settings.allowFileAccess=true
        webView.settings.allowContentAccess=true
        webView.addJavascriptInterface(AndroidDB(),"AndroidDB")
        webView.webViewClient=WebViewClient()
        webView.webChromeClient=WebChromeClient()
        webView.setBackgroundColor(android.graphics.Color.rgb(102,126,234))
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }
    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() { super.onBackPressed() }
}
