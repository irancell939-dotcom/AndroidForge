# PyInstaller onedir specification for Khavaran Soft
from PyInstaller.utils.hooks import collect_submodules
hidden = collect_submodules('flask') + collect_submodules('access_parser')
a = Analysis(['app.py'], pathex=[], binaries=[], datas=[('templates','templates'),('static','static'),('requirements.txt','.')], hiddenimports=hidden, hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=[], noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='KhavaranSoft', debug=False, bootloader_ignore_signals=False, strip=False, upx=True, console=False)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=True, name='KhavaranSoft')
