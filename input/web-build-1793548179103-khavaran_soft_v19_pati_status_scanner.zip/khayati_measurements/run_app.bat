@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ================================================
echo          اجراي دفتر مشتريان و اندازه‌ها
echo ================================================
echo.

REM ساخت محيط اختصاصي پایتون در اولین اجرا
if not exist ".venv\Scripts\python.exe" (
    echo در حال ساخت محيط پایتون...
    where py >nul 2>&1
    if not errorlevel 1 (
        py -3 -m venv .venv
    ) else (
        python -m venv .venv
    )
)

if not exist ".venv\Scripts\python.exe" (
    echo خطا: ساخت محيط پایتون ناموفق بود. نصب بودن Python را بررسي کنيد.
    pause
    exit /b 1
)

REM نصب خودکار Flask و کتابخانه پایتونی خواندن MDB در صورت نياز
".venv\Scripts\python.exe" -c "import flask; import access_parser" >nul 2>&1
if errorlevel 1 (
    echo در حال نصب Flask و کتابخانه خواندن MDB...
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 (
        echo تلاش دوباره از مخزن جايگزين...
        ".venv\Scripts\python.exe" -m pip install -r requirements.txt -i https://repo.huaweicloud.com/repository/pypi/simple
    )
    if errorlevel 1 (
        echo نصب کتابخانه‌ها انجام نشد. اتصال اينترنت يا متن خطا را بررسي کنيد.
        pause
        exit /b 1
    )
)

echo برنامه اجرا مي‌شود و مرورگر به‌صورت خودکار باز خواهد شد.
".venv\Scripts\python.exe" app.py

echo.
echo برنامه متوقف شد.
exit /b 0
