@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo این فایل بسته نصب آفلاین ویندوز را می‌سازد.
echo این مرحله فقط روی رایانه سازنده و با Python و اینترنت برای دریافت ابزار ساخت انجام می‌شود.
py -m pip install --upgrade pip
py -m pip install Flask pyinstaller access-parser
if errorlevel 1 goto error
py -m PyInstaller --noconfirm --clean KhavaranSoft.spec
if errorlevel 1 goto error
echo.
echo خروجی مستقل در پوشه dist\KhavaranSoft ساخته شد.
echo پوشه dist\KhavaranSoft را به رایانه مقصد منتقل کنید؛ روی رایانه مقصد Python لازم نیست.
pause
exit /b 0
:error
echo خطا در ساخت بسته. متن خطا را بررسی کنید.
pause
exit /b 1
