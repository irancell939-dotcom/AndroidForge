package com.aamal.roozaneh;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import androidx.core.app.NotificationCompat;
import java.util.Locale;

public class NotificationReceiver extends BroadcastReceiver {

    private static TextToSpeech tts;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;

        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = null;
        try {
            if (pm != null) {
                wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "aamal:notif");
                wakeLock.acquire(30000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            String action = intent.getAction();
            if ("ACTION_JAMAAT".equals(action) || "ACTION_FARDI".equals(action) || "ACTION_NOT_YET".equals(action)) {
                handleAction(context, intent, action);
                return;
            }

            String type = intent.getStringExtra("type");
            String message = intent.getStringExtra("message");
            String prayerKey = intent.getStringExtra("prayerKey");
            int reqCode = intent.getIntExtra("reqCode", 2100);
            int hour = intent.getIntExtra("hour", -1);
            int minute = intent.getIntExtra("minute", -1);
            if (message == null) message = "کارنامه اعمالت را تکمیل کن";
            if (prayerKey == null) prayerKey = "";

            String title = "اعمال روزانه";
            if ("before".equals(type)) title = "وقت نماز نزدیک است 🕌";
            else if ("after".equals(type)) title = "پیگیری نماز 📿";
            else if ("night".equals(type)) title = "کارنامه امروز";
            String speakText = MainActivity.getSpeakPhrase(context, type != null ? type : "", prayerKey);

            Intent open = new Intent(context, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            open.putExtra("from_notif", true);
            open.putExtra("prayerKey", prayerKey);
            PendingIntent contentPi = PendingIntent.getActivity(context, reqCode + 100, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            PendingIntent fullScreenPi = PendingIntent.getActivity(context, reqCode + 200, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, MainActivity.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setDefaults(NotificationCompat.DEFAULT_VIBRATE | NotificationCompat.DEFAULT_LIGHTS)
                .setContentIntent(contentPi)
                .setFullScreenIntent(fullScreenPi, true)
                .setAutoCancel(true)
                .setTimeoutAfter(10 * 60 * 1000);

            Uri sound = MainActivity.resolveSoundUri(context);
            if (sound != null) builder.setSound(sound);

            if ("after".equals(type) && prayerKey.length() > 0 && !"test".equals(prayerKey)) {
                builder.addAction(0, "جماعت", actionPi(context, "ACTION_JAMAAT", prayerKey, reqCode + 10));
                builder.addAction(0, "انفرادی", actionPi(context, "ACTION_FARDI", prayerKey, reqCode + 11));
                builder.addAction(0, "هنوز نخواندم", actionPi(context, "ACTION_NOT_YET", prayerKey, reqCode + 12));
            }

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(reqCode, builder.build());

            // Speak Persian message
            speak(context, speakText);

            // ALWAYS reschedule for next occurrence
            if (hour >= 0 && minute >= 0) {
                MainActivity.scheduleAlarm(context, hour, minute, reqCode, type, prayerKey, message);
            } else if ("night".equals(type)) {
                MainActivity.scheduleAlarm(context, 21, 0, 9000, "night", "night",
                    "امروزت چگونه گذشت؟ کارنامه اعمالت را تکمیل کن");
            }
            // After relative alarms (test / not-yet), also re-apply daily prayer alarms
            if ("test".equals(prayerKey) || hour < 0) {
                MainActivity.restorePrayerAlarms(context);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            final PowerManager.WakeLock wl = wakeLock;
            // keep wake a bit for TTS
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (wl != null && wl.isHeld()) {
                    try { wl.release(); } catch (Exception ignored) {}
                }
            }, 8000);
        }
    }

    private String messageForBefore(String key) {
        String name = prayerName(key);
        return "پانزده دقیقه تا نماز " + name + " باقی مانده است. وضو بگیرید و آماده شوید.";
    }

    private String messageForAfter(String key) {
        if ("test".equals(key)) {
            return "این یک اعلان آزمایشی است. اگر این صدا را می‌شنوید، اعلان‌ها درست کار می‌کنند.";
        }
        String name = prayerName(key);
        return "نیم ساعت از وقت نماز " + name + " گذشته است. آیا نمازتان را خواندید؟";
    }

    private String prayerName(String key) {
        if (key == null) return "بعدی";
        switch (key) {
            case "fajr": return "صبح";
            case "zuhr": return "ظهر";
            case "asr": return "عصر";
            case "maghrib": return "مغرب";
            case "isha": return "عشاء";
            default: return "بعدی";
        }
    }

    private void speak(Context context, final String text) {
        try {
            final Context appCtx = context.getApplicationContext();
            new Handler(Looper.getMainLooper()).post(() -> {
                try {
                    if (tts != null) {
                        try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {}
                        tts = null;
                    }
                    tts = new TextToSpeech(appCtx, status -> {
                        if (status == TextToSpeech.SUCCESS && tts != null) {
                            // Prefer Persian
                            int r = tts.setLanguage(new Locale("fa", "IR"));
                            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                                r = tts.setLanguage(new Locale("fa"));
                            }
                            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                                tts.setLanguage(Locale.getDefault());
                            }
                            tts.setSpeechRate(0.95f);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aamal_tts");
                            } else {
                                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Uri getSound(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("aamal", Context.MODE_PRIVATE);
        String s = sp.getString("notif_sound", null);
        if (s != null && s.length() > 0) {
            try { return Uri.parse(s); } catch (Exception ignored) {}
        }
        Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        return u;
    }

    private PendingIntent actionPi(Context ctx, String action, String prayerKey, int code) {
        Intent i = new Intent(ctx, NotificationReceiver.class);
        i.setAction(action);
        i.putExtra("prayerKey", prayerKey);
        return PendingIntent.getBroadcast(ctx, code, i,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void handleAction(Context context, Intent intent, String action) {
        String prayerKey = intent.getStringExtra("prayerKey");
        if (prayerKey == null) prayerKey = "";

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            for (int i = 0; i < 5; i++) {
                nm.cancel(2000 + i);
                nm.cancel(1000 + i);
            }
            nm.cancel(9999);
        }

        String name = prayerName(prayerKey);

        if ("ACTION_NOT_YET".equals(action)) {
            MainActivity.scheduleInMinutes(context, 20, 3000 + Math.abs(prayerKey.hashCode() % 100),
                "after", prayerKey,
                "۲۰ دقیقه گذشت — نماز " + name + " را خواندید؟");
            showSimple(context, 8800, "یادآوری تنظیم شد", "۲۰ دقیقه دیگر دوباره می‌پرسیم");
            speak(context, "بیست دقیقه دیگر دوباره یادآوری می‌کنم");
        } else {
            String status = "ACTION_JAMAAT".equals(action) ? "jamaat" : "done";
            SharedPreferences sp = context.getSharedPreferences("aamal", Context.MODE_PRIVATE);
            sp.edit().putString("pending_prayer_" + prayerKey, status)
                .putLong("pending_prayer_ts", System.currentTimeMillis())
                .apply();
            String label = "jamaat".equals(status) ? "با جماعت" : "انفرادی";
            showSimple(context, 8801, "ثبت شد ✓", "نماز " + name + " — " + label);
            speak(context, "نماز " + name + " به صورت " + label + " ثبت شد");
        }
    }

    private void showSimple(Context ctx, int id, String title, String msg) {
        try {
            Intent open = new Intent(ctx, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(ctx, id + 50, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, MainActivity.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(msg)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(pi)
                .setAutoCancel(true);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(id, b.build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
