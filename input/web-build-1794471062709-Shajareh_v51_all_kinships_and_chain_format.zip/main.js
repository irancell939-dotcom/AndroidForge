
let DATA={people:[],marriages:[],parents:[]}, selectedId=null, modalMode='', relation='', existingId=null, scale=1, positions={};
let compactTreeLayout=false;try{compactTreeLayout=localStorage.getItem('shajareh-compact-tree-layout')==='1'}catch(e){}
const $=id=>document.getElementById(id);
window.CURRENT_USERNAME='0';window.CURRENT_USER_ID=0;window.CURRENT_ROLE='0';
function toggleCompare(force){let d=$('compareDrawer'),sh=$('compareShade'),o=force===undefined?!d.classList.contains('open'):!!force;d.classList.toggle('open',o);sh.classList.toggle('open',o);if(o)setTimeout(()=>$('compareSearchA').focus(),220)}
function toggleSearch(force){let d=$('searchDrawer'),sh=$('searchShade'),o=force===undefined?!d.classList.contains('open'):!!force;d.classList.toggle('open',o);sh.classList.toggle('open',o);if(o)setTimeout(()=>$('search').focus(),220)}
function toggleMenu(force){let m=$('mainMenu'),shade=$('menuShade');let open=force===undefined?!m.classList.contains('open'):!!force;if(m)m.classList.toggle('open',open);if(shade)shade.classList.toggle('open',open)}
let mainSearchTimer=null,mainSearchMatches=new Set();async function searchInTree(){let q=$('search').value.trim();clearTimeout(mainSearchTimer);let panel=$('mainSearchResults');if(!q){mainSearchMatches.clear();renderTree('');panel.classList.remove('show');panel.innerHTML='';return}mainSearchMatches.clear();renderTree(q);mainSearchTimer=setTimeout(async()=>{try{let res=await api('/api/search?q='+encodeURIComponent(q));mainSearchMatches=new Set((res.items||[]).map(x=>x.id));renderTree(q);panel.innerHTML='<div class="search-count">تعداد موارد یافته‌شده: '+(res.count||0)+'</div>'+((res.items||[]).map(x=>'<div class="search-hit" onclick="goToSearchPerson('+x.id+')"><b>'+esc(x.first_name+' '+x.last_name)+'</b><small>&nbsp;&nbsp;—&nbsp;&nbsp;'+esc([x.tribe,x.father_name?'پدر: '+x.father_name:''].filter(Boolean).join(' · '))+'</small></div>').join('')||'<div class="search-hit">موردی یافت نشد.</div>');panel.classList.add('show')}catch(e){panel.innerHTML='<div class="search-hit">'+esc(e.message)+'</div>';panel.classList.add('show')}},220)}
function focusTreeCard(id){document.querySelectorAll('.node.focused').forEach(n=>n.classList.remove('focused'));let el=document.querySelector('.node[data-id="'+id+'"]');if(!el)return;el.classList.add('focused');scale=Math.max(scale,1.12);$('world').style.transform=`scale(${scale})`;updateWorldSpace();let cv=$('treecanvas');cv.scrollTo({left:Math.max(0,(el.offsetLeft+el.offsetWidth/2)*scale-cv.clientWidth/2),top:Math.max(0,(el.offsetTop+el.offsetHeight/2)*scale-cv.clientHeight/2),behavior:'smooth'});setTimeout(()=>el.classList.remove('focused'),3500)}
function goToSearchPerson(id){toggleSearch(false);selectNode(Number(id));focusTreeCard(id);$('mainSearchResults').classList.remove('show')}
function clearSearch(){$('search').value='';mainSearchMatches.clear();$('mainSearchResults').classList.remove('show');renderTree()}
function normText(s){return String(s??'').toLowerCase().replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/[\s\u200c\u200f]/g,'')}
let compareA=null,compareB=null,compareTimers={A:null,B:null};
function searchCompare(which){clearTimeout(compareTimers[which]);const input=$('compareSearch'+which),box=$('compareResults'+which),q=input.value.trim();if(!q){box.classList.remove('show');box.innerHTML='';return}compareTimers[which]=setTimeout(async()=>{try{let r=await api('/api/search?q='+encodeURIComponent(q));box.innerHTML=(r.items||[]).map(p=>`<div class="compare-result" onclick="chooseCompare('${which}',${p.id})"><b>${esc(p.first_name+' '+p.last_name)}</b><small>${esc([p.person_code,p.gender,p.tribe,p.father_name?'پدر: '+p.father_name:''].filter(Boolean).join(' · '))}</small></div>`).join('')||'<div class="compare-result">موردی پیدا نشد.</div>';box.classList.add('show')}catch(e){box.innerHTML='<div class="compare-result">'+esc(e.message)+'</div>';box.classList.add('show')}},180)}
function chooseCompare(which,id){let p=DATA.people.find(x=>x.id===id);if(!p)return;if(which==='A')compareA=id;else compareB=id;$('compareSearch'+which).value=p.first_name+' '+p.last_name;$('compareChosen'+which).textContent='✓ '+p.first_name+' '+p.last_name+' · '+(p.gender||'');$('compareResults'+which).classList.remove('show');if(compareA&&compareB)comparePeople()}
function clearCompare(){compareA=compareB=null;['A','B'].forEach(k=>{$('compareSearch'+k).value='';$('compareChosen'+k).textContent='انتخاب نشده';$('compareResults'+k).classList.remove('show')});$('compareSummary').textContent='دو نفر را انتخاب کنید تا نسبت خانوادگی و مسیر ارتباطشان مشخص شود.';document.querySelectorAll('.node.compare-a,.node.compare-b').forEach(n=>n.classList.remove('compare-a','compare-b'));document.querySelectorAll('.compare-edge,.compare-dot,.relation-traveller').forEach(n=>n.remove())}
function parentMap(){let m=new Map();DATA.parents.forEach(e=>{if(!m.has(e.child_id))m.set(e.child_id,[]);m.get(e.child_id).push({id:e.parent_id,role:e.relation})});return m}
function ancestorDistances(id,pm){let d=new Map([[id,0]]),q=[id];while(q.length){let x=q.shift();for(let e of(pm.get(x)||[])){if(!d.has(e.id)){d.set(e.id,d.get(x)+1);q.push(e.id)}}}return d}
function _relationshipTextCore(a,b){
 if(a.id===b.id)return 'هر دو انتخاب به یک شخص اشاره می‌کنند.';
 const full=p=>(p.first_name+' '+(p.last_name||'')).trim();
 const genderWord=p=>p.gender==='مرد'?'پدربزرگ':'مادربزرگ';
 const childWord=p=>p.gender==='مرد'?'پسر':'دختر';
 const siblingWord=p=>p.gender==='مرد'?'برادر':'خواهر';
 const pm=parentMap();
 const ancestorInfo=(id)=>{let out=new Map([[id,{distance:0,firstParent:null}]]),q=[id];while(q.length){let cur=q.shift(),base=out.get(cur);for(const e of(pm.get(cur)||[])){if(!out.has(e.id)){out.set(e.id,{distance:base.distance+1,firstParent:base.distance===0?e:base.firstParent});q.push(e.id)}}}return out};
 const aa=ancestorInfo(a.id),bb=ancestorInfo(b.id);
 const marriage=DATA.marriages.find(m=>(m.husband_id===a.id&&m.wife_id===b.id)||(m.husband_id===b.id&&m.wife_id===a.id));
 if(marriage)return marriage.end_date?'نفر اول همسر سابق نفر دوم است.':'نفر اول همسر نفر دوم است.';
 // Direct ancestor/descendant, with exact grandparent wording.
 if(bb.has(a.id)){let d=bb.get(a.id).distance;if(d===1)return `نفر اول ${a.gender==='مرد'?'پدر':'مادر'} نفر دوم است.`;if(d===2)return `نفر اول ${genderWord(a)} نفر دوم است.`;return `نفر اول جدّ نسل ${d} نفر دوم است.`}
 if(aa.has(b.id)){let d=aa.get(b.id).distance;if(d===1)return `نفر اول ${b.gender==='مرد'?'پسر':'دختر'} نفر دوم است.`;if(d===2)return `نفر اول ${b.gender==='مرد'?'نوهٔ پسری':'نوهٔ دختری'} نفر دوم است.`;return `نفر اول نوادهٔ نسل ${d} نفر دوم است.`}
 // Full/half siblings: common parent.
 const commonParents=(pm.get(a.id)||[]).filter(x=>(pm.get(b.id)||[]).some(y=>y.id===x.id));
 if(commonParents.length){if(commonParents.length===2)return `نفر اول ${siblingWord(a)} تنی نفر دوم است.`;return `نفر اول ${siblingWord(a)} ناتنی نفر دوم است.`}
 // First is an aunt/uncle or niece/nephew of the second.
 if(aa.has(b.id)===false && bb.has(a.id)===false){
   const ap=pm.get(a.id)||[],bp=pm.get(b.id)||[];
   // cousin: their parents are siblings through one shared grandparent
   if(ap.length&&bp.length){
     for(const x of ap){for(const y of bp){
       const px=DATA.people.find(z=>z.id===x.id),py=DATA.people.find(z=>z.id===y.id);
       if(!px||!py||px.id===py.id)continue;
       const gx=ancestorInfo(px.id),gy=ancestorInfo(py.id);
       const shared=[...gx.keys()].filter(id=>gy.has(id)&&gx.get(id).distance===1&&gy.get(id).distance===1);
       if(shared.length){
         // Cousin terminology is directional: classify from the target person's
         // parent (paternal/maternal side) and the subject person's parent sex.
         const childWord=a.gender==='مرد'?'پسر':'دختر';
         let term;
         if(py.gender==='مرد') term=px.gender==='مرد'?childWord+'عموی':childWord+'عمهٔ';
         else term=px.gender==='مرد'?childWord+'داییِ':childWord+'خالهٔ';
         return `${fullName(a)} ${term} ${fullName(b)} است.`;
       }
     }}
   }
   // First is a niece/nephew of the second (second is sibling of first's parent).
   for(const x of ap){const parent=DATA.people.find(z=>z.id===x.id);if(!parent)continue;for(const g of (pm.get(parent.id)||[])){const grandChildren=DATA.parents.filter(e=>e.parent_id===g.id).map(e=>e.child_id);if(grandChildren.includes(b.id)){return `نفر اول ${parent.gender==='مرد'?'برادرزاده':'خواهرزاده'} نفر دوم است.`}}}
   // Aunt/uncle: first person is sibling of a parent of second.
   for(const y of bp){const parent=DATA.people.find(z=>z.id===y.id);if(!parent)continue;const gp=pm.get(parent.id)||[];for(const g of gp){const grand=DATA.people.find(z=>z.id===g.id);if(!grand)continue;const grandChildren=DATA.parents.filter(e=>e.parent_id===grand.id).map(e=>e.child_id);if(grandChildren.includes(a.id)){let term;if(parent.gender==='مرد')term=a.gender==='مرد'?'عموی':'عمهٔ';else term=a.gender==='مرد'?'داییِ':'خالهٔ';return `نفر اول ${term} نفر دوم است.`}}}
 }
 return 'نسبت دقیق از روابط ثبت‌شده قابل تشخیص نیست؛ برای تشخیص درست، رابطه‌های والدین و ازدواج‌ها را کامل کنید.';
}
function relationshipText(a,b){let t=_relationshipTextCore(a,b);return t.replace(/نفر اول/g,fullName(a)).replace(/نفر دوم/g,fullName(b)).replace(/فرد اول/g,fullName(a)).replace(/فرد دوم/g,fullName(b));}
function detailedKinshipAnalysis(a,b){
 const people=DATA.people, pm=parentMap(), byId=id=>people.find(p=>p.id===(id&&typeof id==='object'?id.id:id)), nm=value=>{if(value&&typeof value==='object'&&(value.first_name||value.last_name))return fullName(value);let p=byId(value);if(p)return fullName(p);if(value===a.id)return fullName(a);if(value===b.id)return fullName(b);return 'نام ثبت‌نشده';};
 const pathToAncestors=start=>{let q=[start],paths=new Map([[start,[start]]]);while(q.length){let id=q.shift();for(const e of(pm.get(id)||[])){if(!paths.has(e.id)){paths.set(e.id,[...paths.get(id),e.id]);q.push(e.id)}}}return paths};
 const pa=pathToAncestors(a.id),pb=pathToAncestors(b.id);
 let common=[...pa.keys()].filter(id=>pb.has(id)).sort((x,y)=>(pa.get(x).length+pb.get(x).length)-(pa.get(y).length+pb.get(y).length));
 if(!common.length)return '';
 const ancestor=common[0], pathA=pa.get(ancestor),pathB=pb.get(ancestor);
 if(pathA.length<2||pathB.length<2)return '';
 const branchA=pathA[pathA.length-2],branchB=pathB[pathB.length-2];
 if(branchA===branchB)return '';
 const pA=byId(branchA),pB=byId(branchB),anc=byId(ancestor);
 if(!pA||!pB||!anc)return '';
 const siblings=(pm.get(branchA)||[]).some(x=>(pm.get(branchB)||[]).some(y=>y.id===x.id));
 if(!siblings)return '';
 const depthA=pathA.length-2,depthB=pathB.length-2;
 const parentOf=(id)=>{let x=(pm.get(id)||[])[0];return x?byId(x.id):null};
 const grandLabel=(person,path)=>{
   const d=path.length-2;
   if(d===1)return person.gender==='مرد'?'پدر':'مادر';
   if(d===2){let par=byId(path[1]);let side=par?.gender==='مرد'?'پدری':'مادری';return (person.gender==='مرد'?'پدربزرگ':'مادربزرگ')+' '+side}
   return 'جدِ نسل '+d;
 };
 const siblingTerm=(x,y)=>x.gender==='مرد'&&y.gender==='مرد'?'برادر':(x.gender!=='مرد'&&y.gender!=='مرد'?'خواهر':'خواهر و برادر');
 let out=[];
 out.push(`${nm(branchA)} (${grandLabel(pA,pathA)}ِ ${nm(a)}) و ${nm(branchB)} (${grandLabel(pB,pathB)}ِ ${nm(b)}) هر دو فرزند ${nm(ancestor)} هستند؛ بنابراین ${nm(branchA)} و ${nm(branchB)} ${siblingTerm(pA,pB)} یکدیگرند.`);
 // If the two selected people are children of those sibling branches, report their cousin relationship too—even when they are spouses.
 if(depthA===1&&depthB===1){
   const cousinTerm=(person,personParent,targetParent)=>{
     if(targetParent.gender==='مرد'){
       if(personParent.gender==='مرد')return person.gender==='مرد'?'پسرعموی':'دخترعموی';
       return person.gender==='مرد'?'پسرعمهٔ':'دخترعمهٔ';
     }
     if(personParent.gender==='مرد')return person.gender==='مرد'?'پسرداییِ':'دخترداییِ';
     return person.gender==='مرد'?'پسرخالهٔ':'دخترخالهٔ';
   };
   const aToB=cousinTerm(a,pA,pB), bToA=cousinTerm(b,pB,pA);
   out.push(`${nm(a)} ${aToB} ${nm(b)} است؛ ${nm(b)} نیز ${bToA} ${nm(a)} است.`);
 }
 const elderTerm=(sibling,branch,desc,path)=>{
   const d=path.length-2;
   if(d===1){let par=byId(path[1]);if(!par)return '';if(par.gender==='مرد')return sibling.gender==='مرد'?'عموی':'عمهٔ';return sibling.gender==='مرد'?'داییِ':'خالهٔ'}
   if(d===2){let par=byId(path[1]);if(!par)return '';if(par.gender==='مرد')return sibling.gender==='مرد'?'عموی بزرگِ':'عمهٔ بزرگِ';return sibling.gender==='مرد'?'داییِ بزرگِ':'خالهٔ بزرگِ'}
   return '';
 };
 const uncleOfParent=(sibling,branch,desc,path)=>{
   const d=path.length-2;
   if(d!==2)return '';
   const parent=byId(path[1]);if(!parent)return '';
   if(parent.gender==='مرد')return sibling.gender==='مرد'?'عموی پدرِ':'عمهٔ پدرِ';
   return sibling.gender==='مرد'?'داییِ مادرِ':'خالهٔ مادرِ';
 };
 const grandparentRole=(person,desc)=>`${person.gender==='مرد'?'پدربزرگ':'مادربزرگ'} ${nm(desc)} محسوب می‌شود`;
 let termB=elderTerm(pA,pB,b,pathB);
 if(termB){if(depthB===2){out.push(`${nm(branchA)} ${pA.gender==='مرد'?'برادرِ':'خواهرِ'} ${grandLabel(pB,pathB)} ${nm(b)} (${nm(branchB)}) است؛ بنابراین ${nm(branchA)} نیز ${grandparentRole(pA,b)}.`)}else{out.push(`${nm(branchA)} ${termB} ${nm(b)} است.`)}}
 let termA=elderTerm(pB,pA,a,pathA);
 if(termA){if(depthA===2)out.push(`${nm(branchB)} ${pB.gender==='مرد'?'برادرِ':'خواهرِ'} ${grandLabel(pA,pathA)} ${nm(a)} (${nm(branchA)}) است؛ بنابراین ${nm(branchB)} نیز ${grandparentRole(pB,a)}.`);else out.push(`${nm(branchB)} ${termA} ${nm(a)} است.`)}
 if(depthA===2&&depthB===2){
   const pa1=byId(pathA[1]),pb1=byId(pathB[1]);
   // Use the exact paternal-grandparent branches already established by the
   // displayed paths. Searching every parent indiscriminately could pick a
   // maternal connection and incorrectly turn پسرعمو into پسرخاله.
   const ga=byId(pathA[2]),gb=byId(pathB[2]);
   if(pa1&&pb1&&ga&&gb){
     const sharedParent=(pm.get(ga.id)||[]).some(x=>(pm.get(gb.id)||[]).some(y=>y.id===x.id));
     if(sharedParent){
       let cousinTerm;
       if(gb.gender==='مرد') cousinTerm=ga.gender==='مرد'?(pa1.gender==='مرد'?'پسرعموی':'دخترعموی'):(pa1.gender==='مرد'?'پسرعمهٔ':'دخترعمهٔ');
       else cousinTerm=ga.gender==='مرد'?(pa1.gender==='مرد'?'پسرداییِ':'دخترداییِ'):(pa1.gender==='مرد'?'پسرخالهٔ':'دخترخالهٔ');
       out.push(`${nm(pa1)}، پدرِ ${nm(a)}، ${cousinTerm} ${nm(pb1)}، پدرِ ${nm(b)} است؛ بنابراین ${nm(a)} و ${nm(b)} از شاخهٔ پدری خویشاوندِ هم‌نسل هستند.`);
     }
   }
 }
 // Detect first-cousin links directly from the two selected people's parents.
 const parentA=(pm.get(a.id)||[]).map(x=>byId(x.id)).filter(Boolean);
 const parentB=(pm.get(b.id)||[]).map(x=>byId(x.id)).filter(Boolean);
 const cousinLines=[];
 const cousinWord=(person,personParent,targetParent)=>{
   if(targetParent.gender==='مرد')return personParent.gender==='مرد'?(person.gender==='مرد'?'پسرعموی':'دخترعموی'):(person.gender==='مرد'?'پسرعمهٔ':'دخترعمهٔ');
   return personParent.gender==='مرد'?(person.gender==='مرد'?'پسرداییِ':'دخترداییِ'):(person.gender==='مرد'?'پسرخالهٔ':'دخترخالهٔ');
 };
 for(const x of parentA)for(const y of parentB){
   const shared=(pm.get(x.id)||[]).some(g=>(pm.get(y.id)||[]).some(h=>h.id===g.id));
   if(shared){cousinLines.push(`${nm(a)} ${cousinWord(a,x,y)} ${nm(b)} است؛ ${nm(b)} نیز ${cousinWord(b,y,x)} ${nm(a)} است.`)}
 }
 // Marriage by itself must not hide blood kinship; report spouse-of-sibling links too.
 const spouseMap=new Map();
 for(const m of(DATA.marriages||[])){for(const [u,v] of [[m.husband_id,m.wife_id],[m.wife_id,m.husband_id]]){if(!spouseMap.has(u))spouseMap.set(u,[]);spouseMap.get(u).push(v)}}
 const areSiblings=(x,y)=>(pm.get(x)||[]).some(g=>(pm.get(y)||[]).some(h=>h.id===g.id));
 const inLawLines=[];
 for(const sp of(spouseMap.get(a.id)||[]))if(areSiblings(sp,b)){
   const spouse=byId(sp);if(spouse)inLawLines.push(`${nm(a)} ${a.gender==='مرد'?'شوهرِ':'زنِ'} ${spouse.gender==='زن'?'خواهر':'برادر'} ${nm(b)} است.`);
 }
 for(const sp of(spouseMap.get(b.id)||[]))if(areSiblings(sp,a)){
   const spouse=byId(sp);if(spouse)inLawLines.push(`${nm(a)} ${a.gender==='مرد'?'برادرِ':'خواهرِ'} همسرِ ${nm(b)} است.`);
 }
 const extra=[...new Set([...inLawLines,...cousinLines])];
 for(const line of extra)if(!out.includes(line))out.push(line);
 // Keep the closest relations first: direct family, in-laws, then cousin/extended ancestry.
 const relationRank=x=>/همسر|شوهرِ خواهر|زنِ برادر|برادرِ همسر|خواهرِ همسر/.test(x)?0:/پدر|مادر|فرزند|پسر|دختر/.test(x)&&!/پسرعمو|دخترعمو|پسرعمه|دخترعمه|پسردایی|دختردایی|پسرخاله|دخترخاله/.test(x)?1:/برادر|خواهر/.test(x)?2:/عمو|عمه|دایی|خاله/.test(x)?3:/پسرعمو|دخترعمو|پسرعمه|دخترعمه|پسردایی|دختردایی|پسرخاله|دخترخاله/.test(x)?4:5;
 out.sort((x,y)=>relationRank(x)-relationRank(y));
 return out.map(x=>`<div class="relation-main" style="margin-top:8px;background:#f5f8fc">${esc(x)}</div>`).join('');
}

function personLabel(id){let p=DATA.people.find(x=>x.id===id);return p?fullName(p):'نام ثبت‌نشده'}
function namedRelationLine(x,y){let raw=relationshipText(x,y);if(!raw||raw.includes('قابل تشخیص نیست'))return '';return raw.replace(/^نفر اول\s*/,fullName(x)+' ').replace(/نفر دوم/g,fullName(y));}
function fullName(p){return (p.first_name+' '+(p.last_name||'')).trim()}
function relationshipChain(a,b){
 const people=DATA.people, pm=parentMap();
 const paths=start=>{let q=[start],m=new Map([[start,[start]]]);while(q.length){let id=q.shift();for(const p of(pm.get(id)||[])){if(!m.has(p.id)){m.set(p.id,[...m.get(id),p.id]);q.push(p.id)}}}return m};
 const pa=paths(a.id),pb=paths(b.id);
 const common=[...pa.keys()].filter(id=>pb.has(id)).sort((x,y)=>(pa.get(x).length+pb.get(x).length)-(pa.get(y).length+pb.get(y).length));
 if(!common.length)return '';
 const ancestor=common[0], ancestorPerson=people.find(p=>p.id===ancestor);if(!ancestorPerson)return '';
 const depthA=pa.get(ancestor).length-1,depthB=pb.get(ancestor).length-1;
 const line=(person,depth)=>`${fullName(person)} ${depth===1?'فرزند':`نوادهٔ نسل ${depth}`} ${fullName(ancestorPerson)} ${depth===1?'است':'است'}`;
 return [line(a,depthA),line(b,depthB)].join('\n');
}

function comparePeople(){if(!compareA||!compareB){$('compareSummary').textContent='لطفاً هر دو نفر را انتخاب کنید.';return}let a=DATA.people.find(p=>p.id===compareA),b=DATA.people.find(p=>p.id===compareB);if(!a||!b)return;document.querySelectorAll('.node.compare-a,.node.compare-b').forEach(n=>n.classList.remove('compare-a','compare-b'));document.querySelectorAll('.compare-edge,.compare-dot,.relation-traveller').forEach(n=>n.remove());document.querySelector(`.node[data-id="${a.id}"]`)?.classList.add('compare-a');document.querySelector(`.node[data-id="${b.id}"]`)?.classList.add('compare-b');let rel=relationshipText(a,b),chain=relationshipChain(a,b),analysis=detailedKinshipAnalysis(a,b);$('compareSummary').innerHTML=`<div><strong>${esc(fullName(a))}</strong> <span class="relation-direction">نسبت به</span> <strong>${esc(fullName(b))}</strong></div><div class="relation-main">${esc(rel)}</div>${analysis?`<div style="font-weight:800;color:#173b58;margin-top:12px">تحلیل قابل فهم نسبت خانوادگی</div>${analysis}`:''}${chain&&chain!==rel?`<div class="relation-main" style="background:#f0f7ff"><b>شرح زنجیره ثبت‌شده:</b><br>${chain.split('\n').map(x=>esc(x)).join('<br>')}</div>`:''}<div class="relation-note">مسیر زرد، پیوندهای ثبت‌شده میان دو نفر را نشان می‌دهد.</div>`;highlightRelationPath(a.id,b.id);let el=document.querySelector('.node[data-id="'+a.id+'"]');if(el){scale=Math.max(scale,1);$('world').style.transform=`scale(${scale})`;updateWorldSpace();let cv=$('treecanvas');cv.scrollTo({left:Math.max(0,(el.offsetLeft+el.offsetWidth/2)*scale-cv.clientWidth/2),top:Math.max(0,(el.offsetTop+el.offsetHeight/2)*scale-cv.clientHeight/2),behavior:'smooth'})}}
function highlightRelationPath(start,end){
 let graph=new Map(),add=(u,v,type)=>{if(!graph.has(u))graph.set(u,[]);graph.get(u).push({id:v,type})};
 DATA.parents.forEach(e=>{add(e.parent_id,e.child_id,'parent');add(e.child_id,e.parent_id,'child')});DATA.marriages.forEach(m=>{add(m.husband_id,m.wife_id,'spouse');add(m.wife_id,m.husband_id,'spouse')});
 let q=[start],prev=new Map([[start,null]]);while(q.length&&!prev.has(end)){let u=q.shift();for(let e of(graph.get(u)||[]))if(!prev.has(e.id)){prev.set(e.id,{from:u,type:e.type});q.push(e.id)}}if(!prev.has(end))return false;
 let edges=[],cur=end;while(cur!==start){let x=prev.get(cur);edges.push({from:x.from,to:cur,type:x.type});cur=x.from}edges.reverse();let svg=$('edges'),points=[];
 edges.forEach(e=>{let p1=positions[e.from],p2=positions[e.to];if(!p1||!p2)return;let n1=document.querySelector(`.node[data-id="${e.from}"]`),n2=document.querySelector(`.node[data-id="${e.to}"]`);if(!n1||!n2)return;let x1=p1.x+95,y1=p1.y+(e.type==='spouse'?62:(e.type==='parent'?n1.offsetHeight:0)),x2=p2.x+95,y2=p2.y+(e.type==='spouse'?62:(e.type==='child'?n2.offsetHeight:0));if(e.type==='spouse'){if(x1<x2){x1=p1.x+190;x2=p2.x;}else{x1=p1.x;x2=p2.x+190;}}let line=document.createElementNS('http://www.w3.org/2000/svg','path');line.setAttribute('d',`M ${x1} ${y1} L ${x2} ${y2}`);line.setAttribute('class','compare-edge'+(e.type==='spouse'?' spouse':''));svg.appendChild(line);if(!points.length)points.push({x:x1,y:y1});points.push({x:x2,y:y2});});
 if(points.length>1){let marker=document.createElementNS('http://www.w3.org/2000/svg','circle');marker.setAttribute('class','relation-traveller');marker.setAttribute('r','8');marker.setAttribute('fill','#ffd34e');marker.setAttribute('stroke','#8b5b00');marker.setAttribute('stroke-width','2');marker.style.filter='drop-shadow(0 0 5px #f6bd32)';svg.appendChild(marker);let lens=[],total=0;for(let i=1;i<points.length;i++){let d=Math.hypot(points[i].x-points[i-1].x,points[i].y-points[i-1].y);lens.push(d);total+=d;}let began=0,duration=Math.max(1800,Math.min(5200,total*3));function frame(now){if(!marker.isConnected)return;if(!began)began=now;let progress=(now-began)/duration;if(progress>=1){marker.setAttribute('cx',points[points.length-1].x);marker.setAttribute('cy',points[points.length-1].y);return;}let walk=progress*total,idx=0;while(idx<lens.length-1&&walk>lens[idx]){walk-=lens[idx];idx++;}let t=lens[idx]?walk/lens[idx]:0,A=points[idx],B=points[idx+1];marker.setAttribute('cx',A.x+(B.x-A.x)*t);marker.setAttribute('cy',A.y+(B.y-A.y)*t);requestAnimationFrame(frame)}requestAnimationFrame(frame);}return true;
}

function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function api(url,opts={}){let r;try{r=await fetch(url,{credentials:'same-origin',headers:{'Content-Type':'application/json','Accept':'application/json'},...opts})}catch(net){throw Error('ارتباط با سرور برقرار نشد: '+(net.message||net))}let raw=await r.text();let j;try{j=raw?JSON.parse(raw):{}}catch(_){let detail=raw.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,220);if(r.status===401){location.href='/login';throw Error('نشست ورود پایان یافته است؛ دوباره وارد شوید.')}throw Error('سرور پاسخ JSON نفرستاد (HTTP '+r.status+'). '+(detail||'پاسخ خالی بود.'))}if(r.status===401){location.href='/login';throw Error(j.error||'ابتدا وارد شوید.')}if(!r.ok)throw Error(j.error||('خطای سرور '+r.status));return j}
async function openLineagePicker(){let html='<div class="field"><label>نام شخصی که می‌خواهید شجره اختصاصی او ساخته شود</label><input class="input" id="lineageQuery" placeholder="نام و نام خانوادگی را بنویسید" oninput="searchLineagePicker()" autocomplete="off"></div><div id="lineageResults" class="searchresults" style="max-height:260px"></div><p class="hint">زنجیره پدری این شخص تا قدیمی‌ترین پدر ثبت‌شده نمایش داده می‌شود و صفحه آماده چاپ ساخته می‌شود.</p>';showModal('انتخاب شخص برای شجره اختصاصی',html,'lineage');$('saveBtn').style.display='none';setTimeout(()=>$('lineageQuery')?.focus(),100)}
let lineageTimer=null;async function searchLineagePicker(){clearTimeout(lineageTimer);lineageTimer=setTimeout(async()=>{let q=$('lineageQuery')?.value||'';try{let r=await api('/api/search?q='+encodeURIComponent(q));$('lineageResults').innerHTML=(r.items||[]).slice(0,40).map(p=>`<div class="result" onclick="openPersonLineage(${p.id})"><b>${esc((p.first_name+' '+(p.last_name||'')).trim())}</b><small>${esc(p.tribe||'')} ${p.father_name?' · پدر: '+esc(p.father_name):''}</small></div>`).join('')||'<div class="result">موردی پیدا نشد.</div>'}catch(e){$('lineageResults').textContent=e.message}},180)}
function openPersonLineage(id){closeModal();location.href='/lineage/'+id}
async function changePassword(){let un=prompt('نام کاربری جدید:',window.CURRENT_USERNAME||'admin');if(un===null)return;let oldp=prompt('رمز فعلی را وارد کنید:');if(oldp===null)return;let np=prompt('رمز جدید (حداقل ۶ کاراکتر):');if(np===null)return;let cp=prompt('رمز جدید را دوباره وارد کنید:');if(cp===null)return;if(np!==cp){alert('تکرار رمز با رمز جدید یکسان نیست.');return}try{await api('/api/change-password',{method:'POST',body:JSON.stringify({username:un,old_password:oldp,new_password:np})});alert('نام کاربری و رمز عبور تغییر کرد.');location.reload()}catch(e){alert(e.message)}}
async function openSettings(){let pin=prompt('رمز ورود به تنظیمات را وارد کنید:');if(pin===null)return;if(pin!=='10246600'){alert('رمز تنظیمات نادرست است.');return}let current=document.querySelector('.top h1')?.textContent?.replace(/^🌳\s*/, '')||'شجره‌نامه قوم بلوچ';let st=DATA.settings||{};let html=`<div class="field"><label>عنوان بالای صفحه</label><input class="input" id="settingTitle" maxlength="60" value="${esc(current)}"></div><p class="hint">گزینه‌های نمایش زنان و قوم اصلی اکنون در بخش آمار صفحه اصلی قرار دارند.</p>`;showModal('تنظیمات شجره‌نامه',html,'settings');$('saveBtn').onclick=saveSettings;}
async function saveSettings(){let pin='10246600',title=$('settingTitle').value.trim();if(!title||title.length>60){alert('عنوان باید بین ۱ تا ۶۰ نویسه باشد.');return}try{await api('/api/settings/title',{method:'POST',body:JSON.stringify({settings_password:pin,title,hide_women:!!DATA.settings?.hide_women,main_tribe_only:!!DATA.settings?.main_tribe_only})});closeModal();$('saveBtn').onclick=saveModal;await loadTree();alert('تنظیمات ذخیره شد.')}catch(e){alert(e.message)}}
async function manageUsers(){try{let users=await api('/api/users');let html='<div class="formgrid"><div class="field"><label>نام کاربری جدید</label><input class="input" id="newUserName"></div><div class="field"><label>رمز عبور جدید</label><input class="input" id="newUserPass" type="password"></div><div class="field"><label>سطح دسترسی</label><select id="newUserRole" class="input"><option value="user">کاربر</option><option value="admin">مدیر</option></select></div></div><button class="btn primary" style="margin:10px 0" onclick="addUser()">افزودن کاربر</button><hr><h4>کاربران ثبت‌شده</h4><div>'+users.map(u=>'<div class="result">'+esc(u.username)+' · '+(u.role==='admin'?'مدیر':'کاربر')+(u.id!==window.CURRENT_USER_ID?' <button class="btn danger" onclick="removeUser('+u.id+')">حذف</button>':' (حساب فعلی)')+'</div>').join('')+'</div>';showModal('مدیریت کاربران',html,'users');$('saveBtn').style.display='none'}catch(e){alert(e.message)}}
async function addUser(){try{await api('/api/users',{method:'POST',body:JSON.stringify({username:$('newUserName').value,password:$('newUserPass').value,role:$('newUserRole').value})});alert('کاربر اضافه شد.');manageUsers()}catch(e){alert(e.message)}}
async function removeUser(id){if(!confirm('این کاربر حذف شود؟'))return;try{await api('/api/users/'+id,{method:'DELETE'});manageUsers()}catch(e){alert(e.message)}}
async function downloadBackup(){try{const r=await fetch('/backup',{credentials:'same-origin'});if(!r.ok)throw Error('دریافت فایل پشتیبان ناموفق بود: '+r.status);const blob=await r.blob();if(window.AndroidBackup&&window.AndroidBackup.saveBackup){const reader=new FileReader();reader.onload=()=>{const b64=String(reader.result).split(',')[1]||'';window.AndroidBackup.saveBackup(b64)};reader.readAsDataURL(blob);}else{const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='shajareh-backup.db';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),3000);}}catch(e){alert('پشتیبان‌گیری انجام نشد: '+e.message)}}
async function loadTree(){try{DATA=await api('/api/tree');const tribeCounts={};DATA.people.forEach(p=>{const t=(p.tribe||'').trim();if(t)tribeCounts[t]=(tribeCounts[t]||0)+1});const mainTribe=Object.keys(tribeCounts).sort((a,b)=>tribeCounts[b]-tribeCounts[a]||a.localeCompare(b,'fa'))[0]||'';const mainTribePeople=mainTribe?DATA.people.filter(p=>(p.tribe||'').trim()===mainTribe&&!p.death_date):[];const mainTribeLivingMen=mainTribePeople.filter(p=>p.gender==='مرد').length;const mainTribeLivingWomen=mainTribePeople.filter(p=>p.gender==='زن').length;$('stats').innerHTML=`<div class="stats-summary"><span class="stat">کل افراد: ${DATA.people.length}</span><span class="stat">مردان: ${DATA.people.filter(x=>x.gender==='مرد').length}</span><span class="stat">زنان: ${DATA.people.filter(x=>x.gender==='زن').length}</span><span class="stat">زنده‌ها: ${DATA.people.filter(x=>!x.death_date).length}</span><span class="stat">درگذشتگان: ${DATA.people.filter(x=>x.death_date).length}</span><span class="stat">مردان زنده طایفه اصلی (${esc(mainTribe||'نامشخص')}): ${mainTribeLivingMen}</span><span class="stat">زنان زنده طایفه اصلی (${esc(mainTribe||'نامشخص')}): ${mainTribeLivingWomen}</span><span class="stat">مجموع افراد زنده قوم اصلی: ${mainTribePeople.length}</span><span class="stat">ازدواج‌های فعال: ${DATA.marriages.filter(x=>!x.end_date).length}</span></div><div class="stats-controls"><label><input type="checkbox" id="homeHideWomen" ${DATA.settings?.hide_women?'checked':''} onchange="updateHomeSetting('hide_women',this.checked)"> مخفی کردن زنان در شجره‌نامه</label><label><input type="checkbox" id="homeMainTribe" ${DATA.settings?.main_tribe_only?'checked':''} onchange="updateHomeSetting('main_tribe_only',this.checked)"> فقط نمایش قوم اصلی (پرتعدادترین طایفه)</label><label><input type="checkbox" id="compactTreeLayout" ${compactTreeLayout?'checked':''} onchange="setCompactTreeLayout(this.checked)"> فشرده‌سازی فاصله افقی همه افراد</label></div>`;renderTree();}catch(e){alert(e.message)}}
function toggleStats(){let box=$('stats');box.classList.toggle('collapsed');let title=$('appTitleToggle');if(title)title.setAttribute('aria-expanded',String(!box.classList.contains('collapsed')))}
function setCompactTreeLayout(value){compactTreeLayout=!!value;try{localStorage.setItem('shajareh-compact-tree-layout',compactTreeLayout?'1':'0')}catch(e){}renderTree()}
async function updateHomeSetting(key,value){let title=document.querySelector('.top h1')?.textContent?.replace(/^🌳\s*/,'')||'شجره‌نامه قوم بلوچ';let settings={hide_women:!!DATA.settings?.hide_women,main_tribe_only:!!DATA.settings?.main_tribe_only};settings[key]=!!value;try{await api('/api/settings/title',{method:'POST',body:JSON.stringify({settings_password:'10246600',title,hide_women:settings.hide_women,main_tribe_only:settings.main_tribe_only})});DATA.settings=settings;renderTree()}catch(e){alert(e.message);await loadTree()}}

function layoutPeople(list){
 // حالت فشرده، فاصله همه شاخه‌ها و نسل‌ها را کم می‌کند؛ نه فقط فاصله همسران.
 const spouseGap=compactTreeLayout?195:200;
 const siblingGap=compactTreeLayout?28:105;
 const ids=new Set(list.map(p=>p.id));
 const parents=DATA.parents.filter(e=>ids.has(e.parent_id)&&ids.has(e.child_id));
 // فقط ازدواج فعال در چیدمان کارت‌های زوجین اثر دارد؛ ازدواج‌های طلاق‌گرفته/پایان‌یافته در سوابق و خطوط تاریخی باقی می‌مانند، اما جایگاه همسر فعلی را تصاحب نمی‌کنند.
 const marriages=DATA.marriages.filter(m=>ids.has(m.husband_id)&&ids.has(m.wife_id)&&!m.end_date&&!m.end_reason);
 const depth={};list.forEach(p=>depth[p.id]=0);
 for(let k=0;k<list.length;k++){
   let changed=false;
   parents.forEach(e=>{const d=(depth[e.parent_id]||0)+1;if(d>(depth[e.child_id]||0)){depth[e.child_id]=d;changed=true;}});
   if(!changed)break;
 }
 for(let k=0;k<list.length+2;k++){
   let changed=false;
   marriages.forEach(m=>{const d=Math.max(depth[m.husband_id]||0,depth[m.wife_id]||0);if(depth[m.husband_id]!==d||depth[m.wife_id]!==d){depth[m.husband_id]=d;depth[m.wife_id]=d;changed=true;}});
   parents.forEach(e=>{const d=(depth[e.parent_id]||0)+1;if(d>(depth[e.child_id]||0)){depth[e.child_id]=d;changed=true;}});
   if(!changed)break;
 }
 const maxDepth=Math.max(0,...Object.values(depth));
 const rowStep=Math.max(255,245+Math.min(80,maxDepth*3));
 const generationStep=rowStep*2-122; // فاصله دایره آبی تا نسل بعد سه برابر می‌شود؛ ارتفاع تنه طلایی تا دایره ثابت می‌ماند.
 const parentIds=new Map(),childrenByParent=new Map(),spouses=new Map();
 parents.forEach(e=>{
   if(!parentIds.has(e.child_id))parentIds.set(e.child_id,new Set());
   parentIds.get(e.child_id).add(e.parent_id);
   if(!childrenByParent.has(e.parent_id))childrenByParent.set(e.parent_id,new Set());
   childrenByParent.get(e.parent_id).add(e.child_id);
 });
 marriages.forEach(m=>{
   if(!spouses.has(m.husband_id))spouses.set(m.husband_id,new Set());
   if(!spouses.has(m.wife_id))spouses.set(m.wife_id,new Set());
   spouses.get(m.husband_id).add(m.wife_id);spouses.get(m.wife_id).add(m.husband_id);
 });
 const byId=new Map(list.map(p=>[p.id,p]));
 const spouseGroup=id=>{
   const p=byId.get(id);
   // چیدمان چندهمسری حول کارت شوهر: همسر اول نزدیکِ چپ، همسر دوم نزدیکِ راست،
   // همسر سوم دورتر در چپ، همسر چهارم دورتر در راست و به همین ترتیب.
   const husbandId=p?.gender==='مرد'?id:(marriages.find(m=>m.wife_id===id)?.husband_id);
   if(husbandId&&byId.has(husbandId)){
     const wives=[...new Map(marriages.filter(m=>m.husband_id===husbandId&&byId.has(m.wife_id))
       .sort((a,b)=>a.id-b.id).map(m=>[m.wife_id,m.wife_id])).values()];
     if(wives.length){
       const left=[],right=[];
       wives.forEach((wife,i)=>(i%2===0?left:right).push(wife));
       return [...left.slice(1).reverse(),left[0],husbandId,...right];
     }
     return [husbandId];
   }
   const other=[...(spouses.get(id)||[])].filter(x=>byId.has(x));
   if(other.length===1){const q=byId.get(other[0]);if(p?.gender==='زن'&&q?.gender==='مرد')return [id,other[0]];if(p?.gender==='مرد'&&q?.gender==='زن')return [other[0],id];}
   return [id,...other.sort((a,b)=>a-b)];
 };
 const groupAnchor=id=>spouseGroup(id).find(pid=>byId.get(pid)?.gender==='مرد')||id;
 const unitWidth=id=>{
   const group=spouseGroup(id),anchor=group.indexOf(groupAnchor(id));
   const left=anchor*spouseGap+95,right=(group.length-1-anchor)*spouseGap+95;
   // عرض رزروشده متقارن با محور شوهر تا شاخه‌های خواهر/برادر روی هم نیفتند.
   return Math.max(190,2*Math.max(left,right));
 };
 const childrenOf=id=>[...new Set(spouseGroup(id).flatMap(pid=>[...(childrenByParent.get(pid)||[])]))].filter(x=>byId.has(x)).sort((a,b)=>a-b);
 const memo=new Map();
 function measure(id,stack=new Set()){
   if(memo.has(id))return memo.get(id);
   if(stack.has(id))return unitWidth(id);
   const next=new Set(stack);next.add(id);
   const kids=childrenOf(id);
   const childWidth=kids.reduce((sum,k)=>sum+measure(k,next),0)+Math.max(0,kids.length-1)*siblingGap;
   const width=Math.max(unitWidth(id),childWidth);
   memo.set(id,width);return width;
 }
 const roots=list.filter(p=>!(parentIds.get(p.id)?.size)).sort((a,b)=>a.id-b.id);
 const rootPerson=list.reduce((a,b)=>a.id<b.id?a:b,list[0]);
 // اگر چند ریشه وجود داشته باشد، همسران ریشه در یک خانواده می‌مانند و هر شاخه
 // مستقل فضای جداگانه می‌گیرد؛ ریشه نخست همیشه محور اصلی درخت است.
 const rootIds=roots.map(p=>p.id).filter(id=>!roots.some(q=>q.id!==id&&(spouses.get(id)?.has(q.id))&&q.id<id));
 if(rootPerson&&!rootIds.includes(rootPerson.id))rootIds.unshift(rootPerson.id);
 const uniqueRoots=[...new Set(rootIds)];
 const rootWidths=uniqueRoots.map(id=>measure(id));
 const rootGap=uniqueRoots.length>1?(compactTreeLayout?35:150):0;
 const totalWidth=Math.max(1,rootWidths.reduce((a,b)=>a+b,0)+Math.max(0,uniqueRoots.length-1)*rootGap);
 const pos={},placed=new Set();
 function place(id,center,d,stack=new Set()){
   if(!byId.has(id)||placed.has(id)||stack.has(id))return;
   const next=new Set(stack);next.add(id);
   const group=spouseGroup(id),anchor=group.indexOf(groupAnchor(id));
   // محور خانواده دقیقاً مرکز کارت شوهر است، نه مرکز مجموع کارت‌های همسران.
   const left=center-(anchor*spouseGap+95);
   group.forEach((pid,i)=>{
     if(placed.has(pid)||!byId.has(pid))return;
     pos[pid]={x:left+i*spouseGap,y:22+d*generationStep};placed.add(pid);
   });
   const kids=childrenOf(id).filter(k=>!placed.has(k));
   if(!kids.length)return;
   const widths=kids.map(k=>measure(k,next));
   const gap=siblingGap;
   const span=widths.reduce((a,b)=>a+b,0)+Math.max(0,kids.length-1)*gap;
   let cursor=center-span/2;
   kids.forEach((kid,i)=>{
     const c=cursor+widths[i]/2;
     place(kid,c,d+1,next);
     cursor+=widths[i]+gap;
   });
 }
 let rootCursor=60+(totalWidth/2);
 // برای چند ریشه مستقل، جایگاه‌ها از چپ به راست چیده می‌شوند.
 let startX=60;
 uniqueRoots.forEach((id,i)=>{
   const w=rootWidths[i];place(id,startX+w/2,0,new Set());startX+=w+rootGap;
 });
 // افراد باقی‌مانده (مثلاً داده‌های قدیمی بدون والد ثبت‌شده یا حلقه‌های ناقص)
 // در یک ردیف مستقل قرار می‌گیرند تا هیچ کارتی از شجره حذف نشود.
 let orphanX=Math.max(startX+80, totalWidth+140);
 list.slice().sort((a,b)=>a.id-b.id).forEach(p=>{
   if(placed.has(p.id))return;
   const w=measure(p.id);place(p.id,orphanX+w/2,0,new Set());orphanX+=w+rootGap;
 });
 const minX=Math.min(0,...Object.values(pos).map(p=>p.x));
 const shift=60-minX;
 let maxW=0;Object.values(pos).forEach(p=>{p.x+=shift;maxW=Math.max(maxW,p.x+190);});
 return {pos,width:Math.max(650,maxW+60),height:Math.max(280,maxDepth*generationStep+rowStep+90),rowStep,rootId:rootPerson?.id};
}
let treeBaseWidth=650,treeBaseHeight=610;
function updateWorldSpace(){let sp=$('worldSpace'),world=$('world');if(sp){const w=Math.max(1,Math.ceil(treeBaseWidth*scale)),h=Math.max(1,Math.ceil(treeBaseHeight*scale));sp.style.width=w+'px';sp.style.minWidth=w+'px';sp.style.height=h+'px';sp.style.minHeight=h+'px';sp.style.flex='0 0 auto';sp.style.display='block';if(world){world.style.width=treeBaseWidth+'px';world.style.height=treeBaseHeight+'px';world.style.transformOrigin='0 0';world.style.transform=`scale(${scale})`;}}}
function renderTree(filter=''){
 let list=DATA.people.slice();const settings=DATA.settings||{};
 if(settings.hide_women)list=list.filter(p=>p.gender!=='زن');
 if(settings.main_tribe_only){const counts={};DATA.people.forEach(p=>{let t=(p.tribe||'').trim();if(t)counts[t]=(counts[t]||0)+1});const main=Object.keys(counts).sort((a,b)=>counts[b]-counts[a]||a.localeCompare(b,'fa'))[0];if(main)list=list.filter(p=>(p.tribe||'').trim()===main);}
 $('empty').style.display=list.length?'none':'block';$('world').style.display=list.length?'block':'none';if(!list.length)return;
 let {pos,width,height,rowStep,rootId}=layoutPeople(list);positions=pos;$('world').style.width=width+'px';$('world').style.height=height+'px';
 treeBaseWidth=Math.max(650,width+30);treeBaseHeight=Math.max(610,height+60);const canvasHeight=Math.max(610,height+60);$('treecanvas').style.height='78dvh';$('treecanvas').style.minHeight='560px';$('treebox')?.style.setProperty('min-height','610px');$('world').style.width=treeBaseWidth+'px';$('world').style.height=treeBaseHeight+'px';updateWorldSpace();
 $('nodes').innerHTML=list.map(p=>{let match=!filter||(mainSearchMatches&&mainSearchMatches.size?mainSearchMatches.has(p.id):normText(`${p.first_name} ${p.last_name} ${p.tribe}`).includes(normText(filter)));return `<div class="node ${p.gender==='مرد'?'male':'female'} ${p.death_date?'dead':''} ${p.has_photo?'has-photo':''} ${match&&filter?'selected':''}" data-id="${p.id}" style="left:${pos[p.id].x}px;top:${pos[p.id].y}px;" oncontextmenu="showContext(event,${p.id})" onclick="cardClick(${p.id})">${p.has_photo?`<div class="photo-bg" style="background-image:url('/api/person/${p.id}/photo')"></div>`:''}${p.id===rootId?`<span class="root-home" title="نسل نخست">⌂</span>`:""}<div class="code">${esc(p.person_code)}</div><div class="name">${esc(p.first_name+' '+p.last_name)}</div><div class="meta">${esc(p.gender)} ${p.birth_date?'· تولد '+esc(p.birth_date):''}</div><div class="tribe">قومیت: ${esc(p.tribe||'ثبت نشده')}</div>${p.death_date?'<span class="badge">درگذشته</span>':'<span class="badge">زنده</span>'}</div>`}).join('');
 drawEdges(list,pos,width,height,rowStep);
 if(compareA&&compareB){document.querySelector(`.node[data-id="${compareA}"]`)?.classList.add("compare-a");document.querySelector(`.node[data-id="${compareB}"]`)?.classList.add("compare-b");highlightRelationPath(compareA,compareB);}
}
function drawEdges(list,pos,w,h,rowStep=255){
 const ids=new Set(list.map(p=>p.id)),svg=$('edges');
 svg.setAttribute('width',w);svg.setAttribute('height',h);svg.style.width=w+'px';svg.style.height=h+'px';svg.setAttribute('viewBox',`0 0 ${w} ${h}`);
 // ابعاد واقعی کارت‌ها خوانده می‌شود؛ بنابراین وجود قومیت یا متن اضافه مختصات خطوط را خراب نمی‌کند.
 const box=id=>{const el=document.querySelector(`.node[data-id="${id}"]`);if(!el)return null;const x=el.offsetLeft,y=el.offsetTop,cw=el.offsetWidth,ch=el.offsetHeight;return {id:Number(id),x,y,w:cw,h:ch,cx:x+cw/2,cy:y+ch/2,top:y,bottom:y+ch,left:x,right:x+cw};};
 const pairKey=(a,b)=>[Number(a),Number(b)].sort((x,y)=>x-y).join(':');
 const colors=['#2476c7','#d34d72','#16866b','#9561c7','#d17a24','#168b9a','#b34d9b','#6675c9'];
 const childColor=id=>colors[Math.abs(Number(id))%colors.length];
 let paths='',marriagePoints=new Map(),drawnPairs=new Set();
 // برای هر زوج، آخرین وضعیت ازدواج مبناست: ازدواج فعال=نقطه طلایی، طلاق=ضربدر قرمز، وفات=نقطه مشکی.
 const latestMarriage=new Map();
 DATA.marriages.filter(m=>ids.has(m.husband_id)&&ids.has(m.wife_id)).forEach(m=>latestMarriage.set(pairKey(m.husband_id,m.wife_id),m));
 [...latestMarriage.entries()].forEach(([key,m])=>{
   const a=box(m.husband_id),b=box(m.wife_id);if(!a||!b)return;
   const husband=a,wife=b;
   const y=(a.cy+b.cy)/2;
   let join;
   const wivesForMan=DATA.marriages.filter(x=>x.husband_id===m.husband_id).sort((x,y)=>x.id-y.id);
   const wifeIndex=wivesForMan.findIndex(x=>x.id===m.id)+1;
   if(wife.cx<husband.cx){
     if(wifeIndex<=2){
       join={x:(wife.right+husband.left)/2,y};
       paths+=`<path class="edge-marriage" d="M ${wife.right} ${y} H ${husband.left}"/>`;
     }else{
       const laneY=Math.min(husband.top,wife.top)-14-(wifeIndex-2)*14;
       const nearIndex=wifeIndex%2===1?1:2;
       const nearBox=box(wivesForMan[nearIndex-1]?.wife_id)||husband;
       join={x:(wife.cx+nearBox.cx)/2,y:laneY};
       paths+=`<path class="edge-marriage" d="M ${husband.left} ${y} V ${laneY} H ${wife.cx} V ${wife.top}"/>`;
     }
   }else{
     if(wifeIndex<=2){
       join={x:(husband.right+wife.left)/2,y};
       paths+=`<path class="edge-marriage" d="M ${husband.right} ${y} H ${wife.left}"/>`;
     }else{
       const laneY=Math.min(husband.top,wife.top)-14-(wifeIndex-2)*14;
       const nearIndex=wifeIndex%2===1?1:2;
       const nearBox=box(wivesForMan[nearIndex-1]?.wife_id)||husband;
       join={x:(wife.cx+nearBox.cx)/2,y:laneY};
       paths+=`<path class="edge-marriage" d="M ${husband.right} ${y} V ${laneY} H ${wife.cx} V ${wife.top}"/>`;
     }
   }
   marriagePoints.set(key,join);
   if(m.end_reason==='طلاق'){
     // ناحیه کلیک بزرگ‌تر از خود ضربدر است تا روی موبایل هم به‌آسانی انتخاب شود.
     paths+=`<g class="divorce-marker" data-marriage-id="${m.id}" onclick="restoreDivorce(${m.id})" style="pointer-events:all;cursor:pointer"><circle cx="${join.x}" cy="${join.y}" r="13" fill="transparent"/><path d="M ${join.x-5.5} ${join.y-5.5} L ${join.x+5.5} ${join.y+5.5} M ${join.x+5.5} ${join.y-5.5} L ${join.x-5.5} ${join.y+5.5}" stroke="#d71920" stroke-width="3.2" stroke-linecap="round" fill="none"/></g>`;
   }else if(m.end_reason==='وفات'){
     paths+=`<circle cx="${join.x}" cy="${join.y}" r="5.8" fill="#111820" stroke="#fff" stroke-width="1.5"/>`;
   }else{
     paths+=`<circle cx="${join.x}" cy="${join.y}" r="5.5" fill="#c99a3b" stroke="#fff" stroke-width="1.8"/>`;
   }
 });
 // برای هر خانواده یک تنه از نقطه طلایی تا گره آبی ساخته می‌شود؛
 // سپس یک شاخه افقی مشترک، همه فرزندان را به همان گره متصل می‌کند.
 const parentEdges=DATA.parents.filter(e=>ids.has(e.parent_id)&&ids.has(e.child_id));
 const parentsByChild=new Map();
 parentEdges.forEach(e=>{
   if(!parentsByChild.has(e.child_id))parentsByChild.set(e.child_id,{});
   parentsByChild.get(e.child_id)[e.relation]=e.parent_id;
 });
 const familyBranches=new Map();
 parentsByChild.forEach((relations,childId)=>{
   const child=box(childId);if(!child)return;
   const father=relations['پدر']?box(relations['پدر']):null;
   const mother=relations['مادر']?box(relations['مادر']):null;
   let source=null,key='';
   if(father&&mother){
     key=pairKey(father.id,mother.id);
     source=marriagePoints.get(key)||{x:(father.cx+mother.cx)/2,y:Math.max(father.bottom,mother.bottom)};
   }else{
     const onlyParent=father||mother;if(onlyParent){key='single:'+onlyParent.id;source={x:onlyParent.cx,y:onlyParent.bottom};}
   }
   if(!source)return;
   if(!familyBranches.has(key))familyBranches.set(key,{source,kids:[]});
   familyBranches.get(key).kids.push(child);
 });
 familyBranches.forEach(({source,kids})=>{
   // تنهٔ زوج فقط تا گره آبی پایین می‌آید؛ همهٔ اتصال‌های فرزندان
   // از همان گره آبی و به‌صورت خط مستقیم و رنگ مستقل هر فرزند رسم می‌شوند.
   const branchY=source.y+Math.max(30,rowStep/2);
   const branchColor='#1684d8';
   paths+=`<path d="M ${source.x} ${source.y} V ${branchY}" fill="none" stroke="${branchColor}" stroke-width="3" stroke-linecap="round"/>`;
   kids.forEach(child=>{
     const color=childColor(child.id);
     paths+=`<path d="M ${source.x} ${branchY} L ${child.cx} ${child.top}" fill="none" stroke="${color}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>`;
   });
   paths+=`<circle cx="${source.x}" cy="${branchY}" r="6" fill="#1684d8" stroke="#fff" stroke-width="2"/>`;
 });
 svg.innerHTML=paths;
}
function selectNode(id){selectedId=id;document.querySelectorAll('.node').forEach(n=>n.classList.toggle('selected',Number(n.dataset.id)===id));}
let suppressCardClick=false;function cardClick(id){if(suppressCardClick){suppressCardClick=false;return}selectNode(id);}
function placeContext(x,y){let c=$('context');c.style.display='block';c.style.left='8px';c.style.top='8px';requestAnimationFrame(()=>{let r=c.getBoundingClientRect();c.style.left=Math.max(8,Math.min(x,innerWidth-r.width-8))+'px';c.style.top=Math.max(8,Math.min(y,innerHeight-r.height-8))+'px'})}function showContext(e,id){e.preventDefault();selectedId=id;selectNode(id);placeContext(e.clientX,e.clientY)}
document.addEventListener('click',e=>{if(!$('context').contains(e.target))$('context').style.display='none'});
let touchTimer=null,touchStart=null;document.addEventListener('touchstart',e=>{let n=e.target.closest('.node');if(!n)return;touchStart={x:e.touches[0].clientX,y:e.touches[0].clientY,id:Number(n.dataset.id)};touchTimer=setTimeout(()=>{suppressCardClick=true;selectedId=touchStart.id;selectNode(selectedId);placeContext(touchStart.x,touchStart.y)},550)},{passive:true});document.addEventListener('touchmove',e=>{if(touchStart&&Math.hypot(e.touches[0].clientX-touchStart.x,e.touches[0].clientY-touchStart.y)>12){clearTimeout(touchTimer);touchStart=null}},{passive:true});document.addEventListener('touchend',()=>{clearTimeout(touchTimer);touchStart=null});
function ctxAction(a){$('context').style.display='none';if(!selectedId)return;if(['پدر','مادر','همسر','پسر','دختر'].includes(a)){relation=a;openRelated();}else if(a==='ویرایش')editPerson();else if(a==='روابط')editRelations();else if(a==='فوت')registerDeath();else if(a==='طلاق')registerDivorce();else if(a==='حذف')deletePerson();else if(a==='مشاهده')viewPerson();}
function showModal(title,body,mode){compressedPhotoData='';photoCompressionPromise=Promise.resolve();$('saveBtn').onclick=saveModal;$('saveBtn').style.display='';$('modalTitle').textContent=title;$('modalBody').innerHTML=body;$('modal').style.display='flex';modalMode=mode;}
function closeModal(){$('modal').style.display='none';modalMode='';}
function fields(p={}){return `<div class="formgrid"><div class="field"><label>نام *</label><input class="input" id="f_first_name" value="${esc(p.first_name||'')}"></div><div class="field"><label>نام خانوادگی</label><input class="input" id="f_last_name" value="${esc(p.last_name||'')}"></div><div class="field"><label>جنسیت</label><select id="f_gender"><option ${p.gender==='مرد'?'selected':''}>مرد</option><option ${p.gender==='زن'?'selected':''}>زن</option></select></div><div class="field"><label>تاریخ تولد</label><input class="input" id="f_birth_date" placeholder="مثلاً ۱۳۶۰/۰۲/۱۵" value="${esc(p.birth_date||'')}"></div><div class="field"><label>قوم / طایفه</label><input class="input" id="f_tribe" value="${esc(p.tribe||'')}"></div><div class="field"><label>شغل</label><input class="input" id="f_job" value="${esc(p.job||'')}"></div><div class="field"><label>تلفن</label><input class="input" id="f_phone" value="${esc(p.phone||'')}"></div><div class="field"><label>شهر محل سکونت</label><input class="input" id="f_city" value="${esc(p.city||'')}"></div><div class="field full"><label>تصویر شخص (پس از فشرده‌سازی حداکثر ۵۰ کیلوبایت)</label><input class="input" id="f_photo" type="file" accept="image/*" onchange="compressPersonPhoto(this)"><div id="photoPreview" style="margin-top:8px">${p.has_photo?`<img src="/api/person/${p.id}/photo" style="width:90px;height:90px;object-fit:cover;border-radius:12px"><label><input type="checkbox" id="f_remove_photo"> حذف تصویر فعلی (در صورت نیاز)</label><small style="display:block;color:#64748b;margin-top:5px">برای تعویض، عکس جدید را از کادر انتخاب تصویر برگزینید؛ عکس جدید جایگزین عکس قبلی می‌شود.</small>`:''}</div></div><div class="field full"><label>توضیحات</label><textarea id="f_notes" rows="2">${esc(p.notes||'')}</textarea></div></div>`}
let compressedPhotoData='',photoCompressionPromise=Promise.resolve();
function compressPersonPhoto(input){
 compressedPhotoData='';const removeToggle=$('f_remove_photo');if(removeToggle)removeToggle.checked=false;const f=input.files?.[0];if(!f){photoCompressionPromise=Promise.resolve();return}
 photoCompressionPromise=new Promise((resolve,reject)=>{const img=new Image(),url=URL.createObjectURL(f);const finish=()=>URL.revokeObjectURL(url);
 img.onload=()=>{try{const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');let w=img.naturalWidth||img.width,h=img.naturalHeight||img.height,maxSide=1200;let ratio=Math.min(1,maxSide/Math.max(w,h));w=Math.max(1,Math.round(w*ratio));h=Math.max(1,Math.round(h*ratio));let data='';
 for(let pass=0;pass<7;pass++){canvas.width=w;canvas.height=h;ctx.clearRect(0,0,w,h);ctx.drawImage(img,0,0,w,h);let q=.86;data=canvas.toDataURL('image/jpeg',q);while(data.length*0.75>50*1024&&q>.28){q=Math.max(.28,q-.08);data=canvas.toDataURL('image/jpeg',q)}if(data.length*0.75<=50*1024)break;w=Math.max(180,Math.round(w*.82));h=Math.max(180,Math.round(h*.82));}
 const bytes=Math.floor((data.length-data.indexOf(',')-1)*3/4);if(!data.startsWith('data:image/jpeg;base64,')||bytes>50*1024)throw Error('فشرده‌سازی تصویر به حجم ۵۰ کیلوبایت نرسید؛ لطفاً عکس دیگری انتخاب کنید.');
 compressedPhotoData=data;$('photoPreview').innerHTML=`<img src="${data}" style="width:90px;height:90px;object-fit:cover;border-radius:12px"><div><small>تصویر آماده ذخیره · ${Math.ceil(bytes/1024)} کیلوبایت</small></div>`;finish();resolve();
 }catch(err){finish();input.value='';compressedPhotoData='';alert(err.message||'فشرده‌سازی تصویر ناموفق بود.');reject(err)}};
 img.onerror=()=>{finish();input.value='';alert('خواندن تصویر ممکن نیست یا فرمت آن پشتیبانی نمی‌شود.');reject(Error('خواندن تصویر ناموفق بود.'))};img.src=url;
 });photoCompressionPromise.catch(()=>{});
}
function readFields(){let o={};['first_name','last_name','gender','birth_date','tribe','job','phone','city','notes'].forEach(k=>o[k]=$('f_'+k)?.value||'');if(compressedPhotoData)o.photo_data=compressedPhotoData;if($('f_remove_photo')?.checked&&!compressedPhotoData)o.remove_photo=true;return o}
function openPerson(){selectedId=null;showModal('افزودن شخص جدید',fields(),'newperson')}
async function openRelated(){let base=DATA.people.find(p=>p.id===selectedId);let forced=relation==='همسر'?(base.gender==='مرد'?'زن':'مرد'):(['پدر','پسر'].includes(relation)?'مرد':'زن');showModal('افزودن '+relation,`<p class="hint">شخص جدید به عنوان ${relation} برای «${esc(base.first_name+' '+base.last_name)}» ثبت می‌شود. جنسیت به‌صورت خودکار ${forced} است.</p>${fields({gender:forced})}<hr><h4>اتصال به فرد ثبت‌شده (بدون ساخت شخص جدید)</h4><label>نام یا شناسه فرد موجود را جستجو کنید و از نتایج انتخاب کنید</label><input class="input" id="existingSearch" placeholder="نام یا شناسه شخص را جستجو کنید" oninput="searchExisting()"><div id="existingResults" class="searchresults"></div><input type="hidden" id="existing_id"><div id="motherPickWrap" class="field" style="display:none;margin-top:10px"><label>این فرزند از کدام همسر پدر است؟</label><select id="mother_id" class="input"></select><small>چون این پدر چند همسر دارد، مادر فرزند را مشخص کنید.</small></div><div id="fatherPickWrap" class="field" style="display:none;margin-top:10px"><label>این فرزند از کدام شوهر مادر است؟</label><select id="father_id" class="input"></select><small>چون برای مادر چند ازدواج ثبت شده است، پدر این فرزند را مشخص کنید.</small></div><div class="field" style="margin-top:10px"><label>تاریخ شروع ازدواج (در صورت همسر)</label><input class="input" id="start_date" placeholder="مثلاً ۱۴۰۰/۰۱/۰۱"></div>`,'related');if(['پسر','دختر'].includes(relation)&&base.gender==='مرد')updateMotherChoices(base.id)}
let searchTimer=null;async function searchExisting(){if($('existing_id'))$('existing_id').value='';clearTimeout(searchTimer);searchTimer=setTimeout(async()=>{let q=$('existingSearch').value;let resp=await api('/api/search?q='+encodeURIComponent(q));let arr=resp.items||[];let base=DATA.people.find(p=>p.id===selectedId);let g=relation==='همسر'?(base.gender==='مرد'?'زن':'مرد'):(['پدر','پسر'].includes(relation)?'مرد':'زن');$('existingResults').innerHTML=arr.filter(p=>p.gender===g&&p.id!==selectedId).map(p=>`<div class="result" onclick="chooseExisting(${p.id},'${esc(p.first_name+' '+p.last_name)}')">${esc(p.first_name+' '+p.last_name)} · ${esc(p.tribe||'بدون طایفه')} (${p.gender})</div>`).join('')||'<div class="result">موردی یافت نشد.</div>'},180)}function chooseExisting(id,label){$('existing_id').value=id;$('existingSearch').value=label;$('existingResults').innerHTML='<div class="result active">انتخاب شد: '+esc(label)+'</div>';updateMotherChoices(id)}
function updateMotherChoices(personId){
 let mw=$('motherPickWrap'),fw=$('fatherPickWrap');if(!mw||!fw)return;mw.style.display='none';fw.style.display='none';
 let fatherId=null,motherId=null,base=DATA.people.find(p=>p.id===selectedId);
 if(relation==='پدر')fatherId=Number(personId);
 else if(relation==='مادر')motherId=Number(personId);
 else if(['پسر','دختر'].includes(relation)){if(base?.gender==='مرد')fatherId=base.id;else motherId=base.id;}
 if(fatherId){let wives=DATA.marriages.filter(m=>m.husband_id===fatherId).map(m=>DATA.people.find(p=>p.id===m.wife_id)).filter(Boolean);if(wives.length>1){mw.style.display='block';$('mother_id').innerHTML=wives.map(w=>`<option value="${w.id}">${esc(w.person_code+' - '+w.first_name+' '+w.last_name)}</option>`).join('')}}
 if(motherId){let husbands=DATA.marriages.filter(m=>m.wife_id===motherId).map(m=>DATA.people.find(p=>p.id===m.husband_id)).filter(Boolean);if(husbands.length>1){fw.style.display='block';$('father_id').innerHTML=husbands.map(h=>`<option value="${h.id}">${esc(h.person_code+' - '+h.first_name+' '+h.last_name)}</option>`).join('')}}
}
async function editPerson(){try{if(!selectedId)throw Error('ابتدا شخص را انتخاب کنید.');let p=await api('/api/person/'+selectedId);showModal('ویرایش اطلاعات شخص',fields(p),'editperson');$('saveBtn').onclick=saveModal;$('saveBtn').style.display='';}catch(e){alert('باز کردن ویرایش ناموفق بود: '+e.message)}}
async function editRelations(){let p=DATA.people.find(x=>x.id===selectedId);let rels=DATA.parents.filter(x=>x.child_id===selectedId||x.parent_id===selectedId);let ms=DATA.marriages.filter(x=>x.husband_id===selectedId||x.wife_id===selectedId);let html='<p><b>روابط والدین و فرزندان</b></p>'+rels.map(x=>{let other=DATA.people.find(p=>p.id===(x.child_id===selectedId?x.parent_id:x.child_id));return `<div class="result">${x.relation}: ${esc(other?.person_code+' '+other?.first_name+' '+other?.last_name)} <button class="btn" onclick="removeParent(${x.id})">حذف رابطه</button></div>`}).join('');html+='<p style="margin-top:15px"><b>ازدواج‌ها</b></p>'+ms.map(x=>{let other=DATA.people.find(p=>p.id===(x.husband_id===selectedId?x.wife_id:x.husband_id));return `<div class="result">${esc(other?.person_code+' '+other?.first_name+' '+other?.last_name)} · ${x.end_date?'پایان‌یافته':'فعال'} <button class="btn" onclick="endMarriage(${x.id})">ثبت طلاق</button></div>`}).join('');html+=`<hr><h4>ثبت رابطه با شخصی که قبلاً ثبت شده است</h4><div class="field"><label>نوع رابطه با ${esc(p.first_name+' '+p.last_name)}</label><select id="editRelType" class="input" onchange="resetEditRelationSearch()"><option value="پدر">پدر</option><option value="مادر">مادر</option><option value="همسر">همسر</option><option value="پسر">پسر</option><option value="دختر">دختر</option></select></div><div class="field" style="margin-top:8px"><label>جستجوی شخص بر اساس نام یا شناسه</label><input id="editRelSearch" class="input" placeholder="نام یا P-000001" oninput="searchEditRelation()"><div id="editRelResults" class="searchresults"></div><input type="hidden" id="editRelTarget"></div><div id="editRelMotherWrap" style="display:none;margin-top:8px"><label>مادر این فرزند (به علت چندهمسری پدر)</label><select id="editRelMother" class="input"></select></div><div id="editRelFatherWrap" style="display:none;margin-top:8px"><label>پدر این فرزند (به علت چندهمسری مادر)</label><select id="editRelFather" class="input"></select></div><button class="btn primary" style="margin-top:10px" onclick="saveExistingRelation()">ذخیره رابطه انتخاب‌شده</button>`;showModal('روابط ثبت‌شده','<div>'+html+'</div>','relations');$('saveBtn').style.display='none';}
let editRelTimer=null;async function searchEditRelation(){if($('editRelTarget'))$('editRelTarget').value='';clearTimeout(editRelTimer);editRelTimer=setTimeout(async()=>{let q=$('editRelSearch').value,rel=$('editRelType').value;let base=DATA.people.find(p=>p.id===selectedId);let g=rel==='همسر'?(base.gender==='مرد'?'زن':'مرد'):(['پدر','پسر'].includes(rel)?'مرد':'زن');let resp=await api('/api/search?q='+encodeURIComponent(q));let arr=resp.items||[];$('editRelResults').innerHTML=arr.filter(p=>p.gender===g&&p.id!==selectedId).map(p=>`<div class="result" onclick="chooseEditRelation(${p.id},'${esc(p.first_name+' '+p.last_name)}')">${esc(p.first_name+' '+p.last_name)} · ${esc(p.tribe||'بدون طایفه')} (${p.gender})</div>`).join('')||'<div class="result">موردی یافت نشد.</div>'},160)}
function chooseEditRelation(id,label){$('editRelTarget').value=id;$('editRelSearch').value=label;$('editRelResults').innerHTML='<div class="result active">انتخاب شد: '+esc(label)+'</div>';let rel=$('editRelType').value,base=DATA.people.find(p=>p.id===selectedId),mw=$('editRelMotherWrap'),fw=$('editRelFatherWrap');mw.style.display='none';fw.style.display='none';let fatherId=null,motherId=null;if(rel==='پدر')fatherId=Number(id);else if(rel==='مادر')motherId=Number(id);else if(['پسر','دختر'].includes(rel)){if(base?.gender==='مرد')fatherId=base.id;else motherId=base.id}if(fatherId){let wives=DATA.marriages.filter(m=>m.husband_id===fatherId).map(m=>DATA.people.find(p=>p.id===m.wife_id)).filter(Boolean);if(wives.length>1){mw.style.display='block';$('editRelMother').innerHTML=wives.map(w=>`<option value="${w.id}">${esc(w.person_code+' - '+w.first_name+' '+w.last_name)}</option>`).join('')}}if(motherId){let husbands=DATA.marriages.filter(m=>m.wife_id===motherId).map(m=>DATA.people.find(p=>p.id===m.husband_id)).filter(Boolean);if(husbands.length>1){fw.style.display='block';$('editRelFather').innerHTML=husbands.map(h=>`<option value="${h.id}">${esc(h.person_code+' - '+h.first_name+' '+h.last_name)}</option>`).join('')}}}
async function saveExistingRelation(){let target=$('editRelTarget').value;if(!target){alert('ابتدا یک شخص را از نتایج جستجو انتخاب کنید.');return}let rel=$('editRelType').value,body={base_id:selectedId,target_id:Number(target),relation:rel};if($('editRelMotherWrap').style.display!=='none')body.mother_id=$('editRelMother').value;if($('editRelFatherWrap').style.display!=='none')body.father_id=$('editRelFather').value;try{await api('/api/relation',{method:'POST',body:JSON.stringify(body)});alert('رابطه با موفقیت ذخیره شد.');await loadTree();await editRelations()}catch(e){alert(e.message)}}
function resetEditRelationSearch(){$('editRelTarget').value='';$('editRelSearch').value='';$('editRelResults').innerHTML='';$('editRelMotherWrap').style.display='none';$('editRelFatherWrap').style.display='none'}
async function removeParent(id){if(!confirm('رابطه حذف شود؟'))return;await fetch('/api/parent/'+id,{method:'DELETE'});closeModal();loadTree()}
async function endMarriage(id){if(!confirm('برای این ازدواج طلاق ثبت شود؟'))return;await api('/api/divorce/'+id,{method:'POST',body:JSON.stringify({})});closeModal();loadTree()}
async function restoreDivorce(id){
 if(!confirm('آیا طلاق را حذف می‌کنید؟\nبا تأیید شما این ازدواج دوباره فعال و نشان آن به نقطه طلایی تبدیل می‌شود.'))return;
 try{await api('/api/marriage/restore-divorce/'+id,{method:'POST',body:JSON.stringify({})});await loadTree();}
 catch(e){alert(e.message)}
}
async function registerDeath(){let d=prompt('تاریخ فوت را وارد کنید (خالی = امروز):','');if(d===null)return;try{await api('/api/death/'+selectedId,{method:'POST',body:JSON.stringify({death_date:d})});await loadTree()}catch(e){alert(e.message)}}
async function registerDivorce(){let ms=await api('/api/person/'+selectedId+'/marriages');if(!ms.length){alert('این شخص ازدواج فعال ندارد.');return}let options=ms.map(m=>`${m.id} - ${m.husband_name} / ${m.wife_name}`).join('\n');let id=prompt('شناسه ازدواج موردنظر را انتخاب کنید:\n'+options,ms[0].id);if(!id)return;if(!ms.some(m=>m.id==Number(id))){alert('شناسه ازدواج معتبر نیست.');return}let d=prompt('تاریخ طلاق (خالی = امروز):','');if(d===null)return;try{await api('/api/divorce/'+id,{method:'POST',body:JSON.stringify({end_date:d})});await loadTree()}catch(e){alert(e.message)}}
async function deletePerson(){if(!selectedId){alert('ابتدا کارت شخص موردنظر را انتخاب کنید.');return}let p=DATA.people.find(x=>x.id===selectedId);if(!p){alert('شخص انتخاب‌شده پیدا نشد.');return}if(!confirm(`شخص «${p.first_name} ${p.last_name}» و روابط ثبت‌شده او حذف شود؟ این کار قابل بازگشت نیست.`))return;try{await api('/api/person/'+selectedId,{method:'DELETE'});selectedId=null;closeModal();await loadTree()}catch(e){alert(e.message)}}
async function viewPerson(){
 let f=await api('/api/person/'+selectedId+'/family'),p=f.person;
 const personLabel=x=>x?`${esc(x.person_code)} · ${esc((x.first_name||'')+' '+(x.last_name||''))} <span class="badge">${esc(x.gender||'')}</span>`:'ثبت نشده';
 const list=(arr,extra='')=>arr.length?'<ul class="family-list">'+arr.map(x=>`<li>${personLabel(x)} ${extra?extra(x):''}</li>`).join('')+'</ul>':'<div class="family-none">موردی ثبت نشده است.</div>';
 const spouseExtra=x=>`<small>${x.end_date?'پایان ازدواج: '+esc(x.end_date)+' ('+esc(x.end_reason||'')+')':'ازدواج فعال'}${x.start_date?' · شروع: '+esc(x.start_date):''}</small>`;
 const html=`<div class="person-detail-head"><div class="code">${esc(p.person_code)}</div><h2>${esc(p.first_name+' '+p.last_name)}</h2><span class="badge">${esc(p.gender)} · ${p.death_date?'درگذشته':'زنده'}</span></div>
 <div class="detail-grid">
 <div><b>تاریخ تولد</b><span>${esc(p.birth_date||'—')}</span></div><div><b>تاریخ فوت</b><span>${esc(p.death_date||'—')}</span></div>
 <div><b>قوم / طایفه</b><span>${esc(p.tribe||'—')}</span></div><div><b>شغل</b><span>${esc(p.job||'—')}</span></div>
 <div><b>تلفن</b><span>${esc(p.phone||'—')}</span></div><div><b>شهر محل سکونت</b><span>${esc(p.city||'—')}</span></div>
 <div class="wide"><b>توضیحات</b><span>${esc(p.notes||'—')}</span></div></div>
 <section class="family-section"><h4>پدر</h4>${personLabel(f.father)}</section>
 <section class="family-section"><h4>مادر</h4>${personLabel(f.mother)}</section>
 <section class="family-section"><h4>همسران</h4>${list(f.spouses,spouseExtra)}</section>
 <section class="family-section"><h4>فرزندان</h4>${list(f.children)}</section>
 <section class="family-section"><h4>خواهران و برادران</h4>${list(f.siblings)}</section>`;
 showModal('مشخصات کامل و خانواده شخص',html,'details');$('saveBtn').style.display='none';
}
async function saveModal(){const btn=$('saveBtn');try{if(modalMode==='editperson'||modalMode==='newperson'){const name=$('f_first_name')?.value?.trim();if(!name){alert('نام را وارد کنید.');return}}btn.disabled=true;btn.textContent='در حال ذخیره...';await photoCompressionPromise;const payload=readFields();if(modalMode==='newperson'){await api('/api/person',{method:'POST',body:JSON.stringify(payload)})}else if(modalMode==='editperson'){if(!selectedId)throw Error('شخصی برای ویرایش انتخاب نشده است.');await api('/api/person/'+selectedId,{method:'PUT',body:JSON.stringify(payload)})}else if(modalMode==='related'){let existing=$('existing_id').value;let body={base_id:selectedId,relation,start_date:$('start_date')?.value||'',mother_id:$('mother_id')?.value||''};if($('fatherPickWrap')?.style.display!=='none'&&$('father_id'))body.father_id=$('father_id').value;if(existing){body.target_id=Number(existing);await api('/api/relation',{method:'POST',body:JSON.stringify(body)})}else{Object.assign(body,payload);await api('/api/related',{method:'POST',body:JSON.stringify(body)})}}else{throw Error('فرم فعلی قابل ذخیره نیست.')}closeModal();await loadTree();}catch(e){alert('ذخیره اطلاعات انجام نشد: '+(e.message||e))}finally{btn.disabled=false;btn.textContent='ذخیره';btn.onclick=saveModal;}}

function zoom(f){const cv=$('treecanvas'),cx=cv.scrollLeft+cv.clientWidth/2,cy=cv.scrollTop+cv.clientHeight/2;scale=Math.max(.12,Math.min(3.2,scale*f));$('world').style.transform=`scale(${scale})`;updateWorldSpace();cv.scrollTo({left:Math.max(0,(cv.scrollLeft+cv.clientWidth/2)*f-cv.clientWidth/2),top:Math.max(0,(cv.scrollTop+cv.clientHeight/2)*f-cv.clientHeight/2),behavior:'smooth'})}
function fitTree(){const cv=$('treecanvas');const sx=Math.max(.12,(cv.clientWidth-28)/Math.max(1,treeBaseWidth));const sy=Math.max(.12,(cv.clientHeight-28)/Math.max(1,treeBaseHeight));scale=Math.min(1,sx,sy);$('world').style.transform=`scale(${scale})`;updateWorldSpace();requestAnimationFrame(()=>cv.scrollTo({left:0,top:0,behavior:'smooth'}));}
// جابه‌جایی درخت با یک انگشت یا ماوس؛ شروع حرکت از روی کارت‌ها نیز مجاز است.
let drag=null;const canvas=$('treecanvas');canvas.addEventListener('pointerdown',e=>{if(e.pointerType!=='mouse')return;if(e.target.closest('.zoomtools')||e.target.closest('button')||e.target.closest('input'))return;if(e.pointerType==='mouse'&&e.button!==0)return;drag={id:e.pointerId,x:e.clientX,y:e.clientY,l:canvas.scrollLeft,t:canvas.scrollTop,moved:false};try{canvas.setPointerCapture(e.pointerId)}catch(_){}});canvas.addEventListener('pointermove',e=>{if(drag&&drag.id===e.pointerId){const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(!drag.moved&&Math.hypot(dx,dy)>6){drag.moved=true;suppressCardClick=true;clearTimeout(touchTimer);touchStart=null;}if(drag.moved){canvas.scrollLeft=drag.l-dx;canvas.scrollTop=drag.t-dy;e.preventDefault();}}});function endCanvasDrag(e){if(drag&&(!e||drag.id===e.pointerId)){if(drag.moved){setTimeout(()=>{suppressCardClick=false},80)}drag=null}}canvas.addEventListener('pointerup',endCanvasDrag);canvas.addEventListener('pointercancel',endCanvasDrag);
// پیمایش لمسی قطعی: یک انگشت=حرکت افقی/عمودی، دو انگشت=بزرگ‌نمایی.
let pinchStartDist=0,pinchStartScale=1,pinchActive=false,touchPan=null;
canvas.addEventListener('touchstart',e=>{
 if(e.touches.length===2){pinchActive=true;touchPan=null;pinchStartDist=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);pinchStartScale=scale;drag=null;e.preventDefault();return;}
 if(e.touches.length===1){const t=e.touches[0];touchPan={x:t.clientX,y:t.clientY,left:canvas.scrollLeft,top:canvas.scrollTop,moved:false};clearTimeout(touchTimer);}
},{passive:false});
canvas.addEventListener('touchmove',e=>{
 if(pinchActive&&e.touches.length===2){let d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);scale=Math.max(.12,Math.min(3.2,pinchStartScale*d/Math.max(1,pinchStartDist)));$('world').style.transform=`scale(${scale})`;updateWorldSpace();e.preventDefault();return;}
 if(touchPan&&e.touches.length===1){const t=e.touches[0],dx=t.clientX-touchPan.x,dy=t.clientY-touchPan.y;if(!touchPan.moved&&Math.hypot(dx,dy)>5){touchPan.moved=true;suppressCardClick=true;touchStart=null;}if(touchPan.moved){canvas.scrollLeft=touchPan.left-dx;canvas.scrollTop=touchPan.top-dy;e.preventDefault();}}
},{passive:false});
canvas.addEventListener('touchend',e=>{if(e.touches.length<2)pinchActive=false;if(e.touches.length===0){if(touchPan?.moved)setTimeout(()=>suppressCardClick=false,100);touchPan=null;}},{passive:true});
canvas.addEventListener('touchcancel',()=>{touchPan=null;pinchActive=false;},{passive:true});
// دکمه‌های شناور جستجو و نسبت‌ها با کشیدن انگشت/ماوس جابه‌جا می‌شوند و جای آن‌ها ذخیره می‌شود.
(function enableFloatingButtonMove(){
 const ids=['.floating-search','.floating-compare'];
 ids.forEach((selector,index)=>{
  const el=document.querySelector(selector);if(!el)return;
  const key='shajareh-floating-pos-'+(index===0?'search':'compare');
  try{const saved=JSON.parse(localStorage.getItem(key)||'null');if(saved&&Number.isFinite(saved.left)&&Number.isFinite(saved.top)){el.style.left=saved.left+'px';el.style.top=saved.top+'px';el.style.right='auto';el.style.bottom='auto';}}catch(_){ }
  let state=null;
  el.addEventListener('pointerdown',e=>{
   if(e.pointerType==='mouse'&&e.button!==0)return;
   const r=el.getBoundingClientRect();state={id:e.pointerId,x:e.clientX,y:e.clientY,left:r.left,top:r.top,moved:false};
   try{el.setPointerCapture(e.pointerId)}catch(_){ }
  });
  el.addEventListener('pointermove',e=>{
   if(!state||state.id!==e.pointerId)return;
   const dx=e.clientX-state.x,dy=e.clientY-state.y;
   if(!state.moved&&Math.hypot(dx,dy)>7){state.moved=true;el.classList.add('dragging');el.style.right='auto';el.style.bottom='auto';}
   if(state.moved){const left=Math.max(0,Math.min(innerWidth-el.offsetWidth,state.left+dx));const top=Math.max(0,Math.min(innerHeight-el.offsetHeight,state.top+dy));el.style.left=left+'px';el.style.top=top+'px';e.preventDefault();}
  });
  const finish=e=>{if(!state||state.id!==e.pointerId)return;if(state.moved){const r=el.getBoundingClientRect();localStorage.setItem(key,JSON.stringify({left:r.left,top:r.top}));el.dataset.dragged='1';setTimeout(()=>delete el.dataset.dragged,350);}state=null;el.classList.remove('dragging');};
  el.addEventListener('pointerup',finish);el.addEventListener('pointercancel',finish);
  el.addEventListener('click',e=>{if(el.dataset.dragged==='1'){e.preventDefault();e.stopImmediatePropagation();}},true);
 });
})();
if(window.CURRENT_ROLE!=='admin')$('usersMenuBtn').style.display='none';loadTree();
