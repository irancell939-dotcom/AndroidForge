package ir.khavaran.truckmanager

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.view.View
import android.widget.ProgressBar
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.widget.Toast
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private var attempts = 0
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 7401

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        status = TextView(this).apply {
            text = "در حال آماده‌سازی برنامه..."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(24, 24, 24, 12)
        }
        progress = ProgressBar(this).apply { isIndeterminate = true }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            addJavascriptInterface(AndroidBridge(), "AndroidBridge")
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    view: WebView?,
                    callback: ValueCallback<Array<Uri>>?,
                    params: FileChooserParams?
                ): Boolean {
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = callback
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    return try {
                        startActivityForResult(intent, filePickerRequest)
                        true
                    } catch (e: Exception) {
                        filePathCallback?.onReceiveValue(null)
                        filePathCallback = null
                        Toast.makeText(this@MainActivity, "باز کردن انتخاب‌گر فایل ممکن نیست", Toast.LENGTH_LONG).show()
                        false
                    }
                }
            }
            setDownloadListener { url, userAgent, _, _, _ ->
                try {
                    val request = DownloadManager.Request(Uri.parse(url))
                    request.setTitle("پشتیبان مدیریت کامیون")
                    request.setDescription("ذخیره فایل پشتیبان در پوشه Downloads")
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    request.setAllowedOverMetered(true)
                    request.setAllowedOverRoaming(true)
                    request.addRequestHeader("User-Agent", userAgent ?: "")
                    CookieManager.getInstance().getCookie(url)?.let {
                        request.addRequestHeader("Cookie", it)
                    }
                    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    request.setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS,
                        "Truck_Manager_Backup_$stamp.db"
                    )
                    val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    manager.enqueue(request)
                    Toast.makeText(this@MainActivity, "دانلود پشتیبان آغاز شد؛ پوشه Downloads را بررسی کنید.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "خطا در دانلود: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        layout.addView(status)
        layout.addView(progress)
        layout.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)

        try {
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
            Python.getInstance().getModule("server").callAttr("start_server", filesDir.absolutePath)
            waitForServer()
        } catch (e: Exception) {
            status.text = "خطا در راه‌اندازی: ${e.message}"
            progress.visibility = View.GONE
        }
    }

    private inner class AndroidBridge {
        @JavascriptInterface
        fun printPage() {
            runOnUiThread {
                try {
                    val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val adapter = webView.createPrintDocumentAdapter("گزارش_مدیریت_کامیون")
                    manager.print(
                        "گزارش مدیریت کامیون",
                        adapter,
                        PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .build()
                    )
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "آماده‌سازی چاپ ناموفق بود: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == filePickerRequest) {
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
    }

    private fun waitForServer() {
        thread {
            var ready = false
            while (attempts < 60 && !ready) {
                try {
                    val conn = URL("http://127.0.0.1:5008/").openConnection() as HttpURLConnection
                    conn.connectTimeout = 700
                    conn.readTimeout = 700
                    conn.connect()
                    ready = conn.responseCode in 200..499
                    conn.disconnect()
                } catch (_: Exception) { }
                if (!ready) Thread.sleep(500)
                attempts++
            }
            handler.post {
                progress.visibility = View.GONE
                if (ready) {
                    status.visibility = View.GONE
                    webView.loadUrl("http://127.0.0.1:5008/")
                } else {
                    status.text = "تعذر تشغيل سرور داخلی برنامه. لطفاً برنامه را دوباره اجرا کنید."
                }
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
