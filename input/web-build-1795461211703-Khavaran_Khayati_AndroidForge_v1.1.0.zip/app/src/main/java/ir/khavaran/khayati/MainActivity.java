package ir.khavaran.khayati;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.print.*;
import android.webkit.*;
import android.webkit.ValueCallback;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.app.DownloadManager;
import android.os.Environment;
import android.webkit.URLUtil;
import android.webkit.CookieManager;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int MAX_WAIT_MS = 45000;
    private static final int POLL_MS = 350;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9);

        Intent s = new Intent(this, KhavaranService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(Color.parseColor("#F4EDDC"));
            getWindow().setNavigationBarColor(Color.parseColor("#F4EDDC"));
        }
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(true);
        }

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        }
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= 21) {
            web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        applySystemInsetsPadding(web);

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void printPage() {
                runOnUiThread(() -> printWebView());
            }
        }, "KhavaranNative");

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void printPage() {
                runOnUiThread(() -> printWebView());
            }
        }, "KhayatiAndroid");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
                String host = u.getHost() == null ? "" : u.getHost().toLowerCase();

                // اسکنر بارکد
                if ("binaryeye".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "ابتدا Binary Eye را نصب کنید", Toast.LENGTH_LONG).show();
                    }
                    return true;
                }

                // پیامک / تماس / واتس‌اپ
                if ("sms".equals(scheme) || "smsto".equals(scheme) || "mms".equals(scheme)
                        || "mmsto".equals(scheme) || "tel".equals(scheme)
                        || "whatsapp".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "برنامه مناسب برای باز کردن این لینک پیدا نشد", Toast.LENGTH_LONG).show();
                    }
                    return true;
                }

                // لینک وب واتس‌اپ باید در اپ واتس‌اپ باز شود
                if (("http".equals(scheme) || "https".equals(scheme))
                        && ("wa.me".equals(host) || "api.whatsapp.com".equals(host) || "whatsapp.com".equals(host))) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "واتس‌اپ نصب نیست یا باز نشد", Toast.LENGTH_LONG).show();
                    }
                    return true;
                }

                if ("http".equals(scheme) || "https".equals(scheme)) {
                    if ("127.0.0.1".equals(host) || "localhost".equals(host)) return false;
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(
                    "window.print=function(){if(window.KhavaranNative){window.KhavaranNative.printPage();}else if(window.KhayatiAndroid){window.KhayatiAndroid.printPage();}};",
                    null
                );
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    // اجازه انتخاب هر فایل (db/sqlite و ...)
                    if (intent.getType() == null || "*/*".equals(intent.getType()) == false) {
                        // keep as is
                    }
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    Toast.makeText(MainActivity.this, "امکان باز کردن انتخاب فایل نیست", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });

        // دانلود فایل پشتیبان و سایر پیوست‌ها روی حافظه گوشی
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                if (fileName == null || fileName.isEmpty()) fileName = "khayati_backup.db";
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType != null ? mimeType : "application/octet-stream");
                req.addRequestHeader("User-Agent", userAgent);
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null && !cookies.isEmpty()) {
                    req.addRequestHeader("Cookie", cookies);
                }
                req.setDescription("دانلود فایل خاوران");
                req.setTitle(fileName);
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                dm.enqueue(req);
                Toast.makeText(MainActivity.this, "دانلود شروع شد: " + fileName, Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "خطا در دانلود فایل", Toast.LENGTH_LONG).show();
            }
        });
        setContentView(web);

        web.loadDataWithBaseURL(
            null,
            "<!DOCTYPE html><html dir='rtl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{margin:0;background:#f4eddc;color:#493b2e;font-family:Tahoma,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center}"
                + ".box{padding:28px}.spinner{width:42px;height:42px;border:4px solid #e9dbc0;border-top-color:#8153b8;border-radius:50%;animation:s 0.8s linear infinite;margin:0 auto 16px}"
                + "@keyframes s{to{transform:rotate(360deg)}}p{font-size:15px;line-height:1.8;margin:0}</style></head>"
                + "<body><div class='box'><div class='spinner'></div><p>در حال راه‌اندازی سرور خاوران…</p></div></body></html>",
            "text/html",
            "utf-8",
            null
        );

        new Thread(() -> {
            String url = waitForServerReady();
            runOnUiThread(() -> {
                if (url != null) {
                    web.loadUrl(url);
                } else {
                    web.loadDataWithBaseURL(
                        null,
                        "<!DOCTYPE html><html dir='rtl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                            + "<style>body{margin:0;background:#f4eddc;color:#493b2e;font-family:Tahoma,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center;padding:24px}"
                            + "p{font-size:15px;line-height:1.9}</style></head>"
                            + "<body><p>سرور برنامه راه‌اندازی نشد.<br>برنامه را ببندید و دوباره باز کنید.</p></body></html>",
                        "text/html",
                        "utf-8",
                        null
                    );
                    Toast.makeText(MainActivity.this, "خطا در راه‌اندازی سرور", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    private void applySystemInsetsPadding(final View target) {
        final android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        // دقیقاً ۹ میلی‌متر به بالا نسبت به فاصله قبلی، بدون رفتن زیر نوار وضعیت
        final int nineMmPx = Math.max(1, Math.round(9f * metrics.xdpi / 25.4f));
        final int previousMinTop = Math.round(36 * metrics.density);
        final int minBottom = Math.round(12 * metrics.density);
        final int initialTop = Math.max(0, previousMinTop - nineMmPx);
        target.setPadding(0, initialTop, 0, minBottom);

        if (Build.VERSION.SDK_INT >= 20) {
            target.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override
                public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                    int statusTop = insets.getSystemWindowInsetTop();
                    int bottom = insets.getSystemWindowInsetBottom();
                    // فاصله قبلی منهای ۹ میلی‌متر، اما هرگز کمتر از ارتفاع نوار وضعیت
                    int desired = Math.max(0, previousMinTop - nineMmPx);
                    int top = Math.max(statusTop, desired);
                    if (bottom < minBottom) bottom = minBottom;
                    v.setPadding(0, top, 0, bottom);
                    return insets.consumeSystemWindowInsets();
                }
            });
            target.requestApplyInsets();
        }
    }

    private String waitForServerReady() {
        File portFile = new File(getFilesDir(), "khavaran_data/server_port.txt");
        long deadline = System.currentTimeMillis() + MAX_WAIT_MS;
        Integer port = null;

        while (System.currentTimeMillis() < deadline) {
            if (port == null && portFile.exists()) {
                try {
                    String text = readFile(portFile).trim();
                    if (!text.isEmpty()) {
                        port = Integer.parseInt(text);
                    }
                } catch (Exception ignored) {}
            }
            if (port != null) {
                String candidate = "http://127.0.0.1:" + port + "/";
                if (isServerResponding(candidate)) {
                    return candidate;
                }
            }
            try {
                Thread.sleep(POLL_MS);
            } catch (InterruptedException e) {
                break;
            }
        }
        if (port == null) {
            for (int p = 5000; p <= 5020; p++) {
                String candidate = "http://127.0.0.1:" + p + "/";
                if (isServerResponding(candidate)) return candidate;
            }
        }
        return null;
    }

    private static String readFile(File f) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private static boolean isServerResponding(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(800);
            conn.setReadTimeout(800);
            conn.setRequestMethod("GET");
            conn.setInstanceFollowRedirects(false);
            int code = conn.getResponseCode();
            return code > 0 && code < 500;
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) try { conn.disconnect(); } catch (Exception ignored) {}
        }
    }

    private void printWebView() {
        if (Build.VERSION.SDK_INT >= 19) {
            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
            PrintDocumentAdapter adapter = web.createPrintDocumentAdapter("Khavaran");
            pm.print("چاپ خاوران", adapter, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A5).build());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    String dataString = data.getDataString();
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    } else if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    }
                }
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        // حفظ سرویس پس‌زمینه در صورت بسته شدن موقت
        try {
            Intent s = new Intent(this, KhavaranService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        } catch (Exception ignored) {}
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
