import os
import socket
import threading
from pathlib import Path

_private = os.environ.get("ANDROID_PRIVATE") or os.environ.get("HOME") or str(Path.cwd())
_data = Path(_private) / "khavaran_data"
_data.mkdir(parents=True, exist_ok=True)
os.environ["KHAYATI_DATA_DIR"] = str(_data)
os.environ["HOST"] = "0.0.0.0"
os.environ["KHAVARAN_ANDROID"] = "1"

from werkzeug.serving import make_server
from app import app

_server = None
_thread = None
_port = None
_lock = threading.RLock()
_PORT_FILE = _data / "server_port.txt"


def find_free_port(start=5000, end=5200):
    """اولین پورت آزاد را از بازهٔ داده‌شده پیدا می‌کند."""
    for port in range(start, end + 1):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("0.0.0.0", port))
                return port
        except OSError:
            continue
    # اگر هیچ‌کدام آزاد نبود، سیستم یک پورت تصادفی می‌دهد
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("0.0.0.0", 0))
        return sock.getsockname()[1]


def get_port():
    with _lock:
        return _port


def start_server():
    global _server, _thread, _port
    with _lock:
        if _server is not None:
            return
        _port = find_free_port()
        os.environ["PORT"] = str(_port)
        try:
            _PORT_FILE.write_text(str(_port), encoding="utf-8")
        except Exception:
            pass
        _server = make_server("0.0.0.0", _port, app, threaded=True)
        _thread = threading.Thread(target=_server.serve_forever, name="KhavaranFlask", daemon=True)
        _thread.start()


def stop_server():
    global _server, _thread, _port
    with _lock:
        server = _server
        _server = None
        _thread = None
        _port = None
    if server:
        try:
            server.shutdown()
            server.server_close()
        except Exception:
            pass
    try:
        if _PORT_FILE.exists():
            _PORT_FILE.unlink()
    except Exception:
        pass


# در صورت import مستقیم (غیر از سرویس اندروید) سرور را راه نینداز
# start_server فقط از KhavaranService فراخوانی می‌شود.
