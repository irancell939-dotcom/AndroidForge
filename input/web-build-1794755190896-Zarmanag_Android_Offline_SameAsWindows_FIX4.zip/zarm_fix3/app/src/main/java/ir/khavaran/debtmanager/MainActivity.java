package ir.khavaran.debtmanager;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.os.Handler;
import android.os.Environment;
import android.app.DownloadManager;
import android.database.Cursor;
import android.webkit.DownloadListener;
import android.graphics.Color;
import android.view.View;
import android.webkit.*;
import android.widget.*;
import android.content.*;
import java.io.*;
import java.net.*;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private WebView web;
    private LinearLayout root;
    private TextView status;
    private boolean ready = false;
    private final Handler handler = new Handler();
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 77;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(6,21,47));
        getWindow().setNavigationBarColor(Color.rgb(6,21,47));
        buildScreen();
        resetOldDataOnce();
        preparePrivateFiles();
        startLocalServer();
    }

    private void buildScreen() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(244,246,251));
        status = new TextView(this); status.setText("زرمانگ\nدر حال آماده‌سازی برنامه...");
        status.setTextColor(Color.rgb(31,41,55)); status.setTextSize(17);
        status.setGravity(17); status.setPadding(20,30,20,30);
        root.addView(status, new LinearLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    // Clear the previous test database exactly once for this release.
    // Later app launches keep the user's new local records.
    private void resetOldDataOnce() {
        android.content.SharedPreferences prefs = getSharedPreferences("zarmanag_release", MODE_PRIVATE);
        if (!prefs.getBoolean("fresh_database_v4", false)) {
            File data = new File(getFilesDir(), "zarmanag_data");
            deleteTree(data);
            prefs.edit().putBoolean("fresh_database_v4", true).apply();
        }
    }

    private void deleteTree(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteTree(child);
        }
        file.delete();
    }

    private void preparePrivateFiles() {
        File data = new File(getFilesDir(), "zarmanag_data");
        File db = new File(data,"debts.db");
        File uploads = new File(data,"static/uploads");
        File backups = new File(data,"backups");
        File temp = new File(data,"tmp");
        if (!data.isDirectory() && !data.mkdirs()) {
            status.setText("خطا: پوشه خصوصی برنامه ساخته نشد: " + data.getAbsolutePath());
            return;
        }
        if ((!uploads.isDirectory() && !uploads.mkdirs()) ||
            (!backups.isDirectory() && !backups.mkdirs()) ||
            (!temp.isDirectory() && !temp.mkdirs())) {
            status.setText("خطا: پوشه‌های داخلی برنامه ساخته نشدند.");
            return;
        }
        // The new release intentionally starts with an empty database.
        // Flask init_db() creates debts.db in this private folder on first launch.
        // Flask reads this app-private path for database, uploads, backups and temp files.
        System.setProperty("ZARMANAG_DATA_DIR", data.getAbsolutePath());
    }

    private void startLocalServer() {
        new Thread(() -> {
            try {
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                Python.getInstance().getModule("server").callAttr("start_server", new File(getFilesDir(), "zarmanag_data").getAbsolutePath());
                runOnUiThread(() -> showWebView());
            } catch (Throwable e) {
                final String message = android.util.Log.getStackTraceString(e);
                android.util.Log.e("ZarmanagStartup", message);
                runOnUiThread(() -> status.setText("اجرای برنامه با خطا مواجه شد:\n"+e.toString()+"\n\n"+message));
            }
        }).start();
    }

    private void showWebView() {
        if (ready) return; ready=true;
        web = new WebView(this);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true); s.setLoadWithOverviewMode(true); s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        web.setBackgroundColor(Color.rgb(244,246,251));
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri uri = r.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                if ("sms".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme)) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                        startActivity(intent);
                    } catch (Exception ex) {
                        Toast.makeText(MainActivity.this, "برنامه پیامک یا تماس در دسترس نیست.", Toast.LENGTH_LONG).show();
                    }
                    return true;
                }
                return !"127.0.0.1".equals(uri.getHost());
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) status.setText("اتصال داخلی برقرار نشد. برنامه را دوباره باز کنید.\n"+e.getDescription());
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=cb;
                Intent i=p.createIntent();
                try { startActivityForResult(i,FILE_REQUEST); } catch(Exception ex){fileCallback=null;return false;}
                return true;
            }
        });
        web.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                                  String mimeType, long contentLength) {
                try {
                    String filename = URLUtil.guessFileName(url, contentDisposition, mimeType);
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    request.setTitle(filename);
                    request.setDescription("دریافت نسخه پشتیبان زرمانگ");
                    request.setMimeType(mimeType != null ? mimeType : "application/x-sqlite3");
                    String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
                    if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                    DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    manager.enqueue(request);
                    Toast.makeText(MainActivity.this, "دانلود پشتیبان در پوشه Downloads آغاز شد.", Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "خطا در دانلود: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
        root.removeAllViews(); root.addView(web,new LinearLayout.LayoutParams(-1,-1));
        web.loadUrl("http://127.0.0.1:5000/");
    }

    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if(req==FILE_REQUEST && fileCallback!=null){
            Uri[] result=WebChromeClient.FileChooserParams.parseResult(res,data);
            fileCallback.onReceiveValue(result); fileCallback=null;
        }
    }

    @Override public void onBackPressed() {
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
