import os
import threading
import traceback
import tempfile
from werkzeug.serving import make_server

_server = None
_thread = None

def start_server(data_dir):
    global _server, _thread
    if _server is not None:
        return True
    # All writable application data is confined to Android's private files directory.
    os.makedirs(data_dir, exist_ok=True)
    for name in ('static/uploads', 'backups', 'tmp'):
        os.makedirs(os.path.join(data_dir, name), exist_ok=True)
    os.environ['ZARMANAG_DATA_DIR'] = data_dir
    os.environ['TMPDIR'] = os.path.join(data_dir, 'tmp')
    tempfile.tempdir = os.environ['TMPDIR']
    # Fail early with a useful message if Android did not provide writable storage.
    probe = os.path.join(data_dir, 'tmp', '.write_test')
    with open(probe, 'w', encoding='utf-8') as f:
        f.write('ok')
    os.remove(probe)
    from app import app
    _server = make_server('127.0.0.1', 5000, app, threaded=True)
    _thread = threading.Thread(target=_server.serve_forever, daemon=True)
    _thread.start()
    return True
