# لوغت بلوچی — Balochi Dictionary

A beautiful offline Balochi dictionary Android app with quiz mode.

## Brand Colors
- Night Parchment: `#14110e`
- Saffron Gold: `#e2a45a`
- Cream: `#f6efe2`
- Sage: `#8eae86`

## Features
- Search across Balochi, Persian, English, Arabic, Urdu, Zaboli
- Beautiful dark theme with brand palette
- Word detail bottom sheet
- Quiz mode to practice meanings
- Fully offline (words loaded from assets)

## Build with AndroidForge
1. Zip this entire project folder
2. Upload the ZIP to https://professional-x.github.io/AndroidForge/
3. Build debug or release APK

## Local build
```bash
./gradlew assembleDebug
```

## Structure
- `app/src/main/assets/words.json` — dictionary data
- Jetpack Compose UI
- Material 3 + custom theme
