package com.balochi.dictionary.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.balochi.dictionary.R
import com.balochi.dictionary.ui.screens.HomeScreen
import com.balochi.dictionary.ui.screens.QuizScreen
import com.balochi.dictionary.ui.theme.CardSurface
import com.balochi.dictionary.ui.theme.Cream
import com.balochi.dictionary.ui.theme.NightParchment
import com.balochi.dictionary.ui.theme.SaffronGold
import com.balochi.dictionary.ui.theme.SoftCream

sealed class Screen(val route: String, val titleRes: Int, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    data object Home : Screen("home", R.string.home, Icons.Filled.Home, Icons.Outlined.Home)
    data object Quiz : Screen("quiz", R.string.quiz, Icons.Filled.Quiz, Icons.Outlined.Quiz)
}

@Composable
fun BalochiApp() {
    val navController = rememberNavController()
    val items = listOf(Screen.Home, Screen.Quiz)

    Scaffold(
        containerColor = NightParchment,
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination

            NavigationBar(
                containerColor = CardSurface,
                contentColor = Cream
            ) {
                items.forEach { screen ->
                    val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector = if (selected) screen.selectedIcon else screen.unselectedIcon,
                                contentDescription = null
                            )
                        },
                        label = { Text(stringResource(screen.titleRes)) },
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SaffronGold,
                            selectedTextColor = SaffronGold,
                            unselectedIconColor = SoftCream,
                            unselectedTextColor = SoftCream,
                            indicatorColor = NightParchment
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(NightParchment)
        ) {
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route
            ) {
                composable(Screen.Home.route) {
                    HomeScreen()
                }
                composable(Screen.Quiz.route) {
                    QuizScreen()
                }
            }
        }
    }
}
