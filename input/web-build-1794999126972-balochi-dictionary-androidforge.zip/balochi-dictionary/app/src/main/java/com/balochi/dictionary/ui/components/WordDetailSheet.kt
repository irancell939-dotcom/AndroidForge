package com.balochi.dictionary.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.dictionary.data.Word
import com.balochi.dictionary.ui.theme.CardSurface
import com.balochi.dictionary.ui.theme.Cream
import com.balochi.dictionary.ui.theme.SaffronGold
import com.balochi.dictionary.ui.theme.Sage
import com.balochi.dictionary.ui.theme.SoftCream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WordDetailSheet(
    word: Word,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CardSurface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 8.dp)
                .padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Main Balochi word
            Text(
                text = word.balochi,
                style = MaterialTheme.typography.displayLarge.copy(
                    color = SaffronGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 40.sp
                )
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "بلوچی",
                style = MaterialTheme.typography.labelLarge.copy(color = Sage)
            )
            
            Spacer(modifier = Modifier.height(28.dp))
            
            // All translations
            DetailRow(label = "فارسی", value = word.persian)
            DetailRow(label = "English", value = word.english)
            DetailRow(label = "عربی", value = word.arabic)
            DetailRow(label = "اردو", value = word.urdu)
            DetailRow(label = "زابلی", value = word.zaboli)
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(color = SoftCream)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                color = Cream,
                fontWeight = FontWeight.SemiBold
            )
        )
    }
}
