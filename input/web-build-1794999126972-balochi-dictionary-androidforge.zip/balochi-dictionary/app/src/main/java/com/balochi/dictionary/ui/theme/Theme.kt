package com.balochi.dictionary.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val BalochiDarkColorScheme = darkColorScheme(
    primary = SaffronGold,
    onPrimary = NightParchment,
    secondary = Sage,
    onSecondary = NightParchment,
    tertiary = Cream,
    background = NightParchment,
    onBackground = Cream,
    surface = CardSurface,
    onSurface = Cream,
    surfaceVariant = SubtleBorder,
    onSurfaceVariant = SoftCream,
    error = ErrorRed,
    onError = NightParchment
)

@Composable
fun BalochiDictionaryTheme(
    darkTheme: Boolean = true, // Always dark brand theme
    content: @Composable () -> Unit
) {
    val colorScheme = BalochiDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = NightParchment.toArgb()
            window.navigationBarColor = NightParchment.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
