package com.balochi.dictionary.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette – لوغت بلوچی
val NightParchment = Color(0xFF14110E)      // Background
val SaffronGold = Color(0xFFE2A45A)         // Primary accent
val Cream = Color(0xFFF6EFE2)               // Text / surfaces
val Sage = Color(0xFF8EAE86)                // Secondary accent
val SoftCream = Color(0xFFE8DFD0)           // Secondary text
val CardSurface = Color(0xFF1F1B17)         // Cards
val SubtleBorder = Color(0xFF2A2520)        // Borders
val ErrorRed = Color(0xFFCF6679)
val SuccessGreen = Color(0xFF81C784)
