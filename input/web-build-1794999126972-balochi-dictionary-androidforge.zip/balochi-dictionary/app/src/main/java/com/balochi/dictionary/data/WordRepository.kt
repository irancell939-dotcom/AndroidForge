package com.balochi.dictionary.data

import android.content.Context
import com.google.gson.Gson
import java.io.InputStreamReader

class WordRepository(private val context: Context) {
    private var cachedWords: List<Word>? = null

    fun getWords(): List<Word> {
        if (cachedWords != null) return cachedWords!!
        
        return try {
            val inputStream = context.assets.open("words.json")
            val reader = InputStreamReader(inputStream, Charsets.UTF_8)
            val data = Gson().fromJson(reader, DictionaryData::class.java)
            reader.close()
            cachedWords = data.words
            data.words
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    fun search(query: String): List<Word> {
        if (query.isBlank()) return getWords()
        val q = query.trim().lowercase()
        return getWords().filter { word ->
            word.balochi.contains(q, ignoreCase = true) ||
            word.persian.contains(q, ignoreCase = true) ||
            word.english.contains(q, ignoreCase = true) ||
            word.arabic.contains(q, ignoreCase = true) ||
            word.urdu.contains(q, ignoreCase = true) ||
            word.zaboli.contains(q, ignoreCase = true)
        }
    }
}
