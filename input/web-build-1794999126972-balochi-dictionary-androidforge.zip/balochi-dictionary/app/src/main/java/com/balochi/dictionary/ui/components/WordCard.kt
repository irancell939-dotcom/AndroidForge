package com.balochi.dictionary.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.dictionary.data.Word
import com.balochi.dictionary.ui.theme.CardSurface
import com.balochi.dictionary.ui.theme.Cream
import com.balochi.dictionary.ui.theme.SaffronGold
import com.balochi.dictionary.ui.theme.Sage
import com.balochi.dictionary.ui.theme.SoftCream
import com.balochi.dictionary.ui.theme.SubtleBorder

@Composable
fun WordCard(
    word: Word,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            .border(1.dp, SubtleBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        // Balochi main word
        Text(
            text = word.balochi,
            style = MaterialTheme.typography.headlineMedium.copy(
                color = SaffronGold,
                fontWeight = FontWeight.Bold,
                fontSize = 26.sp
            )
        )
        
        Spacer(modifier = Modifier.height(10.dp))
        
        // Translations row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TranslationChip(label = "فارسی", value = word.persian)
            TranslationChip(label = "English", value = word.english)
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TranslationChip(label = "عربی", value = word.arabic)
            TranslationChip(label = "اردو", value = word.urdu)
        }
    }
}

@Composable
private fun TranslationChip(label: String, value: String) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge.copy(
                color = Sage,
                fontSize = 11.sp
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge.copy(
                color = Cream,
                fontWeight = FontWeight.Medium
            )
        )
    }
}
