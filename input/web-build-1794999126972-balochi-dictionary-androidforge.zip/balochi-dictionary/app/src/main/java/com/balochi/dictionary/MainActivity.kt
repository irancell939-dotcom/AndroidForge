package com.balochi.dictionary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.balochi.dictionary.ui.theme.BalochiDictionaryTheme
import com.balochi.dictionary.ui.BalochiApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BalochiDictionaryTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    BalochiApp()
                }
            }
        }
    }
}
