package com.balochi.dictionary.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.dictionary.R
import com.balochi.dictionary.data.Word
import com.balochi.dictionary.data.WordRepository
import com.balochi.dictionary.ui.theme.CardSurface
import com.balochi.dictionary.ui.theme.Cream
import com.balochi.dictionary.ui.theme.ErrorRed
import com.balochi.dictionary.ui.theme.NightParchment
import com.balochi.dictionary.ui.theme.SaffronGold
import com.balochi.dictionary.ui.theme.Sage
import com.balochi.dictionary.ui.theme.SoftCream
import com.balochi.dictionary.ui.theme.SubtleBorder
import com.balochi.dictionary.ui.theme.SuccessGreen

@Composable
fun QuizScreen() {
    val context = LocalContext.current
    val repository = remember { WordRepository(context) }
    val allWords = remember { repository.getWords() }

    var quizStarted by remember { mutableStateOf(false) }
    var currentIndex by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var selectedAnswer by remember { mutableStateOf<String?>(null) }
    var showResult by remember { mutableStateOf(false) }
    var quizFinished by remember { mutableStateOf(false) }

    val quizWords = remember(quizStarted) {
        if (quizStarted && allWords.isNotEmpty()) allWords.shuffled() else emptyList()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NightParchment)
            .padding(20.dp)
    ) {
        // Header
        Text(
            text = stringResource(R.string.quiz),
            style = MaterialTheme.typography.headlineMedium.copy(
                color = SaffronGold,
                fontWeight = FontWeight.Bold
            ),
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "معنی واژه‌های بلوچی را حدس بزن",
            style = MaterialTheme.typography.bodyMedium.copy(color = SoftCream),
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        when {
            !quizStarted -> {
                StartQuizContent(
                    wordCount = allWords.size,
                    onStart = {
                        if (allWords.isNotEmpty()) {
                            quizStarted = true
                            currentIndex = 0
                            score = 0
                            selectedAnswer = null
                            showResult = false
                            quizFinished = false
                        }
                    }
                )
            }
            quizFinished -> {
                ResultContent(
                    score = score,
                    total = quizWords.size,
                    onRestart = {
                        quizStarted = false
                        quizFinished = false
                    }
                )
            }
            else -> {
                val currentWord = quizWords.getOrNull(currentIndex)
                if (currentWord != null) {
                    QuizQuestionContent(
                        word = currentWord,
                        allWords = allWords,
                        currentIndex = currentIndex,
                        total = quizWords.size,
                        selectedAnswer = selectedAnswer,
                        showResult = showResult,
                        onSelect = { answer ->
                            if (!showResult) {
                                selectedAnswer = answer
                                showResult = true
                                if (answer == currentWord.persian) {
                                    score++
                                }
                            }
                        },
                        onNext = {
                            if (currentIndex + 1 >= quizWords.size) {
                                quizFinished = true
                            } else {
                                currentIndex++
                                selectedAnswer = null
                                showResult = false
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun StartQuizContent(wordCount: Int, onStart: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "$wordCount واژه آماده آزمون",
                style = MaterialTheme.typography.titleMedium.copy(color = Cream)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onStart,
                colors = ButtonDefaults.buttonColors(
                    containerColor = SaffronGold,
                    contentColor = NightParchment
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .height(52.dp)
            ) {
                Text(
                    text = stringResource(R.string.start_quiz),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}

@Composable
private fun ResultContent(score: Int, total: Int, onRestart: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "🎉",
                fontSize = 48.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = stringResource(R.string.score),
                style = MaterialTheme.typography.titleMedium.copy(color = SoftCream)
            )
            Text(
                text = "$score / $total",
                style = MaterialTheme.typography.displayLarge.copy(
                    color = SaffronGold,
                    fontWeight = FontWeight.Bold
                )
            )
            Spacer(modifier = Modifier.height(32.dp))
            Button(
                onClick = onRestart,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Sage,
                    contentColor = NightParchment
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .height(52.dp)
            ) {
                Text(
                    text = stringResource(R.string.try_again),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}

@Composable
private fun QuizQuestionContent(
    word: Word,
    allWords: List<Word>,
    currentIndex: Int,
    total: Int,
    selectedAnswer: String?,
    showResult: Boolean,
    onSelect: (String) -> Unit,
    onNext: () -> Unit
) {
    // Generate options: correct + 3 random wrong
    val options = remember(word.id) {
        val wrongs = allWords
            .filter { it.id != word.id }
            .map { it.persian }
            .shuffled()
            .take(3)
        (wrongs + word.persian).shuffled()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Progress
        Text(
            text = "${currentIndex + 1} / $total",
            style = MaterialTheme.typography.labelLarge.copy(color = Sage),
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Question card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(CardSurface)
                .border(1.dp, SubtleBorder, RoundedCornerShape(20.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "معنی این واژه چیست؟",
                style = MaterialTheme.typography.bodyMedium.copy(color = SoftCream)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = word.balochi,
                style = MaterialTheme.typography.displayLarge.copy(
                    color = SaffronGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 36.sp
                )
            )
        }
        
        Spacer(modifier = Modifier.height(28.dp))
        
        // Options
        options.forEach { option ->
            val isSelected = selectedAnswer == option
            val isCorrect = option == word.persian
            
            val bgColor = when {
                !showResult -> CardSurface
                isCorrect -> SuccessGreen.copy(alpha = 0.2f)
                isSelected && !isCorrect -> ErrorRed.copy(alpha = 0.2f)
                else -> CardSurface
            }
            val borderColor = when {
                !showResult -> SubtleBorder
                isCorrect -> SuccessGreen
                isSelected && !isCorrect -> ErrorRed
                else -> SubtleBorder
            }
            val textColor = when {
                !showResult -> Cream
                isCorrect -> SuccessGreen
                isSelected && !isCorrect -> ErrorRed
                else -> SoftCream
            }
            
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(bgColor)
                    .border(1.5.dp, borderColor, RoundedCornerShape(14.dp))
                    .clickable(enabled = !showResult) { onSelect(option) }
                    .padding(vertical = 16.dp, horizontal = 20.dp)
            ) {
                Text(
                    text = option,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = textColor,
                        fontWeight = if (isSelected || (showResult && isCorrect)) FontWeight.Bold else FontWeight.Normal
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Next button
        AnimatedContent(
            targetState = showResult,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "nextButton"
        ) { visible ->
            if (visible) {
                Button(
                    onClick = onNext,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SaffronGold,
                        contentColor = NightParchment
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Text(
                        text = if (currentIndex + 1 >= total) stringResource(R.string.finish) else stringResource(R.string.next),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}
