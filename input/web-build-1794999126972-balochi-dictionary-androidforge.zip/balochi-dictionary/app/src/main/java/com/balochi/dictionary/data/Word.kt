package com.balochi.dictionary.data

data class Word(
    val id: Int,
    val balochi: String,
    val arabic: String,
    val persian: String,
    val english: String,
    val zaboli: String,
    val urdu: String
)

data class DictionaryData(
    val app: String,
    val version: Int,
    val exportedAt: String,
    val words: List<Word>
)
