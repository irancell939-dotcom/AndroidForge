package com.balochi.quiz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.BalochiWord
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.theme.*

@Composable
fun WordListScreen(
    viewModel: QuizViewModel,
    onBack: () -> Unit,
    onEdit: (BalochiWord) -> Unit
) {
    val colors = getThemeColors(viewModel.currentTheme)
    var wordToDelete by remember { mutableStateOf<BalochiWord?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت", tint = colors.textPrimary)
            }
            Text(
                text = "کلمات (${viewModel.words.size})",
                color = colors.textPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (viewModel.words.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("هنوز کلمه‌ای نیست", color = colors.textSecondary, fontSize = 18.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(viewModel.words, key = { it.id }) { word ->
                    WordTile(
                        word = word,
                        colors = colors,
                        onEdit = { onEdit(word) },
                        onDeleteRequest = { wordToDelete = word }
                    )
                }
            }
        }
    }

    // دیالوگ تأیید حذف
    wordToDelete?.let { word ->
        AlertDialog(
            onDismissRequest = { wordToDelete = null },
            title = { Text("حذف کلمه؟", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "آیا مطمئن هستید که می‌خواهید «${word.english.ifBlank { word.balochi.ifBlank { word.persian } }}» را حذف کنید؟",
                    fontSize = 16.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteWord(word.id)
                        wordToDelete = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = WrongRed)
                ) {
                    Text("حذف", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { wordToDelete = null }) {
                    Text("انصراف")
                }
            },
            containerColor = colors.card,
            titleContentColor = colors.textPrimary,
            textContentColor = colors.textSecondary
        )
    }
}

@Composable
private fun WordTile(
    word: BalochiWord,
    colors: ThemeColors,
    onEdit: () -> Unit,
    onDeleteRequest: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .aspectRatio(0.85f)
            .clip(RoundedCornerShape(16.dp))
            .background(colors.card)
            .border(1.dp, colors.border, RoundedCornerShape(16.dp))
            .clickable { onEdit() }
            .padding(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // منوی سه نقطه
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.TopEnd) {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.MoreVert,
                        contentDescription = "منو",
                        tint = colors.textMuted,
                        modifier = Modifier.size(22.dp)
                    )
                }
                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    containerColor = colors.surface
                ) {
                    DropdownMenuItem(
                        text = { Text("ویرایش", color = colors.textPrimary, fontSize = 16.sp) },
                        onClick = {
                            menuExpanded = false
                            onEdit()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("حذف", color = WrongRed, fontSize = 16.sp) },
                        onClick = {
                            menuExpanded = false
                            onDeleteRequest()
                        }
                    )
                }
            }

            // کلمه اصلی درشت
            val title = when {
                word.balochi.isNotBlank() -> word.balochi
                word.english.isNotBlank() -> word.english
                else -> word.persian
            }
            Text(
                text = title,
                color = colors.accent,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp, bottom = 8.dp)
            )

            // معانی
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                if (word.english.isNotBlank() && title != word.english)
                    MeaningLine("EN", word.english, colors)
                if (word.persian.isNotBlank())
                    MeaningLine("FA", word.persian, colors)
                if (word.arabic.isNotBlank())
                    MeaningLine("AR", word.arabic, colors)
                if (word.urdu.isNotBlank())
                    MeaningLine("UR", word.urdu, colors)
                if (word.balochi.isNotBlank() && title != word.balochi)
                    MeaningLine("BL", word.balochi, colors)
            }

            // آمار
            if (word.correctCount + word.wrongCount > 0) {
                Text(
                    "✓${word.correctCount}  ✗${word.wrongCount}",
                    color = colors.textMuted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun MeaningLine(label: String, value: String, colors: ThemeColors) {
    Text(
        text = "$label: $value",
        color = colors.textSecondary,
        fontSize = 13.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
}
