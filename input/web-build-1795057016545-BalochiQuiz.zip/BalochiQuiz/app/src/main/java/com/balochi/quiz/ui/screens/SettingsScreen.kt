package com.balochi.quiz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.theme.*

@Composable
fun SettingsScreen(
    viewModel: QuizViewModel,
    onBack: () -> Unit
) {
    val colors = getThemeColors(viewModel.currentTheme)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت", tint = colors.textPrimary)
            }
            Text(
                text = "تنظیمات",
                color = colors.textPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(12.dp))

            Text(
                "تم برنامه",
                color = colors.textPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            AppTheme.entries.forEach { theme ->
                val isSelected = viewModel.currentTheme == theme
                val themeColors = getThemeColors(theme)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) colors.cardLight else colors.card)
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) colors.accent else colors.border,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable { viewModel.setTheme(theme) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // پیش‌نمایش رنگ
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(themeColors.background)
                            .border(1.dp, themeColors.border, RoundedCornerShape(10.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(14.dp)
                                .clip(RoundedCornerShape(topStart = 6.dp))
                                .background(themeColors.accent)
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(
                        text = theme.displayName,
                        color = colors.textPrimary,
                        fontSize = 16.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                    Spacer(Modifier.weight(1f))
                    if (isSelected) {
                        Text("✓", color = colors.accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(28.dp))

            Text(
                "زبان‌ها",
                color = colors.textPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                "زبان‌های فعلی پشتیبانی‌شده:\nبلوچی • فارسی • English • العربية • اردو\n\nبرای افزودن زبان جدید در نسخه‌های بعدی می‌توانید درخواست دهید.",
                color = colors.textSecondary,
                fontSize = 14.sp,
                lineHeight = 22.sp
            )

            Spacer(Modifier.height(28.dp))

            Text(
                "درباره",
                color = colors.textPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                "لغت بلوچی\nبرنامه‌نویس: محمدعمر خاوران\n۰۹۱۵۹۴۹۹۹۲۸",
                color = colors.textSecondary,
                fontSize = 14.sp,
                lineHeight = 22.sp
            )

            Spacer(Modifier.height(40.dp))
        }
    }
}
