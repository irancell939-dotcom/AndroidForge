import os
import threading
from werkzeug.serving import make_server

_server = None
_thread = None

def start_server(data_dir):
    global _server, _thread
    if _server is not None:
        return True
    import os
    os.environ['ZARMANAG_DATA_DIR'] = data_dir
    from app import app
    _server = make_server('127.0.0.1', 5000, app, threaded=True)
    _thread = threading.Thread(target=_server.serve_forever, daemon=True)
    _thread.start()
    return True
