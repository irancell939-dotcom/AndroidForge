package com.balochi.quiz.data

import android.content.Context
import com.balochi.quiz.ui.theme.AppTheme

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("balochi_settings", Context.MODE_PRIVATE)

    fun getTheme(): AppTheme {
        val name = prefs.getString("theme", AppTheme.WARM_DARK.name) ?: AppTheme.WARM_DARK.name
        return try { AppTheme.valueOf(name) } catch (_: Exception) { AppTheme.WARM_DARK }
    }

    fun setTheme(theme: AppTheme) {
        prefs.edit().putString("theme", theme.name).apply()
    }

    fun getLangA(): QuizLanguage {
        val code = prefs.getString("langA", QuizLanguage.ENGLISH.code) ?: QuizLanguage.ENGLISH.code
        return QuizLanguage.fromCode(code)
    }

    fun getLangB(): QuizLanguage {
        val code = prefs.getString("langB", QuizLanguage.PERSIAN.code) ?: QuizLanguage.PERSIAN.code
        return QuizLanguage.fromCode(code)
    }

    fun setLanguages(a: QuizLanguage, b: QuizLanguage) {
        prefs.edit()
            .putString("langA", a.code)
            .putString("langB", b.code)
            .apply()
    }
}
