package com.balochi.quiz.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.theme.*
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

@Composable
fun SettingsScreen(
    viewModel: QuizViewModel,
    onBack: () -> Unit
) {
    val colors = getThemeColors(viewModel.currentTheme)
    val context = LocalContext.current
    var showResetDialog by remember { mutableStateOf(false) }
    var lastBackupPath by remember { mutableStateOf<String?>(null) }

    // انتخاب فایل برای بازیابی
    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val json = BufferedReader(InputStreamReader(input)).readText()
                val ok = viewModel.importBackupFromJson(json)
                Toast.makeText(
                    context,
                    if (ok) "بازیابی با موفقیت انجام شد" else "فایل پشتیبان نامعتبر است",
                    Toast.LENGTH_LONG
                ).show()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در خواندن فایل: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت", tint = colors.textPrimary)
            }
            Text(
                text = "تنظیمات",
                color = colors.textPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(12.dp))

            SectionTitle("تم برنامه", colors)
            AppTheme.entries.forEach { theme ->
                val isSelected = viewModel.currentTheme == theme
                val themeColors = getThemeColors(theme)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) colors.cardLight else colors.card)
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) colors.accent else colors.border,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable { viewModel.setTheme(theme) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(themeColors.background)
                            .border(1.dp, themeColors.border, RoundedCornerShape(10.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(14.dp)
                                .clip(RoundedCornerShape(topStart = 6.dp))
                                .background(themeColors.accent)
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(
                        text = theme.displayName,
                        color = colors.textPrimary,
                        fontSize = 16.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                    Spacer(Modifier.weight(1f))
                    if (isSelected) {
                        Text("✓", color = colors.accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            SectionTitle("پشتیبان‌گیری و بازیابی", colors)
            Text(
                "مسیر پوشه برنامه:\n${viewModel.getBackupPath()}",
                color = colors.textMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            SettingsButton("ذخیره پشتیبان", colors) {
                val path = viewModel.exportBackup()
                lastBackupPath = path
                if (path != null) {
                    Toast.makeText(context, "پشتیبان ذخیره شد", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "خطا در ذخیره پشتیبان", Toast.LENGTH_SHORT).show()
                }
            }
            Spacer(Modifier.height(10.dp))

            SettingsButton("ارسال پشتیبان به گوشی دیگر", colors) {
                val path = lastBackupPath ?: viewModel.exportBackup()
                if (path == null) {
                    Toast.makeText(context, "ابتدا پشتیبان بسازید", Toast.LENGTH_SHORT).show()
                    return@SettingsButton
                }
                try {
                    val file = File(path)
                    val uri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        file
                    )
                    val share = Intent(Intent.ACTION_SEND).apply {
                        type = "application/json"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "پشتیبان لغت بلوچی")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(share, "ارسال پشتیبان"))
                } catch (e: Exception) {
                    Toast.makeText(context, "خطا در ارسال: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            Spacer(Modifier.height(10.dp))

            SettingsButton("بازیابی با انتخاب فایل", colors) {
                openDocumentLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
            }
            Spacer(Modifier.height(10.dp))

            SettingsButton("بازیابی آخرین پشتیبان داخلی", colors) {
                val ok = viewModel.importBackup()
                Toast.makeText(
                    context,
                    if (ok) "بازیابی با موفقیت انجام شد" else "فایل پشتیبان داخلی پیدا نشد",
                    Toast.LENGTH_LONG
                ).show()
            }

            Spacer(Modifier.height(24.dp))

            SectionTitle("پیشرفت آزمون", colors)
            SettingsButton("صفر کردن پیشرفت", colors, isDanger = true) {
                showResetDialog = true
            }

            Spacer(Modifier.height(24.dp))

            SectionTitle("درباره", colors)
            Text(
                "لغت بلوچی\nبرنامه‌نویس: محمدعمر خاوران\n۰۹۱۵۹۴۹۹۹۲۸",
                color = colors.textSecondary,
                fontSize = 14.sp,
                lineHeight = 22.sp
            )
            Spacer(Modifier.height(40.dp))
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("صفر کردن پیشرفت؟", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "تمام آمار پاسخ‌ها، سطح و تاریخچه اشتباهات پاک می‌شود. کلمات حذف نمی‌شوند.",
                    fontSize = 15.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.resetProgress()
                        showResetDialog = false
                        Toast.makeText(context, "پیشرفت صفر شد", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = WrongRed)
                ) {
                    Text("بله، صفر کن", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("انصراف")
                }
            },
            containerColor = colors.card,
            titleContentColor = colors.textPrimary,
            textContentColor = colors.textSecondary
        )
    }
}

@Composable
private fun SectionTitle(text: String, colors: ThemeColors) {
    Text(
        text = text,
        color = colors.textPrimary,
        fontSize = 17.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 12.dp)
    )
}

@Composable
private fun SettingsButton(
    text: String,
    colors: ThemeColors,
    isDanger: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.card)
            .border(1.dp, if (isDanger) WrongRed.copy(alpha = 0.5f) else colors.border, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (isDanger) WrongRed else colors.textPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
