package ir.khavaran.khayati;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class ServerService extends Service {
    private static final String CHANNEL_ID = "khayati_server_channel";
    private static final int NOTIFICATION_ID = 5101;
    private static volatile boolean pythonStarted = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startServerNotification();
        new Thread(this::bootPythonServer, "KhayatiBootstrap").start();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startServerNotification();
        return START_STICKY;
    }

    private void startServerNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        Notification notification = builder
                .setContentTitle("تن پوش خاوران فعال است")
                .setContentText("برای اتصال دستگاه‌های دیگر، برنامه را روشن نگه دارید.")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "سرور تن پوش خاوران", NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("نمایش فعال‌بودن پایگاه داده مرکزی تن پوش خاوران");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private void bootPythonServer() {
        try {
            File webRoot = new File(getFilesDir(), "web");
            // هر بار اجرای نسخه جدید، فایل‌های رابط کاربری APK را به‌روز می‌کنیم.
            copyAssetFolder("web", webRoot);
            if (!pythonStarted) {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                Python.getInstance().getModule("server_control").callAttr(
                        "start", getFilesDir().getAbsolutePath(), webRoot.getAbsolutePath()
                );
                pythonStarted = true;
            }
        } catch (Exception e) {
            try {
                File status = new File(getFilesDir(), "server_status.txt");
                try (FileOutputStream out = new FileOutputStream(status)) {
                    out.write(("error: " + e.toString()).getBytes("UTF-8"));
                }
            } catch (Exception ignored) { }
        }
    }

    private void copyAssetFolder(String assetPath, File destination) throws Exception {
        if (!destination.exists() && !destination.mkdirs()) {
            throw new IllegalStateException("Cannot create " + destination);
        }
        String[] children = getAssets().list(assetPath);
        if (children == null) return;
        for (String child : children) {
            String childAsset = assetPath + "/" + child;
            String[] grandchildren = getAssets().list(childAsset);
            File childFile = new File(destination, child);
            if (grandchildren != null && grandchildren.length > 0) {
                copyAssetFolder(childAsset, childFile);
            } else {
                try (InputStream in = getAssets().open(childAsset);
                     FileOutputStream out = new FileOutputStream(childFile)) {
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                }
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
