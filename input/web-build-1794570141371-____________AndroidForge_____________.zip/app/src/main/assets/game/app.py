from flask import Flask, render_template, request, jsonify, session
import random
import time
import json
import os

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "quiz-islamic-secret-2026-v2-change-this")

QUESTIONS_FILE = os.path.join(os.path.dirname(__file__), "questions.json")

# --------------------------------------------------
# رمز ورود به تنظیمات
# --------------------------------------------------

ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "1111")

# --------------------------------------------------
# ۳۰۰ سوال پیش‌فرض
# --------------------------------------------------

DEFAULT_QUESTIONS = [
    {"q": "دعای حضرت یونس در شکم ماهی چه بود؟", "options": ["لا اله الا انت سبحانک انی کنت من الظالمین", "ربنا آتنا فی الدنیا حسنة", "اللهم انی اسئلک العفو", "حسبی الله و نعم الوکیل"], "correct": 0, "source": "قرآن، انبیا: ۸۷"},
    {"q": "کدام سوره با بسم الله شروع نمی‌شود؟", "options": ["سوره توبه", "سوره ناس", "سوره کوثر", "سوره حمد"], "correct": 0, "source": "قرآن"},
    {"q": "آخرین سوره قرآن چه نام دارد؟", "options": ["سوره ناس", "سوره فلق", "سوره اخلاص", "سوره کوثر"], "correct": 0, "source": "قرآن"},
    {"q": "آیه الکرسی در کدام سوره است؟", "options": ["سوره بقره", "سوره آل‌عمران", "سوره نساء", "سوره مائده"], "correct": 0, "source": "قرآن، بقره: ۲۵۵"},
    {"q": "قرآن چند جزء دارد؟", "options": ["۳۰ جزء", "۲۰ جزء", "۴۰ جزء", "۶۰ جزء"], "correct": 0, "source": "مشهور"},
    {"q": "کوتاه‌ترین سوره قرآن چه نام دارد؟", "options": ["سوره کوثر", "سوره عصر", "سوره ناس", "سوره فلق"], "correct": 0, "source": "قرآن"},
    {"q": "چند پیامبر در قرآن نام برده شده‌اند؟", "options": ["۲۵ پیامبر", "۲۰ پیامبر", "۳۰ پیامبر", "۴۰ پیامبر"], "correct": 0, "source": "قرآن"},
    {"q": "کدام دو سوره به نام حیوانات هستند؟", "options": ["نمل و نحل", "بقره و انعام", "فیل و عادیات", "نحل و عنکبوت"], "correct": 0, "source": "قرآن"},
    {"q": "اولین سوره قرآن چه نام دارد؟", "options": ["سوره حمد", "سوره بقره", "سوره علق", "سوره مدثر"], "correct": 0, "source": "قرآن"},
    {"q": "کدام سوره به «قلب قرآن» معروف است؟", "options": ["سوره یس", "سوره الرحمن", "سوره کهف", "سوره ملک"], "correct": 0, "source": "سنن ترمذی"},
    {"q": "کدام سوره در هر رکعت نماز خوانده می‌شود؟", "options": ["سوره حمد", "سوره اخلاص", "سوره کوثر", "سوره ناس"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "کدام شب از هزار ماه بهتر است؟", "options": ["شب قدر", "شب معراج", "شب جمعه", "شب عید"], "correct": 0, "source": "قرآن، قدر: ۳"},
    {"q": "قرآن در چند سال نازل شد؟", "options": ["۲۳ سال", "۲۰ سال", "۱۵ سال", "۳۰ سال"], "correct": 0, "source": "سیره"},
    {"q": "اولین آیات نازل‌شده کدام است؟", "options": ["سوره علق (اقرأ)", "سوره حمد", "سوره بقره", "سوره مدثر"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "کدام سوره به «عروس قرآن» معروف است؟", "options": ["سوره الرحمن", "سوره یس", "سوره کهف", "سوره مریم"], "correct": 0, "source": "سنن ترمذی"},
    {"q": "تعداد سوره‌های قرآن چند است؟", "options": ["۱۱۴ سوره", "۱۱۰ سوره", "۱۲۰ سوره", "۱۰۰ سوره"], "correct": 0, "source": "مشهور"},
    {"q": "کدام سوره به نام حضرت مریم است؟", "options": ["سوره مریم", "سوره نساء", "سوره انبیا", "سوره آل‌عمران"], "correct": 0, "source": "قرآن"},
    {"q": "آیه «قل هو الله احد» در کدام سوره است؟", "options": ["سوره اخلاص", "سوره فلق", "سوره ناس", "سوره کوثر"], "correct": 0, "source": "قرآن"},
    {"q": "طولانی‌ترین سوره قرآن چه نام دارد؟", "options": ["سوره بقره", "سوره آل‌عمران", "سوره نساء", "سوره مائده"], "correct": 0, "source": "قرآن"},
    {"q": "آیه «انا اعطیناک الکوثر» در کدام سوره است؟", "options": ["سوره کوثر", "سوره عصر", "سوره ناس", "سوره فلق"], "correct": 0, "source": "قرآن"},
    {"q": "کدام پیامبر کشتی ساخت؟", "options": ["حضرت نوح", "حضرت موسی", "حضرت ابراهیم", "حضرت عیسی"], "correct": 0, "source": "قرآن"},
    {"q": "کدام پیامبر با آتش نسوخت؟", "options": ["حضرت ابراهیم", "حضرت نوح", "حضرت یوسف", "حضرت ایوب"], "correct": 0, "source": "قرآن، انبیا: ۶۹"},
    {"q": "کدام پیامبر در چاه افتاد؟", "options": ["حضرت یوسف", "حضرت یونس", "حضرت موسی", "حضرت داوود"], "correct": 0, "source": "قرآن، یوسف: ۱۰"},
    {"q": "کدام پیامبر بیمار بود و صبر کرد؟", "options": ["حضرت ایوب", "حضرت یعقوب", "حضرت زکریا", "حضرت یحیی"], "correct": 0, "source": "قرآن، ص: ۴۱"},
    {"q": "کدام پیامبر با حیوانات صحبت می‌کرد؟", "options": ["حضرت سلیمان", "حضرت داوود", "حضرت موسی", "حضرت هود"], "correct": 0, "source": "قرآن، نمل: ۱۶"},
    {"q": "کدام پیامبر عصایش اژدها می‌شد؟", "options": ["حضرت موسی", "حضرت هارون", "حضرت عیسی", "حضرت شعیب"], "correct": 0, "source": "قرآن، طه: ۲۰"},
    {"q": "کدام پیامبر آخرین پیامبر است؟", "options": ["حضرت محمد ﷺ", "حضرت عیسی", "حضرت موسی", "حضرت ابراهیم"], "correct": 0, "source": "قرآن، احزاب: ۴۰"},
    {"q": "کتاب آسمانی حضرت موسی چه نام دارد؟", "options": ["تورات", "انجیل", "زبور", "قرآن"], "correct": 0, "source": "قرآن"},
    {"q": "کتاب آسمانی حضرت عیسی چه نام دارد؟", "options": ["انجیل", "تورات", "زبور", "قرآن"], "correct": 0, "source": "قرآن"},
    {"q": "کتاب آسمانی حضرت داوود چه نام دارد؟", "options": ["زبور", "تورات", "انجیل", "قرآن"], "correct": 0, "source": "قرآن"},
    {"q": "کتاب آسمانی مسلمانان چه نام دارد؟", "options": ["قرآن", "تورات", "انجیل", "زبور"], "correct": 0, "source": "قرآن"},
    {"q": "حضرت آدم از چه چیزی آفریده شد؟", "options": ["خاک", "آب", "آتش", "نور"], "correct": 0, "source": "قرآن"},
    {"q": "اولین پیامبر چه نام دارد؟", "options": ["حضرت آدم", "حضرت نوح", "حضرت ابراهیم", "حضرت موسی"], "correct": 0, "source": "قرآن"},
    {"q": "حضرت یوسف چند برادر داشت؟", "options": ["۱۱ برادر", "۱۰ برادر", "۱۲ برادر", "۹ برادر"], "correct": 0, "source": "قرآن"},
    {"q": "کدام پیامبر قوم ثمود را دعوت کرد؟", "options": ["حضرت صالح", "حضرت هود", "حضرت شعیب", "حضرت لوط"], "correct": 0, "source": "قرآن"},
    {"q": "کدام پیامبر قوم عاد را دعوت کرد؟", "options": ["حضرت هود", "حضرت صالح", "حضرت شعیب", "حضرت لوط"], "correct": 0, "source": "قرآن"},
    {"q": "کدام پیامبر قوم مدین را دعوت کرد؟", "options": ["حضرت شعیب", "حضرت هود", "حضرت صالح", "حضرت لوط"], "correct": 0, "source": "قرآن"},
    {"q": "حضرت یحیی پسر کدام پیامبر است؟", "options": ["حضرت زکریا", "حضرت عیسی", "حضرت موسی", "حضرت هارون"], "correct": 0, "source": "قرآن"},
    {"q": "حضرت ابراهیم پدر کدام پیامبران است؟", "options": ["اسماعیل و اسحاق", "یوسف و بنیامین", "موسی و هارون", "نوح و هود"], "correct": 0, "source": "قرآن"},
    {"q": "پیامبر در چند سالگی به نبوت رسید؟", "options": ["۴۰ سالگی", "۳۰ سالگی", "۵۰ سالگی", "۲۵ سالگی"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر در کدام ماه به دنیا آمد؟", "options": ["ماه ربیع‌الاول", "ماه رمضان", "ماه محرم", "ماه رجب"], "correct": 0, "source": "سیره ابن هشام"},
    {"q": "نام مادر پیامبر چه بود؟", "options": ["آمنه", "خدیجه", "فاطمه", "حلیمه"], "correct": 0, "source": "سیره"},
    {"q": "نام پدر پیامبر چه بود؟", "options": ["عبدالله", "عبدالمطلب", "ابوطالب", "عباس"], "correct": 0, "source": "سیره"},
    {"q": "دایه پیامبر در بادیه چه نام داشت؟", "options": ["حلیمه سعدیه", "آمنه", "خدیجه", "فاطمه"], "correct": 0, "source": "سیره ابن هشام"},
    {"q": "پیامبر در جوانی به چه لقبی مشهور شد؟", "options": ["محمد امین", "محمد فاروق", "محمد صدیق", "محمد کریم"], "correct": 0, "source": "سیره"},
    {"q": "پیامبر در کدام غار به او وحی نازل شد؟", "options": ["غار حرا", "غار ثور", "غار کهف", "غار بدر"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "اولین کسی که به پیامبر ایمان آورد چه کسی بود؟", "options": ["حضرت خدیجه", "ابوبکر", "علی", "عمر"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "از مردان اولین مسلمان چه کسی بود؟", "options": ["ابوبکر", "علی", "عمر", "عثمان"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "از کودکان اولین مسلمان چه کسی بود؟", "options": ["علی بن ابی‌طالب", "ابوبکر", "عمر", "عثمان"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "اولین مسلمان از بردگان چه کسی بود؟", "options": ["زید بن حارثه", "بلال", "سلمان", "عمار"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر چند سال در مکه دعوت کرد؟", "options": ["۱۳ سال", "۱۰ سال", "۱۵ سال", "۲۰ سال"], "correct": 0, "source": "سیره ابن هشام"},
    {"q": "پیامبر در معراج از کدام مسجد به آسمان رفت؟", "options": ["مسجد الاقصی", "مسجد الحرام", "مسجد النبی", "مسجد قبا"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "هجرت پیامبر از مکه به کجا بود؟", "options": ["مدینه", "طائف", "شام", "یمن"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "غار هجرت پیامبر چه نام داشت؟", "options": ["غار ثور", "غار حرا", "غار کهف", "غار اصحاب"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "اولین مسجدی که پیامبر ساخت چه نام داشت؟", "options": ["مسجد قبا", "مسجد النبی", "مسجد الاقصی", "مسجد الحرام"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "اولین موذن اسلام چه کسی بود؟", "options": ["بلال حبشی", "ابوبکر", "عمر", "عثمان"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر در کدام شهر دفن شده است؟", "options": ["مدینه", "مکه", "طائف", "یمن"], "correct": 0, "source": "سیره"},
    {"q": "مدینه قبل از هجرت چه نام داشت؟", "options": ["یثرب", "مکه", "طائف", "یمن"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر در کدام سال هجری وفات یافت؟", "options": ["سال یازدهم هجری", "سال دهم هجری", "سال دوازدهم هجری", "سال نهم هجری"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "غزوه بدر در کدام سال هجری رخ داد؟", "options": ["سال دوم هجری", "سال اول هجری", "سال سوم هجری", "سال چهارم هجری"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "غزوه احد در کدام سال هجری رخ داد؟", "options": ["سال سوم هجری", "سال اول هجری", "سال پنجم هجری", "سال دوم هجری"], "correct": 0, "source": "سیره ابن هشام"},
    {"q": "غزوه خندق در کدام سال هجری رخ داد؟", "options": ["سال پنجم هجری", "سال دوم هجری", "سال سوم هجری", "سال هفتم هجری"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "فتح مکه در کدام سال هجری رخ داد؟", "options": ["سال هشتم هجری", "سال ششم هجری", "سال دهم هجری", "سال پنجم هجری"], "correct": 0, "source": "سیره ابن هشام"},
    {"q": "صلح حدیبیه در کدام سال هجری بود؟", "options": ["سال ششم هجری", "سال هشتم هجری", "سال چهارم هجری", "سال دهم هجری"], "correct": 0, "source": "سیره ابن هشام"},
    {"q": "غزوه خیبر در کدام سال هجری رخ داد؟", "options": ["سال هفتم هجری", "سال پنجم هجری", "سال هشتم هجری", "سال سوم هجری"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "عموی پیامبر که در احد شهید شد چه نام داشت؟", "options": ["حمزه سیدالشهدا", "ابوطالب", "عباس", "ابولهب"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "در غزوه بدر چند نفر از مسلمانان شرکت داشتند؟", "options": ["۳۱۳ نفر", "۱۰۰۰ نفر", "۵۰۰ نفر", "۷۰۰ نفر"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "در غزوه خندق چه کسی پیشنهاد کندن خندق داد؟", "options": ["سلمان فارسی", "ابوبکر", "عمر", "علی"], "correct": 0, "source": "سیره"},
    {"q": "پیامبر در کدام سال حج وداع را انجام داد؟", "options": ["سال دهم هجری", "سال نهم هجری", "سال هشتم هجری", "سال یازدهم هجری"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر در کدام سن وفات یافت؟", "options": ["۶۳ سالگی", "۶۰ سالگی", "۶۵ سالگی", "۷۰ سالگی"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر در کدام روز هفته وفات یافت؟", "options": ["دوشنبه", "جمعه", "شنبه", "یکشنبه"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "غزوه حنین در کدام سال هجری رخ داد؟", "options": ["سال هشتم هجری", "سال هفتم هجری", "سال نهم هجری", "سال دهم هجری"], "correct": 0, "source": "قرآن، توبه: ۲۵"},
    {"q": "کدام غزوه به «غزوه احزاب» نیز معروف است؟", "options": ["خندق", "بدر", "احد", "خیبر"], "correct": 0, "source": "قرآن، احزاب"},
    {"q": "پیامبر در کدام غزوه با روم مقابله کرد؟", "options": ["تبوک", "بدر", "احد", "خندق"], "correct": 0, "source": "سیره"},
    {"q": "در غزوه بدر چند نفر از مسلمانان شهید شدند؟", "options": ["۱۴ نفر", "۲۰ نفر", "۳۰ نفر", "۴۰ نفر"], "correct": 0, "source": "سیره"},
    {"q": "در غزوه احد چند نفر از مسلمانان شهید شدند؟", "options": ["۷۰ نفر", "۵۰ نفر", "۳۰ نفر", "۱۰۰ نفر"], "correct": 0, "source": "سیره"},
    {"q": "در غزوه خیبر چه کسی پرچم را برداشت؟", "options": ["علی بن ابی‌طالب", "ابوبکر", "عمر", "عثمان"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر در کدام غزوه با یهودیان بنی‌نضیر مقابله کرد؟", "options": ["بنی‌نضیر", "بدر", "احد", "خندق"], "correct": 0, "source": "سیره"},
    {"q": "نام همسر اول پیامبر چه بود؟", "options": ["خدیجه", "عایشه", "حفصه", "زینب"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر چند فرزند داشت؟", "options": ["۷ فرزند", "۳ فرزند", "۵ فرزند", "۹ فرزند"], "correct": 0, "source": "سیره"},
    {"q": "دختر محبوب پیامبر چه نام داشت؟", "options": ["فاطمه", "زینب", "رقیه", "ام‌کلثوم"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "همسر فاطمه چه کسی بود؟", "options": ["علی بن ابی‌طالب", "عثمان", "عمر", "ابوبکر"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "امام حسن و امام حسین فرزندان چه کسی هستند؟", "options": ["فاطمه و علی", "عایشه", "حفصه", "زینب"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "عایشه دختر کدام صحابی بود؟", "options": ["ابوبکر", "عمر", "عثمان", "علی"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "حفصه دختر کدام صحابی بود؟", "options": ["عمر", "ابوبکر", "عثمان", "علی"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر چند سال با حضرت خدیجه زندگی کرد؟", "options": ["۲۵ سال", "۲۰ سال", "۱۵ سال", "۳۰ سال"], "correct": 0, "source": "سیره"},
    {"q": "پیامبر چند همسر داشت؟", "options": ["۱۱ همسر", "۹ همسر", "۱۳ همسر", "۷ همسر"], "correct": 0, "source": "سیره"},
    {"q": "پسر پیامبر از همسرش ماریه چه نام داشت؟", "options": ["ابراهیم", "قاسم", "عبدالله", "طاهر"], "correct": 0, "source": "سیره"},
    {"q": "اولین خلیفه مسلمین چه کسی بود؟", "options": ["ابوبکر صدیق", "عمر بن خطاب", "عثمان بن عفان", "علی بن ابی‌طالب"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "دومین خلیفه مسلمین چه کسی بود؟", "options": ["عمر بن خطاب", "ابوبکر", "عثمان", "علی"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "سومین خلیفه مسلمین چه کسی بود؟", "options": ["عثمان بن عفان", "عمر", "علی", "ابوبکر"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "چهارمین خلیفه مسلمین چه کسی بود؟", "options": ["علی بن ابی‌طالب", "عثمان", "عمر", "ابوبکر"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "کدام صحابی به «ذوالنورین» معروف بود؟", "options": ["عثمان بن عفان", "علی", "عمر", "ابوبکر"], "correct": 0, "source": "سیره"},
    {"q": "کدام صحابی به «فاروق» معروف بود؟", "options": ["عمر بن خطاب", "ابوبکر", "عثمان", "علی"], "correct": 0, "source": "سیره"},
    {"q": "کدام صحابی به «صدیق» معروف بود؟", "options": ["ابوبکر", "عمر", "عثمان", "علی"], "correct": 0, "source": "سیره"},
    {"q": "کدام صحابی به «سیف الله» معروف بود؟", "options": ["خالد بن ولید", "حمزه", "علی", "عمر"], "correct": 0, "source": "سیره"},
    {"q": "کدام صحابی بیشترین حدیث را روایت کرده است؟", "options": ["ابوهریره", "ابوبکر", "عمر", "عثمان"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "کدام صحابی به «امین امت» معروف بود؟", "options": ["ابو عبیده", "ابوبکر", "عمر", "علی"], "correct": 0, "source": "سیره"},
    {"q": "کدام صحابی پیشنهاد جمع‌آوری قرآن را داد؟", "options": ["عمر بن خطاب", "ابوبکر", "عثمان", "علی"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "جمع‌آوری نهایی قرآن در زمان کدام خلیفه بود؟", "options": ["عثمان بن عفان", "ابوبکر", "عمر", "علی"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "کدام صحابی فدایی پیامبر در لیلة المبیت بود؟", "options": ["علی بن ابی‌طالب", "ابوبکر", "عمر", "عثمان"], "correct": 0, "source": "سیره"},
    {"q": "کدام صحابی به «سلمان فارسی» معروف است؟", "options": ["سلمان", "بلال", "عمار", "صهیب"], "correct": 0, "source": "سیره"},
    {"q": "کدام صحابی فاتح ایران بود؟", "options": ["سعد بن ابی‌وقاص", "خالد بن ولید", "ابوبکر", "عمر"], "correct": 0, "source": "سیره"},
    {"q": "کدام صحابی فاتح شام بود؟", "options": ["خالد بن ولید", "سعد بن ابی‌وقاص", "ابوبکر", "عمر"], "correct": 0, "source": "سیره"},
    {"q": "کدام صحابی فاتح مصر بود؟", "options": ["عمرو بن عاص", "خالد بن ولید", "ابوبکر", "عمر"], "correct": 0, "source": "سیره"},
    {"q": "کدام صحابی به «سیف الله المسلول» معروف بود؟", "options": ["خالد بن ولید", "ابوبکر", "عمر", "عثمان"], "correct": 0, "source": "سیره"},
    {"q": "کدام صحابی لقب «حبر الامة» داشت؟", "options": ["عبدالله بن عباس", "ابوهریره", "عایشه", "انس"], "correct": 0, "source": "سیره"},
    {"q": "کدام فرشته وحی را بر پیامبران نازل می‌کرد؟", "options": ["جبرئیل", "میکائیل", "اسرافیل", "عزرائیل"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "کدام فرشته مسئول نفخ صور است؟", "options": ["اسرافیل", "جبرئیل", "میکائیل", "عزرائیل"], "correct": 0, "source": "صحیح مسلم"},
    {"q": "کدام فرشته مسئول روزی است؟", "options": ["میکائیل", "جبرئیل", "اسرافیل", "عزرائیل"], "correct": 0, "source": "صحیح مسلم"},
    {"q": "کدام فرشته مسئول قبض روح است؟", "options": ["عزرائیل", "جبرئیل", "میکائیل", "اسرافیل"], "correct": 0, "source": "صحیح مسلم"},
    {"q": "فرشتگان از چه چیزی آفریده شده‌اند؟", "options": ["نور", "خاک", "آتش", "آب"], "correct": 0, "source": "صحیح مسلم"},
    {"q": "شیطان از چه چیزی آفریده شده است؟", "options": ["آتش", "نور", "خاک", "آب"], "correct": 0, "source": "قرآن، اعراف: ۱۲"},
    {"q": "کدام فرشته بر قبر سوال می‌پرسد؟", "options": ["نکیر و منکر", "جبرئیل", "میکائیل", "اسرافیل"], "correct": 0, "source": "سنن ترمذی"},
    {"q": "قرآن بر کدام فرشته نازل شد؟", "options": ["جبرئیل", "میکائیل", "اسرافیل", "عزرائیل"], "correct": 0, "source": "قرآن"},
    {"q": "کدام فرشته پیامبر را در غار حرا صدا زد؟", "options": ["جبرئیل", "میکائیل", "اسرافیل", "عزرائیل"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "کدام پیامبر بر همه فرشتگان برتری دارد؟", "options": ["حضرت محمد ﷺ", "حضرت موسی", "حضرت عیسی", "حضرت ابراهیم"], "correct": 0, "source": "قرآن"},
    {"q": "کدام ماه روزه بر مسلمانان واجب است؟", "options": ["ماه رمضان", "ماه شعبان", "ماه رجب", "ماه محرم"], "correct": 0, "source": "قرآن، بقره: ۱۸۵"},
    {"q": "نماز صبح چند رکعت است؟", "options": ["۲ رکعت", "۳ رکعت", "۴ رکعت", "۱ رکعت"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "نماز مغرب چند رکعت است؟", "options": ["۳ رکعت", "۲ رکعت", "۴ رکعت", "۵ رکعت"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "نماز عشا چند رکعت است؟", "options": ["۴ رکعت", "۳ رکعت", "۲ رکعت", "۵ رکعت"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "نماز ظهر چند رکعت است؟", "options": ["۴ رکعت", "۳ رکعت", "۲ رکعت", "۵ رکعت"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "نماز عصر چند رکعت است؟", "options": ["۴ رکعت", "۳ رکعت", "۲ رکعت", "۵ رکعت"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "زکات به چه معناست؟", "options": ["بخشی از مال برای نیازمندان", "نماز شب", "روزه مستحبی", "حج مستحبی"], "correct": 0, "source": "قرآن، توبه: ۶۰"},
    {"q": "حج بر چه کسانی واجب است؟", "options": ["مستطیع (توانا)", "همه مسلمانان", "فقط علما", "فقط مردان"], "correct": 0, "source": "قرآن، آل‌عمران: ۹۷"},
    {"q": "روزه در کدام ماه‌ها حرام است؟", "options": ["عید فطر و قربان", "رمضان", "شعبان", "رجب"], "correct": 0, "source": "صحیح مسلم"},
    {"q": "نمازهای واجب روزانه چند نوبت است؟", "options": ["۵ نوبت", "۳ نوبت", "۷ نوبت", "۴ نوبت"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "قبله مسلمانان کجاست؟", "options": ["کعبه", "مسجد النبی", "مسجد الاقصی", "قبر پیامبر"], "correct": 0, "source": "قرآن، بقره: ۱۴۴"},
    {"q": "طواف به دور چه چیزی انجام می‌شود؟", "options": ["کعبه", "مسجد النبی", "قبر پیامبر", "مسجد الاقصی"], "correct": 0, "source": "قرآن"},
    {"q": "سعی بین کدام دو کوه انجام می‌شود؟", "options": ["صفا و مروه", "احد و ثور", "حرا و نور", "عرفات و منا"], "correct": 0, "source": "قرآن، بقره: ۱۵۸"},
    {"q": "روزه در کدام ماه مستحب است؟", "options": ["شعبان", "رجب", "محرم", "همه موارد"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "نماز جمعه چند رکعت است؟", "options": ["۲ رکعت", "۳ رکعت", "۴ رکعت", "۵ رکعت"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "نماز عید چند رکعت است؟", "options": ["۲ رکعت", "۳ رکعت", "۴ رکعت", "۱ رکعت"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "نماز وتر چند رکعت است؟", "options": ["۱ رکعت", "۲ رکعت", "۳ رکعت", "۴ رکعت"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "نصاب زکات طلا چند مثقال است؟", "options": ["۲۰ مثقال", "۱۰ مثقال", "۳۰ مثقال", "۴۰ مثقال"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "نصاب زکات نقره چند درهم است؟", "options": ["۲۰۰ درهم", "۱۰۰ درهم", "۳۰۰ درهم", "۴۰۰ درهم"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "زکات چند درصد از مال است؟", "options": ["۲.۵ درصد", "۵ درصد", "۱۰ درصد", "۱ درصد"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر فرمود: «بهترین شما کسی است که...»", "options": ["قرآن را بیاموزد و بیاموزاند", "بیشترین مال را داشته باشد", "بیشترین عبادت را کند", "بیشترین سفر را کند"], "correct": 0, "source": "صحیح بخاری ۵۰۲۷"},
    {"q": "پیامبر فرمود: «اعمال فقط با... سنجیده می‌شوند.»", "options": ["نیت", "تعداد", "سختی", "پایان"], "correct": 0, "source": "صحیح بخاری ۱"},
    {"q": "پیامبر فرمود: «کسی که به خدا و روز قیامت ایمان دارد، باید...»", "options": ["سخن خوب بگوید یا سکوت کند", "زیاد سفر کند", "تنها غذا بخورد", "زیاد بخندد"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر فرمود: «مسلمان کسی است که مسلمانان از... او در امان باشند.»", "options": ["زبان و دست", "چشم", "مال", "پا"], "correct": 0, "source": "صحیح بخاری ۱۰"},
    {"q": "پیامبر فرمود: «خداوند زیباست و... را دوست دارد.»", "options": ["زیبایی", "ثروت", "قدرت", "شهرت"], "correct": 0, "source": "صحیح مسلم"},
    {"q": "پیامبر فرمود: «هیچ‌کس با... خود وارد بهشت نمی‌شود.»", "options": ["عمل", "مال", "خانواده", "دوست"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر فرمود: «بهترین صدقه، صدقه‌ای است که...»", "options": ["از مال حلال باشد", "زیاد باشد", "پنهانی باشد", "در مسجد باشد"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر فرمود: «کسی که... را بخورد، بوی دهانش مردم را آزار می‌دهد.»", "options": ["سیر", "پیاز", "هر دو", "هیچ‌کدام"], "correct": 2, "source": "صحیح مسلم"},
    {"q": "پیامبر فرمود: «بهترین جهاد، گفتن... نزد حاکم ستمگر است.»", "options": ["کلمه حق", "کلمه جنگ", "کلمه صلح", "کلمه دوستی"], "correct": 0, "source": "سنن ابی‌داود"},
    {"q": "پیامبر فرمود: «بهشت زیر پای... است.»", "options": ["مادران", "پدران", "فرزندان", "همسران"], "correct": 0, "source": "سنن نسائی"},
    {"q": "پیامبر فرمود: «... کلید بهشت است.»", "options": ["نماز", "روزه", "زکات", "حج"], "correct": 0, "source": "سنن ترمذی"},
    {"q": "پیامبر فرمود: «... نور است.»", "options": ["علم", "مال", "قدرت", "شهرت"], "correct": 0, "source": "صحیح مسلم"},
    {"q": "پیامبر فرمود: «... نصف ایمان است.»", "options": ["طهارت", "نماز", "روزه", "زکات"], "correct": 0, "source": "صحیح مسلم"},
    {"q": "پیامبر فرمود: «بهترین شما کسی است که با... خوب رفتار کند.»", "options": ["خانواده‌اش", "دوستانش", "همسایگانش", "همکارانش"], "correct": 0, "source": "سنن ترمذی"},
    {"q": "پیامبر فرمود: «... از ایمان است.»", "options": ["حیا", "ثروت", "قدرت", "شهرت"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر فرمود: «دروغ... است.»", "options": ["نفاق", "ایمان", "اسلام", "تقوا"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر فرمود: «غیبت... است.»", "options": ["حرام", "حلال", "مکروه", "مستحب"], "correct": 0, "source": "صحیح مسلم"},
    {"q": "پیامبر فرمود: «... حق همسایه است.»", "options": ["احترام", "بی‌احترامی", "فقط سلام", "فقط هدیه"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پیامبر فرمود: «... از بهترین اعمال است.»", "options": ["خوش‌اخلاقی", "ثروت", "قدرت", "شهرت"], "correct": 0, "source": "سنن ترمذی"},
    {"q": "کدام ماه‌ها حرام هستند؟", "options": ["ذی‌القعده، ذی‌الحجه، محرم، رجب", "رمضان، شوال", "شعبان، رجب", "محرم، صفر"], "correct": 0, "source": "قرآن، توبه: ۳۶"},
    {"q": "هجرت پیامبر مبدأ کدام تقویم است؟", "options": ["تقویم هجری قمری", "تقویم میلادی", "تقویم شمسی", "تقویم یهودی"], "correct": 0, "source": "سیره"},
    {"q": "بیت‌المقدس در کدام شهر است؟", "options": ["قدس", "مکه", "مدینه", "دمشق"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "اولین مسجد قبله مسلمانان کدام بود؟", "options": ["مسجد الاقصی", "مسجد الحرام", "مسجد النبی", "مسجد قبا"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "کعبه در کدام شهر است؟", "options": ["مکه", "مدینه", "طائف", "یمن"], "correct": 0, "source": "قرآن"},
    {"q": "مسجد النبی در کدام شهر است؟", "options": ["مدینه", "مکه", "طائف", "یمن"], "correct": 0, "source": "سیره"},
    {"q": "مسجد الاقصی در کدام شهر است؟", "options": ["قدس", "مکه", "مدینه", "دمشق"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "کعبه توسط کدام پیامبر ساخته شد؟", "options": ["حضرت ابراهیم و اسماعیل", "حضرت نوح", "حضرت موسی", "حضرت عیسی"], "correct": 0, "source": "قرآن، بقره: ۱۲۷"},
    {"q": "سال فیل در چه سالی بود؟", "options": ["سال تولد پیامبر", "سال بعثت", "سال هجرت", "سال فتح مکه"], "correct": 0, "source": "سیره"},
    {"q": "تغییر قبله در کدام سال هجری رخ داد؟", "options": ["سال دوم هجری", "سال اول هجری", "سال سوم هجری", "سال چهارم هجری"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "چاه زمزم در کجاست؟", "options": ["مکه", "مدینه", "طائف", "یمن"], "correct": 0, "source": "سیره"},
    {"q": "غزوه تبوک در کدام منطقه رخ داد؟", "options": ["تبوک", "بدر", "احد", "خندق"], "correct": 0, "source": "سیره"},
    {"q": "اولین شهید اسلام چه کسی بود؟", "options": ["سمیه", "بلال", "عمار", "صهیب"], "correct": 0, "source": "سیره"},
    {"q": "اولین زن مسلمان چه کسی بود؟", "options": ["خدیجه", "عایشه", "فاطمه", "زینب"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "اولین فرزند پیامبر چه نام داشت؟", "options": ["قاسم", "عبدالله", "ابراهیم", "طاهر"], "correct": 0, "source": "سیره"},
    {"q": "اولین کسی که در مکه اذان گفت چه کسی بود؟", "options": ["بلال", "ابوبکر", "عمر", "عثمان"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پادشاه حبشه در زمان پیامبر چه نام داشت؟", "options": ["نجاشی", "هرقل", "کسری", "مقوقس"], "correct": 0, "source": "سیره"},
    {"q": "پادشاه روم در زمان پیامبر چه نام داشت؟", "options": ["هرقل", "نجاشی", "کسری", "مقوقس"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "پادشاه ایران در زمان پیامبر چه نام داشت؟", "options": ["کسری", "هرقل", "نجاشی", "مقوقس"], "correct": 0, "source": "صحیح بخاری"},
    {"q": "کدام سوره به «سوره توحید» معروف است؟", "options": ["سوره اخلاص", "سوره فلق", "سوره ناس", "سوره کوثر"], "correct": 0, "source": "قرآن"},
    {"q": "کدام سوره به «سوره نور» معروف است؟", "options": ["سوره نور", "سوره قصص", "سوره عنکبوت", "سوره روم"], "correct": 0, "source": "قرآن"},
    {"q": "کدام سوره «بنی‌اسرائیل» هم نام دارد؟", "options": ["سوره اسراء", "سوره کهف", "سوره مریم", "سوره طه"], "correct": 0, "source": "قرآن"},
    {"q": "کدام سوره به «سوره فیل» معروف است؟", "options": ["سوره فیل", "سوره اصحاب فیل", "سوره پیل", "سوره ابابیل"], "correct": 0, "source": "قرآن"},
    {"q": "کدام سوره به «سوره ملک» معروف است؟", "options": ["سوره ملک", "سوره پادشاه", "سوره سلطان", "سوره حکومت"], "correct": 0, "source": "قرآن"},
    {"q": "کدام سوره به «سوره قلم» معروف است؟", "options": ["سوره قلم", "سوره مداد", "سوره نوشتن", "سوره墨水"], "correct": 0, "source": "قرآن"},
    {"q": "کدام سوره به «سوره نوح» معروف است؟", "options": ["سوره نوح", "سوره کشتی", "سوره طوفان", "سوره سیل"], "correct": 0, "source": "قرآن"},
    {"q": "کدام سوره به «سوره جن» معروف است؟", "options": ["سوره جن", "سوره شیاطین", "سوره اجنه", "سوره پریان"], "correct": 0, "source": "قرآن"},
    {"q": "کدام سوره به «سوره مزمل» معروف است؟", "options": ["سوره مزمل", "سوره جامه", "سوره لباس", "سوره ردا"], "correct": 0, "source": "قرآن"},
    {"q": "کدام سوره به «سوره مدثر» معروف است؟", "options": ["سوره مدثر", "سوره پوشیده", "سوره جامه", "سوره لباس"], "correct": 0, "source": "قرآن"},
    {"q": "حضرت یونس چند روز در شکم ماهی بود؟", "options": ["چند روز", "۴۰ روز", "۱ روز", "۳ روز"], "correct": 0, "source": "قرآن، صافات: ۱۴۴"},
    {"q": "کدام پیامبر از آسمان غذا آورد؟", "options": ["حضرت عیسی", "حضرت موسی", "حضرت نوح", "حضرت ابراهیم"], "correct": 0, "source": "قرآن، مائده: ۱۱۲"},
    {"q": "کدام پیامبر به آسمان رفت؟", "options": ["حضرت عیسی", "حضرت موسی", "حضرت ابراهیم", "حضرت یوسف"], "correct": 0, "source": "قرآن"},
    {"q": "حضرت سلیمان چه چیزی را از خدا خواست؟", "options": ["حکومت بی‌نظیر", "ثروت", "عمر طولانی", "فرزند زیاد"], "correct": 0, "source": "قرآن، ص: ۳۵"},
    {"q": "کدام پیامبر زبور بر او نازل شد؟", "options": ["حضرت داوود", "حضرت موسی", "حضرت عیسی", "حضرت نوح"], "correct": 0, "source": "قرآن"},
    {"q": "کدام پیامبر تورات بر او نازل شد؟", "options": ["حضرت موسی", "حضرت عیسی", "حضرت داوود", "حضرت محمد"], "correct": 0, "source": "قرآن"},
    {"q": "کدام پیامبر انجیل بر او نازل شد؟", "options": ["حضرت عیسی", "حضرت موسی", "حضرت داوود", "حضرت محمد"], "correct": 0, "source": "قرآن"},
    {"q": "قرآن بر کدام پیامبر نازل شد؟", "options": ["حضرت محمد ﷺ", "حضرت موسی", "حضرت عیسی", "حضرت داوود"], "correct": 0, "source": "قرآن"},
    {"q": "حضرت خدیجه در کدام سال وفات یافت؟", "options": ["سال دهم بعثت", "سال پنجم بعثت", "سال اول بعثت", "سال سیزدهم بعثت"], "correct": 0, "source": "سیره"},
    {"q": "پیامبر نام «مدینه» را برای یثرب انتخاب کرد.", "options": ["درست", "نادرست", "هیچ‌کدام", "نمی‌دانم"], "correct": 0, "source": "سیره"},
]


# --------------------------------------------------
# مدیریت فایل سوالات
# --------------------------------------------------

def load_questions():
    if os.path.exists(QUESTIONS_FILE):
        try:
            with open(QUESTIONS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list) and len(data) > 0:
                    return data
        except Exception:
            pass
    save_questions(DEFAULT_QUESTIONS)
    return [dict(q) for q in DEFAULT_QUESTIONS]


def save_questions(questions):
    with open(QUESTIONS_FILE, "w", encoding="utf-8") as f:
        json.dump(questions, f, ensure_ascii=False, indent=2)


# --------------------------------------------------
# تنظیمات
# --------------------------------------------------

WIN_SCORE = 20
TURN_SECONDS = 20


# --------------------------------------------------
# توابع کمکی
# --------------------------------------------------

def get_game():
    return session.get("game")


def save_game(game):
    session["game"] = game
    session.modified = True


def current_player(game):
    return game["players"][game["turn_index"]]


def error(message, status=400):
    return jsonify({"ok": False, "error": message}), status


def next_turn(game):
    if all(p["finished"] for p in game["players"]):
        game["phase"] = "over"
        game["opened"] = False
        game["deadline"] = None
        game["current_question"] = None
        return

    for _ in range(len(game["players"])):
        game["turn_index"] = (game["turn_index"] + 1) % len(game["players"])
        if not game["players"][game["turn_index"]]["finished"]:
            break

    game["opened"] = False
    game["deadline"] = None
    game["awaiting_start"] = True
    game["current_question"] = None


def timeout_check(game):
    if game["opened"] and game["deadline"] is not None and time.time() >= game["deadline"]:
        next_turn(game)
        return True
    return False


def mark_finished_if_winner(game, player):
    if player["finished"]:
        return False
    if player.get("score", 0) < WIN_SCORE:
        return False

    player["finished"] = True
    if player["name"] not in game["winners"]:
        game["winners"].append(player["name"])

    if all(p["finished"] for p in game["players"]):
        game["phase"] = "over"
        game["opened"] = False
        game["deadline"] = None
        game["current_question"] = None
        return True

    next_turn(game)
    game["awaiting_start"] = True
    game["current_question"] = None
    return True


def update_roster_scores(game):
    roster = session.get("roster", [])
    score_map = {}
    for i, name in enumerate(game["winners"]):
        score_map[name] = score_map.get(name, 0) + (len(game["winners"]) - i)
    for entry in roster:
        if entry["name"] in score_map:
            entry["score"] = entry.get("score", 0) + score_map[entry["name"]]
    session["roster"] = roster
    session.modified = True


# --------------------------------------------------
# Routes
# --------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/admin")
def admin():
    if not session.get("admin_ok"):
        return render_template("admin_login.html")
    return render_template("admin.html")


@app.route("/admin/login", methods=["POST"])
def admin_login():
    data = request.get_json(silent=True) or {}
    pw = str(data.get("password", ""))
    if pw == ADMIN_PASSWORD:
        session["admin_ok"] = True
        session.modified = True
        return jsonify({"ok": True})
    return error("رمز عبور اشتباه است.")


@app.route("/admin/logout", methods=["POST"])
def admin_logout():
    session.pop("admin_ok", None)
    session.modified = True
    return jsonify({"ok": True})


@app.route("/questions/count", methods=["GET"])
def questions_count():
    qs = load_questions()
    return jsonify({"ok": True, "count": len(qs)})


@app.route("/questions/all", methods=["GET"])
def questions_all():
    if not session.get("admin_ok"):
        return error("دسترسی ندارید.", 403)
    qs = load_questions()
    return jsonify({"ok": True, "questions": qs})


@app.route("/questions/add", methods=["POST"])
def questions_add():
    if not session.get("admin_ok"):
        return error("دسترسی ندارید.", 403)
    data = request.get_json(silent=True) or {}
    q_text = str(data.get("q", "")).strip()
    options = data.get("options", [])
    correct = data.get("correct")
    source = str(data.get("source", "")).strip()

    if not q_text:
        return error("متن سوال خالی است.")
    if not isinstance(options, list) or len(options) != 4:
        return error("باید ۴ گزینه وارد شود.")
    options = [str(o).strip() for o in options]
    if any(not o for o in options):
        return error("همه گزینه‌ها باید پر باشند.")
    if not isinstance(correct, int) or correct < 0 or correct > 3:
        return error("گزینه صحیح نامعتبر است.")

    qs = load_questions()
    qs.append({"q": q_text, "options": options, "correct": correct, "source": source})
    save_questions(qs)
    return jsonify({"ok": True, "message": "سوال اضافه شد.", "count": len(qs)})


@app.route("/questions/update", methods=["POST"])
def questions_update():
    if not session.get("admin_ok"):
        return error("دسترسی ندارید.", 403)
    data = request.get_json(silent=True) or {}
    idx = data.get("index")
    q_text = str(data.get("q", "")).strip()
    options = data.get("options", [])
    correct = data.get("correct")
    source = str(data.get("source", "")).strip()

    if not isinstance(idx, int):
        return error("ایندکس نامعتبر است.")
    qs = load_questions()
    if idx < 0 or idx >= len(qs):
        return error("سوال پیدا نشد.")
    if not q_text:
        return error("متن سوال خالی است.")
    if not isinstance(options, list) or len(options) != 4:
        return error("باید ۴ گزینه وارد شود.")
    options = [str(o).strip() for o in options]
    if any(not o for o in options):
        return error("همه گزینه‌ها باید پر باشند.")
    if not isinstance(correct, int) or correct < 0 or correct > 3:
        return error("گزینه صحیح نامعتبر است.")

    qs[idx] = {"q": q_text, "options": options, "correct": correct, "source": source}
    save_questions(qs)
    return jsonify({"ok": True, "message": "سوال ویرایش شد."})


@app.route("/questions/delete", methods=["POST"])
def questions_delete():
    if not session.get("admin_ok"):
        return error("دسترسی ندارید.", 403)
    data = request.get_json(silent=True) or {}
    idx = data.get("index")
    if not isinstance(idx, int):
        return error("ایندکس نامعتبر است.")
    qs = load_questions()
    if idx < 0 or idx >= len(qs):
        return error("سوال پیدا نشد.")
    qs.pop(idx)
    save_questions(qs)
    return jsonify({"ok": True, "message": "سوال حذف شد.", "count": len(qs)})


@app.route("/questions/restore", methods=["POST"])
def questions_restore():
    if not session.get("admin_ok"):
        return error("دسترسی ندارید.", 403)
    save_questions(DEFAULT_QUESTIONS)
    return jsonify({"ok": True, "message": "سوالات بازگردانی شد.", "count": len(DEFAULT_QUESTIONS)})


@app.route("/start", methods=["POST"])
def start():
    data = request.get_json(silent=True) or {}
    names = data.get("names", [])
    if not isinstance(names, list):
        return error("اطلاعات بازیکنان صحیح نیست.")
    names = [str(n).strip() for n in names if str(n).strip()]
    if len(names) < 2:
        return error("حداقل ۲ بازیکن لازم است.")
    if len(names) > 12:
        return error("حداکثر ۱۲ بازیکن مجاز است.")
    if len(set(n.casefold() for n in names)) != len(names):
        return error("نام بازیکنان نباید تکراری باشد.")

    qs = load_questions()
    if len(qs) < 3:
        return error("حداقل ۳ سوال برای شروع بازی لازم است.")

    players = [{
        "id": str(i), "name": name, "score": 0,
        "finished": False, "wrong_answers": 0,
    } for i, name in enumerate(names)]

    game = {
        "players": players, "phase": "play", "turn_index": 0,
        "opened": False, "deadline": None, "winners": [],
        "awaiting_start": True, "current_question": None,
    }
    save_game(game)

    roster = session.get("roster", [])
    existing_names = {e["name"] for e in roster}
    for name in names:
        if name not in existing_names:
            roster.append({"name": name, "score": 0})
    session["roster"] = roster
    session.modified = True
    return jsonify({"ok": True})


@app.route("/reset", methods=["POST"])
def reset():
    session.pop("game", None)
    session.pop("roster", None)
    session.modified = True
    return jsonify({"ok": True})


@app.route("/roster", methods=["GET"])
def roster():
    return jsonify({"ok": True, "players": session.get("roster", [])})


@app.route("/state", methods=["GET"])
def state():
    game = get_game()
    if not game:
        return error("بازی هنوز شروع نشده است.")

    if game["phase"] == "over":
        return jsonify({"phase": "over", "winners": game["winners"], "roster": session.get("roster", [])})

    if game["opened"]:
        timeout_check(game)

    if game["phase"] == "over":
        update_roster_scores(game)
        save_game(game)
        return jsonify({"phase": "over", "winners": game["winners"], "roster": session.get("roster", [])})

    player = current_player(game)
    remaining = 0
    if game["opened"]:
        remaining = max(0, int(game["deadline"] - time.time() + 0.99))

    save_game(game)
    return jsonify({
        "phase": "play", "opened": game["opened"],
        "awaiting_start": game.get("awaiting_start", False),
        "current": player["name"], "remaining": remaining,
        "score": player["score"], "win_score": WIN_SCORE,
        "wrong_answers": player.get("wrong_answers", 0),
        "finished": player["finished"],
        "players": [{"name": p["name"], "score": p["score"], "finished": p["finished"]} for p in game["players"]],
        "winners": game["winners"],
        "total_questions": len(load_questions()),
    })


@app.route("/begin_turn", methods=["POST"])
def begin_turn():
    game = get_game()
    if not game or game["phase"] != "play":
        return error("بازی فعال نیست.")
    if game["opened"]:
        return error("نوبت در حال اجراست.")
    if not game.get("awaiting_start", False):
        return error("این نوبت قبلاً شروع شده است.")
    player = current_player(game)
    if player["finished"]:
        next_turn(game)
        save_game(game)
        return error("این بازیکن قبلاً برنده شده است.")
    game["opened"] = True
    game["deadline"] = time.time() + TURN_SECONDS
    game["awaiting_start"] = False
    save_game(game)
    return jsonify({"ok": True, "remaining": TURN_SECONDS})


@app.route("/question", methods=["GET"])
def question():
    game = get_game()
    if not game or not game["opened"]:
        return error("نوبت فعال نیست.")
    if timeout_check(game):
        save_game(game)
        return error("زمان شما تمام شد.")

    if game.get("current_question") is not None:
        q = game["current_question"]
        return jsonify({"ok": True, "question": q["q"], "options": q["options"], "source": q.get("source", "")})

    qs = load_questions()
    if not qs:
        return error("هیچ سوالی موجود نیست.")

    q = random.choice(qs)

    correct_text = q["options"][q["correct"]]
    shuffled = list(q["options"])
    random.shuffle(shuffled)
    new_correct = shuffled.index(correct_text)

    game["current_question"] = {
        "q": q["q"], "options": shuffled,
        "correct": new_correct, "source": q.get("source", ""),
    }
    save_game(game)
    return jsonify({"ok": True, "question": q["q"], "options": shuffled, "source": q.get("source", "")})


@app.route("/answer", methods=["POST"])
def answer():
    game = get_game()
    if not game or not game["opened"]:
        return error("نوبت فعال نیست.")
    if timeout_check(game):
        save_game(game)
        return error("زمان شما تمام شد.")
    if game.get("current_question") is None:
        return error("سوالی برای پاسخ وجود ندارد.")
    data = request.get_json(silent=True) or {}
    selected = data.get("selected")
    if not isinstance(selected, int):
        return error("پاسخ نامعتبر است.")

    q = game["current_question"]
    player = current_player(game)
    is_correct = (selected == q["correct"])
    if is_correct:
        player["score"] = player.get("score", 0) + 1
        message = "✅ پاسخ درست!"
    else:
        player["wrong_answers"] = player.get("wrong_answers", 0) + 1
        correct_text = q["options"][q["correct"]]
        message = f"❌ اشتباه. پاسخ درست: {correct_text}"

    game["current_question"] = None
    won = mark_finished_if_winner(game, player)
    save_game(game)

    if won:
        if game["phase"] == "over":
            update_roster_scores(game)
            save_game(game)
            return jsonify({"ok": True, "correct": is_correct, "won": True, "game_over": True,
                            "message": message + " تبریک! به ۲۰ جواب درست رسیدی و برنده شدی. بازی تمام شد.",
                            "score": player["score"]})
        return jsonify({"ok": True, "correct": is_correct, "won": True, "game_over": False,
                        "message": message + " تبریک! به ۲۰ جواب درست رسیدی و برنده شدی. نوبت به نفر بعدی رسید.",
                        "score": player["score"]})

    return jsonify({"ok": True, "correct": is_correct, "won": False, "game_over": False,
                    "message": message, "score": player["score"]})


@app.route("/timeout", methods=["POST"])
def timeout():
    game = get_game()
    if not game or game["phase"] != "play":
        return jsonify({"ok": False})
    if not game["opened"]:
        return jsonify({"ok": False})
    game["current_question"] = None
    next_turn(game)
    save_game(game)
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)