"use strict";

const $ = id => document.getElementById(id);
let busy = false;
let timerInterval = null;
let secondsLeft = 20;
let gameFinished = false;
let currentOpened = false;
let awaitingStart = false;
let timeoutRetry = null;
let currentQuestionLoaded = false;

let audioCtx = null;

function getAudioCtx() {
    if (!audioCtx) {
        try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
        catch { return null; }
    }
    if (audioCtx.state === "suspended") audioCtx.resume();
    return audioCtx;
}

function playTone(freq, duration, type = "sine", volume = 0.2, delay = 0) {
    const ctx = getAudioCtx();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    osc.connect(gain); gain.connect(ctx.destination);
    const now = ctx.currentTime + delay;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(volume, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
    osc.start(now); osc.stop(now + duration);
}

function soundCorrect() {
    playTone(660, 0.15, "sine", 0.25, 0);
    playTone(880, 0.20, "sine", 0.25, 0.12);
    playTone(1320, 0.30, "sine", 0.22, 0.25);
}
function soundWrong() {
    playTone(300, 0.20, "sawtooth", 0.25, 0);
    playTone(200, 0.35, "sawtooth", 0.25, 0.15);
}
function soundClick() { playTone(500, 0.05, "square", 0.1, 0); }
function soundWin() {
    playTone(523, 0.15, "sine", 0.3, 0);
    playTone(659, 0.15, "sine", 0.3, 0.15);
    playTone(784, 0.15, "sine", 0.3, 0.3);
    playTone(1047, 0.4, "sine", 0.3, 0.45);
}
function soundTick() { playTone(800, 0.06, "square", 0.12, 0); }

async function api(url, data = null, method = null) {
    const httpMethod = method || (data === null ? "GET" : "POST");
    const options = { method: httpMethod, headers: { "Content-Type": "application/json" } };
    if (httpMethod === "POST") options.body = JSON.stringify(data || {});
    const res = await fetch(url, options);
    let result;
    try { result = await res.json(); } catch { throw new Error("پاسخ سرور قابل خواندن نیست."); }
    if (!res.ok || result.error) throw new Error(result.error || "خطا");
    return result;
}

function showScreen(id) {
    ["setupScreen", "gameScreen", "resultScreen"].forEach(s => $(s).classList.add("hidden"));
    $(id).classList.remove("hidden");
}

function setupMessage(text, type = "") {
    $("setupMessage").textContent = text;
    $("setupMessage").className = "message " + type;
}
function gameMessage(text, type = "") {
    $("gameMessage").textContent = text;
    $("gameMessage").className = "message " + type;
}

async function loadRoster() {
    try { const d = await api("/roster", null, "GET"); return d.players || []; }
    catch { return []; }
}

function renderScoreBoard(containerId, players) {
    const c = $(containerId);
    if (!c) return;
    c.innerHTML = "";
    if (!players || players.length === 0) { c.textContent = "بازیکنی ذخیره نشده است."; return; }
    const sorted = [...players].sort((a, b) => (b.score || 0) - (a.score || 0));
    sorted.forEach((p, i) => {
        const row = document.createElement("div");
        row.className = "score-row";
        const rank = document.createElement("span");
        rank.className = "score-rank";
        rank.textContent = ["🥇", "🥈", "🥉"][i] || (i + 1);
        const name = document.createElement("span");
        name.className = "score-name";
        name.textContent = p.name;
        const score = document.createElement("span");
        score.className = "score-value";
        score.textContent = p.score || 0;
        row.appendChild(rank); row.appendChild(name); row.appendChild(score);
        c.appendChild(row);
    });
}

function createPlayerInput(name = "", index = null) {
    const row = document.createElement("div");
    row.className = "player-input-row";
    const number = document.createElement("span");
    const inputs = $("playerInputs");
    const next = index ?? (inputs.querySelectorAll(".player-name").length + 1);
    number.textContent = next;
    const input = document.createElement("input");
    input.type = "text";
    input.className = "player-name";
    input.placeholder = "نام بازیکن " + next;
    input.maxLength = 30;
    input.value = name;
    row.appendChild(number); row.appendChild(input);
    return row;
}

async function prepareSetupScreen() {
    const roster = await loadRoster();
    if (roster.length > 0) {
        $("setupTitle").textContent = "آماده‌ی مسابقه بعدی هستی؟";
        $("setupDesc").textContent = "بازیکنان و امتیازات ذخیره شده‌اند. می‌توانی بازیکن اضافه کنی یا مسابقه را شروع کنی.";
        $("scoreBoard").classList.remove("hidden");
        renderScoreBoard("scoreList", roster);
    } else {
        $("setupTitle").textContent = "به مسابقه دینی خوش آمدید";
        $("setupDesc").textContent = "نام بازیکنان را وارد کنید و مسابقه را شروع کنید.";
        $("scoreBoard").classList.add("hidden");
    }
    $("playerInputs").innerHTML = "";
    if (roster.length > 0) {
        roster.forEach((p, i) => $("playerInputs").appendChild(createPlayerInput(p.name, i + 1)));
    } else {
        for (let i = 1; i <= 3; i++) $("playerInputs").appendChild(createPlayerInput("", i));
    }
    showScreen("setupScreen");
}

async function fullReset() {
    if (busy) return;
    if (!confirm("همه چیز ریست شود؟ بازیکنان و امتیازات هم حذف می‌شوند.")) return;
    busy = true; stopTimer();
    try { await api("/reset", {}); } catch (e) { console.log(e.message); }
    gameFinished = false; currentOpened = false; awaitingStart = false;
    $("winnersList").innerHTML = "";
    $("gameMessage").textContent = "";
    busy = false;
    await prepareSetupScreen();
}
$("resetBtn").addEventListener("click", fullReset);

async function newGame() {
    if (busy) return;
    busy = true; stopTimer();
    try { await api("/reset", {}); } catch (e) { console.log(e.message); }
    gameFinished = false; currentOpened = false; awaitingStart = false;
    $("winnersList").innerHTML = "";
    $("gameMessage").textContent = "";
    busy = false;
    await prepareSetupScreen();
}
$("newGameBtn").addEventListener("click", newGame);

$("addPlayerBtn").addEventListener("click", function () {
    const container = $("playerInputs");
    const count = container.querySelectorAll(".player-name").length + 1;
    if (count > 12) { setupMessage("حداکثر ۱۲ بازیکن مجاز است."); return; }
    const row = createPlayerInput("", count);
    container.appendChild(row);
    row.querySelector("input").focus();
});

window.startGame = async function () {
    if (busy) return;
    const button = $("startBtn");
    const names = Array.from(document.querySelectorAll(".player-name"))
        .map(i => i.value.trim()).filter(n => n.length > 0);
    if (names.length < 2) { setupMessage("حداقل دو بازیکن وارد کنید."); return; }
    if (names.length > 12) { setupMessage("حداکثر ۱۲ بازیکن مجاز است."); return; }
    const normalized = names.map(n => n.toLowerCase());
    if (new Set(normalized).size !== names.length) { setupMessage("نام بازیکنان نباید تکراری باشد."); return; }

    busy = true; button.disabled = true;
    setupMessage("در حال آماده‌سازی...");
    try {
        await api("/start", { names });
        gameFinished = false; currentOpened = false; awaitingStart = false;
        await refreshState();
    } catch (e) { console.error(e); setupMessage(e.message); }
    finally { busy = false; button.disabled = false; }
};

$("beginTurnBtn").addEventListener("click", async function () {
    if (busy) return;
    soundClick();
    busy = true; $("beginTurnBtn").disabled = true;
    try {
        await api("/begin_turn", {});
        currentOpened = false; awaitingStart = false; currentQuestionLoaded = false;
        await refreshState(true);
    } catch (e) { alert(e.message); await refreshState(); }
    finally { busy = false; $("beginTurnBtn").disabled = false; }
});

function updateTimer() {
    $("timer").textContent = secondsLeft;
    const box = $("timerBox");
    if (box) {
        box.style.background = secondsLeft <= 3
            ? "linear-gradient(135deg, #ffd6dc, #ffaeb8)"
            : "linear-gradient(135deg, #f5edd0, #e8d89a)";
        box.style.color = secondsLeft <= 3 ? "#c11f35" : "#8a6d1f";
    }
}
function stopTimer() {
    if (timerInterval !== null) { clearInterval(timerInterval); timerInterval = null; }
    if (timeoutRetry !== null) { clearTimeout(timeoutRetry); timeoutRetry = null; }
}
async function sendTimeout() {
    if (busy) { timeoutRetry = setTimeout(sendTimeout, 250); return; }
    busy = true;
    try { await api("/timeout", {}); awaitingStart = true; await refreshState(); }
    catch (e) { gameMessage(e.message); }
    finally { busy = false; }
}
function startTimer(seconds) {
    stopTimer();
    secondsLeft = Math.max(0, Math.floor(Number(seconds)));
    updateTimer();
    timerInterval = setInterval(function () {
        secondsLeft--; updateTimer();
        if (secondsLeft <= 3 && secondsLeft > 0) soundTick();
        if (secondsLeft <= 0) { stopTimer(); sendTimeout(); }
    }, 1000);
}

async function loadQuestion() {
    if (currentQuestionLoaded) return;
    try {
        const data = await api("/question", null, "GET");
        currentQuestionLoaded = true;
        renderQuestion(data);
    } catch (e) { gameMessage(e.message); }
}

const CARD_COLORS = ["card-green", "card-blue", "card-orange", "card-purple"];
const CARD_ICONS = ["🅰️", "🅱️", "🅲️", "🅳️"];

function renderQuestion(data) {
    $("questionArea").classList.remove("hidden");
    $("questionSource").textContent = "📚 " + (data.source || "");
    $("questionText").textContent = data.question;

    const list = $("optionsList");
    list.innerHTML = "";
    $("answerMessage").textContent = "";
    $("answerMessage").className = "message";

    (data.options || []).forEach((opt, idx) => {
        const btn = document.createElement("button");
        btn.className = "option-card " + CARD_COLORS[idx % 4];
        btn.type = "button";

        const icon = document.createElement("div");
        icon.className = "option-icon";
        icon.textContent = CARD_ICONS[idx % 4];

        const text = document.createElement("div");
        text.className = "option-text";
        text.textContent = opt;

        btn.appendChild(icon);
        btn.appendChild(text);
        btn.addEventListener("click", () => submitAnswer(idx));
        list.appendChild(btn);
    });
}

async function submitAnswer(selected) {
    if (busy || gameFinished) return;
    busy = true;
    document.querySelectorAll(".option-card").forEach(b => b.disabled = true);
    document.querySelectorAll(".option-card").forEach((b, i) => {
        if (i === selected) b.classList.add("selected");
    });

    try {
        const result = await api("/answer", { selected });

        if (result.correct) soundCorrect();
        else soundWrong();

        if (result.message) {
            $("answerMessage").textContent = result.message;
            $("answerMessage").className = "message " + (result.correct ? "success" : "");
        }

        if (typeof result.score === "number") {
            $("myScore").textContent = result.score;
            const pct = Math.min(100, (result.score / 20) * 100);
            $("progressFill").style.width = pct + "%";
        }

        if (result.won) {
            soundWin();
            busy = false;
            currentQuestionLoaded = false;
            await refreshState();
            return;
        }

        currentQuestionLoaded = false;
        setTimeout(async () => {
            busy = false;
            if (!gameFinished) await loadQuestion();
        }, 900);
    } catch (e) {
        gameMessage(e.message);
        busy = false;
    }
}

function renderWinners(winners) {
    const list = $("winnersList");
    list.innerHTML = "";
    if (!winners || winners.length === 0) { list.textContent = "مسابقه تمام شد."; return; }
    winners.forEach((w, i) => {
        const row = document.createElement("div");
        row.className = "winner-row";
        const rank = document.createElement("span");
        rank.className = "winner-rank";
        rank.textContent = ["🥇", "🥈", "🥉"][i] || (i + 1);
        const name = document.createElement("span");
        name.textContent = typeof w === "string" ? w : w.name;
        row.appendChild(rank); row.appendChild(name);
        list.appendChild(row);
    });
}

async function refreshState(startNewTimer = false) {
    const data = await api("/state", null, "GET");

    if (data.phase === "over" || data.phase === "finished") {
        stopTimer();
        gameFinished = true;
        showScreen("resultScreen");
        renderWinners(data.winners || []);
        if (data.roster) renderScoreBoard("finalScoreList", data.roster);
        return;
    }

    if (data.phase === "play") {
        showScreen("gameScreen");
        $("currentPlayer").textContent = data.current;
        $("waitingPlayerName").textContent = data.current;
        $("myScore").textContent = data.score || 0;
        const pct = Math.min(100, ((data.score || 0) / 20) * 100);
        $("progressFill").style.width = pct + "%";

        if (data.awaiting_start) {
            stopTimer();
            currentOpened = false;
            awaitingStart = true;
            currentQuestionLoaded = false;
            busy = false;
            $("waitingStartArea").classList.remove("hidden");
            $("questionArea").classList.add("hidden");
            $("timer").textContent = "۲۰";
            return;
        }

        awaitingStart = false;
        $("waitingStartArea").classList.add("hidden");

        if (data.opened) {
            $("questionArea").classList.remove("hidden");
            if (startNewTimer || !currentOpened) {
                currentOpened = true;
                startTimer(data.remaining || 20);
            }
            await loadQuestion();
        } else {
            stopTimer();
            currentOpened = false;
            currentQuestionLoaded = false;
            $("questionArea").classList.add("hidden");
            $("timer").textContent = "۲۰";
        }
    }
}

document.addEventListener("DOMContentLoaded", async function () {
    try { await refreshState(); return; } catch (e) { console.log("بازی وجود ندارد."); }
    await prepareSetupScreen();
});