import os
import sys
import importlib.util


def start_server(game_dir):
    game_dir = os.path.abspath(game_dir)
    if game_dir not in sys.path:
        sys.path.insert(0, game_dir)
    os.chdir(game_dir)
    app_path = os.path.join(game_dir, "app.py")
    spec = importlib.util.spec_from_file_location("quiz_flask_app", app_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.app.run(host="127.0.0.1", port=5000, debug=False, threaded=True, use_reloader=False)
