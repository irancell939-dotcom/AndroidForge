package ir.khavaran.quiz;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import android.graphics.Color;
import android.content.res.AssetManager;
import android.content.Context;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private LinearLayout root;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService serverExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService probeExecutor = Executors.newSingleThreadExecutor();
    private boolean pageLoaded = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(13, 90, 67));
        getWindow().setNavigationBarColor(Color.rgb(13, 90, 67));
        buildLoadingView();
        try {
            copyAssetFolder(getAssets(), "game", new File(getFilesDir(), "game"));
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            serverExecutor.execute(() -> {
                try {
                    Python.getInstance().getModule("android_server")
                        .callAttr("start_server", new File(getFilesDir(), "game").getAbsolutePath());
                } catch (Exception e) {
                    handler.post(() -> status.setText("خطا در راه‌اندازی بازی: " + e.getMessage()));
                }
            });
            waitForServer(0);
        } catch (Exception e) {
            status.setText("خطا در آماده‌سازی برنامه: " + e.getMessage());
        }
    }

    private void buildLoadingView() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(245, 248, 246));
        status = new TextView(this);
        status.setText("در حال آماده‌سازی مسابقه دینی…");
        status.setTextColor(Color.rgb(13, 90, 67));
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void waitForServer(int attempt) {
        if (attempt > 40) {
            status.setText("راه‌اندازی سرور طول کشید. لطفاً برنامه را دوباره باز کنید.");
            return;
        }
        probeExecutor.execute(() -> {
            boolean ready = false;
            try {
                java.net.HttpURLConnection c = (java.net.HttpURLConnection)
                    new java.net.URL("http://127.0.0.1:5000/").openConnection();
                c.setConnectTimeout(500);
                c.setReadTimeout(500);
                c.setRequestMethod("GET");
                ready = c.getResponseCode() == 200;
                c.disconnect();
            } catch (Exception ignored) {}
            final boolean isReady = ready;
            handler.post(() -> {
                if (isReady) showGame();
                else handler.postDelayed(() -> waitForServer(attempt + 1), 500);
            });
        });
    }

    private void showGame() {
        if (pageLoaded) return;
        pageLoaded = true;
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("http://127.0.0.1:5000/");
    }

    private void copyAssetFolder(AssetManager assets, String assetPath, File dest) throws IOException {
        if (!dest.exists() && !dest.mkdirs()) throw new IOException("ساخت پوشه ناموفق بود");
        String[] files = assets.list(assetPath);
        if (files == null) return;
        for (String name : files) {
            String child = assetPath + "/" + name;
            String[] nested = assets.list(child);
            File out = new File(dest, name);
            if (nested != null && nested.length > 0) {
                copyAssetFolder(assets, child, out);
            } else {
                try (InputStream in = assets.open(child); FileOutputStream fos = new FileOutputStream(out)) {
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = in.read(buffer)) != -1) fos.write(buffer, 0, count);
                }
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        serverExecutor.shutdownNow();
        probeExecutor.shutdownNow();
        super.onDestroy();
    }
}
