خیاطی خاوران - نسخه ۲۸ - پروژه کامل Gradle برای AndroidForge

این بسته برخلاف بسته قبلی فقط سورس Flask نیست؛ ریشه ZIP شامل settings.gradle و build.gradle و پوشه app است تا دستور gradle assembleDebug در مسیر workspace پروژه را تشخیص دهد.

ویژگی‌ها:
- پروژه واقعی Android با Gradle و افزونه Chaquopy
- اجرای Flask داخل برنامه و نمایش در WebView محلی
- ذخیره دیتابیس در فضای خصوصی برنامه
- انتخاب فایل برای بازیابی پشتیبان
- ارسال چاپ WebView به سرویس چاپ اندروید
- آیکون جدید قیچی، نخ و سوزن با زمینه سرمه‌ای و طلایی
- حفظ قالب‌ها و اصلاحات چاپ نسخه ۲۷

ساخت: در ریشه همین پروژه اجرا شود: gradle assembleDebug
حداقل Android: 7.0 (API 24)
Python: 3.11 از طریق Chaquopy
