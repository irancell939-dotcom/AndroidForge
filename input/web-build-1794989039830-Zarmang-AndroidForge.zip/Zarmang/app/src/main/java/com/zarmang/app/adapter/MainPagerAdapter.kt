package com.zarmang.app.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.zarmang.app.data.ItemType
import com.zarmang.app.ui.ItemListFragment

class MainPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
    override fun getItemCount(): Int = 4

    override fun createFragment(position: Int): Fragment {
        val type = when (position) {
            0 -> ItemType.RECEIVABLE
            1 -> ItemType.DEBT
            2 -> ItemType.MY_INSTALLMENT
            else -> ItemType.THEIR_INSTALLMENT
        }
        return ItemListFragment.newInstance(type.value)
    }
}
