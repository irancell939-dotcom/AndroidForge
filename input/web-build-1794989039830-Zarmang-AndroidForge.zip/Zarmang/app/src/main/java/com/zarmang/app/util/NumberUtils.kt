package com.zarmang.app.util

object NumberUtils {

    fun formatWithComma(amount: Long): String {
        return "%,d".format(amount).replace(',', '٬')
    }

    fun toPersianDigits(input: String): String {
        val persian = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')
        val builder = StringBuilder()
        for (c in input) {
            if (c in '0'..'9') {
                builder.append(persian[c - '0'])
            } else {
                builder.append(c)
            }
        }
        return builder.toString()
    }

    fun fromPersianDigits(input: String): String {
        val map = mapOf(
            '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4',
            '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9'
        )
        return input.map { map[it] ?: it }.joinToString("")
    }

    fun amountToWords(amount: Long): String {
        if (amount == 0L) return "صفر تومان"
        val units = arrayOf("", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه")
        val teens = arrayOf("ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده")
        val tens = arrayOf("", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود")
        val hundreds = arrayOf("", "صد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد")
        val scales = arrayOf("", "هزار", "میلیون", "میلیارد", "تریلیون")

        fun convertLessThanThousand(n: Long): String {
            if (n == 0L) return ""
            val h = (n / 100).toInt()
            val t = ((n % 100) / 10).toInt()
            val u = (n % 10).toInt()
            val parts = mutableListOf<String>()
            if (h > 0) parts.add(hundreds[h])
            if (t == 1) {
                parts.add(teens[u])
            } else {
                if (t > 1) parts.add(tens[t])
                if (u > 0) parts.add(units[u])
            }
            return parts.joinToString(" و ")
        }

        var num = amount
        val parts = mutableListOf<String>()
        var scaleIndex = 0
        while (num > 0 && scaleIndex < scales.size) {
            val chunk = num % 1000
            if (chunk > 0) {
                val chunkWords = convertLessThanThousand(chunk)
                val scale = scales[scaleIndex]
                parts.add(0, if (scale.isEmpty()) chunkWords else "$chunkWords $scale")
            }
            num /= 1000
            scaleIndex++
        }
        return parts.joinToString(" و ") + " تومان"
    }
}
