package com.zarmang.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.zarmang.app.adapter.MainPagerAdapter
import com.zarmang.app.data.ItemType

class MainActivity : AppCompatActivity() {

    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout
    private lateinit var fabAdd: FloatingActionButton
    private lateinit var fabArchive: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewPager = findViewById(R.id.viewPager)
        tabLayout = findViewById(R.id.tabLayout)
        fabAdd = findViewById(R.id.fabAdd)
        fabArchive = findViewById(R.id.fabArchive)

        val adapter = MainPagerAdapter(this)
        viewPager.adapter = adapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            when (position) {
                0 -> {
                    tab.text = getString(R.string.tab_receivables)
                    tab.setIcon(R.drawable.ic_receivable)
                }
                1 -> {
                    tab.text = getString(R.string.tab_debts)
                    tab.setIcon(R.drawable.ic_debt)
                }
                2 -> {
                    tab.text = getString(R.string.tab_my_installments)
                    tab.setIcon(R.drawable.ic_installment)
                }
                3 -> {
                    tab.text = getString(R.string.tab_their_installments)
                    tab.setIcon(R.drawable.ic_their_installment)
                }
            }
        }.attach()

        fabAdd.setOnClickListener {
            val type = when (viewPager.currentItem) {
                0 -> ItemType.RECEIVABLE
                1 -> ItemType.DEBT
                2 -> ItemType.MY_INSTALLMENT
                else -> ItemType.THEIR_INSTALLMENT
            }
            val intent = Intent(this, AddEditItemActivity::class.java).apply {
                putExtra("type", type.value)
            }
            startActivity(intent)
        }

        fabArchive.setOnClickListener {
            startActivity(Intent(this, ArchiveActivity::class.java))
        }
    }
}
