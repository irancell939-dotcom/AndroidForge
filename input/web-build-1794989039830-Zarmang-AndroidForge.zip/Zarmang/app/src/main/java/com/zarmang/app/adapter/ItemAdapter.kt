package com.zarmang.app.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.zarmang.app.R
import com.zarmang.app.data.DebtItem
import com.zarmang.app.data.ItemType
import com.zarmang.app.util.DateUtils
import com.zarmang.app.util.NumberUtils

class ItemAdapter(
    private val onClick: (DebtItem) -> Unit
) : ListAdapter<DebtItem, ItemAdapter.ViewHolder>(DiffCallback()) {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val card: CardView = view.findViewById(R.id.card)
        val name: TextView = view.findViewById(R.id.tvName)
        val amount: TextView = view.findViewById(R.id.tvAmount)
        val remaining: TextView = view.findViewById(R.id.tvRemaining)
        val dueDate: TextView = view.findViewById(R.id.tvDueDate)
        val forWhat: TextView = view.findViewById(R.id.tvForWhat)
        val typeIndicator: View = view.findViewById(R.id.typeIndicator)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_debt, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.name.text = item.fullName
        holder.amount.text = NumberUtils.toPersianDigits(NumberUtils.formatWithComma(item.totalAmount)) + " تومان"
        holder.remaining.text = "باقیمانده: " + NumberUtils.toPersianDigits(NumberUtils.formatWithComma(item.remainingAmount))
        holder.dueDate.text = "سررسید: " + DateUtils.toPersianDisplay(item.dueDate)
        holder.forWhat.text = item.forWhat.ifEmpty { "—" }

        val colorRes = when (ItemType.fromValue(item.type)) {
            ItemType.RECEIVABLE -> R.color.receivable_color
            ItemType.DEBT -> R.color.debt_color
            ItemType.MY_INSTALLMENT -> R.color.installment_color
            ItemType.THEIR_INSTALLMENT -> R.color.their_installment_color
        }
        holder.typeIndicator.setBackgroundColor(ContextCompat.getColor(holder.itemView.context, colorRes))

        holder.card.setOnClickListener { onClick(item) }
    }

    class DiffCallback : DiffUtil.ItemCallback<DebtItem>() {
        override fun areItemsTheSame(old: DebtItem, new: DebtItem) = old.id == new.id
        override fun areContentsTheSame(old: DebtItem, new: DebtItem) = old == new
    }
}
