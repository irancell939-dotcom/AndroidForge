package com.zarmang.app.data

enum class ItemType(val value: Int, val titleRes: String) {
    RECEIVABLE(0, "طلب از دیگران"),
    DEBT(1, "بدهی به دیگران"),
    MY_INSTALLMENT(2, "قسط من"),
    THEIR_INSTALLMENT(3, "قسط دیگران");

    companion object {
        fun fromValue(value: Int): ItemType {
            return entries.find { it.value == value } ?: RECEIVABLE
        }
    }
}
