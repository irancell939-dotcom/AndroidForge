package com.zarmang.app

import android.app.DatePickerDialog
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.zarmang.app.data.AppDatabase
import com.zarmang.app.data.DebtItem
import com.zarmang.app.data.ItemType
import com.zarmang.app.util.DateUtils
import com.zarmang.app.util.NumberUtils
import kotlinx.coroutines.launch
import saman.zamani.persiandate.PersianDate

class AddEditItemActivity : AppCompatActivity() {

    private var itemId: Long = -1
    private var itemType: Int = 0
    private var photoUri: String? = null
    private lateinit var etName: EditText
    private lateinit var etPhone: EditText
    private lateinit var etAmount: EditText
    private lateinit var etForWhat: EditText
    private lateinit var etDescription: EditText
    private lateinit var tvDueDate: TextView
    private lateinit var tvAmountWords: TextView
    private lateinit var btnSave: Button
    private lateinit var btnSelectPhoto: Button
    private lateinit var ivPhoto: ImageView
    private var selectedDate: String = DateUtils.todayJalali()

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            photoUri = it.toString()
            ivPhoto.setImageURI(it)
            ivPhoto.visibility = ImageView.VISIBLE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_edit)

        itemType = intent.getIntExtra("type", 0)
        itemId = intent.getLongExtra("itemId", -1)

        etName = findViewById(R.id.etName)
        etPhone = findViewById(R.id.etPhone)
        etAmount = findViewById(R.id.etAmount)
        etForWhat = findViewById(R.id.etForWhat)
        etDescription = findViewById(R.id.etDescription)
        tvDueDate = findViewById(R.id.tvDueDate)
        tvAmountWords = findViewById(R.id.tvAmountWords)
        btnSave = findViewById(R.id.btnSave)
        btnSelectPhoto = findViewById(R.id.btnSelectPhoto)
        ivPhoto = findViewById(R.id.ivPhoto)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = if (itemId > 0) "ویرایش" else "افزودن ${ItemType.fromValue(itemType).titleRes}"

        tvDueDate.text = DateUtils.toPersianDisplay(selectedDate)
        tvDueDate.setOnClickListener { showPersianDatePicker() }

        etAmount.addTextChangedListener(object : TextWatcher {
            private var current = ""
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s.toString() != current) {
                    etAmount.removeTextChangedListener(this)
                    val clean = NumberUtils.fromPersianDigits(s.toString()).replace(Regex("[^\\d]"), "")
                    if (clean.isNotEmpty()) {
                        val num = clean.toLongOrNull() ?: 0L
                        val formatted = NumberUtils.toPersianDigits(NumberUtils.formatWithComma(num))
                        current = formatted
                        etAmount.setText(formatted)
                        etAmount.setSelection(formatted.length)
                        tvAmountWords.text = NumberUtils.amountToWords(num)
                    } else {
                        current = ""
                        tvAmountWords.text = ""
                    }
                    etAmount.addTextChangedListener(this)
                }
            }
        })

        btnSelectPhoto.setOnClickListener { pickImage.launch("image/*") }

        btnSave.setOnClickListener { saveItem() }

        if (itemId > 0) loadItem()
    }

    private fun showPersianDatePicker() {
        val pd = PersianDate()
        // Simple year/month/day picker using standard DatePicker for demo; in production use Persian picker
        val dialog = DatePickerDialog(this, { _, y, m, d ->
            // Convert approx or use PersianDate methods
            selectedDate = DateUtils.formatJalali(pd.shYear, m + 1, d)
            tvDueDate.text = DateUtils.toPersianDisplay(selectedDate)
        }, pd.grgYear, pd.grgMonth - 1, pd.grgDay)
        dialog.show()
        Toast.makeText(this, "تاریخ را انتخاب کنید (تقویم میلادی به شمسی تبدیل می‌شود)", Toast.LENGTH_SHORT).show()
    }

    private fun loadItem() {
        lifecycleScope.launch {
            val item = AppDatabase.getInstance(this@AddEditItemActivity).debtDao().getById(itemId)
            item?.let {
                etName.setText(it.fullName)
                etPhone.setText(it.phone)
                etAmount.setText(NumberUtils.toPersianDigits(NumberUtils.formatWithComma(it.totalAmount)))
                etForWhat.setText(it.forWhat)
                etDescription.setText(it.description)
                selectedDate = it.dueDate
                tvDueDate.text = DateUtils.toPersianDisplay(it.dueDate)
                tvAmountWords.text = NumberUtils.amountToWords(it.totalAmount)
                photoUri = it.photoPath
                // photo load omitted for brevity
            }
        }
    }

    private fun saveItem() {
        val name = etName.text.toString().trim()
        if (name.isEmpty()) {
            etName.error = "نام الزامی است"
            return
        }
        val cleanAmount = NumberUtils.fromPersianDigits(etAmount.text.toString()).replace(Regex("[^\\d]"), "")
        val amount = cleanAmount.toLongOrNull() ?: 0L
        if (amount <= 0) {
            etAmount.error = "مبلغ معتبر وارد کنید"
            return
        }

        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(this@AddEditItemActivity).debtDao()
            if (itemId > 0) {
                val existing = dao.getById(itemId) ?: return@launch
                val paid = existing.totalAmount - existing.remainingAmount
                val remaining = (amount - paid).coerceAtLeast(0)
                dao.update(
                    existing.copy(
                        fullName = name,
                        phone = etPhone.text.toString().trim(),
                        totalAmount = amount,
                        remainingAmount = remaining,
                        forWhat = etForWhat.text.toString().trim(),
                        description = etDescription.text.toString().trim(),
                        dueDate = selectedDate,
                        photoPath = photoUri,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            } else {
                dao.insert(
                    DebtItem(
                        fullName = name,
                        phone = etPhone.text.toString().trim(),
                        totalAmount = amount,
                        remainingAmount = amount,
                        forWhat = etForWhat.text.toString().trim(),
                        description = etDescription.text.toString().trim(),
                        dueDate = selectedDate,
                        photoPath = photoUri,
                        type = itemType
                    )
                )
            }
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
