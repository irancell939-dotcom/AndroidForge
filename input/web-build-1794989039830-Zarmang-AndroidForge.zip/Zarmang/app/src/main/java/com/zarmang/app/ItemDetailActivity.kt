package com.zarmang.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.zarmang.app.data.AppDatabase
import com.zarmang.app.data.ItemType
import com.zarmang.app.util.DateUtils
import com.zarmang.app.util.NumberUtils
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ItemDetailActivity : AppCompatActivity() {

    private var itemId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_detail)

        itemId = intent.getLongExtra("itemId", -1)
        if (itemId < 0) {
            finish()
            return
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "جزئیات"

        val tvName = findViewById<TextView>(R.id.tvName)
        val tvPhone = findViewById<TextView>(R.id.tvPhone)
        val tvAmount = findViewById<TextView>(R.id.tvAmount)
        val tvRemaining = findViewById<TextView>(R.id.tvRemaining)
        val tvDueDate = findViewById<TextView>(R.id.tvDueDate)
        val tvForWhat = findViewById<TextView>(R.id.tvForWhat)
        val tvDesc = findViewById<TextView>(R.id.tvDesc)
        val tvType = findViewById<TextView>(R.id.tvType)
        val btnPay = findViewById<Button>(R.id.btnPay)
        val btnEdit = findViewById<Button>(R.id.btnEdit)
        val btnDelete = findViewById<Button>(R.id.btnDelete)
        val btnArchive = findViewById<Button>(R.id.btnArchive)

        val dao = AppDatabase.getInstance(this).debtDao()

        lifecycleScope.launch {
            val item = dao.getById(itemId) ?: return@launch
            tvName.text = item.fullName
            tvPhone.text = item.phone.ifEmpty { "—" }
            tvAmount.text = NumberUtils.toPersianDigits(NumberUtils.formatWithComma(item.totalAmount)) + " تومان"
            tvRemaining.text = NumberUtils.toPersianDigits(NumberUtils.formatWithComma(item.remainingAmount)) + " تومان"
            tvDueDate.text = DateUtils.toPersianDisplay(item.dueDate)
            tvForWhat.text = item.forWhat.ifEmpty { "—" }
            tvDesc.text = item.description.ifEmpty { "—" }
            tvType.text = ItemType.fromValue(item.type).titleRes

            btnPay.setOnClickListener {
                startActivity(Intent(this@ItemDetailActivity, PaymentActivity::class.java).apply {
                    putExtra("itemId", itemId)
                })
            }
            btnEdit.setOnClickListener {
                startActivity(Intent(this@ItemDetailActivity, AddEditItemActivity::class.java).apply {
                    putExtra("itemId", itemId)
                    putExtra("type", item.type)
                })
            }
            btnDelete.setOnClickListener {
                AlertDialog.Builder(this@ItemDetailActivity)
                    .setTitle(R.string.confirm_delete)
                    .setPositiveButton(R.string.yes) { _, _ ->
                        lifecycleScope.launch {
                            dao.delete(item)
                            finish()
                        }
                    }
                    .setNegativeButton(R.string.no, null)
                    .show()
            }
            btnArchive.setOnClickListener {
                lifecycleScope.launch {
                    dao.archive(itemId)
                    Toast.makeText(this@ItemDetailActivity, "به بایگانی منتقل شد", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
