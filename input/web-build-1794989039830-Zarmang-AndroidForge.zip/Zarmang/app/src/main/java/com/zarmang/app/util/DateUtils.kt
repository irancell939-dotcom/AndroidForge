package com.zarmang.app.util

import saman.zamani.persiandate.PersianDate
import saman.zamani.persiandate.PersianDateFormat
import java.util.Calendar

object DateUtils {

    fun todayJalali(): String {
        val pd = PersianDate()
        return String.format("%04d/%02d/%02d", pd.shYear, pd.shMonth, pd.shDay)
    }

    fun formatJalali(year: Int, month: Int, day: Int): String {
        return String.format("%04d/%02d/%02d", year, month, day)
    }

    fun toPersianDisplay(jalali: String): String {
        return NumberUtils.toPersianDigits(jalali)
    }

    fun getCurrentPersianDate(): PersianDate {
        return PersianDate()
    }

    fun parseJalali(dateStr: String): Triple<Int, Int, Int>? {
        return try {
            val parts = dateStr.split("/")
            if (parts.size == 3) {
                Triple(parts[0].toInt(), parts[1].toInt(), parts[2].toInt())
            } else null
        } catch (e: Exception) {
            null
        }
    }
}
