package com.zarmang.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DebtDao {
    @Query("SELECT * FROM debt_items WHERE type = :type AND isArchived = 0 ORDER BY dueDate ASC")
    fun getActiveByType(type: Int): Flow<List<DebtItem>>

    @Query("SELECT * FROM debt_items WHERE isArchived = 1 ORDER BY updatedAt DESC")
    fun getArchived(): Flow<List<DebtItem>>

    @Query("SELECT * FROM debt_items WHERE id = :id")
    suspend fun getById(id: Long): DebtItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: DebtItem): Long

    @Update
    suspend fun update(item: DebtItem)

    @Delete
    suspend fun delete(item: DebtItem)

    @Query("UPDATE debt_items SET isArchived = 1, remainingAmount = 0, updatedAt = :time WHERE id = :id")
    suspend fun archive(id: Long, time: Long = System.currentTimeMillis())

    @Query("SELECT * FROM payments WHERE itemId = :itemId ORDER BY createdAt DESC")
    fun getPaymentsForItem(itemId: Long): Flow<List<Payment>>

    @Insert
    suspend fun insertPayment(payment: Payment): Long

    @Delete
    suspend fun deletePayment(payment: Payment)

    @Query("SELECT SUM(amount) FROM payments WHERE itemId = :itemId")
    suspend fun getTotalPaid(itemId: Long): Long?
}
