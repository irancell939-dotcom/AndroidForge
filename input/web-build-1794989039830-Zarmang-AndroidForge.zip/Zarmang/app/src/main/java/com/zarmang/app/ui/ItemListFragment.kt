package com.zarmang.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zarmang.app.ItemDetailActivity
import com.zarmang.app.R
import com.zarmang.app.adapter.ItemAdapter
import com.zarmang.app.data.AppDatabase
import com.zarmang.app.data.ItemType
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ItemListFragment : Fragment() {

    private var itemType: Int = 0
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyView: TextView
    private lateinit var adapter: ItemAdapter

    companion object {
        fun newInstance(type: Int): ItemListFragment {
            return ItemListFragment().apply {
                arguments = Bundle().apply { putInt("type", type) }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        itemType = arguments?.getInt("type") ?: 0
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_item_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView = view.findViewById(R.id.recyclerView)
        emptyView = view.findViewById(R.id.emptyView)

        adapter = ItemAdapter { item ->
            val intent = Intent(requireContext(), ItemDetailActivity::class.java).apply {
                putExtra("itemId", item.id)
            }
            startActivity(intent)
        }
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        val dao = AppDatabase.getInstance(requireContext()).debtDao()
        viewLifecycleOwner.lifecycleScope.launch {
            dao.getActiveByType(itemType).collectLatest { list ->
                adapter.submitList(list)
                emptyView.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }
}
