package com.zarmang.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "debt_items")
data class DebtItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fullName: String,
    val phone: String = "",
    val totalAmount: Long, // in Tomans
    val remainingAmount: Long,
    val forWhat: String = "",
    val description: String = "",
    val dueDate: String, // Jalali date as yyyy/MM/dd
    val photoPath: String? = null,
    val type: Int, // ItemType value
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
