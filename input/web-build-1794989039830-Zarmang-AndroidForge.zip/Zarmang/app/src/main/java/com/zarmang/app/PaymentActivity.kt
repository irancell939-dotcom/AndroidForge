package com.zarmang.app

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.zarmang.app.data.AppDatabase
import com.zarmang.app.data.Payment
import com.zarmang.app.util.DateUtils
import com.zarmang.app.util.NumberUtils
import kotlinx.coroutines.launch

class PaymentActivity : AppCompatActivity() {

    private var itemId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        itemId = intent.getLongExtra("itemId", -1)
        if (itemId < 0) { finish(); return }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "ثبت پرداخت / دریافت"

        val etAmount = findViewById<EditText>(R.id.etPayAmount)
        val tvWords = findViewById<TextView>(R.id.tvPayWords)
        val tvDate = findViewById<TextView>(R.id.tvPayDate)
        val btnConfirm = findViewById<Button>(R.id.btnConfirmPay)
        var selectedDate = DateUtils.todayJalali()
        tvDate.text = DateUtils.toPersianDisplay(selectedDate)

        etAmount.addTextChangedListener(object : TextWatcher {
            private var current = ""
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s.toString() != current) {
                    etAmount.removeTextChangedListener(this)
                    val clean = NumberUtils.fromPersianDigits(s.toString()).replace(Regex("[^\\d]"), "")
                    if (clean.isNotEmpty()) {
                        val num = clean.toLongOrNull() ?: 0L
                        val formatted = NumberUtils.toPersianDigits(NumberUtils.formatWithComma(num))
                        current = formatted
                        etAmount.setText(formatted)
                        etAmount.setSelection(formatted.length)
                        tvWords.text = NumberUtils.amountToWords(num)
                    } else {
                        current = ""
                        tvWords.text = ""
                    }
                    etAmount.addTextChangedListener(this)
                }
            }
        })

        btnConfirm.setOnClickListener {
            val clean = NumberUtils.fromPersianDigits(etAmount.text.toString()).replace(Regex("[^\\d]"), "")
            val amount = clean.toLongOrNull() ?: 0L
            if (amount <= 0) {
                etAmount.error = "مبلغ معتبر وارد کنید"
                return@setOnClickListener
            }
            lifecycleScope.launch {
                val dao = AppDatabase.getInstance(this@PaymentActivity).debtDao()
                val item = dao.getById(itemId) ?: return@launch
                val newRemaining = (item.remainingAmount - amount).coerceAtLeast(0)
                dao.insertPayment(Payment(itemId = itemId, amount = amount, paymentDate = selectedDate))
                dao.update(item.copy(remainingAmount = newRemaining, updatedAt = System.currentTimeMillis()))
                if (newRemaining == 0L) {
                    dao.archive(itemId)
                    Toast.makeText(this@PaymentActivity, "پرداخت کامل شد و به بایگانی منتقل شد", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@PaymentActivity, "پرداخت ثبت شد", Toast.LENGTH_SHORT).show()
                }
                finish()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
