# امداد خودرو زاهدان | Emdad Khodro Zahedan

اپلیکیشن مستقل اندروید مبتنی بر WebView برای سایت **https://Emdad054.ir**

## مشخصات

| مورد            | مقدار                          |
|-----------------|--------------------------------|
| نام برنامه      | امداد خودرو زاهدان             |
| Package Name    | `ir.emdad054.app`              |
| آدرس            | https://Emdad054.ir            |
| موتور           | Android System WebView         |
| حالت نمایش      | تمام‌صفحه (Fullscreen)         |
| دکمه برگشت      | پشتیبانی کامل از تاریخچه       |
| خطای اینترنت    | صفحه اختصاصی + دکمه تلاش مجدد  |
| حداقل اندروید   | Android 7.0 (API 24)           |
| Target SDK      | 34                             |

## ویژگی‌ها

- بارگذاری مستقیم سایت در WebView
- تمام‌صفحه (Immersive mode)
- مدیریت دکمه Back گوشی (بازگشت به صفحه قبل یا خروج)
- صفحه خطای زیبا هنگام قطع اینترنت با دکمه «تلاش مجدد»
- پشتیبانی از JavaScript، DOM Storage و کش
- سازگار با AndroidForge

## ساخت با AndroidForge

1. فایل ZIP این پروژه را در AndroidForge آپلود کنید.
2. Build را اجرا کنید.
3. APK را دانلود و نصب کنید.

## ساخت محلی با Android Studio

1. پروژه را در Android Studio باز کنید.
2. Sync Gradle.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).

## تغییر آدرس سایت

در فایل `MainActivity.java` مقدار ثابت `APP_URL` را تغییر دهید:

```java
private static final String APP_URL = "https://Emdad054.ir";
```
