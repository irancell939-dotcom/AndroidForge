package com.priceapp.calculator

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var etPrice: EditText
    private lateinit var etPercent: EditText
    private lateinit var btnCalculate: MaterialButton
    private lateinit var btnClear: MaterialButton
    private lateinit var cardResult: MaterialCardView
    private lateinit var tvNewPrice: TextView
    private lateinit var tvIncrease: TextView
    private lateinit var tvPriceWords: TextView
    private lateinit var tvNewPriceWords: TextView

    private var isFormatting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etPrice = findViewById(R.id.etPrice)
        etPercent = findViewById(R.id.etPercent)
        btnCalculate = findViewById(R.id.btnCalculate)
        btnClear = findViewById(R.id.btnClear)
        cardResult = findViewById(R.id.cardResult)
        tvNewPrice = findViewById(R.id.tvNewPrice)
        tvIncrease = findViewById(R.id.tvIncrease)
        tvPriceWords = findViewById(R.id.tvPriceWords)
        tvNewPriceWords = findViewById(R.id.tvNewPriceWords)

        setupPriceFormatter()

        btnCalculate.setOnClickListener {
            hideKeyboard()
            calculate()
        }
        btnClear.setOnClickListener { clearAll() }
    }

    private fun setupPriceFormatter() {
        etPrice.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                if (isFormatting) return
                isFormatting = true

                val clean = s.toString()
                    .replace(",", "")
                    .replace("٬", "")
                    .replace(" ", "")
                    .trim()

                if (clean.isEmpty()) {
                    tvPriceWords.text = ""
                    isFormatting = false
                    return
                }

                try {
                    val number = clean.toLong()
                    val formatted = NumberFormat.getNumberInstance(Locale.US).format(number)
                    // Use Persian thousand separator
                    val persianFormatted = formatted.replace(",", "٬")

                    etPrice.setText(persianFormatted)
                    etPrice.setSelection(persianFormatted.length)

                    tvPriceWords.text = numberToPersianWords(number) + " تومان"
                } catch (e: Exception) {
                    tvPriceWords.text = ""
                }

                isFormatting = false
            }
        })
    }

    private fun calculate() {
        val priceText = etPrice.text.toString()
            .replace("٬", "")
            .replace(",", "")
            .replace(" ", "")
            .trim()
        val percentText = etPercent.text.toString().trim()

        if (priceText.isEmpty() || percentText.isEmpty()) {
            Toast.makeText(this, getString(R.string.empty_fields), Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val price = priceText.toDouble()
            val percent = percentText.toDouble()

            if (price < 0 || percent < 0) {
                Toast.makeText(this, getString(R.string.negative_not_allowed), Toast.LENGTH_SHORT).show()
                return
            }

            val increaseAmount = price * (percent / 100.0)
            val newPrice = price + increaseAmount

            val formatter = NumberFormat.getNumberInstance(Locale("fa", "IR"))
            formatter.maximumFractionDigits = 0

            tvNewPrice.text = formatter.format(newPrice)
            tvIncrease.text = "+ ${formatter.format(increaseAmount)}"

            // Words for new price
            val newPriceLong = newPrice.toLong()
            tvNewPriceWords.text = numberToPersianWords(newPriceLong) + " تومان"

            cardResult.visibility = View.VISIBLE
            cardResult.alpha = 0f
            cardResult.animate().alpha(1f).setDuration(280).start()

        } catch (e: NumberFormatException) {
            Toast.makeText(this, getString(R.string.invalid_number), Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearAll() {
        etPrice.text.clear()
        etPercent.text.clear()
        tvPriceWords.text = ""
        tvNewPriceWords.text = ""
        cardResult.visibility = View.GONE
        etPrice.requestFocus()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        currentFocus?.let {
            imm.hideSoftInputFromWindow(it.windowToken, 0)
        }
    }

    // ---------- تبدیل عدد به حروف فارسی ----------
    private fun numberToPersianWords(number: Long): String {
        if (number == 0L) return "صفر"

        val ones = arrayOf(
            "", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه",
            "ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده",
            "شانزده", "هفده", "هجده", "نوزده"
        )
        val tens = arrayOf(
            "", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود"
        )
        val hundreds = arrayOf(
            "", "صد", "دویست", "سیصد", "چهارصد", "پانصد",
            "ششصد", "هفتصد", "هشتصد", "نهصد"
        )
        val scales = arrayOf("", "هزار", "میلیون", "میلیارد", "تریلیون")

        fun threeDigitsToWords(n: Int): String {
            val result = mutableListOf<String>()
            val h = n / 100
            val t = (n % 100) / 10
            val o = n % 10

            if (h > 0) result.add(hundreds[h])

            if (t == 1) {
                result.add(ones[10 + o])
            } else {
                if (t > 1) result.add(tens[t])
                if (o > 0) result.add(ones[o])
            }
            return result.joinToString(" و ")
        }

        if (number < 0) return "منفی " + numberToPersianWords(-number)

        val parts = mutableListOf<String>()
        var num = number
        var scaleIndex = 0

        while (num > 0) {
            val chunk = (num % 1000).toInt()
            if (chunk != 0) {
                val words = threeDigitsToWords(chunk)
                val scale = scales[scaleIndex]
                parts.add(0, if (scale.isEmpty()) words else "$words $scale")
            }
            num /= 1000
            scaleIndex++
        }

        return parts.joinToString(" و ")
    }
}
