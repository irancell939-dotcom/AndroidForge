# Optional AndroidForge bridge: import this module and call stop() on full exit.
def stop():
    import main
    main.stop_server()
