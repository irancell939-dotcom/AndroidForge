# AndroidForge / Chaquopy entry point
import os
from pathlib import Path

_private = os.environ.get("ANDROID_PRIVATE") or os.environ.get("HOME") or str(Path.cwd())
_data = Path(_private) / "khavaran_data"
_data.mkdir(parents=True, exist_ok=True)
os.environ["KHAYATI_DATA_DIR"] = str(_data)
os.environ["HOST"] = "127.0.0.1"
os.environ["PORT"] = "5000"

from werkzeug.serving import make_server
from app import app
import threading

_server = None
_thread = None

def start_server():
    global _server, _thread
    if _server is not None:
        return
    _server = make_server("127.0.0.1", 5000, app, threaded=True)
    _thread = threading.Thread(target=_server.serve_forever, daemon=True)
    _thread.start()

def stop_server():
    global _server, _thread
    if _server is not None:
        _server.shutdown()
        _server.server_close()
        _server = None
        _thread = None

start_server()
