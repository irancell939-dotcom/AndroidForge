package ir.khavaran.khayati;

import android.app.*;
import android.content.*;
import android.os.*;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class KhavaranService extends Service {
    private static final String CHANNEL = "khavaran_server";
    @Override public void onCreate() {
        super.onCreate();
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        createChannel();
        Notification n = new Notification.Builder(this, CHANNEL)
            .setContentTitle("خاوران سافت فعال است")
            .setContentText("سرویس برنامه برای ادامه کار و چاپ فعال می‌ماند")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setOngoing(true).build();
        startForeground(41, n);
        new Thread(() -> {
            try {
                Python.getInstance().getModule("main").callAttr("start_server");
            } catch (Exception e) { android.util.Log.e("Khavaran", "Python server start failed", e); }
        }).start();
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "سرویس خاوران", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }
    @Override public void onDestroy() {
        try { Python.getInstance().getModule("server_control").callAttr("stop_server"); } catch(Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
