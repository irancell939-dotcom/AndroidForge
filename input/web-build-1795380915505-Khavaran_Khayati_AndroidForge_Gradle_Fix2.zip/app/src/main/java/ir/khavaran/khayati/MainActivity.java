package ir.khavaran.khayati;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.print.*;
import android.webkit.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9);
        Intent s = new Intent(this, KhavaranService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void printPage() { runOnUiThread(() -> printWebView()); }
        }, "KhavaranNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u=r.getUrl();
                if ("binaryeye".equals(u.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,u)); }
                    catch(Exception e) { Toast.makeText(MainActivity.this,"ابتدا Binary Eye را نصب کنید",Toast.LENGTH_LONG).show(); }
                    return true;
                }
                if ("http".equals(u.getScheme()) || "https".equals(u.getScheme())) {
                    if ("127.0.0.1".equals(u.getHost())) return false;
                    try { startActivity(new Intent(Intent.ACTION_VIEW,u)); } catch(Exception ignored) {}
                    return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("window.print=function(){if(window.KhavaranNative){window.KhavaranNative.printPage();}};", null);
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadUrl("http://127.0.0.1:5000");
    }
    private void printWebView() {
        if (Build.VERSION.SDK_INT >= 19) {
            PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
            PrintDocumentAdapter adapter=web.createPrintDocumentAdapter("Khavaran");
            pm.print("چاپ خاوران",adapter,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A5).build());
        }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
