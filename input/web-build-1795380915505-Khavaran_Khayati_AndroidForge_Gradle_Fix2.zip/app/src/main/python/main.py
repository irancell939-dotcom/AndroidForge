import os, threading
from pathlib import Path
_private = os.environ.get("ANDROID_PRIVATE") or os.environ.get("HOME") or str(Path.cwd())
_data = Path(_private) / "khavaran_data"
_data.mkdir(parents=True, exist_ok=True)
os.environ["KHAYATI_DATA_DIR"] = str(_data)
os.environ["HOST"] = "127.0.0.1"
os.environ["PORT"] = "5000"
os.environ["KHAVARAN_ANDROID"] = "1"
from werkzeug.serving import make_server
from app import app
_server = None
_thread = None
_lock = threading.RLock()
def start_server():
    global _server, _thread
    with _lock:
        if _server is not None: return
        _server = make_server("127.0.0.1", 5000, app, threaded=True)
        _thread = threading.Thread(target=_server.serve_forever, name="KhavaranFlask", daemon=True)
        _thread.start()
def stop_server():
    global _server, _thread
    with _lock:
        server = _server
        _server = None
        _thread = None
    if server:
        server.shutdown()
        server.server_close()
start_server()
