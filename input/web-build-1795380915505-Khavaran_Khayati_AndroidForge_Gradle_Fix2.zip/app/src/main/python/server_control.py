def stop_server():
    import main
    main.stop_server()
