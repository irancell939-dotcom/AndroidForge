خاوران سافت – پروژه کامل Gradle برای AndroidForge

این بسته اکنون ریشه واقعی Gradle دارد:
- settings.gradle و build.gradle در ریشه
- app/build.gradle با Android Gradle Plugin 8.7.3 و Chaquopy 16.0.0
- minSdk 24 و Python 3.11
- سورس Flask آخرین نسخه، قالب‌ها و static
- سرویس foreground برای حفظ اجرای سرور در پس‌زمینه
- بازکردن Binary Eye از طریق binaryeye://
- اتصال window.print به Android PrintManager
- آیکون لانچر پیراهن بلوچی مردانه

در AndroidForge کل ZIP را به عنوان پروژه Gradle وارد کنید؛ پوشه ریشه‌ای که باز می‌شود باید settings.gradle و build.gradle را نشان دهد. سپس assembleDebug را اجرا کنید.
توجه: ساخت محلی این بسته در محیط فعلی بدون دریافت وابستگی‌های Android/Gradle انجام نشده است؛ موفقیت نهایی Build باید در AndroidForge تأیید شود. Android ممکن است اجرای سرویس دائمی را تحت محدودیت‌های سیستم‌عامل مدیریت کند.
