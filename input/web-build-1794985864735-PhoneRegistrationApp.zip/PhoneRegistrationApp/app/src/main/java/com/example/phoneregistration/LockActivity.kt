package com.example.phoneregistration

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.util.concurrent.Executor

class LockActivity : AppCompatActivity() {

    private lateinit var prefs: android.content.SharedPreferences

    private fun isMasterCode(code: String): Boolean {
        val digits = code.filter { it.isDigit() }
        return digits.length == 15 && digits.endsWith("10246600")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)
        when (prefs.getString("app_theme", "dark")) {
            "green" -> setTheme(R.style.Theme_PhoneRegistrationApp_Green)
            "purple" -> setTheme(R.style.Theme_PhoneRegistrationApp_Purple)
            "dark" -> setTheme(R.style.Theme_PhoneRegistrationApp_Dark)
            else -> setTheme(R.style.Theme_PhoneRegistrationApp)
        }
        super.onCreate(savedInstanceState)

        val pin = prefs.getString("app_pin", null)
        if (pin.isNullOrBlank()) {
            startMain()
            return
        }

        setContentView(R.layout.activity_lock)

        val etPin = findViewById<TextInputEditText>(R.id.etPin)
        val btnUnlock = findViewById<MaterialButton>(R.id.btnUnlock)
        val btnBiometric = findViewById<MaterialButton>(R.id.btnBiometric)
        val tvError = findViewById<TextView>(R.id.tvError)
        val tvForgot = findViewById<TextView>(R.id.tvForgot)

        btnUnlock.setOnClickListener {
            val entered = etPin.text?.toString().orEmpty()
            if (entered == pin) {
                startMain()
            } else {
                tvError.visibility = View.VISIBLE
                tvError.text = "رمز اشتباه است"
                etPin.text?.clear()
            }
        }

        val biometricEnabled = prefs.getBoolean("biometric_unlock", true)
        val canAuth = BiometricManager.from(this).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        ) == BiometricManager.BIOMETRIC_SUCCESS

        if (biometricEnabled && canAuth) {
            btnBiometric.visibility = View.VISIBLE
            btnBiometric.text = "باز کردن با اثر انگشت / الگو"
            btnBiometric.setOnClickListener { authenticateUnlockOnly() }
        } else {
            btnBiometric.visibility = View.GONE
        }

        // Recovery: master code only — no biometric recovery
        tvForgot.setOnClickListener { showMasterCodeDialog() }
    }

    private fun authenticateUnlockOnly() {
        val executor: Executor = ContextCompat.getMainExecutor(this)
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("ورود به دفترچه تلفن خاوران")
            .setSubtitle("با اثر انگشت یا الگو / رمز گوشی وارد شوید")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                startMain()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                    errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                    Toast.makeText(this@LockActivity, errString, Toast.LENGTH_SHORT).show()
                }
            }
        }).authenticate(promptInfo)
    }

    private fun showMasterCodeDialog() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "کد بازیابی"
            setPadding(48, 36, 48, 36)
            setTextColor(0xFF1A237E.toInt())
            setHintTextColor(0xFF90A4AE.toInt())
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("بازیابی رمز")
            .setMessage("کد بازیابی را وارد کنید.")
            .setView(box)
            .setPositiveButton("تأیید") { _, _ ->
                val code = input.text?.toString().orEmpty()
                if (isMasterCode(code)) {
                    startActivity(Intent(this, ChangePinActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "کد بازیابی نامعتبر است", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun startMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
