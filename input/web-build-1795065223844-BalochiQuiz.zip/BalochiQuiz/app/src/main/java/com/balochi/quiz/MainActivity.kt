package com.balochi.quiz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.screens.AppNavigation
import com.balochi.quiz.ui.theme.BalochiQuizTheme
import com.balochi.quiz.ui.theme.getThemeColors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: QuizViewModel = viewModel()
            val theme by androidx.compose.runtime.remember { androidx.compose.runtime.derivedStateOf { viewModel.currentTheme } }
            BalochiQuizTheme(appTheme = viewModel.currentTheme) {
                val colors = getThemeColors(viewModel.currentTheme)
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = colors.background
                ) {
                    AppNavigation(viewModel = viewModel)
                }
            }
        }
    }
}
