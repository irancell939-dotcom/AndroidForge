package com.balochi.quiz.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

@Composable
fun BalochiQuizTheme(
    appTheme: AppTheme = AppTheme.WARM_DARK,
    content: @Composable () -> Unit
) {
    val colors = getThemeColors(appTheme)
    val isLight = appTheme == AppTheme.WHITE

    val colorScheme = if (isLight) {
        lightColorScheme(
            primary = colors.accent,
            onPrimary = colors.background,
            secondary = Sage,
            onSecondary = colors.background,
            tertiary = colors.accent,
            background = colors.background,
            onBackground = colors.textPrimary,
            surface = colors.surface,
            onSurface = colors.textPrimary,
            surfaceVariant = colors.card,
            onSurfaceVariant = colors.textSecondary,
            error = WrongRed,
            onError = colors.textPrimary
        )
    } else {
        darkColorScheme(
            primary = colors.accent,
            onPrimary = colors.background,
            secondary = Sage,
            onSecondary = colors.background,
            tertiary = colors.accent,
            background = colors.background,
            onBackground = colors.textPrimary,
            surface = colors.surface,
            onSurface = colors.textPrimary,
            surfaceVariant = colors.card,
            onSurfaceVariant = colors.textSecondary,
            error = WrongRed,
            onError = colors.textPrimary
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colors.background.toArgb()
            window.navigationBarColor = colors.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = isLight
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
