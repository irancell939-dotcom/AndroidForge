package com.balochi.quiz.ui.theme

import androidx.compose.ui.graphics.Color

// Brand accent (kept across themes)
val SaffronGold = Color(0xFFE2A45A)
val Sage = Color(0xFF8EAE86)
val CorrectGreen = Color(0xFF66BB6A)
val WrongRed = Color(0xFFEF5350)

// --- Theme definitions ---
enum class AppTheme(val displayName: String) {
    WARM_DARK("تیره گرم"),
    BLACK("مشکی"),
    BLUE("آبی تیره"),
    WHITE("روشن")
}

data class ThemeColors(
    val background: Color,
    val surface: Color,
    val card: Color,
    val cardLight: Color,
    val chip: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val border: Color,
    val accent: Color
)

val WarmDarkColors = ThemeColors(
    background = Color(0xFF14110E),
    surface = Color(0xFF1C1814),
    card = Color(0xFF2A241E),
    cardLight = Color(0xFF332C25),
    chip = Color(0xFF3A322A),
    textPrimary = Color(0xFFF8F1E3),
    textSecondary = Color(0xFFC9B8A4),
    textMuted = Color(0xFF9A8B78),
    border = Color(0xFF4A4036),
    accent = SaffronGold
)

val BlackColors = ThemeColors(
    background = Color(0xFF0A0A0A),
    surface = Color(0xFF121212),
    card = Color(0xFF1E1E1E),
    cardLight = Color(0xFF2A2A2A),
    chip = Color(0xFF333333),
    textPrimary = Color(0xFFF5F5F5),
    textSecondary = Color(0xFFB0B0B0),
    textMuted = Color(0xFF808080),
    border = Color(0xFF3A3A3A),
    accent = Color(0xFFFFB74D)
)

val BlueColors = ThemeColors(
    background = Color(0xFF0D1B2A),
    surface = Color(0xFF1B263B),
    card = Color(0xFF243B55),
    cardLight = Color(0xFF2E4A66),
    chip = Color(0xFF3A5A7A),
    textPrimary = Color(0xFFE0E6ED),
    textSecondary = Color(0xFFA8B8C8),
    textMuted = Color(0xFF7A8A9A),
    border = Color(0xFF3D5A73),
    accent = Color(0xFF4FC3F7)
)

val WhiteColors = ThemeColors(
    background = Color(0xFFF8F6F2),
    surface = Color(0xFFFFFFFF),
    card = Color(0xFFFFFFFF),
    cardLight = Color(0xFFF0EDE8),
    chip = Color(0xFFE8E4DE),
    textPrimary = Color(0xFF1A1612),
    textSecondary = Color(0xFF5A5248),
    textMuted = Color(0xFF8A8070),
    border = Color(0xFFD0C8BC),
    accent = Color(0xFFC47B2A)
)

fun getThemeColors(theme: AppTheme): ThemeColors = when (theme) {
    AppTheme.WARM_DARK -> WarmDarkColors
    AppTheme.BLACK -> BlackColors
    AppTheme.BLUE -> BlueColors
    AppTheme.WHITE -> WhiteColors
}

// Backward-compatible aliases (used in existing code until fully migrated)
val WarmNightParchment get() = WarmDarkColors.background
val Cream get() = WarmDarkColors.textPrimary
val DarkSurface get() = WarmDarkColors.surface
val CardBackground get() = WarmDarkColors.card
val CardBackgroundLight get() = WarmDarkColors.cardLight
val ChipBackground get() = WarmDarkColors.chip
val TextPrimary get() = WarmDarkColors.textPrimary
val TextSecondary get() = WarmDarkColors.textSecondary
val TextMuted get() = WarmDarkColors.textMuted
val BorderSubtle get() = WarmDarkColors.border
val OptionSelected get() = SaffronGold.copy(alpha = 0.22f)
