package com.balochi.quiz.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.balochi.quiz.data.BalochiWord
import com.balochi.quiz.data.QuizViewModel

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Quiz : Screen("quiz")
    data object AddWord : Screen("add_word")
    data object WordList : Screen("word_list")
    data object Settings : Screen("settings")
    data object Sentences : Screen("sentences")
}

@Composable
fun AppNavigation(viewModel: QuizViewModel) {
    val navController = rememberNavController()
    var editingWord by remember { mutableStateOf<BalochiWord?>(null) }

    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = viewModel,
                onStartQuiz = {
                    viewModel.startQuiz()
                    navController.navigate(Screen.Quiz.route)
                },
                onAddWord = {
                    editingWord = null
                    navController.navigate(Screen.AddWord.route)
                },
                onWordList = { navController.navigate(Screen.WordList.route) },
                onSentences = { navController.navigate(Screen.Sentences.route) },
                onSettings = { navController.navigate(Screen.Settings.route) }
            )
        }
        composable(Screen.Quiz.route) {
            QuizScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onFinish = { navController.popBackStack(Screen.Home.route, inclusive = false) }
            )
        }
        composable(Screen.AddWord.route) {
            AddWordScreen(
                viewModel = viewModel,
                existingWord = editingWord,
                onBack = {
                    editingWord = null
                    navController.popBackStack()
                }
            )
        }
        composable(Screen.WordList.route) {
            WordListScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onEdit = { word ->
                    editingWord = word
                    navController.navigate(Screen.AddWord.route)
                }
            )
        }
        composable(Screen.Sentences.route) {
            SentencesScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Settings.route) {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
