package com.balochi.quiz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.QuizLanguage
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.ui.theme.*

@Composable
fun HomeScreen(
    viewModel: QuizViewModel,
    onStartQuiz: () -> Unit,
    onAddWord: () -> Unit,
    onWordList: () -> Unit,
    onSentences: () -> Unit,
    onSettings: () -> Unit
) {
    val colors = getThemeColors(viewModel.currentTheme)
    val scroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // هدر ثابت
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "لغت بلوچی",
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.accent
                )
                Text(
                    text = "آزمون هوشمند چندزبانه",
                    fontSize = 13.sp,
                    color = colors.textSecondary
                )
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Settings, "تنظیمات", tint = colors.textSecondary, modifier = Modifier.size(26.dp))
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scroll)
                .padding(horizontal = 18.dp)
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))

            // پیشرفت کلی
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(colors.card)
                    .border(1.dp, colors.border, RoundedCornerShape(16.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ProgressItem("سطح", "${viewModel.progress.level}", colors)
                ProgressItem("آزمون‌ها", "${viewModel.progress.totalQuizzes}", colors)
                ProgressItem("درست", "${viewModel.progress.totalCorrect}", colors)
            }

            Spacer(Modifier.height(10.dp))

            // پیشرفت هر زبان
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(colors.card)
                    .border(1.dp, colors.border, RoundedCornerShape(16.dp))
                    .padding(12.dp)
            ) {
                Text(
                    "پیشرفت زبان‌ها",
                    color = colors.textPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                QuizLanguage.entries.forEach { lang ->
                    val p = viewModel.langProgress[lang.code]
                    val correct = p?.correct ?: 0
                    val answered = p?.answered ?: 0
                    val pct = if (answered > 0) (correct * 100 / answered) else 0
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(lang.displayName, color = colors.textSecondary, fontSize = 13.sp, modifier = Modifier.width(72.dp))
                        Text("$correct/$answered", color = colors.textPrimary, fontSize = 13.sp, modifier = Modifier.width(56.dp))
                        Text("$pct%", color = colors.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // انتخاب دو زبان
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(colors.card)
                    .border(1.dp, colors.border, RoundedCornerShape(18.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = "زبان‌های آزمون",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
                Text("زبان اول", fontSize = 12.sp, color = colors.textMuted, modifier = Modifier.padding(bottom = 6.dp))
                LanguageRow(
                    selected = viewModel.langA,
                    other = viewModel.langB,
                    colors = colors,
                    onSelect = { viewModel.setLanguages(it, viewModel.langB) }
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text("زبان دوم", fontSize = 12.sp, color = colors.textMuted, modifier = Modifier.padding(bottom = 6.dp))
                LanguageRow(
                    selected = viewModel.langB,
                    other = viewModel.langA,
                    colors = colors,
                    onSelect = { viewModel.setLanguages(viewModel.langA, it) }
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            MainButton(
                text = "شروع آزمون تصادفی",
                icon = Icons.Default.PlayArrow,
                colors = colors,
                onClick = onStartQuiz,
                enabled = viewModel.words.any {
                    it.hasMeaning(viewModel.langA) && it.hasMeaning(viewModel.langB)
                }
            )

            Spacer(modifier = Modifier.height(11.dp))
            OutlinedMainButton("افزودن کلمه", Icons.Default.Add, colors, onAddWord)
            Spacer(modifier = Modifier.height(11.dp))
            OutlinedMainButton("لیست کلمات (${viewModel.words.size})", Icons.Default.List, colors, onWordList)
            Spacer(modifier = Modifier.height(11.dp))
            OutlinedMainButton("جملات کوتاه (۳۰۰+)", Icons.Default.List, colors, onSentences)

            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "برنامه‌نویس: محمدعمر خاوران\n۰۹۱۵۹۴۹۹۹۲۸",
                fontSize = 13.sp,
                color = colors.textMuted,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
        }
    }
}

@Composable
private fun ProgressItem(label: String, value: String, colors: ThemeColors) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = colors.accent)
        Text(text = label, fontSize = 12.sp, color = colors.textSecondary)
    }
}

@Composable
private fun LanguageRow(
    selected: QuizLanguage,
    other: QuizLanguage,
    colors: ThemeColors,
    onSelect: (QuizLanguage) -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        QuizLanguage.entries.forEach { lang ->
            val isSelected = selected == lang
            val isDisabled = other == lang
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        when {
                            isSelected -> colors.accent
                            isDisabled -> colors.chip.copy(alpha = 0.4f)
                            else -> colors.chip
                        }
                    )
                    .clickable(enabled = !isDisabled) { onSelect(lang) }
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = lang.displayName,
                    color = when {
                        isSelected -> colors.background
                        isDisabled -> colors.textMuted
                        else -> colors.textPrimary
                    },
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun MainButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    colors: ThemeColors,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(56.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = colors.accent,
            contentColor = colors.background,
            disabledContainerColor = colors.card,
            disabledContentColor = colors.textMuted
        )
    ) {
        Icon(icon, null, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun OutlinedMainButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    colors: ThemeColors,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = colors.textPrimary),
        border = ButtonDefaults.outlinedButtonBorder.copy(
            width = 1.5.dp,
            brush = androidx.compose.ui.graphics.SolidColor(colors.border)
        )
    ) {
        Icon(icon, null, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}
