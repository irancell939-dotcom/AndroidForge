package com.balochi.quiz.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.balochi.quiz.data.SettingsRepository
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        NotificationHelper.showReminder(context)
        // برنامه‌ریزی مجدد همه نوبت‌ها
        ReminderScheduler.schedule(context)
    }
}

object ReminderScheduler {
    private const val BASE_REQ = 4401

    fun schedule(context: Context) {
        val settings = SettingsRepository(context).getReminder()
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        // لغو همه هشدارهای قبلی (حداکثر ۸ نوبت)
        for (i in 0 until 8) {
            am.cancel(pendingIntent(context, i))
        }

        if (!settings.enabled || settings.days.isEmpty()) return

        val times = settings.effectiveTimes().take(8)
        val now = Calendar.getInstance()

        times.forEachIndexed { index, t ->
            val target = nextOccurrence(now, t.hour, t.minute, settings.days) ?: return@forEachIndexed
            val pi = pendingIntent(context, index)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pi)
            } else {
                am.set(AlarmManager.RTC_WAKEUP, target.timeInMillis, pi)
            }
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0 until 8) {
            am.cancel(pendingIntent(context, i))
        }
    }

    private fun nextOccurrence(now: Calendar, hour: Int, minute: Int, days: List<Int>): Calendar? {
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        for (i in 0..8) {
            val candidate = start.clone() as Calendar
            candidate.add(Calendar.DAY_OF_YEAR, i)
            val day = candidate.get(Calendar.DAY_OF_WEEK)
            if (days.contains(day) && candidate.after(now)) {
                return candidate
            }
        }
        return null
    }

    private fun pendingIntent(context: Context, index: Int): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, BASE_REQ + index, intent, flags)
    }
}
