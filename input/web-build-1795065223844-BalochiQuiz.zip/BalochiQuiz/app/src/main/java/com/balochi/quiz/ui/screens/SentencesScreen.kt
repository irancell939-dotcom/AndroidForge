package com.balochi.quiz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.data.Sentence
import com.balochi.quiz.data.SentenceRepository
import com.balochi.quiz.ui.theme.*

@Composable
fun SentencesScreen(
    viewModel: QuizViewModel,
    onBack: () -> Unit
) {
    val colors = getThemeColors(viewModel.currentTheme)
    val context = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { SentenceRepository(context) }
    val all = remember { repo.getAll() }
    var query by remember { mutableStateOf("") }

    val filtered = remember(query, all) {
        if (query.isBlank()) all
        else {
            val q = query.trim()
            all.filter {
                it.english.contains(q, true) || it.persian.contains(q, true) ||
                    it.arabic.contains(q, true) || it.urdu.contains(q, true) ||
                    it.genderNote.contains(q, true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت", tint = colors.textPrimary)
            }
            Text(
                "جملات کوتاه (${filtered.size})",
                color = colors.textPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // نکته جنسیت
        Text(
            text = "توجه: در عربی (و گاهی اردو) شکل فعل برای مذکر و مؤنث فرق دارد. هر جا لازم باشد در کارت جمله توضیح داده شده است.",
            color = colors.textSecondary,
            fontSize = 12.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp),
            placeholder = { Text("جستجو در جملات...", color = colors.textMuted) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = colors.textMuted) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Clear, null, tint = colors.textMuted)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.accent,
                unfocusedBorderColor = colors.border,
                focusedTextColor = colors.textPrimary,
                unfocusedTextColor = colors.textPrimary,
                cursorColor = colors.accent,
                focusedContainerColor = colors.card,
                unfocusedContainerColor = colors.card
            )
        )

        LazyColumn(
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered, key = { it.id }) { sentence ->
                SentenceCard(sentence, colors)
            }
        }
    }
}

@Composable
private fun SentenceCard(sentence: Sentence, colors: ThemeColors) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.card)
            .border(1.dp, colors.border, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        if (sentence.english.isNotBlank()) {
            Text(sentence.english, color = colors.accent, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
        }
        if (sentence.persian.isNotBlank())
            Text("FA: ${sentence.persian}", color = colors.textPrimary, fontSize = 15.sp)
        if (sentence.arabic.isNotBlank())
            Text("AR: ${sentence.arabic}", color = colors.textPrimary, fontSize = 15.sp)
        if (sentence.urdu.isNotBlank())
            Text("UR: ${sentence.urdu}", color = colors.textPrimary, fontSize = 15.sp)
        if (sentence.balochi.isNotBlank())
            Text("BL: ${sentence.balochi}", color = colors.textPrimary, fontSize = 15.sp)
        if (sentence.genderNote.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(
                "⚖ ${sentence.genderNote}",
                color = Sage,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }
    }
}
