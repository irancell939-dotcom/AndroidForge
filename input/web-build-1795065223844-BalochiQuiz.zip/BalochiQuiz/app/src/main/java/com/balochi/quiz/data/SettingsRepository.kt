package com.balochi.quiz.data

import android.content.Context
import com.balochi.quiz.ui.theme.AppTheme
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("balochi_settings", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getTheme(): AppTheme {
        val name = prefs.getString("theme", AppTheme.WARM_DARK.name) ?: AppTheme.WARM_DARK.name
        return try { AppTheme.valueOf(name) } catch (_: Exception) { AppTheme.WARM_DARK }
    }

    fun setTheme(theme: AppTheme) {
        prefs.edit().putString("theme", theme.name).apply()
    }

    fun getLangA(): QuizLanguage {
        val code = prefs.getString("langA", QuizLanguage.ENGLISH.code) ?: QuizLanguage.ENGLISH.code
        return QuizLanguage.fromCode(code)
    }

    fun getLangB(): QuizLanguage {
        val code = prefs.getString("langB", QuizLanguage.PERSIAN.code) ?: QuizLanguage.PERSIAN.code
        return QuizLanguage.fromCode(code)
    }

    fun setLanguages(a: QuizLanguage, b: QuizLanguage) {
        prefs.edit().putString("langA", a.code).putString("langB", b.code).apply()
    }

    // صدا
    fun isSoundMuted(): Boolean = prefs.getBoolean("sound_muted", false)
    fun setSoundMuted(muted: Boolean) = prefs.edit().putBoolean("sound_muted", muted).apply()

    fun getSoundType(): Int = prefs.getInt("sound_type", 1) // پیش‌فرض: تأیید (0 کلاسیک، 1 تأیید، 2 ساده)
    fun setSoundType(type: Int) = prefs.edit().putInt("sound_type", type.coerceIn(0, 2)).apply()

    // اعلان یادآوری (چند نوبت در روز)
    data class ReminderTime(val hour: Int = 20, val minute: Int = 0)

    data class ReminderSettings(
        val enabled: Boolean = false,
        val hour: Int = 20, // سازگاری با نسخه‌های قبل
        val minute: Int = 0,
        val times: List<ReminderTime> = listOf(ReminderTime(20, 0)),
        val days: List<Int> = listOf(1, 2, 3, 4, 5, 6, 7)
    ) {
        fun effectiveTimes(): List<ReminderTime> {
            return if (times.isNotEmpty()) times.distinctBy { it.hour * 60 + it.minute }.sortedBy { it.hour * 60 + it.minute }
            else listOf(ReminderTime(hour, minute))
        }
    }

    fun getReminder(): ReminderSettings {
        val json = prefs.getString("reminder", null) ?: return ReminderSettings()
        return try {
            gson.fromJson(json, ReminderSettings::class.java) ?: ReminderSettings()
        } catch (_: Exception) {
            ReminderSettings()
        }
    }

    fun setReminder(r: ReminderSettings) {
        prefs.edit().putString("reminder", gson.toJson(r)).apply()
    }

    // پیشرفت هر زبان
    data class LangProgress(val correct: Int = 0, val answered: Int = 0)

    fun getLangProgress(): Map<String, LangProgress> {
        val json = prefs.getString("lang_progress", null) ?: return emptyMap()
        return try {
            val type = object : TypeToken<Map<String, LangProgress>>() {}.type
            gson.fromJson(json, type) ?: emptyMap()
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun recordLangAnswer(langCode: String, isCorrect: Boolean) {
        val map = getLangProgress().toMutableMap()
        val cur = map[langCode] ?: LangProgress()
        map[langCode] = LangProgress(
            correct = cur.correct + if (isCorrect) 1 else 0,
            answered = cur.answered + 1
        )
        prefs.edit().putString("lang_progress", gson.toJson(map)).apply()
    }

    fun resetLangProgress() {
        prefs.edit().remove("lang_progress").apply()
    }
}
