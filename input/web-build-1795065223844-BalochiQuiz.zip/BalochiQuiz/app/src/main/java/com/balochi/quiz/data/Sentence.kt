package com.balochi.quiz.data

/**
 * جمله کوتاه چندزبانه
 * genderNote: توضیح تفاوت فعل زنانه/مردانه در صورت نیاز
 */
data class Sentence(
    val id: String = java.util.UUID.randomUUID().toString(),
    val english: String = "",
    val persian: String = "",
    val arabic: String = "",
    val urdu: String = "",
    val balochi: String = "",
    val genderNote: String = "" // مثال: «رفت (مذکر) / رفتت (مؤنث)»
) {
    fun getText(lang: QuizLanguage): String = when (lang) {
        QuizLanguage.BALOCHI -> balochi
        QuizLanguage.PERSIAN -> persian
        QuizLanguage.ENGLISH -> english
        QuizLanguage.ARABIC -> arabic
        QuizLanguage.URDU -> urdu
    }

    fun hasText(lang: QuizLanguage): Boolean = getText(lang).isNotBlank()
}
