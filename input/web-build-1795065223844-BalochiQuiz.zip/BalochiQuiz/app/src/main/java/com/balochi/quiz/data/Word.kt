package com.balochi.quiz.data

/**
 * مدل کلمه با پشتیبانی کامل چندزبانه + آمار پیشرفت
 */
data class BalochiWord(
    val id: String = java.util.UUID.randomUUID().toString(),
    val balochi: String = "",
    val persian: String = "",
    val english: String = "",
    val arabic: String = "",
    val urdu: String = "",
    val example: String = "",
    // آمار یادگیری (برای تکرار فاصله‌دار)
    val correctCount: Int = 0,
    val wrongCount: Int = 0,
    val lastSeen: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun getMeaning(lang: QuizLanguage): String = when (lang) {
        QuizLanguage.BALOCHI -> balochi
        QuizLanguage.PERSIAN -> persian
        QuizLanguage.ENGLISH -> english
        QuizLanguage.ARABIC -> arabic
        QuizLanguage.URDU -> urdu
    }

    fun hasMeaning(lang: QuizLanguage): Boolean = getMeaning(lang).isNotBlank()

    fun hasAnyMeaning(): Boolean =
        balochi.isNotBlank() || persian.isNotBlank() ||
                english.isNotBlank() || arabic.isNotBlank() || urdu.isNotBlank()

    /** اولویت بالاتر = بیشتر اشتباه خورده یا مدت‌ها ندیده شده */
    fun priorityScore(): Float {
        val total = correctCount + wrongCount
        if (total == 0) return 1.5f
        val errorRate = wrongCount.toFloat() / (total + 0.5f)
        val daysSince = if (lastSeen == 0L) 14f else {
            ((System.currentTimeMillis() - lastSeen) / (1000f * 60 * 60 * 24)).coerceAtLeast(0f)
        }
        val recencyBoost = (daysSince / 3f).coerceIn(0.4f, 3.5f)
        // کلمات اشتباه‌خورده اولویت خیلی بالاتر دارند
        return errorRate * 5f + recencyBoost + (wrongCount * 0.4f)
    }
}

enum class QuizLanguage(val displayName: String, val code: String) {
    BALOCHI("بلوچی", "bal"),
    PERSIAN("فارسی", "fa"),
    ENGLISH("English", "en"),
    ARABIC("العربية", "ar"),
    URDU("اردو", "ur");

    companion object {
        fun fromCode(code: String): QuizLanguage =
            entries.find { it.code == code } ?: PERSIAN
    }
}
