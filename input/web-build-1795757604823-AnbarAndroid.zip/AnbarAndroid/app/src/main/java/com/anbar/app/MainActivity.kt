package com.anbar.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    companion object {
        private const val REQ_FILE = 1001
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.setSupportZoom(false)
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain", "*/*"))
                }
                try {
                    startActivityForResult(Intent.createChooser(intent, "انتخاب فایل پشتیبان"), REQ_FILE)
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback = null
                    return false
                }
                return true
            }
        }
        webView.addJavascriptInterface(AnbarBridge(), "AnbarAndroid")
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            val result = if (resultCode == Activity.RESULT_OK && data != null) {
                WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            } else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    inner class AnbarBridge {
        private fun anbarDir(): File {
            val docs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            val dir = File(docs, "ANBAR")
            if (!dir.exists()) dir.mkdirs()
            if (dir.exists() && dir.canWrite()) return dir
            val alt = File(getExternalFilesDir(null), "ANBAR")
            if (!alt.exists()) alt.mkdirs()
            return alt
        }

        @JavascriptInterface
        fun saveBackup(json: String): String {
            return try {
                val dir = anbarDir()
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val file = File(dir, "anbar_backup_$stamp.json")
                file.writeText(json, Charsets.UTF_8)
                JSONObject()
                    .put("ok", true)
                    .put("path", file.absolutePath)
                    .put("name", file.name)
                    .toString()
            } catch (e: Exception) {
                JSONObject().put("ok", false).put("error", e.message ?: "error").toString()
            }
        }

        @JavascriptInterface
        fun listBackups(): String {
            return try {
                val dir = anbarDir()
                val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".json") }
                    ?.sortedByDescending { it.lastModified() }
                    ?.take(30)
                    ?: emptyList()
                val arr = org.json.JSONArray()
                files.forEach { f ->
                    arr.put(
                        JSONObject()
                            .put("name", f.name)
                            .put("path", f.absolutePath)
                            .put("size", f.length())
                    )
                }
                JSONObject().put("ok", true).put("files", arr).put("dir", dir.absolutePath).toString()
            } catch (e: Exception) {
                JSONObject().put("ok", false).put("error", e.message ?: "error").toString()
            }
        }

        @JavascriptInterface
        fun readBackup(path: String): String {
            return try {
                val file = File(path)
                val dir = anbarDir()
                if (!file.canonicalPath.startsWith(dir.canonicalPath)) {
                    return JSONObject().put("ok", false).put("error", "مسیر نامعتبر").toString()
                }
                val text = file.readText(Charsets.UTF_8)
                JSONObject().put("ok", true).put("data", text).toString()
            } catch (e: Exception) {
                JSONObject().put("ok", false).put("error", e.message ?: "error").toString()
            }
        }

        @JavascriptInterface
        fun getAnbarPath(): String {
            return try {
                anbarDir().absolutePath
            } catch (e: Exception) {
                ""
            }
        }

        @JavascriptInterface
        fun openSms(phone: String, body: String): String {
            return try {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("smsto:" + phone)
                    putExtra("sms_body", body)
                }
                startActivity(intent)
                JSONObject().put("ok", true).toString()
            } catch (e: Exception) {
                try {
                    val intent2 = Intent(Intent.ACTION_VIEW).apply {
                        data = Uri.parse("sms:" + phone + "?body=" + Uri.encode(body))
                    }
                    startActivity(intent2)
                    JSONObject().put("ok", true).toString()
                } catch (e2: Exception) {
                    JSONObject().put("ok", false).put("error", e2.message ?: "sms error").toString()
                }
            }
        }

    }
}
