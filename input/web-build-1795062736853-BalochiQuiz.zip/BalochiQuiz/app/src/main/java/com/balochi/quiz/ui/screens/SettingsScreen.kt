package com.balochi.quiz.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.balochi.quiz.data.QuizViewModel
import com.balochi.quiz.data.SettingsRepository
import com.balochi.quiz.ui.theme.*
import com.balochi.quiz.util.ReminderScheduler
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.Calendar

@Composable
fun SettingsScreen(
    viewModel: QuizViewModel,
    onBack: () -> Unit
) {
    val colors = getThemeColors(viewModel.currentTheme)
    val context = LocalContext.current
    var showResetDialog by remember { mutableStateOf(false) }
    var lastBackupPath by remember { mutableStateOf<String?>(null) }
    var hour by remember { mutableStateOf(viewModel.reminder.hour) }
    var minute by remember { mutableStateOf(viewModel.reminder.minute) }
    var days by remember { mutableStateOf(viewModel.reminder.days.toSet()) }

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val json = BufferedReader(InputStreamReader(input)).readText()
                val ok = viewModel.importBackupFromJson(json)
                Toast.makeText(
                    context,
                    if (ok) "بازیابی با موفقیت انجام شد" else "فایل پشتیبان نامعتبر است",
                    Toast.LENGTH_LONG
                ).show()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در خواندن فایل", Toast.LENGTH_LONG).show()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(context, "برای اعلان باید اجازه بدهید", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت", tint = colors.textPrimary)
            }
            Text("تنظیمات", color = colors.textPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            // تم
            SectionTitle("تم برنامه", colors)
            AppTheme.entries.forEach { theme ->
                val isSelected = viewModel.currentTheme == theme
                val themeColors = getThemeColors(theme)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) colors.cardLight else colors.card)
                        .border(if (isSelected) 2.dp else 1.dp, if (isSelected) colors.accent else colors.border, RoundedCornerShape(14.dp))
                        .clickable { viewModel.setTheme(theme) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(themeColors.background)
                            .border(1.dp, themeColors.border, RoundedCornerShape(8.dp))
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(theme.displayName, color = colors.textPrimary, fontSize = 15.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                    Spacer(Modifier.weight(1f))
                    if (isSelected) Text("✓", color = colors.accent, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(20.dp))

            // صدا
            SectionTitle("صدای آزمون", colors)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.card)
                    .border(1.dp, colors.border, RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("بی‌صدا کردن", color = colors.textPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Switch(
                    checked = viewModel.soundMuted,
                    onCheckedChange = { viewModel.updateSoundMuted(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = colors.accent)
                )
            }
            Spacer(Modifier.height(10.dp))
            Text("نوع صدا", color = colors.textSecondary, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("کلاسیک", "تأیید", "ساده").forEachIndexed { i, label ->
                    val sel = viewModel.soundType == i
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (sel) colors.accent else colors.card)
                            .border(1.dp, if (sel) colors.accent else colors.border, RoundedCornerShape(12.dp))
                            .clickable { viewModel.updateSoundType(i) }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, color = if (sel) colors.background else colors.textPrimary, fontSize = 13.sp,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            // یادآوری
            SectionTitle("یادآوری روزانه آزمون", colors)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.card)
                    .border(1.dp, colors.border, RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("فعال کردن اعلان", color = colors.textPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Switch(
                    checked = viewModel.reminder.enabled,
                    onCheckedChange = { enabled ->
                        if (enabled && Build.VERSION.SDK_INT >= 33) {
                            val granted = ContextCompat.checkSelfPermission(
                                context, Manifest.permission.POST_NOTIFICATIONS
                            ) == PackageManager.PERMISSION_GRANTED
                            if (!granted) {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        }
                        val r = viewModel.reminder.copy(enabled = enabled, hour = hour, minute = minute, days = days.toList())
                        viewModel.updateReminder(r)
                        if (enabled) ReminderScheduler.schedule(context) else ReminderScheduler.cancel(context)
                    },
                    colors = SwitchDefaults.colors(checkedTrackColor = colors.accent)
                )
            }
            Spacer(Modifier.height(10.dp))
            Text("ساعت: ${"%02d".format(hour)}:${"%02d".format(minute)}", color = colors.textPrimary, fontSize = 15.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ساعت", color = colors.textSecondary, fontSize = 13.sp, modifier = Modifier.width(48.dp))
                Slider(
                    value = hour.toFloat(),
                    onValueChange = { hour = it.toInt() },
                    valueRange = 0f..23f,
                    steps = 22,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = colors.accent, activeTrackColor = colors.accent)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("دقیقه", color = colors.textSecondary, fontSize = 13.sp, modifier = Modifier.width(48.dp))
                Slider(
                    value = minute.toFloat(),
                    onValueChange = { minute = (it.toInt() / 5) * 5 },
                    valueRange = 0f..55f,
                    steps = 10,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = colors.accent, activeTrackColor = colors.accent)
                )
            }
            Text("روزهای هفته", color = colors.textSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 6.dp))
            // Calendar: 1=Sun ... 7=Sat — نمایش فارسی
            val dayLabels = listOf(
                7 to "ش", 1 to "ی", 2 to "د", 3 to "س", 4 to "چ", 5 to "پ", 6 to "ج"
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                dayLabels.forEach { (day, label) ->
                    val sel = days.contains(day)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (sel) colors.accent else colors.card)
                            .border(1.dp, if (sel) colors.accent else colors.border, RoundedCornerShape(10.dp))
                            .clickable {
                                days = if (sel) days - day else days + day
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, color = if (sel) colors.background else colors.textPrimary,
                            fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            SettingsButton("ذخیره زمان یادآوری", colors) {
                val r = SettingsRepository.ReminderSettings(
                    enabled = viewModel.reminder.enabled,
                    hour = hour,
                    minute = minute,
                    days = days.toList()
                )
                viewModel.updateReminder(r)
                if (r.enabled) ReminderScheduler.schedule(context) else ReminderScheduler.cancel(context)
                Toast.makeText(context, "یادآوری ذخیره شد", Toast.LENGTH_SHORT).show()
            }

            Spacer(Modifier.height(20.dp))

            // پشتیبان
            SectionTitle("پشتیبان‌گیری و بازیابی", colors)
            SettingsButton("ذخیره پشتیبان", colors) {
                val path = viewModel.exportBackup()
                lastBackupPath = path
                Toast.makeText(context, if (path != null) "پشتیبان ذخیره شد" else "خطا", Toast.LENGTH_SHORT).show()
            }
            Spacer(Modifier.height(8.dp))
            SettingsButton("ارسال پشتیبان به گوشی دیگر", colors) {
                val path = lastBackupPath ?: viewModel.exportBackup()
                if (path == null) {
                    Toast.makeText(context, "ابتدا پشتیبان بسازید", Toast.LENGTH_SHORT).show()
                    return@SettingsButton
                }
                try {
                    val file = File(path)
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                    val share = Intent(Intent.ACTION_SEND).apply {
                        type = "application/json"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(share, "ارسال پشتیبان"))
                } catch (e: Exception) {
                    Toast.makeText(context, "خطا در ارسال", Toast.LENGTH_SHORT).show()
                }
            }
            Spacer(Modifier.height(8.dp))
            SettingsButton("بازیابی با انتخاب فایل", colors) {
                openDocumentLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
            }
            Spacer(Modifier.height(8.dp))
            SettingsButton("بازیابی آخرین پشتیبان داخلی", colors) {
                val ok = viewModel.importBackup()
                Toast.makeText(context, if (ok) "بازیابی شد" else "پیدا نشد", Toast.LENGTH_SHORT).show()
            }

            Spacer(Modifier.height(20.dp))
            SectionTitle("پیشرفت", colors)
            SettingsButton("صفر کردن پیشرفت", colors, isDanger = true) { showResetDialog = true }

            Spacer(Modifier.height(20.dp))
            SectionTitle("درباره", colors)
            Text(
                "لغت بلوچی\nبرنامه‌نویس: محمدعمر خاوران\n۰۹۱۵۹۴۹۹۹۲۸",
                color = colors.textSecondary, fontSize = 14.sp, lineHeight = 22.sp
            )
            Spacer(Modifier.height(36.dp))
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("صفر کردن پیشرفت؟", fontWeight = FontWeight.Bold) },
            text = { Text("آمار همه زبان‌ها و سطح پاک می‌شود. کلمات حذف نمی‌شوند.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.resetProgress()
                        showResetDialog = false
                        Toast.makeText(context, "پیشرفت صفر شد", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = WrongRed)
                ) { Text("بله، صفر کن", fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("انصراف") }
            },
            containerColor = colors.card,
            titleContentColor = colors.textPrimary,
            textContentColor = colors.textSecondary
        )
    }
}

@Composable
private fun SectionTitle(text: String, colors: ThemeColors) {
    Text(text, color = colors.textPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
private fun SettingsButton(text: String, colors: ThemeColors, isDanger: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.card)
            .border(1.dp, if (isDanger) WrongRed.copy(alpha = 0.5f) else colors.border, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (isDanger) WrongRed else colors.textPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}
