package com.example.phoneregistration

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {

    private lateinit var rvHistory: RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var btnClear: MaterialButton
    private lateinit var prefs: SharedPreferences
    private val records = mutableListOf<CallRecord>()
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        val prefs = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)
        when (prefs.getString("app_theme", "blue")) {
            "green" -> setTheme(R.style.Theme_PhoneRegistrationApp_Green)
            "purple" -> setTheme(R.style.Theme_PhoneRegistrationApp_Purple)
            "dark" -> setTheme(R.style.Theme_PhoneRegistrationApp_Dark)
            else -> setTheme(R.style.Theme_PhoneRegistrationApp)
        }
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.call_history)

        rvHistory = findViewById(R.id.rvHistory)
        tvEmpty = findViewById(R.id.tvEmptyHistory)
        btnClear = findViewById(R.id.btnClearHistory)
        prefs = getSharedPreferences("phone_reg_v2", Context.MODE_PRIVATE)

        adapter = HistoryAdapter(records)
        rvHistory.layoutManager = LinearLayoutManager(this)
        rvHistory.adapter = adapter

        loadHistory()
        updateEmpty()

        btnClear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.clear_history)
                .setMessage("تمام سابقه تماس پاک شود؟")
                .setPositiveButton(R.string.delete) { _, _ ->
                    prefs.edit().putString("call_history", "[]").apply()
                    records.clear()
                    adapter.notifyDataSetChanged()
                    updateEmpty()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun loadHistory() {
        records.clear()
        val json = prefs.getString("call_history", "[]") ?: "[]"
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                records.add(
                    CallRecord(
                        obj.getString("id"),
                        obj.getString("name"),
                        obj.getString("phone"),
                        obj.getLong("timestamp")
                    )
                )
            }
        } catch (_: Exception) {}
        adapter.notifyDataSetChanged()
    }

    private fun updateEmpty() {
        if (records.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            rvHistory.visibility = View.GONE
            btnClear.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            rvHistory.visibility = View.VISIBLE
            btnClear.visibility = View.VISIBLE
        }
    }
}

class HistoryAdapter(private val items: List<CallRecord>) :
    RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    private val dateFormat = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale("fa"))

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvHistName)
        val tvPhone: TextView = view.findViewById(R.id.tvHistPhone)
        val tvTime: TextView = view.findViewById(R.id.tvHistTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvName.text = item.name
        holder.tvPhone.text = item.phone
        holder.tvTime.text = dateFormat.format(Date(item.timestamp))
    }

    override fun getItemCount(): Int = items.size
}
