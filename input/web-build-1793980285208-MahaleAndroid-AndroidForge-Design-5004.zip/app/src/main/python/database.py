# database.py
from flask_sqlalchemy import SQLAlchemy
import jdatetime
from datetime import date

db = SQLAlchemy()

class Kooche(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)

class Khane(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    kooche_id = db.Column(db.Integer, db.ForeignKey('kooche.id'), nullable=False)
    kooche = db.relationship('Kooche', backref=db.backref('khaneha', lazy=True))
    line = db.Column(db.String(20), nullable=False)
    owner_name = db.Column(db.String(100), nullable=False)
    number = db.Column(db.Integer, nullable=False)

class Saknin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    khane_id = db.Column(db.Integer, db.ForeignKey('khane.id'), nullable=False)
    khane = db.relationship('Khane', backref=db.backref('saknin', lazy=True))
    name = db.Column(db.String(50), nullable=False)
    family = db.Column(db.String(50), nullable=False)
    father_name = db.Column(db.String(50))
    birth_date = db.Column(db.String(10))
    mobile = db.Column(db.String(15))
    education = db.Column(db.String(50))
    tashkil = db.Column(db.String(100))
    address = db.Column(db.String(200))
    last_meeting = db.Column(db.String(10))
    notes = db.Column(db.Text)

    @property
    def age(self):
        if not self.birth_date:
            return None
        try:
            jdate = jdatetime.datetime.strptime(self.birth_date, "%Y/%m/%d")
            gregorian = jdate.togregorian().date()
            today = date.today()
            return today.year - gregorian.year - ((today.month, today.day) < (gregorian.month, gregorian.day))
        except:
            return None

class Jamaat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    start_date = db.Column(db.String(10), nullable=False)
    duration_days = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), default='reserved')
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())

class JamaatMember(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    jamaat_id = db.Column(db.Integer, db.ForeignKey('jamaat.id'), nullable=False)
    saknin_id = db.Column(db.Integer, db.ForeignKey('saknin.id'), nullable=False)
    status = db.Column(db.String(20), default='joined')
    jamaat = db.relationship('Jamaat', backref=db.backref('members', lazy=True))
    saknin = db.relationship('Saknin', backref=db.backref('jamaat_memberships', lazy=True))

class Karmand(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    family = db.Column(db.String(50), nullable=False)
    tashkil_duration = db.Column(db.String(20))
    mobile = db.Column(db.String(15))
    status = db.Column(db.String(10), default='فعال')
# در انتهای database.py
class Taqaza(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)  # عنوان تقاضا
    description = db.Column(db.Text)  # توضیحات
    week_start = db.Column(db.String(10), nullable=False)  # شروع هفته (شمسی: 1404/07/01)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())


class AppUser(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default='user')
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())

class MessageTemplate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    body = db.Column(db.Text, nullable=False)
    channel = db.Column(db.String(20), default='both')
