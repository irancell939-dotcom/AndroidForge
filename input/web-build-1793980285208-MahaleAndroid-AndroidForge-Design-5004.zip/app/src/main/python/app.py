# app.py
import os
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from database import db, Kooche, Khane, Saknin, Jamaat, JamaatMember, Karmand, Taqaza, AppUser, MessageTemplate
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import jdatetime
from collections import Counter
from datetime import timedelta
import random

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SECRET_KEY'] = 'mahale-sheikhein-private-session-key-2026'
db_path = os.environ.get('MAHALE_DB_PATH', os.path.join(basedir, 'instance', 'mahalle.db'))
os.makedirs(os.path.dirname(db_path), exist_ok=True)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_path
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

_tables_created = False

@app.before_request
def create_tables_once():
    global _tables_created
    if not _tables_created:
        os.makedirs(os.path.join(basedir, 'instance'), exist_ok=True)
        db.create_all()
        # حساب مدیر اولیه فقط در اولین اجرا ساخته می‌شود.
        if not AppUser.query.filter_by(username='admin').first():
            db.session.add(AppUser(username='admin', password_hash=generate_password_hash('739184'), role='admin', active=True))
            db.session.commit()
        if MessageTemplate.query.count() == 0:
            db.session.add_all([
                MessageTemplate(title='اطلاع‌رسانی عمومی', body='سلام {name} عزیز،‌\nاز طرف مسجد شیخین (رض) پیام داریم: ', channel='both'),
                MessageTemplate(title='دعوت به مسجد', body='السلام علیکم {name} عزیز. شما را به برنامه‌های مسجد شیخین (رض) دعوت می‌کنیم. حضور شما موجب خوشحالی است.', channel='both'),
                MessageTemplate(title='یادآوری ملاقات', body='سلام {name} عزیز. جهت هماهنگی ملاقات با شما پیام می‌دهیم. لطفاً زمان مناسب را اطلاع دهید.', channel='both')
            ])
            db.session.commit()
        _tables_created = True

# ---------- Authentication ----------
def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login', next=request.path))
        return view(*args, **kwargs)
    return wrapped

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login'))
        user = db.session.get(AppUser, session['user_id'])
        if not user or user.role != 'admin':
            abort(403)
        return view(*args, **kwargs)
    return wrapped

@app.before_request
def require_login():
    if request.endpoint not in ('login', 'static') and not session.get('user_id'):
        return redirect(url_for('login', next=request.path))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = AppUser.query.filter_by(username=username, active=True).first()
        if user and check_password_hash(user.password_hash, password):
            session.clear(); session['user_id'] = user.id; session['username'] = user.username; session['role'] = user.role
            return redirect(request.args.get('next') or url_for('index'))
        flash('نام کاربری یا رمز عبور اشتباه است.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/users', methods=['GET', 'POST'])
@admin_required
def users():
    if request.method == 'POST':
        username=request.form.get('username','').strip(); password=request.form.get('password',''); role=request.form.get('role','user')
        if not username or len(password) < 6:
            flash('نام کاربری لازم است و رمز باید حداقل ۶ رقم/حرف باشد.', 'danger')
        elif AppUser.query.filter_by(username=username).first():
            flash('این نام کاربری قبلاً ثبت شده است.', 'danger')
        else:
            db.session.add(AppUser(username=username, password_hash=generate_password_hash(password), role='admin' if role=='admin' else 'user', active=True)); db.session.commit()
            flash('کاربر جدید ساخته شد.', 'success')
        return redirect(url_for('users'))
    return render_template('users.html', users=AppUser.query.order_by(AppUser.id).all())

@app.route('/users/toggle/<int:user_id>', methods=['POST'])
@admin_required
def toggle_user(user_id):
    user=AppUser.query.get_or_404(user_id)
    if user.username == 'admin':
        flash('مدیر اصلی قابل غیرفعال‌سازی نیست.', 'warning')
    else:
        user.active=not user.active; db.session.commit(); flash('وضعیت کاربر تغییر کرد.', 'success')
    return redirect(url_for('users'))

@app.route('/message-templates', methods=['GET','POST'])
@admin_required
def message_templates():
    if request.method == 'POST':
        title=request.form.get('title','').strip(); body=request.form.get('body','').strip(); channel=request.form.get('channel','both')
        if title and body:
            db.session.add(MessageTemplate(title=title, body=body, channel=channel)); db.session.commit(); flash('متن پیش‌فرض ذخیره شد.', 'success')
        else: flash('عنوان و متن پیام الزامی است.', 'danger')
        return redirect(url_for('message_templates'))
    return render_template('message_templates.html', templates=MessageTemplate.query.order_by(MessageTemplate.id.desc()).all())

@app.route('/message-templates/delete/<int:template_id>', methods=['POST'])
@admin_required
def delete_message_template(template_id):
    item=MessageTemplate.query.get_or_404(template_id); db.session.delete(item); db.session.commit(); flash('متن حذف شد.', 'info'); return redirect(url_for('message_templates'))

@app.route('/message/<int:saknin_id>', methods=['GET','POST'])
def send_message(saknin_id):
    person=Saknin.query.get_or_404(saknin_id)
    templates=MessageTemplate.query.order_by(MessageTemplate.id).all()
    selected=request.form.get('template_id', type=int) if request.method=='POST' else (templates[0].id if templates else None)
    chosen=MessageTemplate.query.get(selected) if selected else None
    body=request.form.get('body') if request.method=='POST' else (chosen.body if chosen else 'سلام {name} عزیز، ')
    body=(body or '').replace('{name}', person.name + ' ' + person.family).replace('{family}', person.family)
    phone=to_international(person.mobile or '')
    from urllib.parse import quote
    return render_template('message.html', person=person, templates=templates, selected=selected, body=body, phone=phone, sms_url='sms:'+quote(person.mobile or '')+'?body='+quote(body), wa_url='https://wa.me/'+phone+'?text='+quote(body))

# ---------- Jinja Filter for International Phone ----------
@app.template_filter('to_international')
def to_international(phone):
    if not phone:
        return ''
    clean = phone.replace(' ', '').replace('-', '').replace('+', '')
    if clean.startswith('0'):
        return '98' + clean[1:]
    elif clean.startswith('98'):
        return clean
    else:
        return clean

# ---------- Routes ----------

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/koocheha', methods=['GET', 'POST'])
def koocheha():
    if request.method == 'POST':
        name = request.form['name'].strip()
        if name and not Kooche.query.filter_by(name=name).first():
            kooche = Kooche(name=name)
            db.session.add(kooche)
            db.session.commit()
            flash('کوچه با موفقیت اضافه شد.', 'success')
        else:
            flash('نام کوچه تکراری است یا خالی است.', 'danger')
        return redirect(url_for('koocheha'))
    
    koocheha_list = Kooche.query.all()
    return render_template('koocheha.html', koocheha=koocheha_list)

@app.route('/khaneha', methods=['GET', 'POST'])
def khaneha():
    kooche_id_filter = request.args.get('kooche_id', type=int)

    if request.method == 'POST':
        kooche_id = request.form.get('kooche_id')
        line = request.form.get('line')
        owner = request.form.get('owner').strip()

        if not (kooche_id and line and owner):
            flash('لطفاً همه فیلدها را پر کنید.', 'danger')
            return redirect(url_for('khaneha'))

        last_khane = Khane.query.filter_by(kooche_id=kooche_id, line=line).order_by(Khane.number.desc()).first()
        new_number = (last_khane.number + 1) if last_khane else 1

        khane = Khane(kooche_id=kooche_id, line=line, owner_name=owner, number=new_number)
        db.session.add(khane)
        db.session.commit()
        flash('خانه با موفقیت اضافه شد.', 'success')
        return redirect(url_for('khaneha'))

    koocheha = Kooche.query.all()
    if kooche_id_filter:
        khaneha = Khane.query.filter_by(kooche_id=kooche_id_filter).all()
        filtered_kooche = Kooche.query.get(kooche_id_filter)
    else:
        khaneha = Khane.query.all()
        filtered_kooche = None
    
    return render_template('khaneha.html', 
                          koocheha=koocheha, 
                          khaneha=khaneha, 
                          kooche_id_filter=kooche_id_filter,
                          filtered_kooche=filtered_kooche)

@app.route('/khane/delete/<int:id>')
def delete_khane(id):
    khane = Khane.query.get_or_404(id)
    db.session.delete(khane)
    db.session.commit()
    flash('خانه حذف شد.', 'info')
    return redirect(url_for('khaneha'))

@app.route('/saknin', methods=['GET'])
def saknin():
    search = request.args.get('search', '').strip()
    if search:
        saknin_list = Saknin.query.join(Khane).join(Kooche).filter(
            (Saknin.name.contains(search)) |
            (Saknin.family.contains(search)) |
            (Kooche.name.contains(search))
        ).all()
    else:
        saknin_list = Saknin.query.all()
    return render_template('saknin.html', saknin=saknin_list, search=search)

@app.route('/saknin/add', methods=['POST'])
def add_saknin():
    data = request.get_json()
    khane_id = data.get('khane_id')
    name = data.get('name')
    family = data.get('family')
    father_name = data.get('father_name')
    birth_date = data.get('birth_date')
    mobile = data.get('mobile')
    education = data.get('education')
    tashkil = data.get('tashkil')
    last_meeting = data.get('last_meeting')

    if not all([khane_id, name, family]):
        return {'error': 'نام و نام خانوادگی و خانه الزامی است.'}, 400

    khane = Khane.query.get(khane_id)
    auto_address = f"خانه {khane.number} لاین {khane.line} {khane.kooche.name}" if khane else ""

    saknin = Saknin(
        khane_id=khane_id,
        name=name,
        family=family,
        father_name=father_name,
        birth_date=birth_date,
        mobile=mobile,
        education=education,
        tashkil=tashkil,
        address=auto_address,
        last_meeting=last_meeting,
        notes=None
    )
    db.session.add(saknin)
    db.session.commit()
    return {'success': True}

@app.route('/saknin/edit/<int:id>', methods=['GET', 'POST'])
def edit_saknin(id):
    saknin = Saknin.query.get_or_404(id)
    if request.method == 'POST':
        saknin.name = request.form['name']
        saknin.family = request.form['family']
        saknin.father_name = request.form.get('father_name') or None
        saknin.birth_date = request.form.get('birth_date') or None
        saknin.mobile = request.form.get('mobile') or None
        saknin.education = request.form.get('education') or None
        saknin.tashkil = request.form.get('tashkil') or None
        saknin.notes = request.form.get('notes') or None
        db.session.commit()
        flash('اطلاعات ساکن به‌روزرسانی شد.', 'success')
        return redirect(url_for('saknin'))
    
    return render_template('edit_saknin.html', saknin=saknin)

@app.route('/saknin/delete/<int:id>')
def delete_saknin(id):
    saknin = Saknin.query.get_or_404(id)
    db.session.delete(saknin)
    db.session.commit()
    flash('ساکن حذف شد.', 'info')
    return redirect(url_for('saknin'))

@app.route('/molaqat', methods=['GET', 'POST'])
def molaqat():
    today_shamsi = jdatetime.date.today().strftime("%Y/%m/%d")
    selected_date = request.args.get('date', today_shamsi)

    if request.method == 'POST':
        saknin_id = request.form.get('saknin_id')
        notes = request.form.get('notes', '')
        saknin = Saknin.query.get(saknin_id)
        if saknin:
            saknin.last_meeting = today_shamsi
            saknin.notes = notes
            db.session.commit()
            flash('ملاقات ثبت شد.', 'success')
        return redirect(url_for('molaqat'))

    search = request.args.get('search', '').strip()
    if search:
        saknin_list = Saknin.query.join(Khane).join(Kooche).filter(
            (Saknin.name.contains(search)) |
            (Saknin.family.contains(search)) |
            (Kooche.name.contains(search))
        ).all()
    else:
        saknin_list = Saknin.query.all()

    meetings_on_date = Saknin.query.filter_by(last_meeting=selected_date).all()

    thirty_days_ago = (jdatetime.date.today() - timedelta(days=30)).strftime("%Y/%m/%d")
    candidates = Saknin.query.filter(
        (Saknin.last_meeting == None) | (Saknin.last_meeting < thirty_days_ago)
    ).all()
    suggested = random.sample(candidates, min(3, len(candidates))) if candidates else []

    return render_template('molaqat.html',
                          saknin=saknin_list,
                          search=search,
                          meetings_on_date=meetings_on_date,
                          selected_date=selected_date,
                          suggested=suggested,
                          today=today_shamsi)

@app.route('/report')
def report():
    total_koocheha = Kooche.query.count()
    total_khaneha = Khane.query.count()
    total_saknin = Saknin.query.count()

    kooche_khaneha = []
    for k in Kooche.query.all():
        count = Khane.query.filter_by(kooche_id=k.id).count()
        kooche_khaneha.append((k.name, count))

    kooche_saknin = []
    for k in Kooche.query.all():
        count = db.session.query(Saknin).join(Khane).filter(Khane.kooche_id == k.id).count()
        kooche_saknin.append((k.name, count))

    educations = [s.education for s in Saknin.query.all() if s.education]
    education_counts = Counter(educations).most_common()

    tashkils = [s.tashkil for s in Saknin.query.all() if s.tashkil]
    tashkil_counts = Counter(tashkils).most_common()

    karmandan_tashkil = [k.tashkil_duration for k in Karmand.query.all() if k.tashkil_duration]
    karmandan_tashkil_counts = Counter(karmandan_tashkil).most_common()

    return render_template('report.html',
                          total_koocheha=total_koocheha,
                          total_khaneha=total_khaneha,
                          total_saknin=total_saknin,
                          kooche_khaneha=kooche_khaneha,
                          kooche_saknin=kooche_saknin,
                          education_counts=education_counts,
                          tashkil_counts=tashkil_counts,
                          karmandan_tashkil_counts=karmandan_tashkil_counts)

# ---------- Jamaat Routes ----------
@app.route('/jamaat', methods=['GET', 'POST'])
def jamaat():
    if request.method == 'POST':
        start_date = request.form.get('start_date')
        duration = request.form.get('duration', type=int)
        if start_date and duration:
            new_jamaat = Jamaat(start_date=start_date, duration_days=duration)
            db.session.add(new_jamaat)
            db.session.commit()
            flash('جماعت جدید رزرو شد.', 'success')
        return redirect(url_for('jamaat'))

    search = request.args.get('search', '').strip()
    if search:
        jamaat_list = Jamaat.query.filter(
            Jamaat.start_date.contains(search)
        ).order_by(Jamaat.created_at.desc()).all()
    else:
        jamaat_list = Jamaat.query.order_by(Jamaat.created_at.desc()).all()

    last_confirmed = Jamaat.query.filter_by(status='confirmed').order_by(Jamaat.start_date.desc()).first()

    saknin_list = Saknin.query.all()
    return render_template('jamaat.html',
                          jamaat_list=jamaat_list,
                          saknin_list=saknin_list,
                          last_confirmed=last_confirmed,
                          search=search)

@app.route('/jamaat/add_member', methods=['POST'])
def add_jamaat_member():
    jamaat_id = request.form.get('jamaat_id')
    saknin_id = request.form.get('saknin_id')
    if jamaat_id and saknin_id:
        existing = JamaatMember.query.filter_by(jamaat_id=jamaat_id, saknin_id=saknin_id).first()
        if not existing:
            member = JamaatMember(jamaat_id=jamaat_id, saknin_id=saknin_id)
            db.session.add(member)
            db.session.commit()
    return redirect(url_for('jamaat'))

@app.route('/jamaat/cancel_member/<int:member_id>')
def cancel_jamaat_member(member_id):
    member = JamaatMember.query.get_or_404(member_id)
    member.status = 'cancelled'
    db.session.commit()
    return redirect(url_for('jamaat'))

@app.route('/jamaat/confirm/<int:jamaat_id>')
def confirm_jamaat(jamaat_id):
    jamaat = Jamaat.query.get_or_404(jamaat_id)
    jamaat.status = 'confirmed'
    db.session.commit()
    for member in jamaat.members:
        if member.status == 'joined':
            saknin = member.saknin
            saknin.tashkil = f"جماعت: {jamaat.start_date} - {jamaat.duration_days} روز"
            db.session.add(saknin)
    db.session.commit()
    flash('جماعت تأیید و قطعی شد.', 'success')
    return redirect(url_for('jamaat'))

@app.route('/jamaat/edit/<int:jamaat_id>', methods=['GET', 'POST'])
def edit_jamaat(jamaat_id):
    jamaat = Jamaat.query.get_or_404(jamaat_id)
    if request.method == 'POST':
        jamaat.start_date = request.form.get('start_date')
        jamaat.duration_days = request.form.get('duration', type=int)
        db.session.commit()
        flash('جماعت ویرایش شد.', 'success')
        return redirect(url_for('jamaat'))
    return render_template('edit_jamaat.html', jamaat=jamaat)

@app.route('/jamaat/delete/<int:jamaat_id>')
def delete_jamaat(jamaat_id):
    jamaat = Jamaat.query.get_or_404(jamaat_id)
    db.session.delete(jamaat)
    db.session.commit()
    flash('جماعت لغو شد.', 'info')
    return redirect(url_for('jamaat'))

@app.route('/api/saknin/search')
def search_saknin_api():
    q = request.args.get('q', '').strip()
    if q:
        results = Saknin.query.join(Khane).join(Kooche).filter(
            (Saknin.name.contains(q)) |
            (Saknin.family.contains(q)) |
            (Kooche.name.contains(q))
        ).limit(20).all()
    else:
        results = []
    return {
        'results': [
            {'id': s.id, 'text': f"{s.name} {s.family} — {s.address}"}
            for s in results
        ]
    }

# ---------- Karmandan Routes ----------
@app.route('/karmandan', methods=['GET', 'POST'])
def karmandan():
    if request.method == 'POST':
        name = request.form.get('name')
        family = request.form.get('family')
        tashkil = request.form.get('tashkil_duration')
        mobile = request.form.get('mobile')
        status = request.form.get('status', 'فعال')
        if name and family:
            karmand = Karmand(
                name=name,
                family=family,
                tashkil_duration=tashkil,
                mobile=mobile,
                status=status
            )
            db.session.add(karmand)
            db.session.commit()
            flash('کارمند جدید اضافه شد.', 'success')
        return redirect(url_for('karmandan'))
    
    karmandan_list = Karmand.query.all()
    return render_template('karmandan.html', karmandan=karmandan_list)

@app.route('/karmandan/edit/<int:id>', methods=['GET', 'POST'])
def edit_karmand(id):
    karmand = Karmand.query.get_or_404(id)
    if request.method == 'POST':
        karmand.name = request.form.get('name')
        karmand.family = request.form.get('family')
        karmand.tashkil_duration = request.form.get('tashkil_duration')
        karmand.mobile = request.form.get('mobile')
        karmand.status = request.form.get('status', 'فعال')
        db.session.commit()
        flash('اطلاعات کارمند به‌روزرسانی شد.', 'success')
        return redirect(url_for('karmandan'))
    return render_template('edit_karmand.html', karmand=karmand)

@app.route('/karmandan/delete/<int:id>')
def delete_karmand(id):
    karmand = Karmand.query.get_or_404(id)
    db.session.delete(karmand)
    db.session.commit()
    flash('کارمند حذف شد.', 'info')
    return redirect(url_for('karmandan'))

# ---------- Taqaza Routes ----------
@app.route('/taqaza', methods=['GET', 'POST'])
def taqaza():
    today = jdatetime.date.today()
    weekday = today.weekday()  # شنبه = 0
    week_start = (today - timedelta(days=weekday)).strftime("%Y/%m/%d")

    if request.method == 'POST':
        title = request.form.get('title')
        desc = request.form.get('description')
        if title:
            count = Taqaza.query.filter_by(week_start=week_start).count()
            if count < 10:
                new_taqaza = Taqaza(title=title, description=desc, week_start=week_start)
                db.session.add(new_taqaza)
                db.session.commit()
                flash('تقاضا با موفقیت ثبت شد.', 'success')
            else:
                flash('حداکثر تعداد تقاضا (10 مورد) برای این هفته تکمیل شده است.', 'danger')
        return redirect(url_for('taqaza'))

    current_taqazat = Taqaza.query.filter_by(week_start=week_start).order_by(Taqaza.created_at.desc()).all()
    old_taqazat = Taqaza.query.filter(Taqaza.week_start != week_start).order_by(Taqaza.week_start.desc(), Taqaza.created_at.desc()).all()

    return render_template('taqaza.html',
                          current_taqazat=current_taqazat,
                          old_taqazat=old_taqazat,
                          week_start=week_start)

def start_server(database_path):
    import threading
    os.environ['MAHALE_DB_PATH'] = database_path
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + database_path
    def run():
        app.run(host='127.0.0.1', port=5004, debug=False, use_reloader=False, threaded=True)
    threading.Thread(target=run, daemon=True).start()

if __name__ == '__main__':
    app.run(debug=False, host='127.0.0.1', port=5004, use_reloader=False)