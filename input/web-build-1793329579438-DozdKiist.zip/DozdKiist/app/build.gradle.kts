
### راه‌حل

فایل زیر را باز کن:

`DozdKiist/app/build.gradle.kts`

**تمام محتوای قبلی را پاک کن و فقط کد زیر را کپی کن.**

دقت کن هیچ علامت سه‌تایی بک‌تیک را کپی نکنی.

```kotlin
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.khavaran.dozdkiist"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.khavaran.dozdkiist"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}